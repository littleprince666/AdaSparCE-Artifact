"""Restore pinned fetch-only inputs; reject any byte mismatch before writing tasks."""
from __future__ import annotations

import argparse
import base64
import concurrent.futures
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import urllib.request

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))


def read(path):
    return json.loads(Path(path).read_text())


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def inside(relative):
    p = ROOT / relative
    if not p.resolve().is_relative_to(ROOT) or Path(relative).is_absolute():
        raise ValueError("Input path escapes the package")
    return p


def replay(group, plan):
    import z3

    def no_check(*args, **kwargs):
        raise RuntimeError("Restoration must not call a solver check")

    z3.Solver.check = no_check
    chosen = {p: d for p, d in plan["derivatives"].items() if d["group"] == group}
    result = {}
    if group == "chc":
        from tools.experiments.new_family_materialize import _replay_sources
        base = ROOT / "datasets/ICST2027-FamilyHoldout-20261018"
        tasks = [(str(inside(p).relative_to(base)), d["task"], d["task"]["original_horn_source"])
                 for p, d in chosen.items()]
        for p, raw in _replay_sources(base, tasks).items():
            if Path(p).name in ("normalized.c", "task.c_smt"):
                result[(base / p).relative_to(ROOT).as_posix()] = raw
    elif group == "c32":
        from tools.experiments.ultimate_c32 import ScalarC32
        base = ROOT / "datasets/ICST2027-UltimateNLA-20261019/upstream/ultimate/trunk/examples/programs/nonlinearArithmetic"
        wanted = {d["task"]["source_path"]: p for p, d in chosen.items()}
        for row in read(ROOT / "inputs/c32-source-order.json"):
            if row["path"].startswith("memsafety/"):
                continue
            try:
                problem = ScalarC32((base / row["path"]).read_text())
                if row["path"] in wanted:
                    p = wanted[row["path"]]
                    result[p + "/normalized.c"] = problem.carrier().encode()
                    result[p + "/task.c_smt"] = problem.smt().encode()
            except Exception:
                if row["path"] in wanted:
                    raise
    elif group == "eldarica":
        from tools.experiments.chc_source_transport_v3 import TransportUnsupported
        from tools.experiments.chc_source_transport_v4 import transport
        from tools.experiments.eldarica_nla_audit import horn_fingerprints, nonlinear_locations
        from tools.experiments.new_family_chc import OnePredicateCHC, Unsupported
        base = ROOT / "datasets/ICST2027-EldaricaNLA-20261019/upstream/eldarica"
        wanted = {d["task"]["original_horn_repository_path"]: p for p, d in chosen.items()}
        split = "SPLIT_HERE_asdfghjklzxcvbnmqwertyuiop"
        # Reproduce the entire original sorted conversion pass in a fresh
        # process. Z3's equivalent branch print order depends on AST history.
        for row in read(ROOT / "inputs/eldarica-source-order.json"):
            original = base / row["path"]
            text = original.read_text()
            horn_fingerprints(text)
            try:
                transported = transport(text)
            except (TransportUnsupported, ValueError, z3.Z3Exception):
                continue
            horn_fingerprints(transported.source)
            try:
                problem = OnePredicateCHC(transported.source)
                carrier, vc = problem.carrier_c(), problem.smt()
                pieces = vc.split(split)
                if len(pieces) != 5:
                    raise ValueError("requires-three-original-VC-sections")
                for index in (2, 3, 4):
                    z3.parse_smt2_string(pieces[0] + "true" + pieces[1] + pieces[index])
                nonlinear_locations(problem)
                problem.signature()
                problem.signature(True)
                relative = original.relative_to(ROOT).as_posix()
                if relative in wanted:
                    p = wanted[relative]
                    result[p + "/normalized.c"] = carrier.encode()
                    result[p + "/task.c_smt"] = vc.encode()
            except (Unsupported, ValueError, z3.Z3Exception):
                if original.relative_to(ROOT).as_posix() in wanted:
                    raise
    for p, d in chosen.items():
        for name, expected in d["expected"].items():
            relative = p + "/" + name
            if relative not in result or sha(result[relative]) != expected:
                raise ValueError("Rebuilt input differs from the evaluated bytes: " + relative)
    if len(result) != 2 * len(chosen):
        raise ValueError("Incomplete input reconstruction")
    return result


def retrieve(relative, record, cache):
    target = inside(relative)
    if target.exists():
        if sha(target.read_bytes()) != record["sha256"]:
            raise ValueError("Existing upstream bytes differ: " + relative)
        return
    if cache:
        raw = (cache / relative).read_bytes()
    else:
        errors = []
        raw = None
        urls = [record["url"]]
        prefix = "https://raw.githubusercontent.com/"
        if record["url"].startswith(prefix):
            owner, repo, commit, path = record["url"][len(prefix):].split("/", 3)
            urls.append(f"https://cdn.jsdelivr.net/gh/{owner}/{repo}@{commit}/{path}")
        for url in urls:
            try:
                request = urllib.request.Request(url, headers={"User-Agent": "anonymous-replication-input-fetch"})
                with urllib.request.urlopen(request, timeout=30) as stream:
                    candidate = stream.read(16 * 1024 * 1024 + 1)
                if sha(candidate) != record["sha256"]:
                    raise ValueError("Pinned source checksum mismatch")
                raw = candidate
                break
            except Exception as error:
                errors.append(type(error).__name__)
        if raw is None:
            raise RuntimeError("Could not fetch pinned source: " + relative + "; " + ",".join(errors))
    if sha(raw) != record["sha256"]:
        raise ValueError("Pinned source checksum mismatch: " + relative)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("xb") as stream:
        stream.write(raw)


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("--group", choices=("all", "chc", "c32", "eldarica"), default="all")
    parser.add_argument("--source-cache", type=Path, help="Optional offline cache with the same relative source paths")
    parser.add_argument("--_replay", choices=("chc", "c32", "eldarica"), help=argparse.SUPPRESS)
    args = parser.parse_args()
    plan = read(ROOT / "inputs/fetch-plan.json")
    if args._replay:
        values = replay(args._replay, plan)
        print(json.dumps({p: base64.b64encode(raw).decode() for p, raw in values.items()}))
        return
    groups = ["chc", "c32", "eldarica"] if args.group == "all" else [args.group]
    prefixes = dict(chc="datasets/ICST2027-FamilyHoldout-", c32="datasets/ICST2027-UltimateNLA-", eldarica="datasets/ICST2027-EldaricaNLA-")
    for group in groups:
        sources = [(p, r) for p, r in plan["sources"].items() if p.startswith(prefixes[group])]
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            list(pool.map(lambda item: retrieve(*item, args.source_cache), sources))
        process = subprocess.run([sys.executable, "-B", str(Path(__file__).resolve()), "--_replay", group],
            capture_output=True, text=True, timeout=180, cwd=ROOT)
        if process.returncode:
            raise RuntimeError("Isolated input reconstruction failed:\n" + process.stderr)
        contents = {p: base64.b64decode(raw, validate=True) for p, raw in json.loads(process.stdout).items()}
        # Validate every reconstructed input before creating any missing task.
        for p, raw in contents.items():
            target = inside(p)
            expected = plan["derivatives"][str(Path(p).parent)]["expected"][Path(p).name]
            if sha(raw) != expected or target.exists() and target.read_bytes() != raw:
                raise ValueError("Reconstruction or existing input checksum mismatch: " + p)
        for p, raw in contents.items():
            target = inside(p)
            if not target.exists():
                target.parent.mkdir(parents=True, exist_ok=True)
                with target.open("xb") as stream:
                    stream.write(raw)
        print(group, "restored", len(contents), "exact derived files; no solver checks", flush=True)


if __name__ == "__main__":
    main()
