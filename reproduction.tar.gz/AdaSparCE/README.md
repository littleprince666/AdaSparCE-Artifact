# Anonymous replication materials

This package supplies the software, fixed experimental inputs, parameters and
instructions needed to rerun the studies reported in the paper. It contains no
historical result rows, search logs, solver traces or stored proof outcomes.
Running the commands below produces new local results.

The ICST research-track policy asks for the information needed to replicate
results and an anonymized package with necessary software, data and instructions:
https://conf.researchr.org/track/icst-2027/icst-2027-research-papers#Replication-Material
The file selection here implements that scope; the conference does not prescribe
a file-by-file minimum, a public Git repository, or an open-source license.

## Installation and integrity

The evaluated environment is Linux, Python **3.14.4**, a system GCC/CPP, and the
versions in `requirements.txt`. The reported machine was an Intel Xeon Gold 6136
(3.0 GHz). Execution time and timeout outcomes can vary with hardware and system
load. Search, independent checking and statistics must run as separate stages.

```bash
python3 verify.py
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
python reproduce.py list
```

`verify.py` uses only the Python standard library. It checks release checksums,
source syntax, the complete planned task/variant/seed identities and fixed pool
contents. It neither solves tasks nor verifies the paper's historical numbers.

## Smoke execution

Use a new output directory. Smoke outputs are labeled and are not full-study
results. This runs one original task and seed with the unchanged study budget.

```bash
python reproduce.py prepare --study ablation-nl50 --output /tmp/ada-smoke --smoke
python reproduce.py run --output /tmp/ada-smoke
python reproduce.py reverify --output /tmp/ada-smoke
python reproduce.py report --output /tmp/ada-smoke
```

For another smoke task, add `--tasks ID`, `--variants VARIANT`, and/or `--seeds 0`
to `prepare --smoke`. These subset options are rejected for a formal preparation.

## Complete native studies

Run each study sequentially using the four stages below. Do not overlap timing
studies with solver tests or independent rechecks. Full preparations use every
specified task, seeds 0--4, eight workers and the original shuffled job order.

```bash
python reproduce.py prepare --study ablation-nl50 --output /tmp/ada-ablation
python reproduce.py run --output /tmp/ada-ablation
python reproduce.py reverify --output /tmp/ada-ablation
python reproduce.py report --output /tmp/ada-ablation
```

Repeat with `--study main-lin316`, `semantic-interfaces`, or `budget-nl50-600s`
and separate output directories. The first three use 30 seconds of native
search; the budget study uses 600 seconds. Native search time excludes process
startup and independent rechecking. Original source files and configurations
remain separate for each batch; unpublished neural/graph implementations are
omitted because every reported variant disables them.

`confirmed-results.csv` and `confirmed-summary.json` are generated locally.
A confirmation requires a budget-qualified returned formula plus independent
INIT, STEP and EXIT UNSAT results, with 60 seconds per obligation. SAT, UNKNOWN,
timeouts, errors and unsupported tasks remain in the denominator. Unconfirmed
runs cost twice the task budget in confirmed PAR-2. The CSV supplies paired task
identities, native candidate-check counts and checker costs. Pair costs on
commonly confirmed task-seed identities, not on two independently selected
solved subsets. First-1/5/10/30-second coverage is calculated from actual native
search time in its own batch; it does not replace a shorter-budget experiment.

## Fixed-pool controls

Use the same four stages with `--study shared-pool` or `joint-pool`. The fixed Q0
files in `shared-inputs/` are experimental inputs collected before the controlled
replays. Their original generation charges, formula order, scores, formula ASTs
and author transport are preserved. They contain no formal replay outcomes.
The shared-pool study has four arms; the joint control has three. All arms are
rerun with the same original generation cost charged to their 30-second budget.
They are composition controls, not complete online Clause2Inv measurements.

## Cold external comparisons

Install the fixed external dependencies before preparing a timing study:

```bash
python -m tools.experiments.install_external_baselines fetch --methods dig
python -m tools.experiments.install_external_baselines install --methods cvc5,dig
```

The pins are cvc5 1.3.4 and DIG commit
`8ef9d04f982e7f46d7d4cf0f705d8311573c0b47`, with DIG's separate Z3 4.16.0.0.
Only the evaluated author code is used, without cached candidate or answer
files. See `THIRD_PARTY.md` and the installer's fixed dependency lists.

Use the four stages with `--study cold-nl50` or `cold-lin316`. NL50 uses one
worker and Ada/cvc5/DIG; LIN316 uses eight workers and Ada/cvc5. Each task has a
strict 30-second cold-process deadline, including imports, conversion,
compilation/generation and acceptance. Rechecking is separate. These timings
must be compared within their own cold batch, not mixed with native timings.
No paid API requests or unexecuted online-LLM arms are part of this package's
reproduction procedure.

## Fetch-only input-support studies

Main NL50/LIN316 C/VC inputs are included. Additional input-support cohorts retain
their pinned source URLs, hashes, manifests, converters and semantic profiles;
their upstream and derived program texts are restored locally, not redistributed.

```bash
python restore_inputs.py --group all
```

The restoration visits the original whole conversion passes where required by
Z3's AST print-order history, and accepts generated C/VC files only when their
SHA-256 values match the evaluated inputs. No solver check, safety-result lookup,
new task selection or inference method runs during restoration. A matching
offline source cache can be supplied using `--source-cache /path/to/cache`.

Then use the four stages with any of these study identifiers:

| Study | Fixed scope |
| --- | --- |
| `input-support-before-primary` | Two original CHC support inputs, original frontend |
| `input-support-before-regression` | Three original CHC regression inputs |
| `input-support-repaired-primary` | Same two already exposed inputs, repaired frontend |
| `input-support-repaired-regression` | Same three exposed regression inputs, repaired frontend |
| `input-support-c32` | Three exact C32 assertion-safety regressions |
| `input-support-native-nla` | One known nonlinear Horn regression |

These are input-support/regression checks, not unseen-family performance.
Mathematical Int and C32 defined-execution semantics remain separate. Family
labels and full task denominators come from the fixed manifests, not new method
outcomes. The independent rechecker uses the same Z3 implementation, not a
second prover; it does not independently establish the original C-to-VC encoding.

Formal `prepare` also freezes task clusters before inference. Formal `report`
produces `paired-statistics.json` with task-, equal-VC- and equal-cluster summaries
and 10,000 paired cluster bootstrap resamples. Seeds are averaged within tasks,
not treated as independent programs. Semantic-interface reports additionally
produce the original factorial contrasts. The original statistical algorithms
are in `tools/experiments/supplemental_statistics.py` and
`helpers/interface_statistics.py`. Input-support studies additionally supply
their original cluster definitions. Smoke reports skip full-dataset statistics.

## Layout

- `studies/`: complete pre-run tasks, seeds, variants, configurations and jobs.
- `source-files/`: deduplicated frozen source files, materialized by `prepare`.
- `datasets/`, `inputs/`, `shared-inputs/`: included inputs and fetch-only recipes.
- `helpers/`, `tools/`: original acceptance/replay adapters, independent checking,
  dependency installation, input converters and statistics.
- `manifest.json`: anonymous inventory with release checksums and scope.

No Git repository, internal development reports, manuscript sources, historical
experimental result files or installed environments are required to use this
package. Existing output directories are preserved; use a fresh directory for
a new study or smoke run.
