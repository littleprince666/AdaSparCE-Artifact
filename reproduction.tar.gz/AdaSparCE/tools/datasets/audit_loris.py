import argparse
import hashlib
import json
import re
import subprocess
TOKEN = re.compile('//[^\\n]*|/\\*[\\s\\S]*?\\*/|"(?:\\\\.|[^"\\\\])*"|\\\'(?:\\\\.|[^\\\'\\\\])*\\\'|[A-Za-z_]\\w*|0[xX][0-9a-fA-F]+[uUlL]*|\\d+(?:\\.\\d*)?(?:[eE][+-]?\\d+)?[uUlLfF]*|<<=|>>=|==|!=|<=|>=|&&|\\|\\||\\+\\+|--|->|<<|>>|[+*/%&|^-]=|[^\\s]')
KEYWORDS = set('auto break case char const continue default do double else enum extern float for goto if inline int long register restrict return short signed sizeof static struct switch typedef union unsigned void volatile while _Bool'.split())
API = {'__VERIFIER_assert': 'assert', '__VERIFIER_assume': 'assume', 'assume_abort_if_not': 'assume'}
def digest(tokens):
    return hashlib.sha256(json.dumps(tokens, separators=(",", ":")).encode()).hexdigest()


def fingerprints(source):
    tokens = [t for t in TOKEN.findall(source) if not t.startswith(("//", "/*"))]
    names = {}
    alpha, shape = [], []
    for i, token in enumerate(tokens):
        if re.fullmatch(r"[A-Za-z_]\w*", token):
            if token in KEYWORDS or (i + 1 < len(tokens) and tokens[i + 1] == "("):
                value = API.get(token, token)
            else:
                value = names.setdefault(token, "var" + str(len(names)))
        else:
            value = token
        alpha.append(value)
        shape.append("NUMBER" if token[0].isdigit() else value)
    return {"tokens": digest(tokens), "alpha": digest(alpha), "constant_shape": digest(shape)}

