import argparse
import concurrent.futures
import hashlib
import json
import math
import os
from pathlib import Path
import random
import signal
import statistics
import subprocess
import sys
import time
ROOT = Path(__file__).resolve().parents[2]
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')


def sources(output):
    return {str(p.relative_to(output)): sha(p)
            for p in sorted((output / 'sources').rglob('*'))
            if p.is_file() and (p.suffix == '.py' or p.name == 'run-config.json')}


def audit(output):
    f = json.loads((output / 'freeze.json').read_text())
    assert sources(output) == f['source_hashes'], 'source changed'
    assert sha(__file__) == f['runner_sha256'], 'runner changed'
    assert sys.version == f['python'] and __import__('z3').get_version_string() == f['z3']
    for p, h in f['inputs'].items():
        assert sha(p) == h, 'input changed: ' + p
    return f


def solved(row, budget=30):
    elapsed = row.get('total_time')
    return (row['status'] == 'solved' and isinstance(elapsed, (int, float))
            and math.isfinite(elapsed) and 0 <= elapsed <= budget)


def run(output, workers):
    import fcntl
    with (output / 'run.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        f = audit(output)
        fingerprint = sha(output / 'freeze.json')
        result_path = output / 'results.jsonl'
        rows = [json.loads(s) for s in result_path.read_text().splitlines()] if result_path.exists() else []
        keys = {(j['variant'], j['seed'], j['id']) for j in f['jobs']}
        completed = set()
        for r in rows:
            key = (r['variant'], r['seed'], r['id'])
            assert key in keys and key not in completed and r['freeze_sha256'] == fingerprint
            assert sha(output / r['trace']) == r['trace_sha256']
            assert sha(output / r['stdout']) == r['stdout_sha256']
            completed.add(key)
        runtime = output / 'runtime.json'
        if runtime.exists():
            assert json.loads(runtime.read_text())['workers'] == workers
        else:
            write(runtime, dict(workers=workers, cpu_affinity=sorted(os.sched_getaffinity(0)),
                started=time.time(), tests_concurrent=False, python=sys.version))
        def one(j):
            trace = Path(j['command'][j['command'].index('--log-jsonl') + 1])
            trace.parent.mkdir(parents=True, exist_ok=True)
            if trace.exists():
                trace.rename(trace.with_suffix('.interrupted.' + str(time.time_ns())))
            log = trace.with_suffix('.stdout')
            started = time.perf_counter()
            env = dict(os.environ, **f['environment'], PYTHONDONTWRITEBYTECODE='1')
            with log.open('w') as stream:
                process = subprocess.Popen(j['command'], cwd=output / 'sources' / j['variant'],
                    env=env, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
                try:
                    process.wait(timeout=53)
                    status = None
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
                    status = 'hard-timeout'
            result = None
            if status is None and process.returncode == 0:
                for line in reversed(log.read_text().splitlines()):
                    try:
                        value = json.loads(line)
                        if isinstance(value, dict) and 'status' in value:
                            result = value
                            break
                    except json.JSONDecodeError:
                        pass
            if result is None:
                result = dict(status=status or 'error', reason='returncode-' + str(process.returncode))
            if not trace.exists():
                trace.write_text(json.dumps(dict(event='runner_missing_trace', **result)) + '\n')
            result.update({k: j[k] for k in ('variant', 'seed', 'id')})
            result.update(wall_time=time.perf_counter() - started, trace=str(trace.relative_to(output)),
                trace_sha256=sha(trace), stdout=str(log.relative_to(output)), stdout_sha256=sha(log),
                freeze_sha256=fingerprint)
            return result
        pending = [j for j in f['jobs'] if (j['variant'], j['seed'], j['id']) not in completed]
        print('Running', len(pending), '/', len(f['jobs']), flush=True)
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
            futures = [pool.submit(one, j) for j in pending]
            for future in concurrent.futures.as_completed(futures):
                row = future.result()
                with result_path.open('a') as stream:
                    stream.write(json.dumps(row, ensure_ascii=False) + '\n')
                rows.append(row)
                if len(rows) % 10 == 0:
                    print(len(rows), '/', len(f['jobs']), row['variant'], row['id'], row['status'], flush=True)
        audit(output)
        write(output / 'completion.json', dict(rows=len(rows), expected=len(f['jobs']),
            complete=len(rows) == len(f['jobs']), results_sha256=sha(result_path), freeze_sha256=fingerprint))

