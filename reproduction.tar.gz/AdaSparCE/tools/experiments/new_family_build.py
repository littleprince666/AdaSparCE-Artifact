"""Build the source/family-reviewed CHC holdout without running any solver.

The primary two-family slice is deliberately small. Uncertain histories are
kept in a separate regression collection, never promoted to unseen families.
Raw and derived upstream sources are local fetch-only research inputs.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import json
from pathlib import Path
import re

from tools.datasets.audit_loris import fingerprints
from tools.experiments.new_family_audit import DEFAULT_OUT, ROOT, dump, sha
from tools.experiments.new_family_chc import OnePredicateCHC, Unsupported
from tools.experiments.new_family_fetch import PIN


# Mechanism review, fixed before the first inference on these sources. A family
# ID groups all variants even when their coordinate signatures differ.
REVIEW = {
    'bouncy_three_counters_merged_000': ('bouncy-balanced-counters','primary',
        'Three independently chosen counter updates and signed balance; safety relates coincident counters to balance. No matching source name or mechanism label found in the frozen exposure inventory.'),
    'bouncy_two_counters_merged_000': ('bouncy-balanced-counters','primary','Two-counter variant of the same update/balance mechanism.'),
    'three_dots_moving_2_000': ('moving-dots-coalescence','primary',
        'Three moving positions, an equality-sensitive direction change and a decreasing potential bound. No matching source name or mechanism label found in the frozen exposure inventory.'),
    'dillig32_000': ('alternating-toggle-counters','regression',
        'Alternating Boolean-valued integer toggle increments paired counters; possible classic Dillig/Code2Inv ancestry cannot be ruled out.'),
    's_mutants_20_000': ('alternating-toggle-counters','regression','Same toggle mechanism as dillig32, with a different initialization and safety assertion.'),
    's_disj_ite_05_000': ('threshold-two-phase-accumulator','regression',
        'Piecewise affine accumulator changes at a fixed threshold; known phase examples in development metadata prevent an unseen-family claim.'),
    's_disj_ite_06_000': ('threshold-two-phase-accumulator','regression','Same two-phase transition as s_disj_ite_05, changed safety assertion.'),
    's_mutants_21_000': ('coupled-random-walk-accumulator','regression',
        'Nondeterministic paired increments followed by accumulation; historical generic counter ancestry is uncertain.'),
    's_mutants_22_000': ('coupled-random-walk-accumulator','regression','Same-sign paired walk with parity-sensitive accumulator safety; conservatively grouped with 21/23.'),
    's_mutants_23_000': ('coupled-random-walk-accumulator','regression','Opposite-sign paired walk and accumulator, changed initial/safety conditions.'),
    's_mutants_02_000': ('iterated-summation','excluded',
        'Successive prefix-sum recurrence is already covered by development nonlinear summation families, including NL1/NL29.'),
    's_mutants_05_000': ('affine-counter-rates','excluded',
        'Two counters with constant update rates; classic affine-rate development family, no defensible new-family claim.'),
    's_mutants_16_000': ('bounded-affine-frame','excluded',
        'Synchronized unit increments with a fixed parameter offset and interval safety; known affine counter mechanism.'),
    's_mutants_17_000': ('bounded-affine-frame','excluded','Erased-constant shape matches s_mutants_16; changed loop/safety constants do not make a new family.'),
    'yz_plus_minus_1_000': ('coupled-arithmetic-recurrence','excluded',
        'Opposite-rate counters feed a prefix-sum recurrence; existing polynomial-recurrence families prevent certification by source-name novelty alone.'),
    'yz_plus_minus_2_000': ('coupled-arithmetic-recurrence','excluded','Same coupled plus/minus recurrence mechanism, with an additional affine counter.'),
}


def build(output):
    output=Path(output).resolve()
    if (output/'FROZEN.json').exists():
        raise ValueError('Already frozen; use check, never overwrite the evaluated set')
    exposure=json.loads((output/'exposure-audit.json').read_text())
    downloads=json.loads((output/'source-downloads.json').read_text())
    if not downloads['complete'] or len(downloads['sources'])!=55 or downloads['commit']!=PIN:
        raise ValueError('Incomplete or foreign pinned source universe')
    known_hashes=set(exposure['distinct_inputs']) | set(exposure['historical_sources'].values())
    known_fingerprints={}
    for item in exposure['distinct_inputs'].values():
        for kind,value in item.get('fingerprints',{}).items():
            if isinstance(value,str):
                known_fingerprints.setdefault((kind,value),[]).extend(item['paths'])
    records=[]
    selected={}
    for row in sorted(downloads['sources'],key=lambda x:x['path']):
        source=output/'upstream/chc-comp26'/row['path']
        raw=source.read_bytes()
        if sha(raw)!=row['sha256']:
            raise ValueError('Pinned source changed: '+str(source))
        record=dict(source=row['path'],source_sha256=row['sha256'],official_url=row['official_url'])
        try:
            problem=OnePredicateCHC(raw.decode())
        except (Unsupported, ValueError) as error:
            record.update(decision='unsupported',reason=str(error))
            records.append(record)
            continue
        if source.stem not in REVIEW:
            raise ValueError('Supported source lacks pre-result mechanism review: '+source.stem)
        family,role,reason=REVIEW[source.stem]
        c,vc=problem.carrier_c(),problem.smt()
        matches=[]
        for kind,value in fingerprints(c).items():
            if isinstance(value,str):
                matches.extend(known_fingerprints.get((kind,value),[]))
        byte_match=sha(raw) in known_hashes or sha(vc.encode()) in known_hashes
        record.update(family_id=family,review_role=role,reason=reason,
            state_variables=len(problem.state),auxiliary_variables=len(problem.locals),
            rule_counts=problem.rule_counts,coordinate_signature=problem.signature(),
            erased_constant_signature=problem.signature(True),
            known_byte_match=byte_match,carrier_fingerprint_matches=sorted(set(matches)),
            source_status=(re.search(r'\(set-info\s+:status\s+(\w+)\)',raw.decode()) or [None,'unknown'])[1])
        if byte_match or matches:
            record.update(decision='exposure-match',reason='Frozen exposure fingerprint/hash match; '+reason)
        elif role=='excluded':
            record['decision']='known-or-uncertified-family'
        elif family in selected:
            record.update(decision='same-family-variant',representative=selected[family])
        else:
            selected[family]=source.stem
            record['decision']='primary' if role=='primary' else 'external-regression'
            base=output if role=='primary' else output/'regression'
            identity='chc26-'+source.stem
            taskdir=base/'tasks'/identity
            taskdir.mkdir(parents=True,exist_ok=False)
            (taskdir/'normalized.c').write_text(c)
            (taskdir/'task.c_smt').write_text(vc)
            task=dict(id=identity,relative_path='tasks/'+identity,checker_vc='task.c_smt',
                family_id=family,split='test-locked',source='CHC-COMP26-pinned',
                dataset_version='icst2027-family-holdout-20261018',source_group=record['decision'],
                source_sha256=row['sha256'],source_status=record['source_status'],
                original_horn_source=str(source.relative_to(output)),
                original_horn_sha256=row['sha256'],
                semantics='mathematical Int; exact original Horn INIT/STEP/safety obligations',
                redistribution='fetch-only; NOASSERTION')
            dump(taskdir/'task.json',task)
            record['task']=task
        records.append(record)
    for role,base in [('primary',output),('external-regression',output/'regression')]:
        manifest=[row['task'] for row in records if row['decision']==role]
        if not manifest:raise ValueError('Empty collection: '+role)
        dump(base/'manifest.json',manifest)
    counts=dict(Counter(row['decision'] for row in records))
    audit=dict(schema='adasparce.family-selection-audit.v1',date='2026-10-18',
        records=records,counts=counts,
        review='Manual mechanism grouping plus frozen all-history hash/name/fingerprint screening, before any inference on these inputs.',
        limitations=['Two primary mechanism families provide only exploratory evidence and no nonlinear-family evaluation.',
            'Absent source names and token fingerprints are not proofs of semantic non-equivalence to all historical programs.',
            'Unknown historical bytes cannot be fully compared. Ambiguous classic families are excluded or reported as regression.',
            'Source status is unknown when absent; report proof completion over the entire frozen denominator, not safe-program recall.',
            'Official source is publicly accessible but has no asserted redistribution license; publish fetcher, metadata and hashes only.'])
    dump(output/'family-selection-audit.json',audit)
    files={str(p.relative_to(output)):sha(p.read_bytes()) for p in sorted(output.rglob('*'))
           if p.is_file() and p.name!='FROZEN.json'}
    tools={str(Path(__file__).relative_to(ROOT)):sha(Path(__file__).read_bytes()),
        'tools/experiments/new_family_chc.py':sha((ROOT/'tools/experiments/new_family_chc.py').read_bytes())}
    dump(output/'FROZEN.json',dict(schema='adasparce.source-family-freeze.v1',
        frozen_utc=datetime.now(timezone.utc).isoformat(),files=files,tool_hashes=tools,
        no_inference_before_freeze=True,counts=counts,
        primary_family_count=counts['primary'],regression_family_count=counts['external-regression']))
    print(json.dumps(counts,indent=2))


def check(output):
    output=Path(output).resolve()
    frozen=json.loads((output/'FROZEN.json').read_text())
    for relative,expected in frozen['files'].items():
        if sha((output/relative).read_bytes())!=expected:
            raise ValueError('Frozen family input changed: '+relative)
    for relative,expected in frozen['tool_hashes'].items():
        if sha((ROOT/relative).read_bytes())!=expected:
            raise ValueError('Frozen conversion tool changed: '+relative)
    print('Family/source freeze verified:',frozen['counts'])


if __name__=='__main__':
    parser=argparse.ArgumentParser(__doc__)
    parser.add_argument('action',choices=('build','check'))
    parser.add_argument('--output',type=Path,default=DEFAULT_OUT)
    args=parser.parse_args()
    (build if args.action=='build' else check)(args.output)
