"""Exact one-predicate scalar CHC -> INIT/STEP/POST adapter; no synthesis.

Only a single nonzero-arity predicate over mathematical Int is supported.
The original Horn assertions are retained verbatim in the dataset.  Auxiliary
rule variables remain universally checked free constants in each raw VC.
The emitted C is a relational, nondeterministic feature carrier, never a
hand-written easier algorithm and never a source of final proof semantics.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import re

import z3

SPLIT = "SPLIT_HERE_asdfghjklzxcvbnmqwertyuiop"
TOKEN = re.compile(r';[^\n]*|\|[^|]*\||"(?:""|[^"])*"|[()]|[^\s()]+')


class Unsupported(ValueError):
    pass


def sexprs(source: str):
    tokens = [t for t in TOKEN.findall(source) if not t.startswith(";")]
    stack, result = [], []
    for token in tokens:
        if token == "(":
            node = []
            (stack[-1] if stack else result).append(node)
            stack.append(node)
        elif token == ")":
            if not stack:
                raise Unsupported("unbalanced-s-expression")
            stack.pop()
        else:
            if not stack:
                raise Unsupported("atom-outside-command")
            stack[-1].append(token)
    if stack:
        raise Unsupported("unbalanced-s-expression")
    return result


def emit(value):
    return "(" + " ".join(map(emit, value)) + ")" if isinstance(value, list) else value


def conjuncts(expr):
    return [child for arg in expr.children() for child in conjuncts(arg)] if z3.is_and(expr) else [expr]


def variables(expr):
    found = {}
    def visit(node):
        if z3.is_quantifier(node):
            raise Unsupported("nested-quantifier")
        if z3.is_const(node) and node.decl().kind() == z3.Z3_OP_UNINTERPRETED:
            found[node.sexpr()] = node
        for child in node.children():
            visit(child)
    visit(expr)
    return list(found.values())


def c_expr(expr):
    if z3.is_true(expr): return "1"
    if z3.is_false(expr): return "0"
    if z3.is_int_value(expr): return str(expr.as_long())
    if z3.is_const(expr): return str(expr)
    args = [c_expr(arg) for arg in expr.children()]
    kind = expr.decl().kind()
    binary = {z3.Z3_OP_ADD: "+", z3.Z3_OP_SUB: "-", z3.Z3_OP_MUL: "*",
              z3.Z3_OP_EQ: "==", z3.Z3_OP_LE: "<=", z3.Z3_OP_LT: "<",
              z3.Z3_OP_GE: ">=", z3.Z3_OP_GT: ">", z3.Z3_OP_AND: "&&", z3.Z3_OP_OR: "||"}
    if kind in binary:
        return "(" + (" " + binary[kind] + " ").join(args) + ")"
    if kind == z3.Z3_OP_UMINUS: return "(-" + args[0] + ")"
    if kind == z3.Z3_OP_NOT: return "(!" + args[0] + ")"
    if kind == z3.Z3_OP_IMPLIES: return "((!" + args[0] + ") || " + args[1] + ")"
    if kind == z3.Z3_OP_ITE: return "(" + args[0] + " ? " + args[1] + " : " + args[2] + ")"
    if kind == z3.Z3_OP_DISTINCT and len(args) == 2: return "(" + args[0] + " != " + args[1] + ")"
    raise Unsupported("unsupported-C-carrier-operator:" + str(expr.decl()))


@dataclass
class OnePredicateCHC:
    source: str
    max_state_variables: int = 12

    def __post_init__(self):
        commands = sexprs(self.source)
        self.commands = commands
        declarations, assertions, predicates, globals_ = [], [], {}, []
        for command in commands:
            name = command[0]
            if name in {"set-logic", "set-info", "set-option", "check-sat", "exit", "query"}:
                continue
            if name == "declare-rel":
                command = ["declare-fun", command[1], command[2], "Bool"]
                name = command[0]
            if name in {"declare-fun", "declare-const"}:
                declarations.append(emit(command))
                if name == "declare-fun" and command[3] == "Bool":
                    predicates[command[1].strip("|")] = command[2]
                elif name == "declare-fun" and command[2]:
                    raise Unsupported("uninterpreted-nonpredicate-function")
            elif name == "declare-var":
                declarations.append(emit(["declare-const", command[1], command[2]]))
                globals_.append((command[1].strip("|"), command[2]))
            elif name in {"assert", "rule"}:
                if len(command) != 2:
                    raise Unsupported("named-rule-or-assertion")
                assertions.append(command[1])
            else:
                raise Unsupported("unsupported-command:" + str(name))
        nonzero = {name: sorts for name, sorts in predicates.items() if sorts}
        if len(nonzero) != 1:
            raise Unsupported("requires-one-nonzero-arity-predicate:" + str(len(nonzero)))
        self.predicate, self.sorts = next(iter(nonzero.items()))
        if not self.sorts or len(self.sorts) > self.max_state_variables or any(s != "Int" for s in self.sorts):
            raise Unsupported("requires-1-to-12-mathematical-Int-state-variables")
        self.state = [z3.Int("v" + str(i)) for i in range(len(self.sorts))]
        self.next = [z3.Int("v" + str(i) + "!") for i in range(len(self.sorts))]
        self.locals = []
        initial, transitions, bad = [], [], []
        prefix = "\n".join(declarations) + "\n"
        for index, assertion in enumerate(assertions):
            parsed = z3.parse_smt2_string(prefix + "(assert " + emit(assertion) + ")")[0]
            if z3.is_quantifier(parsed):
                if not parsed.is_forall(): raise Unsupported("requires-universal-Horn-rules")
                bound = [z3.Const("r%03dv%03d" % (index, j), parsed.var_sort(j)) for j in range(parsed.num_vars())]
                parsed = z3.substitute_vars(parsed.body(), *reversed(bound))
            # declare-var inputs are implicitly universal in fixedpoint syntax.
            substitutions = [(z3.Const(n, z3.IntSort() if s == "Int" else z3.BoolSort()),
                              z3.Const("r%03dg%03d" % (index, j), z3.IntSort() if s == "Int" else z3.BoolSort()))
                             for j, (n, s) in enumerate(globals_) if s in {"Int", "Bool"}]
            if substitutions: parsed = z3.substitute(parsed, *substitutions)
            antecedent, head = parsed.children() if z3.is_implies(parsed) else (z3.BoolVal(True), parsed)
            parts = conjuncts(antecedent)
            atoms = [p for p in parts if self.is_predicate(p)]
            if len(atoms) > 1:
                raise Unsupported("nonlinear-Horn-body")
            rest = [p for p in parts if not self.is_predicate(p)]
            if any(self.contains_predicate(p) for p in rest):
                raise Unsupported("predicate-not-positive-top-level-body-atom")
            body = z3.And(*rest)
            if atoms:
                body = z3.And(body, *[a == b for a, b in zip(self.state, atoms[0].children())])
            is_head = self.is_predicate(head)
            is_failure = z3.is_false(head) or (z3.is_const(head) and str(head) in predicates and not predicates[str(head)])
            if is_head and not atoms:
                initial.append(z3.And(body, *[a == b for a, b in zip(self.state, head.children())]))
            elif is_head and atoms:
                transitions.append(z3.And(body, *[a == b for a, b in zip(self.next, head.children())]))
            elif is_failure and atoms:
                bad.append(body)
            else:
                raise Unsupported("rule-outside-init-step-error-shape")
        if not initial or not transitions or not bad:
            raise Unsupported("missing-init-step-or-safety-rule")
        self.pre = z3.simplify(z3.Or(*initial))
        self.transition = z3.simplify(z3.Or(*transitions))
        self.post = z3.simplify(z3.Not(z3.Or(*bad)))
        state_names = {x.sexpr() for x in self.state + self.next}
        self.locals = sorted({v.sexpr(): v for e in [self.pre, self.transition, self.post]
                              for v in variables(e) if v.sexpr() not in state_names}.values(), key=str)
        if any(v.sort().kind() not in {z3.Z3_INT_SORT, z3.Z3_BOOL_SORT} for v in self.locals):
            raise Unsupported("non-Int-rule-variable")
        self.rule_counts = {"init": len(initial), "step": len(transitions), "safety": len(bad)}
        # Validate carrier coverage before accepting the source, without solving.
        for e in [self.pre, self.transition, self.post]: c_expr(e)

    def is_predicate(self, expr):
        return z3.is_app(expr) and expr.decl().name() == self.predicate

    def contains_predicate(self, expr):
        return self.is_predicate(expr) or any(self.contains_predicate(c) for c in expr.children())

    def smt(self):
        declarations = ["(set-logic QF_NIA)"]
        for symbol in self.state + self.next + self.locals:
            declarations.append("(declare-const %s %s)" % (symbol.sexpr(), symbol.sort()))
        def define(name, arguments, body):
            return "(define-fun %s (%s) Bool\n%s)\n" % (name, " ".join("(%s Int)" % x.sexpr() for x in arguments), body)
        prefix = "\n".join(declarations) + "\n" + define("inv-f", self.state, SPLIT)
        prefix += define("pre-f", self.state, self.pre.sexpr())
        prefix += define("trans-f", self.state + self.next, self.transition.sexpr())
        prefix += define("post-f", self.state, self.post.sexpr())
        now = " ".join(map(str, self.state)); nxt = " ".join(x.sexpr() for x in self.next)
        inv, inv_next = "(inv-f %s)" % now, "(inv-f %s)" % nxt
        queries = ["(assert (not (=> (pre-f %s) %s)))" % (now, inv),
                   "(assert (not (=> (and %s (trans-f %s %s)) %s)))" % (inv, now, nxt, inv_next),
                   "(assert (not (=> %s (post-f %s))))" % (inv, now)]
        return prefix + "\n" + ("\n" + SPLIT + "\n").join([""] + queries) + "\n"

    def carrier_c(self):
        names = [str(v) for v in self.state]
        local_names = [str(v) for v in self.locals]
        nxt_names = ["next_" + n for n in names]
        substitutions = [(v, z3.Int(n)) for v, n in zip(self.next, nxt_names)]
        # Bool auxiliaries are represented by comparisons with zero; no Bool
        # predicate state is imported under this policy.
        substitutions += [(v, z3.Int(str(v)) != 0) for v in self.locals if z3.is_bool(v)]
        pre, trans, post = [z3.substitute(e, *substitutions) for e in [self.pre, self.transition, self.post]]
        lines = ["/* Relational feature carrier of the accompanying original CHC.",
                 " * Mathematical Int semantics; task.c_smt defines proof authority.",
                 " * Every next-state tuple is nondeterministically chosen and constrained", 
                 " * by the full imported transition, not by a simplified algorithm. */",
                 "extern int unknown(void);", "extern void assume(int);", "extern void assert(int);", "int main(void) {"]
        for name in names + nxt_names + local_names:
            lines.append("  int %s = unknown();" % name)
        lines.append("  assume(%s);" % c_expr(pre))
        lines.append("  while (unknown()) {")
        for name in nxt_names + local_names: lines.append("    %s = unknown();" % name)
        lines.append("    assume(%s);" % c_expr(trans))
        for name, nxt in zip(names, nxt_names): lines.append("    %s = %s;" % (name, nxt))
        lines.append("  }")
        for name in local_names: lines.append("  %s = unknown();" % name)
        lines.extend(["  assert(%s);" % c_expr(post), "  return 0;", "}"])
        return "\n".join(lines) + "\n"

    def signature(self, erase_constants=False):
        """Fixed coordinate/order screening signature, never an equivalence proof."""
        local_map = {str(v): "aux" + str(i) for i, v in enumerate(self.locals)}
        commutative = {z3.Z3_OP_AND, z3.Z3_OP_OR, z3.Z3_OP_ADD, z3.Z3_OP_MUL, z3.Z3_OP_EQ}
        def tree(e):
            if not e.num_args():
                value = "NUM" if erase_constants and z3.is_int_value(e) else local_map.get(str(e), e.sexpr())
                return [str(e.sort()), value]
            children = [tree(c) for c in e.children()]
            if e.decl().kind() in commutative: children.sort(key=lambda x: json.dumps(x))
            return [e.decl().name(), children]
        return hashlib.sha256(json.dumps([tree(e) for e in [self.pre, self.transition, self.post]], sort_keys=True).encode()).hexdigest()
