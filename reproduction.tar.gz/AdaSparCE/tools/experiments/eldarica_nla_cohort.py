"""Fetch the already sealed complete official Eldarica SMT source cohort.

The fetch/check commands use only the standard library and never parse SMT,
import Z3, invoke a solver, or read expected-result/regression output files.
The pre-existing selection freeze is immutable. All upstream and derived
source text is fetch-only, independent of the upstream repository licence.
"""
from __future__ import annotations

import argparse
import base64
import concurrent.futures
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import urllib.request

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_OUT = ROOT / "datasets/ICST2027-EldaricaNLA-20261019"
REPOSITORY = "uuverifiers/eldarica"
PIN = "9c3addbebf8f7f201f7bf6d65d77e43d97122201"
EXPECTED_SOURCES = 135


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def file_sha(path):
    checksum = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda:stream.read(1_048_576), b""):
            checksum.update(block)
    return checksum.hexdigest()


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode()


def write_new(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(json_bytes(value))


def selection(output):
    output = Path(output).resolve()
    freeze_path = output / "SELECTION_FROZEN.json"
    freeze = json.loads(freeze_path.read_text())
    tree_path = output / "source-tree.json"
    if (freeze.get("schema") != "adasparce.official-arithmetic-cohort-selection.v1"
            or freeze.get("source") != "https://github.com/" + REPOSITORY
            or freeze.get("source_commit") != PIN
            or freeze.get("source_count") != EXPECTED_SOURCES
            or freeze.get("method_inference_started") is not False
            or file_sha(tree_path) != freeze.get("source_tree_sha256")):
        raise ValueError("Foreign or modified pre-fetch source selection")
    tree = json.loads(tree_path.read_text())
    if tree.get("sha") != PIN or tree.get("truncated") is not False:
        raise ValueError("Incomplete or foreign official source tree")
    full = sorted([r for r in tree["tree"] if r.get("type") == "blob"
                   and r["path"].startswith("regression-tests/") and r["path"].endswith(".smt2")],
                  key=lambda row:row["path"])
    sources = freeze["sources"]
    if len(full) != EXPECTED_SOURCES or full != sorted(sources, key=lambda row:row["path"]):
        raise ValueError("Sealed inventory is not the complete official .smt2 cohort")
    seen = set()
    for row in sources:
        path = PurePosixPath(row["path"])
        if (path.is_absolute() or ".." in path.parts or str(path) != row["path"]
                or row["path"] in seen or row.get("mode") != "100644"
                or not isinstance(row.get("size"), int) or row["size"] < 0
                or row["url"] != f"https://api.github.com/repos/{REPOSITORY}/git/blobs/{row['sha']}"):
            raise ValueError("Invalid sealed source identity")
        seen.add(row["path"])
    for relative, expected in freeze["pre_fetch_exposure_evidence"].items():
        path = (ROOT / relative).resolve()
        if not path.is_relative_to(ROOT) or file_sha(path) != expected:
            raise ValueError("Pre-fetch exposure evidence changed: " + relative)
    return freeze, sorted(sources, key=lambda row:row["path"])


def retrieve(url, limit):
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    request = urllib.request.Request(url, headers={"User-Agent":"AdaSparCE-sealed-official-source-fetch"})
    with opener.open(request, timeout=8) as response:
        raw = response.read(limit + 1)
    if len(raw) > limit:
        raise ValueError("Pinned source size limit")
    return raw


def validate_source(raw, row):
    blob = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
    if len(raw) != row["size"] or blob != row["sha"]:
        raise ValueError("Pinned source Git blob/size mismatch: " + row["path"])
    return sha(raw)


def fetch(output):
    output = Path(output).resolve()
    _, sources = selection(output)
    upstream = output / "upstream" / "eldarica"
    previous_path = output / "source-downloads.json"
    previous = json.loads(previous_path.read_text()) if previous_path.exists() else None
    previous_rows = {r["path"]:r for r in previous.get("sources", [])} if previous else {}

    def one(row):
        path = upstream / row["path"]
        if not path.resolve().is_relative_to(upstream.resolve()):
            raise ValueError("Source destination escapes upstream directory")
        official = f"https://raw.githubusercontent.com/{REPOSITORY}/{PIN}/{row['path']}"
        checksum, retrieval = None, None
        if path.exists():
            checksum = validate_source(path.read_bytes(), row)
            retrieval = previous_rows.get(row["path"], {}).get("retrieval_url", "cached-exact-pinned-Git-blob")
        else:
            failures = []
            for endpoint, encoding in [(official, "raw"),
                    (f"https://cdn.jsdelivr.net/gh/{REPOSITORY}@{PIN}/{row['path']}", "raw"),
                    (row["url"], "github-json-base64")]:
                try:
                    payload = retrieve(endpoint, max(2_000_000, row["size"] * 2 + 2048))
                    if encoding == "github-json-base64":
                        envelope = json.loads(payload)
                        if envelope.get("sha") != row["sha"] or envelope.get("encoding") != "base64":
                            raise ValueError("Foreign GitHub blob envelope")
                        raw = base64.b64decode(envelope["content"])
                    else:
                        raw = payload
                    candidate_checksum = validate_source(raw, row)
                    path.parent.mkdir(parents=True, exist_ok=True)
                    with path.open("xb") as stream:
                        stream.write(raw)
                    checksum = candidate_checksum
                    retrieval = endpoint
                    break
                except Exception as error:
                    failures.append(type(error).__name__ + ": " + str(error))
            if checksum is None:
                raise RuntimeError(row["path"] + ": " + "; ".join(failures))
        return dict(path=row["path"], git_blob_sha1=row["sha"], bytes=row["size"], sha256=checksum,
                    official_url=official, retrieval_url=retrieval)

    records, errors = [], []
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as executor:
        futures = {executor.submit(one, row):row["path"] for row in sources}
        for future in concurrent.futures.as_completed(futures):
            try:
                records.append(future.result())
            except Exception as error:
                errors.append(dict(path=futures[future], reason=str(error)))
    if errors:
        pending = dict(schema="adasparce.eldarica-cohort-fetch-attempt.v1",
                       completed=len(records), expected=len(sources), failures=sorted(errors,key=lambda r:r["path"]),
                       no_SMT_parse_or_solver=True, attempted_utc=datetime.now(timezone.utc).isoformat())
        (output / "fetch-attempt.json").write_bytes(json_bytes(pending))
        raise RuntimeError("Pinned source fetch incomplete: " + str(len(errors)) + "; see fetch-attempt.json")
    record = dict(schema="adasparce.eldarica-source-downloads.v1", repository=REPOSITORY, commit=PIN,
                  selection_freeze_sha256=file_sha(output / "SELECTION_FROZEN.json"),
                  source_tree_sha256=file_sha(output / "source-tree.json"), complete=True,
                  no_SMT_parse_or_solver=True, no_expected_result_or_regression_script_read=True,
                  sources=sorted(records, key=lambda r:r["path"]))
    if previous is not None:
        if previous != record:
            raise ValueError("Immutable download inventory differs from exact cached restoration")
    else:
        write_new(previous_path, record)
    print(json.dumps(dict(complete=True, sources=len(records), no_SMT_parse_or_solver=True)))
    return record


def check(output):
    output = Path(output).resolve()
    _, sources = selection(output)
    downloaded = json.loads((output / "source-downloads.json").read_text())
    if (downloaded.get("schema") != "adasparce.eldarica-source-downloads.v1"
            or downloaded.get("selection_freeze_sha256") != file_sha(output / "SELECTION_FROZEN.json")
            or downloaded.get("source_tree_sha256") != file_sha(output / "source-tree.json")
            or downloaded.get("complete") is not True
            or len(downloaded.get("sources", [])) != len(sources)):
        raise ValueError("Incomplete or foreign downloaded cohort")
    entries = {r["path"]:r for r in downloaded["sources"]}
    if set(entries) != {r["path"] for r in sources}:
        raise ValueError("Downloaded identity denominator differs")
    for row in sources:
        path = output / "upstream" / "eldarica" / row["path"]
        checksum = validate_source(path.read_bytes(), row)
        if entries[row["path"]]["sha256"] != checksum:
            raise ValueError("Downloaded SHA-256 changed")
    print(json.dumps(dict(verified=True, sources=len(sources), no_SMT_parse_or_solver=True)))
    return downloaded


if __name__ == "__main__":
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("action", choices=("fetch", "check"))
    parser.add_argument("--output", type=Path, default=DEFAULT_OUT)
    args = parser.parse_args()
    (fetch if args.action == "fetch" else check)(args.output)
