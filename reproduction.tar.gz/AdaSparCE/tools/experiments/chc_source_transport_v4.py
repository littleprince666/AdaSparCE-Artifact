"""Generic, explicitly proved lowering of an arithmetic safety head.

After v3's exact typed-AST helper/output transport, a top-level Horn rule
    A and P(args) => H
with one positive predicate body atom and a predicate-free Boolean head can
be written as A and P(args) and not H => false.  This is a Boolean identity,
not literal AST identity.  No arithmetic atom, parameter or binder is changed.
"""
from __future__ import annotations

import hashlib
import json

from tools.experiments.chc_source_transport_v3 import TransportResult, transport as exact_transport


def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()


def transport(source):
    from tools.experiments.new_family_chc import emit, sexprs
    exact = exact_transport(source)
    commands = sexprs(exact.source)
    original_commands = sexprs(source)
    raw_rules = [c for c in original_commands if c and c[0] in {"assert", "rule"}]
    predicates = {c[1] for c in commands if c and c[0] == "declare-fun" and len(c) == 4 and c[3] == "Bool"}
    predicates.update(c[1] for c in commands if c and c[0] == "declare-rel")
    def is_predicate(node):
        return isinstance(node, list) and bool(node) and isinstance(node[0], str) and node[0] in predicates
    def contains_predicate(node):
        if isinstance(node, str): return node in predicates
        return is_predicate(node) or any(contains_predicate(c) for c in node)
    def has_nested_binder(node):
        return (isinstance(node, list) and bool(node)
                and ((isinstance(node[0], str) and node[0] in {"forall", "exists", "lambda"})
                     or any(has_nested_binder(c) for c in node)))
    def conjuncts(node):
        if isinstance(node, list) and node and node[0] == "and":
            return [part for child in node[1:] for part in conjuncts(child)]
        return [node]
    truth_table = [dict(A=a, H=h, original=((not a) or h),
                        lowered=(not (a and not h)))
                   for a in (False, True) for h in (False, True)]
    if not all(row["original"] == row["lowered"] for row in truth_table):
        raise AssertionError("Boolean identity template is invalid")
    evidence, rewritten, index = [], [], 0
    for command in commands:
        if not command or command[0] not in {"assert", "rule"}:
            rewritten.append(command)
            continue
        body = command[1]
        binder = None
        core = body
        if isinstance(core, list) and core and core[0] == "forall" and len(core) == 3:
            binder, core = core[1], core[2]
        lowered = False
        new_core = core
        if (isinstance(core, list) and len(core) == 3 and core[0] == "=>"
                and core[2] != "false" and not contains_predicate(core[2])
                and not has_nested_binder(core[2]) and not has_nested_binder(core[1])):
            antecedent, head = core[1], core[2]
            parts = conjuncts(antecedent)
            positive = [part for part in parts if is_predicate(part)]
            # All occurrences of the predicate must be the one positive
            # top-level atom.  No negative/non-Horn body is reinterpreted.
            remainder = [part for part in parts if not is_predicate(part)]
            if len(positive) == 1 and not any(contains_predicate(part) for part in remainder):
                new_core = ["=>", ["and", antecedent, ["not", head]], "false"]
                lowered = True
                # This executable template check is separate from the Boolean
                # identity proof: A and H are exactly the original subtrees.
                if (new_core[1][1] != antecedent or new_core[1][2] != ["not", head]
                        or new_core[2] != "false"):
                    raise AssertionError("A safety head arithmetic subtree changed")
        new_body = ["forall", binder, new_core] if binder is not None else new_core
        transformed = [command[0], new_body]
        if not lowered and transformed != command:
            raise AssertionError("An unselected source rule changed")
        row = dict(index=index, original_source_rule_smt2=emit(raw_rules[index]),
            expanded_original_rule_smt2=emit(command), normalized_rule_smt2=emit(transformed),
            lowering_applied=lowered, predicate_interpretations_supplied=False,
            solver_or_inference=False, arithmetic_subtrees_and_predicate_arguments_unchanged=True,
            quantifier_binders_and_scope_unchanged=True)
        if lowered:
            row.update(identity="(A => H) iff ((A and (not H)) => false)",
                proof_kind="exhaustive-Boolean-template-plus-exact-subtree-instantiation",
                truth_table=truth_table, antecedent_subtree_sha256=digest(emit(core[1])),
                head_subtree_sha256=digest(emit(core[2])),
                original_to_normalized_AST_identity_claim=False)
        else:
            row.update(proof_kind="unchanged-rule-tree-after-v3-typed-AST-identity",
                       original_to_normalized_AST_identity_claim=True)
        evidence.append(row);rewritten.append(transformed);index += 1
    result = "\n".join(emit(command) for command in rewritten) + "\n"
    # Verify every final rule is well typed, with original uninterpreted
    # predicates, and serializes to the same final typed AST.  This is a
    # syntax/identity check on the *lowered* rule, not a false claim that the
    # pre-lowering and post-lowering ASTs are identical.
    final_identity = exact_transport(result)
    return TransportResult(final_identity.source, dict(
        schema="adasparce.pure-Horn-source-transport.v4",
        original_source_sha256=digest(source), transported_source_sha256=digest(final_identity.source),
        exact_helper_output_transport=exact.evidence,
        final_rule_typed_AST_identity=final_identity.evidence,
        rules=evidence, all_rule_equivalence_identities_verified=True,
        safety_head_lowerings=sum(row["lowering_applied"] for row in evidence),
        no_invariant_substitution=True, no_solver_or_inference=True,
        arithmetic_subtrees_parameters_and_quantifier_scope_unchanged=True,
        original_to_final_AST_identity_claim=not any(row["lowering_applied"] for row in evidence),
        semantic_scope_not_widened=True))
