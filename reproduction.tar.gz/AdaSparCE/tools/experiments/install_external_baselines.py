"""Pinned dependency/source setup for the audited external-baseline runner.

doctor is read-only and imports no solver or model SDK. fetch/install/all are
explicit mutations; never run them while a frozen timing study is active.
Archives are source-verification containers. Only author code and the canonical
Clause2Inv gate's inert directory-metadata sidecar are extracted.
"""
from __future__ import annotations

import argparse
from importlib import metadata
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import urllib.request
import zipfile

from tools.experiments.strong_baseline_protocol import (
    ARCHIVES, COMMITS, DEPENDENCIES, EXTERNAL, METHODS, ROOT, sha,
)


# These versions are taken from the local runtime/distribution metadata used
# for the 2026-10-18 setup, not resolved from today's latest package releases.
# Every transitively needed Python distribution is explicit; --no-deps prevents
# pip from silently substituting an unconstrained dependency version.
ADA_PINS = ('z3-solver==5.1.0.0','sympy==1.14.0','pycparser==3.0','mpmath==1.3.0')
DIG_PINS = ('z3-solver==4.16.0.0','beartype==0.22.9','numpy==2.5.2',
            'sympy==1.14.0','pycparser==3.0','mpmath==1.3.0')
CLAUSE_PINS = (
    'openai==1.109.1','pyjson5==2.0.0','rich==13.9.4','numpy==2.5.2',
    'tqdm==4.70.1','z3-solver==5.1.0.0','annotated-types==0.8.0',
    'anyio==4.15.1','certifi==2026.7.22','distro==1.9.0','h11==0.16.0',
    'httpcore==1.0.9','httpx==0.28.1','idna==3.20','jiter==0.17.0',
    'pydantic==2.14.1','pydantic_core==2.50.1','sniffio==1.3.1',
    'typing-inspection==0.4.4','typing_extensions==4.16.0',
    'markdown-it-py==3.0.0','mdurl==0.1.2','Pygments==2.19.2',
)
PINS = dict(ada=ADA_PINS,cvc5=('cvc5==1.3.4','z3-solver==5.1.0.0'),
            dig=DIG_PINS,clause2inv=CLAUSE_PINS)
PROJECTS = dict(dig='dig',clause2inv='Clause2Inv')
REPOSITORIES = dict(dig='https://github.com/dynaroars/dig',
                    Clause2Inv='https://github.com/SoftWiser-group/Clause2Inv')
SOURCE_SIDECARS = {'Clause2Inv': frozenset({'generator/.DS_Store'})}


def canonical_name(name):
    return re.sub(r'[-_.]+','-',name).lower()


def write(path, value):
    path=Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_name(path.name+'.tmp')
    temporary.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    temporary.replace(path)


def required(method):
    return {canonical_name(pin.split('==')[0]):pin.split('==')[1] for pin in PINS[method]}


def distributions_at(path, inherit=True):
    paths=[str(path)]+list(sys.path) if inherit else [str(path)]
    found={}
    for distribution in metadata.distributions(path=paths):
        name=distribution.metadata.get('Name')
        if name:
            found.setdefault(canonical_name(name),dict(version=distribution.version,
                location=str(distribution.locate_file(''))))
    return found


def check_packages(method, inherit=True):
    installed=distributions_at(DEPENDENCIES[method],inherit)
    expected=required(method)
    problems=[]
    for name,version in expected.items():
        actual=installed.get(name)
        if actual is None:
            problems.append(name+'=='+version+' absent')
        elif actual['version']!=version:
            problems.append(name+': expected '+version+', installed '+actual['version'])
    return dict(expected=expected,installed={name:installed.get(name) for name in expected},
                problems=problems,search_path=str(DEPENDENCIES[method]),global_fallback=inherit)


def wanted(project, relative):
    parts=PurePosixPath(relative).parts
    if not parts or PurePosixPath(relative).is_absolute() or '..' in parts:
        return False
    if '__pycache__' in parts or relative.endswith('.pyc'):
        return False
    if project=='dig':
        return parts[0]=='src'
    return (parts[0] in ('generator','combinator') and relative.endswith('.py')
            or relative in SOURCE_SIDECARS.get(project,()))


def sidecar(project, relative):
    return relative in SOURCE_SIDECARS.get(project,())


def archive_files(project, archive_path):
    """Read only author code and the inert gate sidecar, never result members."""
    import hashlib
    if sha(archive_path)!=ARCHIVES[project]:
        raise ValueError('pinned-archive-hash-mismatch:'+str(archive_path))
    records=[]
    with zipfile.ZipFile(archive_path) as archive:
        roots={PurePosixPath(item.filename).parts[0] for item in archive.infolist() if item.filename}
        if len(roots)!=1:
            raise ValueError('expected-one-pinned-archive-root')
        prefix=next(iter(roots))+'/'
        for item in archive.infolist():
            relative=item.filename.removeprefix(prefix)
            if item.is_dir() or not wanted(project,relative):
                continue
            if stat.S_ISLNK(item.external_attr>>16):
                raise ValueError('source-symlink-not-supported:'+relative)
            data=archive.read(item)
            records.append((relative,data,hashlib.sha256(data).hexdigest()))
    if not records:
        raise ValueError('no-author-code-in-pinned-archive')
    return records


def fetch_archive(project):
    path=EXTERNAL/(project+'.zip')
    if path.exists():
        if sha(path)!=ARCHIVES[project]:
            raise ValueError('existing-archive-differs; choose a clean checkout, never overwrite a frozen installation')
        return path
    repository=REPOSITORIES[project].removeprefix('https://github.com/')
    url=f'https://codeload.github.com/{repository}/zip/{COMMITS[project]}'
    temporary=path.with_name(path.name+'.download')
    request=urllib.request.Request(url,headers={'User-Agent':'AdaSparCE-pinned-source-installer'})
    try:
        with urllib.request.urlopen(request,timeout=60) as response,temporary.open('wb') as stream:
            total=0
            while chunk:=response.read(1_048_576):
                total+=len(chunk)
                if total>512*1_048_576:
                    raise ValueError('archive-size-limit')
                stream.write(chunk)
        if sha(temporary)!=ARCHIVES[project]:
            raise ValueError('downloaded-archive-does-not-match-protocol-pin')
        temporary.replace(path)
    finally:
        if temporary.exists():
            temporary.unlink()
    return path


def fetch_source(method):
    if method not in PROJECTS:
        return dict(method=method,status='no-author-source-needed',pins=PINS[method])
    project=PROJECTS[method]
    archive_path=fetch_archive(project)
    records=archive_files(project,archive_path)
    destination=EXTERNAL/project
    if destination.exists():
        for relative,data,fingerprint in records:
            path=destination/relative
            if not path.is_file() or sha(path)!=fingerprint:
                raise ValueError('existing-author-code-missing-or-modified:'+relative+
                    '; use a clean checkout; no in-place overwrite is performed')
        status='existing-code-verified'
    else:
        with tempfile.TemporaryDirectory(prefix=project+'-code-',dir=EXTERNAL) as temporary:
            staged=Path(temporary)/project
            staged.mkdir()
            for relative,data,fingerprint in records:
                path=staged/relative
                path.parent.mkdir(parents=True,exist_ok=True)
                path.write_bytes(data)
            staged.rename(destination)
        status='pinned-code-installed'
    record=dict(repository=REPOSITORIES[project],commit=COMMITS[project],
        archive_sha256=ARCHIVES[project],
        download_url=f'https://codeload.github.com/{REPOSITORIES[project].removeprefix("https://github.com/")}/zip/{COMMITS[project]}',
        selected_files_sha256={relative:fingerprint for relative,_,fingerprint in records
                               if not sidecar(project,relative)},
        source_metadata_sidecars_sha256={relative:fingerprint for relative,_,fingerprint in records
                                        if sidecar(project,relative)},
        extraction='DIG src; Clause2Inv generator/combinator Python plus generator/.DS_Store gate sidecar',
        sidecar_policy='Directory metadata only, retained for canonical gate verification; not candidate generation or method input',
        unused_archive_members='Not opened, extracted, or copied into timed source snapshots',
        fresh_runtime='No benchmark answers, LLM responses, synthesized invariants or execution traces are supplied')
    metadata_path=EXTERNAL/(project+'-source.json')
    if metadata_path.exists():
        previous=json.loads(metadata_path.read_text())
        if previous.get('commit')!=COMMITS[project] or previous.get('archive_sha256')!=ARCHIVES[project]:
            raise ValueError('existing-source-metadata-pin-mismatch')
    else:
        write(metadata_path,record)
    return dict(method=method,status=status,
                source_files=sum(not sidecar(project,relative) for relative,_,_ in records),
                source_metadata_sidecars=[relative for relative,_,_ in records if sidecar(project,relative)],
                source=str(destination),archive_sha256=ARCHIVES[project])


def install_packages(method):
    existing=check_packages(method)
    if not existing['problems']:
        return dict(method=method,status='existing-pins-verified',packages=existing)
    destination=DEPENDENCIES[method]
    if destination.exists():
        raise ValueError('existing-dependency-target-is-not-the-pinned-runtime: '+str(destination)+
            '; use a clean checkout or environment; never mutate a frozen target')
    if method=='dig' and sys.version_info<(3,14):
        raise ValueError('pinned-author-DIG-requires-Python-3.14-or-newer')
    with tempfile.TemporaryDirectory(prefix=method+'-deps-',dir=EXTERNAL) as temporary:
        staged=Path(temporary)/'packages'
        report=Path(temporary)/'pip-report.json'
        command=[sys.executable,'-m','pip','--disable-pip-version-check','install',
            '--no-input','--no-compile','--only-binary=:all:','--no-deps',
            '--index-url','https://pypi.org/simple','--target',str(staged),
            '--report',str(report),*PINS[method]]
        environment=dict(os.environ)
        environment.pop('PIP_EXTRA_INDEX_URL',None)
        subprocess.run(command,check=True,env=environment)
        found=distributions_at(staged,False)
        if any(found.get(name,{}).get('version')!=version for name,version in required(method).items()):
            raise ValueError('pip-output-does-not-match-explicit-pins')
        installation=json.loads(report.read_text())
        staged.rename(destination)
        write(EXTERNAL/(method+'-dependency-install.json'),dict(
            python=sys.version,pins=PINS[method],pip_report=installation,
            installer_sha256=sha(Path(__file__)),target=str(destination)))
        if method=='cvc5' and not (EXTERNAL/'cvc5-source.json').exists():
            wheel=next(item for item in installation['install']
                       if canonical_name(item['metadata']['name'])=='cvc5')
            write(EXTERNAL/'cvc5-source.json',dict(repository='https://github.com/cvc5/cvc5',
                release_tag='cvc5-1.3.4',python_distribution='cvc5==1.3.4',
                pypi_wheel=wheel['download_info']))
    return dict(method=method,status='pinned-dependencies-installed',target=str(destination))


def doctor(methods):
    checks={}
    for method in methods:
        packages=check_packages(method)
        reasons=list(packages['problems'])
        source=None
        if method in PROJECTS:
            project=PROJECTS[method]
            path=EXTERNAL/(project+'-source.json')
            archive=EXTERNAL/(project+'.zip')
            source=dict(metadata=str(path),archive=str(archive),verified=False)
            if not path.is_file() or not archive.is_file():
                reasons.append('pinned author metadata/archive absent; run fetch')
            else:
                record=json.loads(path.read_text())
                if record.get('commit')!=COMMITS[project] or record.get('archive_sha256')!=ARCHIVES[project]:
                    reasons.append('author source metadata pin mismatch')
                else:
                    try:
                        records=archive_files(project,archive)
                        mismatches=[relative for relative,_,fingerprint in records
                            if not (EXTERNAL/project/relative).is_file() or sha(EXTERNAL/project/relative)!=fingerprint]
                        source.update(verified=not mismatches,
                            source_files=sum(not sidecar(project,relative) for relative,_,_ in records),
                            source_metadata_sidecars=[relative for relative,_,_ in records if sidecar(project,relative)],
                            sidecar_policy='Canonical gate metadata only; not candidate generation or method input',
                            mismatches=mismatches)
                        if mismatches:
                            reasons.append('author code differs from pinned archive')
                    except (OSError,ValueError,zipfile.BadZipFile) as error:
                        reasons.append(type(error).__name__+':'+str(error))
        if method in ('ada','dig') and not shutil.which('gcc'):
            reasons.append('gcc/CPP unavailable')
        if method=='dig' and sys.version_info<(3,14):
            reasons.append('pinned DIG requires Python >=3.14')
        if method=='clause2inv' and not os.environ.get('OPENAI_API_KEY'):
            reasons.append('OPENAI_API_KEY absent; no API request attempted')
        checks[method]=dict(available=not reasons,reasons=reasons,packages=packages,source=source,
            credential_present=bool(os.environ.get('OPENAI_API_KEY')) if method=='clause2inv' else None)
    return dict(date='2026-10-18',methods=checks,
        policy='Metadata/source checks only; no solver imports, inference, compilation, or API requests',
        pins_source='tools/experiments/strong_baseline_protocol.py plus installed distribution metadata',
        installation_policy='Never overwrite existing mismatched sources or frozen dependency targets')


def main():
    parser=argparse.ArgumentParser(__doc__)
    parser.add_argument('action',choices=('doctor','fetch','install','all'))
    parser.add_argument('--methods',default=','.join(METHODS))
    args=parser.parse_args()
    methods=args.methods.split(',')
    if not methods or len(set(methods))!=len(methods) or not set(methods)<=set(METHODS):
        parser.error('methods must be a unique comma-separated subset of ada,cvc5,dig,clause2inv')
    if args.action=='doctor':
        print(json.dumps(doctor(methods),ensure_ascii=False,indent=2))
        return
    EXTERNAL.mkdir(parents=True,exist_ok=True)
    records=[]
    for method in methods:
        if args.action in ('fetch','all'):
            records.append(fetch_source(method))
        if args.action in ('install','all'):
            records.append(install_packages(method))
    print(json.dumps(dict(actions=records,note='No benchmark inference or API request was executed'),
                     ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
