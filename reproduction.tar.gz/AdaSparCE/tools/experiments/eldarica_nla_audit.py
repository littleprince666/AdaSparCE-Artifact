"""Audit the complete sealed Eldarica source cohort without inference.

Run only after a timed experiment window has ended.  The unchanged exact
OnePredicateCHC adapter handles supported inputs; every rejection is retained.
All generated C/VC source remains fetch-only.  No primary family is certified
automatically by a missing hash or fingerprint match.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

from tools.experiments.eldarica_nla_cohort import DEFAULT_OUT, ROOT, check, file_sha, json_bytes, selection, sha, write_new


NUMBER = re.compile(r"^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$")
COMMUTATIVE = {"and", "or", "+", "*", "=", "distinct"}
SPLIT = "SPLIT_HERE_asdfghjklzxcvbnmqwertyuiop"


def horn_fingerprints(source):
    """Consistent-renaming and constant-shape *syntactic* Horn screens.

    Metadata and solver commands are omitted, while declarations, binding,
    operators, sorts, rules and assertions are retained.  A nonmatch never
    proves a new semantic mechanism.  A shape match is conservatively exposed.
    """
    from tools.experiments.new_family_chc import sexprs
    commands = sexprs(source)
    globals_ = {}
    for command in commands:
        if command and command[0] in {"declare-fun", "declare-rel", "declare-const", "declare-var", "define-fun"}:
            globals_.setdefault(command[1], "g" + str(len(globals_)))

    def canonical(erase):
        def walk(node, local, serial):
            if not isinstance(node, list):
                return local.get(node, globals_.get(node, "NUM" if erase and NUMBER.fullmatch(node) else node))
            if not node: return []
            op = node[0] if isinstance(node[0], str) else None
            if op in {"forall", "exists"} and len(node) == 3:
                scope, binders = dict(local), []
                for binder in node[1]:
                    name = "q" + str(serial[0]);serial[0] += 1
                    scope[binder[0]] = name
                    binders.append([name, walk(binder[1], local, serial)])
                return [node[0], binders, walk(node[2], scope, serial)]
            if op == "let" and len(node) == 3:
                scope, bindings = dict(local), []
                for binder in node[1]:
                    name = "l" + str(serial[0]);serial[0] += 1
                    bindings.append([name, walk(binder[1], local, serial)])
                    scope[binder[0]] = name
                return ["let", bindings, walk(node[2], scope, serial)]
            if op == "define-fun" and len(node) == 5:
                scope, params = dict(local), []
                for i, binder in enumerate(node[2]):
                    scope[binder[0]] = "p" + str(i)
                    params.append([scope[binder[0]], walk(binder[1], local, serial)])
                return ["define-fun", globals_[node[1]], params,
                        walk(node[3], local, serial), walk(node[4], scope, serial)]
            children = [walk(child, local, serial) for child in node[1:]]
            if op in COMMUTATIVE:
                children.sort(key=lambda child:json.dumps(child, sort_keys=True, separators=(",", ":")))
            return [walk(node[0], local, serial)] + children
        retained = [walk(command, {}, [0]) for command in commands
                    if command and command[0] not in {"set-logic", "set-info", "set-option", "check-sat", "exit", "query", "get-model", "get-proof"}]
        return sha(json.dumps(retained, sort_keys=True, separators=(",", ":")).encode())
    return dict(alpha=canonical(False), constant_shape=canonical(True))


def nonlinear_locations(problem):
    import z3
    def contains(node):
        if z3.is_app(node):
            kind = node.decl().kind()
            if kind == z3.Z3_OP_MUL:
                if sum(not (z3.is_int_value(c) or z3.is_rational_value(c)) for c in node.children()) >= 2:
                    return True
            if kind == z3.Z3_OP_POWER:
                base, exponent = node.children()
                if not (z3.is_int_value(base) or z3.is_rational_value(base)):
                    if not z3.is_rational_value(exponent) or exponent.as_fraction() not in (0, 1):
                        return True
        return any(contains(c) for c in node.children())
    return [name for name, expression in [("init", problem.pre), ("step", problem.transition), ("safety", problem.post)]
            if contains(expression)]


def collect_models(output, sources):
    """Always visit the entire cohort in the same fresh-process order first.

    Z3 printer order can depend on AST allocation history.  Do not parse the
    historical corpus before this pass or reconstruct just selected inputs.
    The pass creates no Solver and never calls check-sat.
    """
    import z3
    from tools.experiments.new_family_chc import OnePredicateCHC, Unsupported
    records = []
    for row in sources:
        path = output / "upstream" / "eldarica" / row["path"]
        raw = path.read_bytes()
        text = raw.decode("utf-8")
        record = dict(source=row["path"], source_sha256=sha(raw), git_blob_sha1=row["sha"],
                      source_status=(re.search(r"\(set-info\s+:status\s+(\w+)\)", text) or [None, "unknown"])[1])
        try:
            record["source_fingerprints"] = horn_fingerprints(text)
        except Exception as error:
            record["fingerprint_error"] = str(error)
        try:
            problem = OnePredicateCHC(text)
            carrier, vc = problem.carrier_c(), problem.smt()
            # Syntax-check all original obligations without checking a model
            # or searching for an invariant.  True is only a parse placeholder.
            pieces = vc.split(SPLIT)
            if len(pieces) != 5: raise ValueError("expected-three-original-VC-sections")
            for index in (2, 3, 4):
                z3.parse_smt2_string(pieces[0] + "true" + pieces[1] + pieces[index])
            record.update(structural_status="supported", state_variables=len(problem.state),
                auxiliary_variables=len(problem.locals), rule_counts=problem.rule_counts,
                nonlinear_locations=nonlinear_locations(problem),
                coordinate_signature=problem.signature(), erased_constant_signature=problem.signature(True),
                carrier_sha256=sha(carrier.encode()), vc_sha256=sha(vc.encode()),
                _carrier=carrier, _vc=vc)
        except (Unsupported, ValueError, z3.Z3Exception) as error:
            record.update(structural_status="unsupported", reason=str(error))
        records.append(record)
    return records


def exposure_indices(freeze):
    """Read pre-fetch exposure only, ignoring all method outcome fields."""
    from tools.datasets.audit_loris import fingerprints
    exposed_path = next((ROOT / path for path in freeze["pre_fetch_exposure_evidence"]
                         if path.endswith("/exposure-audit.json")), None)
    if exposed_path is None: raise ValueError("Missing complete pre-fetch exposure audit")
    exposure = json.loads(exposed_path.read_text())
    hashes = set(exposure["distinct_inputs"]) | set(exposure["historical_sources"].values())
    c_index = {name:defaultdict(list) for name in ("tokens", "alpha", "constant_shape")}
    for item in exposure["distinct_inputs"].values():
        for name, value in item.get("fingerprints", {}).items():
            c_index[name][value].extend(item["paths"])
    horn_index = {name:defaultdict(list) for name in ("alpha", "constant_shape")}
    seen, examined, eligible, failures = set(), 0, 0, 0
    # Distinct bytes prevent the many old proof/snapshot copies from changing
    # weighting.  Raw hashes cover every recorded byte, including missing paths.
    for relative, checksum in exposure["current_sources"].items():
        if Path(relative).suffix not in {".smt2", ".sl", ".c_smt"} or checksum in seen:
            continue
        path = ROOT / relative
        if not path.is_file(): continue
        raw = path.read_bytes()
        if sha(raw) != checksum: raise ValueError("Exposed historical bytes changed: " + relative)
        seen.add(checksum); examined += 1
        text = raw.decode("utf-8", errors="replace")
        # A three-VC benchmark is indexed through its exact function prefix;
        # original Horn inputs retain every assertion.  Generated proof query
        # values are never interpreted as outcomes or used to select inputs.
        if SPLIT in text:
            pieces = text.split(SPLIT)
            if len(pieces) != 5: continue
            text = pieces[0] + "true" + pieces[1]
        elif not any(token in text for token in ("HORN", "declare-rel", "forall")):
            continue
        eligible += 1
        try:
            for name, value in horn_fingerprints(text).items():
                horn_index[name][value].append(relative)
        except Exception:
            failures += 1
    for relative in freeze["pre_fetch_exposure_evidence"]:
        if relative.endswith("/source-downloads.json"):
            downloaded = json.loads((ROOT / relative).read_text())
            hashes.update(row["sha256"] for row in downloaded.get("sources", []))
    return exposure, hashes, c_index, horn_index, dict(distinct_SMT_bytes_read=examined,
        original_Horn_or_VC_prefixes_indexed=eligible, unsupported_fingerprint_prefixes=failures)


def audit(output, revision=None):
    import z3
    from tools.datasets.audit_loris import fingerprints
    output = Path(output).resolve()
    freeze, sources = selection(output)
    downloaded = check(output)
    # This is deliberately first: generated text is independent of the legacy
    # corpus's AST allocation history, and can be reproduced in a fresh worker.
    records = collect_models(output, sources)
    exposure, hashes, c_index, horn_index, history_counts = exposure_indices(freeze)
    staged = output / "review-models"
    for row in records:
        row["known_source_byte_match"] = row["source_sha256"] in hashes
        row["source_fingerprint_matches"] = {name:sorted(set(horn_index[name].get(value, [])))
            for name, value in row.get("source_fingerprints", {}).items()}
        if row["structural_status"] != "supported":
            row["decision"] = "unsupported"
            continue
        carrier, vc = row.pop("_carrier"), row.pop("_vc")
        row["known_VC_byte_match"] = row["vc_sha256"] in hashes
        row["carrier_fingerprint_matches"] = {name:sorted(set(c_index[name].get(value, [])))
            for name, value in fingerprints(carrier).items()}
        # A whole-source syntactic Horn comparison and a C carrier comparison
        # cannot prove mechanism novelty relative to a different C encoding.
        # Every supported nonlinear source therefore still needs manual review.
        matched = (row["known_source_byte_match"] or row["known_VC_byte_match"]
                   or any(row["source_fingerprint_matches"].values())
                   or any(row["carrier_fingerprint_matches"].values()))
        row["decision"] = ("exposed-regression-pending-review" if matched else
                           "nonlinear-pending-mechanism-review" if row["nonlinear_locations"] else
                           "linear-pending-regression-or-exclusion-review")
        identity = "eldarica-" + Path(row["source"]).stem + "-" + sha(row["source"].encode())[:8]
        row["model_identity"] = identity
        directory = staged / identity
        directory.mkdir(parents=True, exist_ok=True)
        for name, content in [("normalized.c", carrier), ("task.c_smt", vc)]:
            target = directory / name
            payload = content.encode()
            if target.exists():
                if target.read_bytes() != payload:
                    raise ValueError("Previously staged exact source model changed: " + str(target))
            else:
                with target.open("xb") as stream:
                    stream.write(payload)
    report = dict(schema="adasparce.eldarica-structure-exposure-audit.v1",
        generated_utc=datetime.now(timezone.utc).isoformat(), source_count=len(sources),
        selection_freeze_sha256=file_sha(output / "SELECTION_FROZEN.json"),
        source_downloads_sha256=file_sha(output / "source-downloads.json"),
        no_solver_or_method_inference=True, no_expected_regression_results_read=True,
        exact_converter="tools/experiments/new_family_chc.py",
        exact_converter_sha256=file_sha(ROOT / "tools/experiments/new_family_chc.py"),
        audit_script_sha256=file_sha(Path(__file__)), history_counts=history_counts,
        historical_family_labels=exposure["family_labels"],
        counts=dict(Counter(row["decision"] for row in records)),
        certified_unseen_nonlinear_families=0, no_test_manifest_emitted=True, records=records,
        limitations=["Nonlinear Horn-body branching is distinct from nonlinear arithmetic and is rejected by the declared one-predicate converter.",
            "Raw, alpha, erased-constant and carrier screens are exposure aids; nonmatches do not prove semantic or mechanism independence.",
            "All supported sources require manual mechanism review before any primary/regression manifest or final family freeze.",
            "Original source status is recorded but never used to select a task; unknown and unsafe classes remain eligible.",
            "Missing historical bytes and different source encodings prevent automatic certification of an unseen algorithm family.",
            "All upstream and derived source text is fetch-only; publish tools and metadata instead."])
    name = "structural-exposure-audit" + ("-" + revision if revision else "") + ".json"
    write_new(output / name, report)
    print(json.dumps(dict(source_count=len(sources), counts=report["counts"],
                         certified_unseen_nonlinear_families=0), indent=2))
    return report


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--timed-window-ended", action="store_true",
                        help="Required acknowledgement: this command parses the complete source/historical corpus")
    parser.add_argument("--revision", help="Preserve an earlier diagnostic audit under its original name")
    args = parser.parse_args()
    if not args.timed_window_ended:
        parser.error("Wait for the timing coordinator to end the formal window before structural parsing")
    if args.revision is not None and not re.fullmatch(r"[a-z0-9-]{1,20}", args.revision):
        parser.error("Invalid audit revision identifier")
    import z3
    original = z3.Solver.check
    def forbidden_check(*args, **kwargs):
        raise RuntimeError("Solver.check forbidden in pre-result structural/exposure audit")
    z3.Solver.check = forbidden_check
    try:
        audit(args.output, args.revision)
    finally:
        z3.Solver.check = original


if __name__ == "__main__":
    main()
