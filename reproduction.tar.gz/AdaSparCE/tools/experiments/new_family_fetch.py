"""Fetch the predeclared CHC-COMP source slice, without reading solver results.

Official pinned GitHub URLs identify the sources; a content CDN is a retrieval
fallback only.  No .yml competition result/majority-vote files are downloaded.
Licensing is deliberately NOASSERTION: public access is not a redistribution
license, and downstream publication should distribute this fetcher + hashes.

For an already frozen collection, the original download inventory is immutable.
Only missing upstream files are restored, using its original pinned hashes;
retrieval provenance and all selection/audit files remain byte-for-byte intact.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import json
from pathlib import Path, PurePosixPath
import urllib.request

from tools.experiments.new_family_audit import DEFAULT_OUT, dump, sha

PIN = "b4fa7a708e5863bbcdb5de50d692ead3a67cbedc"
REPOSITORY = "chc-comp/chc-comp26-benchmarks"
SET_SHA256 = "05e73db61e04b228231264765b91cbc043d27ce28e42088af173277b0045f058"


def download(relative, destination, *, expected_sha256=None, expected_bytes=None,
             missing_only=False):
    urls = ["https://raw.githubusercontent.com/%s/%s/%s" % (REPOSITORY, PIN, relative),
            "https://cdn.jsdelivr.net/gh/%s@%s/%s" % (REPOSITORY, PIN, relative)]
    errors = []
    for url in urls:
        try:
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            request = urllib.request.Request(url, headers={"User-Agent": "AdaSparCE-reproducible-family-audit"})
            with opener.open(request, timeout=15) as response:
                raw = response.read(2_000_001)
            if len(raw) > 2_000_000:
                raise ValueError("source-size-limit")
            if expected_sha256 is not None and sha(raw) != expected_sha256:
                raise ValueError("Pinned source hash differs: " + relative)
            if expected_bytes is not None and len(raw) != expected_bytes:
                raise ValueError("Pinned source size differs: " + relative)
            destination.parent.mkdir(parents=True, exist_ok=True)
            # A frozen restoration never overwrites an existing path, including
            # one created concurrently after the preflight verification.
            with destination.open("xb" if missing_only else "wb") as stream:
                stream.write(raw)
            return {"path": relative, "sha256": sha(raw), "bytes": len(raw),
                    "official_url": urls[0], "retrieval_url": url}
        except Exception as error:
            errors.append(type(error).__name__ + ": " + str(error))
    raise RuntimeError(relative + ": " + "; ".join(errors))


def _fetch_frozen(output):
    """Restore upstream bytes without changing frozen provenance or selection."""
    frozen = json.loads((output / "FROZEN.json").read_text(encoding="utf-8"))
    if frozen.get("schema") != "adasparce.source-family-freeze.v1":
        raise ValueError("Unknown family-freeze schema")
    frozen_files = frozen["files"]

    def bound_json(relative):
        raw = (output / relative).read_bytes()
        if sha(raw) != frozen_files.get(relative):
            raise ValueError("Frozen metadata changed: " + relative)
        return json.loads(raw)

    record = bound_json("source-downloads.json")
    bound_json("selection-policy.json")
    if (record.get("schema") != "adasparce.new-family-source-downloads.v1"
            or record.get("repository") != REPOSITORY
            or record.get("commit") != PIN
            or record.get("complete") is not True
            or record.get("failures")
            or len(record.get("sources", [])) != 55
            or record.get("selection_policy_sha256") != frozen_files.get("selection-policy.json")):
        raise ValueError("Frozen download inventory is incomplete or has a different pin/policy")

    metadata = record.get("metadata", [])
    if (len(metadata) != 2
            or {row["path"] for row in metadata} != {"LIA-Lin.set", "README.md"}):
        raise ValueError("Unexpected frozen upstream metadata inventory")
    root = output / "upstream" / "chc-comp26"
    if not root.resolve().is_relative_to(output):
        raise ValueError("Upstream directory escapes the frozen collection")
    entries = metadata + record["sources"]
    seen, missing = set(), []
    for row in entries:
        relative = row["path"]
        source_path = PurePosixPath(relative)
        if (source_path.is_absolute() or ".." in source_path.parts
                or str(source_path) != relative or relative in seen):
            raise ValueError("Invalid or duplicate frozen source path: " + relative)
        seen.add(relative)
        bound_path = "upstream/chc-comp26/" + relative
        official_url = "https://raw.githubusercontent.com/%s/%s/%s" % (REPOSITORY, PIN, relative)
        if (row["sha256"] != frozen_files.get(bound_path)
                or row["official_url"] != official_url
                or not isinstance(row.get("bytes"), int) or row["bytes"] < 0):
            raise ValueError("Source record disagrees with the freeze: " + relative)
        if relative == "LIA-Lin.set" and row["sha256"] != SET_SHA256:
            raise ValueError("Frozen source universe has a different pin")
        if relative not in {"LIA-Lin.set", "README.md"} and not (
                relative.startswith("extra-small-lia/") and relative.endswith(".smt2")):
            raise ValueError("Unexpected frozen benchmark source: " + relative)
        destination = root / relative
        if not destination.resolve().is_relative_to(root.resolve()):
            raise ValueError("Source destination escapes upstream directory: " + relative)
        if destination.exists():
            raw = destination.read_bytes()
            if sha(raw) != row["sha256"] or len(raw) != row["bytes"]:
                raise ValueError("Cached frozen source changed: " + relative)
        else:
            missing.append(row)
    expected_paths = {"upstream/chc-comp26/" + relative for relative in seen}
    if expected_paths != {relative for relative in frozen_files if relative.startswith("upstream/")}:
        raise ValueError("Frozen upstream files and download inventory differ")

    # All immutable metadata and existing sources have passed before any fetch.
    # Actual fallback retrieval URLs are deliberately not written back: this is
    # restoration of an evaluated collection, not a new provenance freeze.
    restored, failures = [], []
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as executor:
        futures = {
            executor.submit(download, row["path"], root / row["path"],
                            expected_sha256=row["sha256"], expected_bytes=row["bytes"],
                            missing_only=True): row["path"]
            for row in missing
        }
        for future in concurrent.futures.as_completed(futures):
            relative = futures[future]
            try:
                future.result()
                restored.append(relative)
                print("restored", relative, flush=True)
            except Exception as error:
                failures.append({"path": relative, "reason": str(error)})
    bound_json("source-downloads.json")
    bound_json("selection-policy.json")
    print(json.dumps({"frozen": True, "source_count": len(record["sources"]),
                      "restored_count": len(restored), "failures": sorted(failures, key=lambda x: x["path"]),
                      "complete": not failures}, indent=2))
    if failures:
        raise RuntimeError("Frozen upstream restoration failed for %d file(s); inventory unchanged" % len(failures))
    return record


def fetch(output=DEFAULT_OUT):
    output = Path(output).resolve()
    if (output / "FROZEN.json").exists():
        return _fetch_frozen(output)
    if not (output / "exposure-audit.json").exists():
        raise ValueError("Freeze the exposure audit before fetching fresh inputs")
    policy = {
        "schema": "adasparce.new-family-selection.v1", "date": "2026-10-18",
        "source": "https://github.com/" + REPOSITORY, "source_commit": PIN,
        "universe": "Every extra-small-lia entry in the official pinned LIA-Lin.set; no competition .yml files or solver outputs are read.",
        "support": "Exactly one nonzero-arity invariant predicate, 1–12 mathematical Int state parameters, positive single-predicate linear Horn bodies, explicit init/step/safety clauses; exact relational feature carrier; no arrays, bitvectors, Real/Bool predicate state, unknown functions or nested quantifiers.",
        "selection": "Syntactic/semantic support and history/family review only; exclude exact/alpha/constant-shape or known-family matches; keep at most one lexicographically first source per manually reviewed mechanism family. No method is executed before freeze.",
        "labels": "Preserve source set-info:status if present; otherwise unknown. Labels are not inferred from AdaSparCE or from competition result files. All label classes are eligible under the same structural/family policy.",
        "license": "NOASSERTION", "redistribution": "fetch-only; no permission to republish raw or derived upstream benchmark text is asserted",
        "C_baseline_boundary": "C-only systems must receive the faithful full relational carrier with all nondeterministic choices/constraints or be reported unsupported; never substitute a hand-simplified program.",
    }
    policy_path = output / "selection-policy.json"
    if policy_path.exists() and json.loads(policy_path.read_text()) != policy:
        raise ValueError("Existing source-selection policy differs")
    dump(policy_path, policy)
    root = output / "upstream" / "chc-comp26"
    set_path = root / "LIA-Lin.set"
    metadata = []
    for relative in ("LIA-Lin.set", "README.md"):
        path = root / relative
        if not path.exists(): metadata.append(download(relative, path))
        else: metadata.append({"path": relative, "sha256": sha(path.read_bytes()), "bytes": path.stat().st_size,
                               "official_url": "https://raw.githubusercontent.com/%s/%s/%s" % (REPOSITORY, PIN, relative), "retrieval_url": "verified-cache"})
    candidates = sorted(line.removeprefix("./").removesuffix(".yml") + ".smt2"
                        for line in set_path.read_text().splitlines() if line.startswith("./extra-small-lia/"))
    if sha(set_path.read_bytes()) != SET_SHA256:
        raise ValueError("Pinned LIA-Lin.set bytes differ")
    if len(candidates) != 55 or len(set(candidates)) != 55:
        raise ValueError("Unexpected pinned source universe")
    existing_path = output / "source-downloads.json"
    prior = {x["path"]: x for x in json.loads(existing_path.read_text()).get("sources", [])} if existing_path.exists() else {}
    records, failures = [], []
    def one(relative):
        path = root / relative
        if path.exists() and relative in prior:
            if sha(path.read_bytes()) != prior[relative]["sha256"]:
                raise ValueError("Cached source changed: " + relative)
            return prior[relative]
        return download(relative, path)
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as executor:
        futures = {executor.submit(one, path): path for path in candidates}
        for future in concurrent.futures.as_completed(futures):
            path = futures[future]
            try:
                records.append(future.result())
                print("fetched", path, flush=True)
            except Exception as error:
                failures.append({"path": path, "reason": str(error)})
    record = {"schema": "adasparce.new-family-source-downloads.v1", "repository": REPOSITORY, "commit": PIN,
              "selection_policy_sha256": sha(policy_path.read_bytes()), "metadata": metadata,
              "sources": sorted(records, key=lambda x: x["path"]), "failures": sorted(failures, key=lambda x: x["path"]),
              "complete": not failures and len(records) == 55,
              "license": "NOASSERTION", "redistribution": "fetch-only; upstream texts are locally fetched inputs, not a newly licensed dataset",
              "results_read": False}
    dump(existing_path, record)
    print(json.dumps({"source_count": len(records), "failures": failures, "complete": record["complete"]}, indent=2))
    return record


if __name__ == "__main__":
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUT)
    fetch(parser.parse_args().output)
