"""Semantics-preserving transport of static Horn source assertions.

Remove output-only requests and expand pure, nonrecursive SMT define-fun
helpers with the SMT parser.  Keep every declaration/state parameter and every
original rule.  Reparse the transported rules with predicate symbols left
uninterpreted and require exact typed AST identity, without any Solver call.
This does not change OnePredicateCHC or widen its accepted semantic fragment.
"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
import hashlib


class TransportUnsupported(ValueError):
    pass


@dataclass
class TransportResult:
    source: str
    evidence: dict


OUTPUT_ONLY = {"get-model", "get-proof", "get-unsat-core", "get-unsat-assumptions",
               "get-assignment", "get-assertions", "get-value", "get-info", "get-option", "echo", "exit"}
METADATA = {"set-logic", "set-info", "set-option"}
DECLARATIONS = {"declare-fun", "declare-const", "declare-sort", "define-sort",
                "declare-datatype", "declare-datatypes"}


def digest(text):
    return hashlib.sha256(text.encode()).hexdigest()


def transport(source):
    import z3
    from tools.experiments.new_family_chc import emit, sexprs
    commands = sexprs(source)
    original_prefix, target_prefix, emitted_prefix, assertions, emitted_queries = [], [], [], [], []
    removed, helpers, predicates = Counter(), [], []
    query_seen = False
    for command in commands:
        if not command or not isinstance(command[0], str):
            raise TransportUnsupported("non-command-source-form")
        name = command[0]
        if name in OUTPUT_ONLY:
            removed[name] += 1
        elif name in METADATA:
            # The parser works over the original explicit sorts.  Algorithm
            # options and source labels do not become logical assumptions.
            emitted_prefix.append(emit(command))
        elif name in {"check-sat", "query"}:
            # OnePredicateCHC already ignores these static query commands.
            # Preserve them for provenance; never ask Z3 to execute a query.
            emitted_queries.append(emit(command))
            query_seen = True
        elif name in {"push", "pop", "reset", "reset-assertions", "check-sat-assuming"}:
            raise TransportUnsupported("semantic-scope-or-assumption-command:" + name)
        elif name in {"define-fun-rec", "define-funs-rec"}:
            raise TransportUnsupported("recursive-helper-definition")
        elif name == "define-fun":
            if len(command) != 5 or not isinstance(command[2], list):
                raise TransportUnsupported("malformed-pure-helper")
            helpers.append(command[1])
            original_prefix.append(emit(command))
        elif name in {"assert", "rule"}:
            if len(command) != 2:
                raise TransportUnsupported("named-or-malformed-rule")
            if query_seen:
                raise TransportUnsupported("assertion-after-query-requires-script-scope-semantics")
            assertions.append((name, command[1], tuple(original_prefix), tuple(target_prefix)))
        elif name == "declare-rel":
            declaration = ["declare-fun", command[1], command[2], "Bool"]
            original_prefix.append(emit(declaration));target_prefix.append(emit(declaration))
            emitted_prefix.append(emit(command))
            if command[2]: predicates.append(dict(name=command[1], sorts=command[2], kind="uninterpreted"))
        elif name == "declare-var":
            declaration = ["declare-const", command[1], command[2]]
            original_prefix.append(emit(declaration));target_prefix.append(emit(declaration))
            # Retain fixedpoint's implicit universal binding for the unchanged
            # converter; do not turn it into a shared fixed program constant.
            emitted_prefix.append(emit(command))
        elif name in DECLARATIONS:
            original_prefix.append(emit(command));target_prefix.append(emit(command))
            emitted_prefix.append(emit(command))
            if name == "declare-fun" and len(command) == 4 and command[2] and command[3] == "Bool":
                predicates.append(dict(name=command[1], sorts=command[2], kind="uninterpreted"))
        else:
            raise TransportUnsupported("unsupported-semantic-command:" + name)
    if not assertions:
        raise TransportUnsupported("missing-source-assertions")
    rule_evidence, emitted_rules = [], []
    for index, (kind, body, rule_original_prefix, rule_target_prefix) in enumerate(assertions):
        original_header = "(set-logic ALL)\n" + "\n".join(rule_original_prefix) + "\n"
        target_header = "(set-logic ALL)\n" + "\n".join(rule_target_prefix) + "\n"
        try:
            # define-fun expansion is SMT's own capture-avoiding substitution;
            # predicates have their original uninterpreted declarations here.
            original = z3.parse_smt2_string(original_header + "(assert " + emit(body) + ")")
            if len(original) != 1:
                raise TransportUnsupported("requires-one-original-rule-AST")
            # Z3's default printer flattens associative AST nodes.  Disable
            # that formatting locally so reparsing preserves exact node
            # arities, instead of weakening the identity gate to equivalence.
            previous_flat_assoc = z3.get_param("pp.flat_assoc")
            z3.set_param("pp.flat_assoc", False)
            try:
                serialized = original[0].sexpr()
            finally:
                z3.set_param("pp.flat_assoc", previous_flat_assoc)
            target = z3.parse_smt2_string(target_header + "(assert " + serialized + ")")
            if len(target) != 1 or not z3.eq(original[0], target[0]):
                raise TransportUnsupported("typed-original-rule-AST-not-identical:" + str(index))
        except z3.Z3Exception as error:
            raise TransportUnsupported("typed-source-parser:" + str(error)) from error
        rule_evidence.append(dict(index=index, command=kind,
            original_expanded_AST_sha256=digest(original[0].sexpr()),
            transported_AST_sha256=digest(target[0].sexpr()),
            strict_typed_AST_identical=True, predicate_interpretations_supplied=False,
            solver_or_satisfiability_query=False))
        emitted_rules.append("(" + kind + " " + serialized + ")")
    result = "\n".join(emitted_prefix + emitted_rules + emitted_queries) + "\n"
    evidence = dict(schema="adasparce.pure-Horn-source-transport.v3",
        original_source_sha256=digest(source), transported_source_sha256=digest(result),
        removed_output_commands=dict(removed), expanded_pure_helpers=helpers,
        assertion_count=len(assertions), original_predicate_declarations=predicates,
        rules=rule_evidence, all_original_rule_ASTs_identical=True,
        no_invariant_substitution=True, no_solver_or_inference=True,
        fixedpoint_declare_var_and_rule_binding_preserved=True,
        SMT_printer_flat_assoc=False, printer_setting_restored=True,
        semantic_scope_not_widened=True)
    return TransportResult(result, evidence)
