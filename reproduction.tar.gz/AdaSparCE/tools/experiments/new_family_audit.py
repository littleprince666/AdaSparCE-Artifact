"""Freeze the conservative pre-evaluation exposure inventory (no solver calls).

Cached upstream inputs count as potentially exposed.  In particular, source
screening is not confused with a fresh unseen benchmark.  Historical inventory
entries whose files have disappeared remain part of the exposure record.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import subprocess
from zipfile import ZipFile

from tools.datasets.audit_loris import fingerprints

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_OUT = ROOT / "datasets/ICST2027-FamilyHoldout-20261018"
SOURCE_SUFFIXES = {".c", ".sl", ".smt2", ".c_smt"}
EXPOSURE_ROOTS = ("datasets", "baseline", "Result", "tests", "configs", "docs", "paper")
METADATA_NAMES = {"manifest.json", "run_manifest.json", "freeze.json", "families.json", "build_info.json"}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def dump(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n")


def walk_family_labels(value, found):
    if isinstance(value, dict):
        for key, item in value.items():
            if key in {"family", "family_name", "family_id"} and isinstance(item, str):
                found.add(item)
            walk_family_labels(item, found)
    elif isinstance(value, list):
        for item in value:
            walk_family_labels(item, found)


def audit(output: Path = DEFAULT_OUT):
    output = output.resolve()
    sources, metadata, labels, distinct = {}, {}, set(), {}
    for directory in EXPOSURE_ROOTS:
        for path in sorted((ROOT / directory).rglob("*")):
            if not path.is_file() or output == path or output in path.parents:
                continue
            relative = str(path.relative_to(ROOT))
            if path.suffix in SOURCE_SUFFIXES:
                raw = path.read_bytes()
                checksum = sha(raw)
                sources[relative] = checksum
                item = distinct.setdefault(checksum, {"paths": [], "kind": path.suffix})
                item["paths"].append(relative)
                if path.suffix == ".c" and "fingerprints" not in item:
                    item["fingerprints"] = fingerprints(raw.decode("utf-8", errors="replace"))
            elif path.name in METADATA_NAMES or path.name.startswith("FROZEN") and path.suffix == ".json":
                raw = path.read_bytes()
                metadata[relative] = sha(raw)
                try:
                    walk_family_labels(json.loads(raw), labels)
                except (ValueError, UnicodeDecodeError):
                    pass

    historical_path = ROOT / "Result/DatasetAudit/loris-source.json"
    historical = json.loads(historical_path.read_text()) if historical_path.exists() else {}
    historical_sources = historical.get("known_corpus_hashes", {})
    missing_historical = {p: checksum for p, checksum in historical_sources.items() if p not in sources}
    loris = ROOT / "datasets/_archive/sources/LORIS"
    loris_members = {}
    if (loris / "final_benchmarks.zip").exists():
        with ZipFile(loris / "final_benchmarks.zip") as archive:
            for listname in ("finalbenchmark.txt", "nonlinearbenchmark.txt"):
                for relative in (loris / "experiments" / listname).read_text().splitlines():
                    member = "final_benchmarks/" + relative.strip()
                    raw = archive.read(member)
                    checksum = sha(raw)
                    loris_members[member] = checksum
                    item = distinct.setdefault(checksum, {"paths": [], "kind": ".c"})
                    item["paths"].append("LORIS-archive:" + member)
                    item.setdefault("fingerprints", fingerprints(raw.decode("utf-8", errors="replace")))

    # Existing reports can refer to removed datasets.  Keep both the source
    # program inventory and the review evidence instead of claiming absence.
    labels.update({"geometric-product", "fibonacci-cassini", "prod4br"})
    history_raw = subprocess.check_output(
        ["git", "rev-list", "--objects", "--all", "--", "*.c", "*.sl", "*.smt2", "*.c_smt", "*manifest*.json", "*families*.json"],
        cwd=ROOT, text=True,
    )
    git_objects = [line.split(" ", 1) for line in history_raw.splitlines()]
    git_sources = {}
    for entry in git_objects:
        if len(entry) != 2 or Path(entry[1]).suffix not in SOURCE_SUFFIXES:
            continue
        kind = subprocess.check_output(["git", "cat-file", "-t", entry[0]], cwd=ROOT, text=True).strip()
        if kind != "blob":
            continue
        raw = subprocess.check_output(["git", "cat-file", "blob", entry[0]], cwd=ROOT)
        checksum = sha(raw)
        git_sources[entry[0] + ":" + entry[1]] = checksum
        item = distinct.setdefault(checksum, {"paths": [], "kind": Path(entry[1]).suffix})
        item["paths"].append("git:" + entry[0] + ":" + entry[1])
        if Path(entry[1]).suffix == ".c":
            item.setdefault("fingerprints", fingerprints(raw.decode("utf-8", errors="replace")))

    record = {
        "schema": "adasparce.new-family-exposure.v1", "date": "2026-10-18",
        "policy": "All current cached sources, all recorded historical corpus paths, reachable Git inputs, prior family metadata and LORIS pre-audit inputs are potentially exposed; an unproved history is external-regression, never unseen.",
        "current_sources": sources, "metadata_sha256": metadata,
        "historical_inventory_sha256": sha(historical_path.read_bytes()) if historical else None,
        "historical_sources": historical_sources, "missing_historical_paths": missing_historical,
        "loris_archive_members": loris_members, "reachable_git_sources": git_sources,
        "reachable_git_object_listing_sha256": sha(history_raw.encode()),
        "family_labels": sorted(labels), "distinct_inputs": distinct,
        "roles": {
            "PolyInvBench-26/release-v5": "development-or-previously-evaluated",
            "External-Generalization-Holdout-v2": "external-regression; 28 programs migrated into development",
            "dev_rebalance": "80 development programs: Quokka 33, External-v2 28, LoopInvGen 19",
            "IsolatedFamilies-14-v1": "external-regression; 14 variants of geometric-product, fibonacci-cassini and prod4br already evaluated",
            "Clause2Inv-LIN316/NL50": "development-regression",
            "LORIS": "source-pre-audited; all 510 source entries and 143 generated models are historically exposed; 120 pending review are not certified unseen",
        },
        "counts": {"current_sources": len(sources), "current_C_paths": sum(Path(p).suffix == ".c" for p in sources),
                   "historical_paths": len(historical_sources), "missing_historical_paths": len(missing_historical),
                   "loris_source_entries": len(loris_members), "distinct_input_bytes": len(distinct),
                   "metadata_files": len(metadata), "reachable_git_source_blobs": len(git_sources)},
        "limitations": ["This is a conservative exposure bound, not proof that every stored source influenced development.",
                       "Token, consistent-renaming and erased-constant fingerprints are screening aids, not semantic equivalence proofs.",
                       "Unknown historical bytes remain exposure evidence; matching source names or algorithm families requires exclusion even when the original file is absent.",
                       "No invariant inference, performance measurement, published solver results or learned answers are read by this audit."],
    }
    dump(output / "exposure-audit.json", record)
    print(json.dumps(record["counts"], ensure_ascii=False, indent=2))
    return record


if __name__ == "__main__":
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUT)
    audit(parser.parse_args().output)
