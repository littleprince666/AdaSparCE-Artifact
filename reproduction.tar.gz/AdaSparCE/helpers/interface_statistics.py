import json, random, statistics
from itertools import combinations
from pathlib import Path
from tools.experiments import supplemental_statistics as paired_statistics
FEATURES=('target', 'sparse_groups', 'boundary_partners')
def configurations():
 return json.loads((Path(__file__).resolve().parents[1]/"studies/semantic-interfaces/definition.json").read_text())["configs"]

def factorial_contrasts(rows, clusters, draws=10000, bootstrap_seed=20261019):
    """Prespecified secondary finite differences, averaged over other bits.

    A main effect averages the four enabled-minus-disabled contrasts. A
    two-factor interaction averages its two difference-of-differences;
    the three-factor interaction is the full third finite difference.
    """
    configs = configurations()
    task_values = {}
    for row in rows:
        key = 'NL50:' + row['id']
        task_values.setdefault((key, row['variant']), []).append((
            float(row['confirmed']), row['search_seconds'] if row['confirmed'] else 60.0))
    tasks = sorted({key for key, _ in task_values})
    means = {key: (statistics.mean(item[0] for item in values),
                   statistics.mean(item[1] for item in values))
             for key, values in task_values.items()}
    members = {}
    for key in tasks:
        members.setdefault(clusters[key]['cluster'], []).append(key)
    groups = list(members.values())
    contrasts = {}
    for order in (1, 2, 3):
        for subset in combinations(FEATURES, order):
            coefficients = {}
            for variant, config in configs.items():
                sign = 1
                for feature in subset:
                    sign *= 1 if config['transition_kernel_' + feature + '_enabled'] else -1
                coefficients[variant] = sign / (2 ** (3 - order))
            deltas = {key: tuple(sum(coefficients[variant] * means[key, variant][metric]
                                     for variant in configs) for metric in (0, 1)) for key in tasks}
            compressed = [(len(group), sum(deltas[key][0] for key in group),
                           sum(deltas[key][1] for key in group)) for group in groups]
            rng = random.Random(bootstrap_seed)
            coverage_draws, par2_draws = [], []
            for _ in range(draws):
                sample = [compressed[rng.randrange(len(compressed))] for _ in compressed]
                denominator = sum(item[0] for item in sample)
                coverage_draws.append(100 * sum(item[1] for item in sample) / denominator)
                par2_draws.append(sum(item[2] for item in sample) / denominator)
            contrasts[' × '.join(subset)] = dict(
                factors=list(subset), coefficients=coefficients,
                coverage_delta_percentage_points=100 * statistics.mean(item[0] for item in deltas.values()),
                coverage_delta_cluster_bootstrap_ci95=[paired_statistics.percentile(coverage_draws, .025),
                                                       paired_statistics.percentile(coverage_draws, .975)],
                par2_delta_seconds=statistics.mean(item[1] for item in deltas.values()),
                par2_delta_cluster_bootstrap_ci95=[paired_statistics.percentile(par2_draws, .025),
                                                 paired_statistics.percentile(par2_draws, .975)])
    return dict(contrasts=contrasts, draws=draws, bootstrap_seed=bootstrap_seed,
                interpretation='Secondary task-weighted factorial finite differences. Main effects are enabled minus disabled, averaged over other bits. Higher-order effects are averaged finite differences. Boundary pairing is inactive at target=0 by construction; report that dependency. Seeds are averaged within each task before family/VC-cluster bootstrap; descriptive intervals are not multiplicity-adjusted.')

