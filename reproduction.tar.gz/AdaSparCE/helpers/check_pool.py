import hashlib, json, sys, time, z3
from pathlib import Path
def digest(x): return hashlib.sha256(x.encode()).hexdigest()
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def proof_worker(job):
    """Independent plain original-text queries, no search/normalization calls."""
    if sha(job['vc_path'])!=job['vc_sha256']:
        raise ValueError('proof-input-changed')
    sections=Path(job['vc_path']).read_text().split('SPLIT_HERE_asdfghjklzxcvbnmqwertyuiop')
    if len(sections)!=5:
        raise ValueError('expected-five-original-sections')
    checks=[]
    for name,index in zip(('INIT','STEP','EXIT'),(2,3,4)):
        query=sections[0]+job['invariant_smtlib']+sections[1]+sections[index]
        solver=z3.Solver()
        solver.set(timeout=int(job['timeout_per_vc']*1000),random_seed=0)
        solver.add(z3.parse_smt2_string(query))
        started=time.perf_counter()
        status=solver.check()
        checks.append(dict(vc=name,status=str(status),seconds=time.perf_counter()-started,
            query_sha256=digest(query),reason_unknown=solver.reason_unknown() if status==z3.unknown else None,
            counterexample=str(solver.model()) if status==z3.sat else None))
    return dict(key=job['key'],status='verified' if all(c['status']=='unsat' for c in checks) else 'unverified',
                checks=checks,z3=z3.get_version_string())


print(json.dumps(proof_worker(json.load(sys.stdin))))
