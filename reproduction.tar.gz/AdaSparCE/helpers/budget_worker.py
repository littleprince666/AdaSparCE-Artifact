import json, os, signal, subprocess, sys, time
from pathlib import Path
from tools.experiments.full_recovery import sha
def run_one(output, frozen, job):
    trace = Path(job['command'][job['command'].index('--log-jsonl') + 1])
    trace.parent.mkdir(parents=True, exist_ok=True)
    stdout = trace.with_suffix('.stdout')
    if trace.exists() or stdout.exists():
        raise ValueError('Preserve and resolve unrecorded/interrupted artifacts before resuming')
    env = dict(os.environ, **frozen['environment'], PYTHONDONTWRITEBYTECODE='1',
               PYTHONHASHSEED=str(job['seed']))
    started = time.perf_counter()
    killed = False
    with stdout.open('w') as stream:
        process = subprocess.Popen(job['command'], cwd=output / 'sources/full', env=env,
            stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            process.wait(timeout=frozen['hard_process_timeout'])
        except subprocess.TimeoutExpired:
            killed = True
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
    result = None
    if not killed and process.returncode == 0:
        for line in reversed(stdout.read_text().splitlines()):
            try:
                value = json.loads(line)
                if isinstance(value, dict) and 'status' in value:
                    result = value
                    break
            except json.JSONDecodeError:
                pass
    if result is None:
        result = dict(status='hard-timeout' if killed else 'error',
                      reason='returncode-' + str(process.returncode))
    if not trace.exists():
        trace.write_text(json.dumps(dict(event='runner_missing_trace', **result)) + '\n')
    result.update({name: job[name] for name in ('variant', 'seed', 'id')})
    result.update(wall_time=time.perf_counter() - started,
        trace=str(trace.relative_to(output)), trace_sha256=sha(trace),
        stdout=str(stdout.relative_to(output)), stdout_sha256=sha(stdout),
        freeze_sha256=sha(output / 'freeze.json'))
    return result

