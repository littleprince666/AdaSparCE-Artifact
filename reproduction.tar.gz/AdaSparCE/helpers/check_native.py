import ast, hashlib, json, operator, re, sys, time, z3
from pathlib import Path
REPO=Path("/")
SPLIT="SPLIT_HERE_asdfghjklzxcvbnmqwertyuiop"
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def invariant_symbols(smt):
    match = re.search(r"\(\s*define-fun\s+inv-f\s*\((.*?)\)\s*Bool", smt, re.S)
    if not match:
        raise ValueError("missing invariant interface")
    pairs = re.findall(r"\(\s*([^\s()]+)\s+(Int|Real)\s*\)", match[1])
    if not pairs or len({p[0] for p in pairs}) != len(pairs):
        raise ValueError("empty or duplicate invariant variables")
    return {name: z3.Int(name) if sort == "Int" else z3.Real(name) for name, sort in pairs}


def parse_invariant(text, symbols):
    if not isinstance(text, str) or len(text) > 1_000_000:
        raise ValueError("invalid printed invariant")
    tree = ast.parse(text, mode="eval")
    if sum(1 for _ in ast.walk(tree)) > 10000:
        raise ValueError("invariant AST too large")
    binary = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
              ast.Div: operator.truediv, ast.Mod: operator.mod, ast.Pow: operator.pow}
    compare = {ast.Eq: operator.eq, ast.NotEq: operator.ne, ast.Lt: operator.lt,
               ast.LtE: operator.le, ast.Gt: operator.gt, ast.GtE: operator.ge}
    functions = {name: getattr(z3, name) for name in
                 ("And", "Or", "Not", "Implies", "If", "Xor", "Distinct", "ToReal", "ToInt", "Abs")}

    def visit(node):
        if isinstance(node, ast.Name) and node.id in symbols:
            return symbols[node.id]
        if isinstance(node, ast.Constant):
            if type(node.value) is bool:
                return z3.BoolVal(node.value)
            if type(node.value) is int:
                return z3.IntVal(node.value)
            if type(node.value) is float:
                return z3.RealVal(ast.get_source_segment(text, node))
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.USub, ast.UAdd)):
            value = visit(node.operand)
            return -value if isinstance(node.op, ast.USub) else value
        if isinstance(node, ast.BinOp) and type(node.op) in binary:
            # Printed `1/2` is ambiguous between a rational literal and
            # constant integer division. Do not silently invent a sort.
            if isinstance(node.op, ast.Div) and not any(isinstance(n, ast.Name) for n in ast.walk(node)):
                raise ValueError("ambiguous constant division in printed invariant")
            if isinstance(node.op, ast.Pow) and (not isinstance(node.right, ast.Constant)
                    or type(node.right.value) is not int or not 0 <= node.right.value <= 100):
                raise ValueError("unsupported exponent")
            return binary[type(node.op)](visit(node.left), visit(node.right))
        if isinstance(node, ast.Compare) and len(node.ops) == 1 and type(node.ops[0]) in compare:
            return compare[type(node.ops[0])](visit(node.left), visit(node.comparators[0]))
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in functions and not node.keywords:
            return functions[node.func.id](*(visit(arg) for arg in node.args))
        raise ValueError("unsupported printed invariant syntax: " + type(node).__name__)

    result = visit(tree.body)
    if not z3.is_bool(result):
        raise ValueError("invariant is not Boolean")
    return result


def raw_queries(smt, invariant):
    sections = smt.split(SPLIT)
    if len(sections) != 5:
        raise ValueError("expected exactly three VC sections")
    expression = parse_invariant(invariant, invariant_symbols(smt))
    return [sections[0] + expression.sexpr() + sections[1] + sections[i] for i in (2, 3, 4)]


def check_one(job):
    smt = (REPO / job["vc_path"]).read_text()
    if sha(REPO / job["vc_path"]) != job["vc_sha256"]:
        raise ValueError("VC changed before checking")
    rows = []
    for name, query in zip(("INIT", "STEP", "EXIT"), raw_queries(smt, job["invariant"])):
        start = time.perf_counter()
        solver = z3.Solver()
        solver.set(timeout=int(1000 * job["timeout_per_vc"]), random_seed=0)
        solver.add(z3.parse_smt2_string(query))
        status = solver.check()
        rows.append({"vc": name, "status": str(status), "seconds": time.perf_counter() - start,
                     "query_sha256": hashlib.sha256(query.encode()).hexdigest(),
                     "reason_unknown": solver.reason_unknown() if status == z3.unknown else None,
                     "counterexample": str(solver.model()) if status == z3.sat else None})
    return {"key": job["key"], "vc_sha256": job["vc_sha256"], "invariant": job["invariant"],
            "status": "verified" if all(r["status"] == "unsat" for r in rows) else "unverified",
            "checks": rows, "z3": z3.get_version_string()}


print(json.dumps(check_one(json.load(sys.stdin))))
