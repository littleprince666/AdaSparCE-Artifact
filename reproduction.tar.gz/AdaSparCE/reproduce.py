"""Re-run the paper's fixed studies without any historical result files."""
from __future__ import annotations

import argparse
import concurrent.futures
import csv
from datetime import datetime, timezone
import hashlib
from importlib.metadata import version
import importlib.util
import json
import math
import os
from pathlib import Path
import statistics
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    temporary.replace(path)


def relocate(value, output=None, original=None):
    if isinstance(value, dict):
        return {relocate(k, output, original): relocate(v, output, original) for k, v in value.items()}
    if isinstance(value, list):
        return [relocate(v, output, original) for v in value]
    if isinstance(value, str):
        if original and value.startswith("@PACKAGE@/" + original + "/"):
            return str(output) + value[len("@PACKAGE@/" + original):]
        return value.replace("@PACKAGE@", str(ROOT))
    return value


def definition(study):
    return read(ROOT / "studies" / study / "definition.json")


def validate_dependencies(d):
    if sys.version_info[:3] != (3, 14, 4):
        raise ValueError("The evaluated interpreter is Python 3.14.4; use that version for the fixed protocol")
    pins = {"z3-solver": "5.1.0.0", "sympy": "1.14.0", "pycparser": "3.0", "mpmath": "1.3.0"}
    actual = {name: version(name) for name in pins}
    if actual != pins:
        raise ValueError("Install requirements.txt in the active environment: " + str(actual))
    if "cvc5" in d["variants"]:
        from tools.experiments.strong_baseline_protocol import inspect_method
        checked = inspect_method("cvc5")
        if not checked["available"]:
            raise ValueError("Install the cvc5 isolated dependencies; " + str(checked["reasons"]))
    if "dig" in d["variants"]:
        from tools.experiments.strong_baseline_protocol import inspect_method
        checked = inspect_method("dig")
        if not checked["available"]:
            raise ValueError("Install the pinned DIG source/dependencies; " + str(checked["reasons"]))
    return actual


def materialize(tree, destination):
    for name, object_path in tree.items():
        target = destination / name
        target.parent.mkdir(parents=True, exist_ok=True)
        data = (ROOT / object_path).read_bytes()
        if hashlib.sha256(data).hexdigest() != Path(object_path).stem:
            raise ValueError("Runtime source object changed: " + object_path)
        target.write_bytes(data)


def prepare(args):
    d = definition(args.study)
    # Smoke subsets have their own explicit output and never change the
    # published study definitions or the denominator of a formal run.
    if (args.tasks or args.variants or args.seeds) and not args.smoke:
        raise ValueError("Subset options require --smoke")
    if args.smoke:
        ids = args.tasks.split(",") if args.tasks else [d["tasks"][0]["id"]]
        variants = args.variants.split(",") if args.variants else [d["variants"][0]]
        seeds = [int(v) for v in args.seeds.split(",")] if args.seeds else [0]
        if not set(ids) <= {t["id"] for t in d["tasks"]} or not set(variants) <= set(d["variants"]) or not set(seeds) <= set(d["seeds"]):
            raise ValueError("Foreign task, variant or seed")
        d["tasks"] = [t for t in d["tasks"] if t["id"] in ids]
        d["variants"], d["seeds"] = variants, seeds
        d["jobs"] = [j for j in d["jobs"] if j["id"] in ids and j["variant"] in variants and j["seed"] in seeds]
    pins = validate_dependencies(d)
    output = args.output.resolve()
    if output.exists():
        raise ValueError("Choose a new output directory; existing runs are never overwritten")
    dataset = ROOT / d["dataset"]
    needed = {}
    for t in d["tasks"]:
        for name in ("normalized.c", "task.c_smt"):
            path = dataset / t["relative_path"] / name
            relative = path.relative_to(ROOT).as_posix()
            if not path.is_file():
                raise FileNotFoundError(relative + "; first run python restore_inputs.py --group all")
            if sha(path) != d["input_sha256"][relative]:
                raise ValueError("Input differs from the evaluated bytes: " + relative)
            needed[str(path)] = sha(path)
    output.mkdir(parents=True)
    from tools.experiments.supplemental_statistics import freeze_clusters
    freeze_clusters({d["dataset_name"]: dataset}, output / "clusters.json")
    state = dict(study=d["id"], kind=d["kind"], smoke=args.smoke,
                 expected_runs=len(d["jobs"]), workers=d["workers"],
                 created_utc=datetime.now(timezone.utc).isoformat(),
                 definition_sha256=sha(ROOT / "studies" / args.study / "definition.json"),
                 package_manifest_sha256=sha(ROOT / "manifest.json"))
    if d["kind"] == "pool":
        materialize(d["trees"]["shared"], output / "source")
        (output / "pools").mkdir()
        for t in d["tasks"]:
            pool = relocate(read(ROOT / d["pool_files"][t["id"]]))
            write(output / "pools" / (t["id"] + ".json"), pool)
        protocol = output / "protocol.md"
        protocol.write_text("Fixed pre-result Q0, original equal generation charges, same order, original replay code and original-VC acceptance.\n")
        spec = dict(schema="adasparce.minimal-pool-reexecution.v1", tasks=d["tasks"],
            variants=d["variants"], seeds=d["seeds"], dataset=str(dataset),
            full_collection=not args.smoke,
            budget_seconds=d["budget"], candidate_seconds=d["candidate_seconds"],
            max_checks=d["max_checks"], author_representation=d["author_representation"],
            source_hashes={str(p.relative_to(output / "source")): sha(p)
                           for p in sorted((output / "source").rglob("*")) if p.is_file()},
            inputs=needed, python=sys.version,
            dependencies={k: pins[k] for k in ("z3-solver", "sympy", "pycparser")},
            protocol_sha256=sha(protocol))
        write(output / "spec.json", spec)
        pools = {"pools/" + t["id"] + ".json": sha(output / "pools" / (t["id"] + ".json")) for t in d["tasks"]}
        write(output / "freeze.json", dict(schema=spec["schema"], spec_sha256=sha(output / "spec.json"),
            pool_hashes=pools, jobs=d["jobs"], expected=len(d["jobs"]),
            source_hashes=spec["source_hashes"], protocol_sha256=spec["protocol_sha256"]))
    else:
        from tools.experiments import full_recovery
        for variant in d["variants"]:
            materialize(d["trees"][variant], output / "sources" / variant)
        jobs = []
        for j in d["jobs"]:
            item = dict(j)
            if d["kind"] == "native":
                command = relocate(item["command"])
                command[0] = sys.executable
                command[command.index("--log-jsonl") + 1] = str(output / "runs" / item["variant"] / ("seed" + str(item["seed"])) / "traces" / (item["id"] + ".jsonl"))
                item["command"] = command
            jobs.append(item)
        configs = {v: d["configs"][v] for v in d["variants"]}
        if d["kind"] == "cold":
            from tools.experiments.strong_baseline_protocol import DEPENDENCIES
            for v, config in configs.items():
                config["author_root"] = str(output / "sources" / v / "author") if config["author_root"] else None
                config["dependency_path"] = str(DEPENDENCIES[v])
        frozen = dict(schema="adasparce.minimal-reexecution.v1", dataset=str(dataset),
            dataset_name=d["dataset_name"], tasks=d["tasks"], variants=d["variants"], seeds=d["seeds"],
            budget=d["budget"], hard_process_timeout=d["budget"] + 23, jobs=jobs,
            workers=d["workers"], configs=configs, environment=d["environment"], inputs=needed,
            source_hashes=full_recovery.sources(output), runner_sha256=sha(full_recovery.__file__),
            python=sys.version, z3=__import__("z3").get_version_string())
        write(output / "freeze.json", frozen)
    state["freeze_sha256"] = sha(output / "freeze.json")
    write(output / "reproduction.json", state)
    print(json.dumps(state, indent=2))


def state_for(output):
    state = read(output / "reproduction.json")
    if state["freeze_sha256"] != sha(output / "freeze.json"):
        raise ValueError("Prepared protocol changed; create a new run directory")
    if state["package_manifest_sha256"] != sha(ROOT / "manifest.json"):
        raise ValueError("Package manifest changed")
    if state["definition_sha256"] != sha(ROOT / "studies" / state["study"] / "definition.json"):
        raise ValueError("Study definition changed")
    return state


def pool_action(output, state, action):
    module = "joint_pool_study" if state["study"] == "joint-pool" else "shared_pool_study"
    subprocess.run([sys.executable, "-B", "-m", "tools.experiments." + module, action,
                    "--output", str(output), "--workers", str(state["workers"])],
                   cwd=output / "source", check=True)


def run(output):
    state = state_for(output)
    d = definition(state["study"])
    d["variants"] = read(output / ("spec.json" if state["kind"] == "pool" else "freeze.json"))["variants"]
    validate_dependencies(d)
    if state["kind"] == "pool":
        pool_action(output, state, "run")
        return
    from tools.experiments import full_recovery
    if state["kind"] == "native" and d["budget"] == 30:
        full_recovery.run(output, workers=state["workers"])
        return
    import fcntl
    with (output / "run.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        frozen = full_recovery.audit(output)
        path = output / "results.jsonl"
        rows = [json.loads(line) for line in path.read_text().splitlines()] if path.exists() else []
        expected = {(j["variant"], j["seed"], j["id"]) for j in frozen["jobs"]}
        seen = {(r["variant"], r["seed"], r["id"]) for r in rows}
        if len(seen) != len(rows) or not seen <= expected:
            raise ValueError("Duplicate or foreign result")
        for r in rows:
            if r["freeze_sha256"] != sha(output / "freeze.json"):
                raise ValueError("Stale result")
            for name in ("trace", "stdout", "stderr"):
                if name in r and sha(output / r[name]) != r[name + "_sha256"]:
                    raise ValueError("Changed run artifact")
        if state["kind"] == "cold":
            from tools.experiments.strong_baseline_protocol import run_one
        else:
            spec = importlib.util.spec_from_file_location("budget_worker", ROOT / "helpers/budget_worker.py")
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            run_one = module.run_one
        pending = [j for j in frozen["jobs"] if (j["variant"], j["seed"], j["id"]) not in seen]
        with concurrent.futures.ThreadPoolExecutor(max_workers=state["workers"]) as pool:
            for row in pool.map(lambda j: run_one(output, frozen, j), pending):
                with path.open("a") as stream:
                    stream.write(json.dumps(row) + "\n")
                    stream.flush()
                    os.fsync(stream.fileno())
                rows.append(row)
                print(len(rows), "/", len(expected), row["status"], flush=True)
        write(output / "completion.json", dict(complete=len(rows) == len(expected), rows=len(rows),
            results_sha256=sha(path), freeze_sha256=sha(output / "freeze.json")))


def reverify(output):
    state = state_for(output)
    if state["kind"] == "pool":
        pool_action(output, state, "reverify")
        return
    frozen = read(output / "freeze.json")
    rows = [json.loads(line) for line in (output / "results.jsonl").read_text().splitlines()]
    if len(rows) != len(frozen["jobs"]) or not read(output / "completion.json")["complete"]:
        raise ValueError("Complete every search before independent checking")
    tasks = {t["id"]: t for t in frozen["tasks"]}
    directory = output / "reverification"
    directory.mkdir(exist_ok=True)
    for row in rows:
        if row["status"] != "solved":
            continue
        vc = Path(frozen["dataset"]) / tasks[row["id"]]["relative_path"] / "task.c_smt"
        key = hashlib.sha256(json.dumps([sha(vc), row["invariant"]]).encode()).hexdigest()
        job = dict(key=key, vc_path=str(vc), vc_sha256=sha(vc), invariant=row["invariant"], timeout_per_vc=60)
        target = directory / (key + ".json")
        checker_hash = sha(ROOT / "helpers/check_native.py")
        if target.exists():
            cached = read(target)
            if cached["job"] != job or cached["checker_sha256"] != checker_hash:
                raise ValueError("Stale independent proof")
            continue
        try:
            process = subprocess.run([sys.executable, "-B", str(ROOT / "helpers/check_native.py")],
                input=json.dumps(job), text=True, capture_output=True, timeout=195)
            result = json.loads(process.stdout) if process.returncode == 0 else dict(status="error", detail=process.stderr)
        except subprocess.TimeoutExpired:
            result = dict(status="hard-timeout")
        write(target, dict(job=job, result=result, checker_sha256=checker_hash))
    write(output / "proof-completion.json", dict(freeze_sha256=sha(output / "freeze.json"),
        results_sha256=sha(output / "results.jsonl"), checker_sha256=sha(ROOT / "helpers/check_native.py")))


def report(output):
    state = state_for(output)
    if state["kind"] == "pool":
        pool_action(output, state, "report")
        if not state["smoke"]:
            from tools.experiments.supplemental_statistics import summarize
            with (output / "confirmed-results.csv").open() as stream:
                records = list(csv.DictReader(stream))
            paired = summarize(records, read(output / "clusters.json")["tasks"], "ada_c")
            write(output / "paired-statistics.json", paired)
        return
    frozen = read(output / "freeze.json")
    done = read(output / "completion.json")
    proof_done = read(output / "proof-completion.json")
    if not done["complete"] or done["results_sha256"] != proof_done["results_sha256"] or sha(output / "results.jsonl") != done["results_sha256"]:
        raise ValueError("Incomplete or changed search/proof records")
    raw = [json.loads(line) for line in (output / "results.jsonl").read_text().splitlines()]
    expected = {(j["variant"], j["seed"], j["id"]) for j in frozen["jobs"]}
    if len(raw) != len(expected) or {(r["variant"], r["seed"], r["id"]) for r in raw} != expected:
        raise ValueError("Incomplete, duplicate or foreign identities")
    tasks = {t["id"]: t for t in frozen["tasks"]}
    records = []
    for r in raw:
        elapsed = r.get("total_time")
        within = (r["status"] == "solved" and isinstance(elapsed, (int, float))
                  and math.isfinite(elapsed) and 0 <= elapsed <= frozen["budget"])
        verified, statuses = False, ""
        vc = Path(frozen["dataset"]) / tasks[r["id"]]["relative_path"] / "task.c_smt"
        if r["status"] == "solved":
            key = hashlib.sha256(json.dumps([sha(vc), r["invariant"]]).encode()).hexdigest()
            proof = read(output / "reverification" / (key + ".json"))["result"]
            statuses = "/".join(c["status"] for c in proof.get("checks", []))
            verified = proof["status"] == "verified" and statuses == "unsat/unsat/unsat"
        checks, solver_seconds = 0, 0.0
        if state["kind"] == "native":
            for line in (output / r["trace"]).read_text().splitlines():
                e = json.loads(line)
                if e.get("event") in ("ada_candidate", "iteration") and "checker_time_ms" in e:
                    checks += 1
                    solver_seconds += e["checker_time_ms"] / 1000
        confirmed = within and verified
        records.append(dict(dataset=frozen["dataset_name"], variant=r["variant"], seed=r["seed"],
            id=r["id"], raw_vc_sha256=sha(vc), status=r["status"], confirmed=confirmed,
            search_seconds=elapsed, candidate_checks=checks, checker_seconds=solver_seconds,
            confirmed_par2_seconds=elapsed if confirmed else 2 * frozen["budget"], vc_statuses=statuses))
    with (output / "confirmed-results.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)
    metrics = {}
    for v in frozen["variants"]:
        group = [r for r in records if r["variant"] == v]
        solved = [r for r in group if r["confirmed"]]
        metrics[v] = dict(confirmed_per_seed=[sum(r["confirmed"] and r["seed"] == s for r in group) for s in frozen["seeds"]],
            mean_confirmed=len(solved) / len(frozen["seeds"]),
            mean_solved_seconds=statistics.mean(r["search_seconds"] for r in solved) if solved else None,
            confirmed_par2_seconds=statistics.mean(r["confirmed_par2_seconds"] for r in group),
            confirmed_within_seconds={str(t): sum(r["search_seconds"] <= t for r in solved) / len(frozen["seeds"])
                                      for t in (1, 5, 10, 30) if t <= frozen["budget"]})
    write(output / "confirmed-summary.json", dict(smoke=state["smoke"], metrics=metrics,
        rows=len(records), expected=len(expected), historical_results_used=False))
    if not state["smoke"]:
        from tools.experiments.supplemental_statistics import summarize
        reference = "ada" if state["kind"] == "cold" else "full"
        clusters = read(output / "clusters.json")["tasks"]
        write(output / "paired-statistics.json", summarize(records, clusters, reference, budget=frozen["budget"]))
        if state["study"] == "semantic-interfaces":
            spec = importlib.util.spec_from_file_location("interface_statistics", ROOT / "helpers/interface_statistics.py")
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            write(output / "factorial-statistics.json", module.factorial_contrasts(records, clusters))
    print(json.dumps(metrics, indent=2))


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("action", choices=("list", "prepare", "run", "reverify", "report"))
    parser.add_argument("--study", choices=list(read(ROOT / "studies/index.json")))
    parser.add_argument("--output", type=Path)
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--tasks")
    parser.add_argument("--variants")
    parser.add_argument("--seeds")
    args = parser.parse_args()
    if args.action == "list":
        print(json.dumps(read(ROOT / "studies/index.json"), indent=2))
        return
    if args.output is None or args.action == "prepare" and args.study is None:
        parser.error("--output is required; prepare also requires --study")
    if args.action == "prepare":
        prepare(args)
    else:
        {"run": run, "reverify": reverify, "report": report}[args.action](args.output.resolve())


if __name__ == "__main__":
    main()
