# Third-party sources

Benchmark manifests retain original provenance. New-source cohorts are fetch-only.

Clause2Inv combinator: https://github.com/SoftWiser-group/Clause2Inv at 326a84b468663e3921917c5e57857a1808626d9d; only the three replay input source files are retained.

DIG: https://github.com/dynaroars/dig at 8ef9d04f982e7f46d7d4cf0f705d8311573c0b47; only the evaluated src code is retained. Its original LICENSE is included below.

No new license grant is made for third-party benchmarks or code.
