"""Verification components for AdaSparCE."""
