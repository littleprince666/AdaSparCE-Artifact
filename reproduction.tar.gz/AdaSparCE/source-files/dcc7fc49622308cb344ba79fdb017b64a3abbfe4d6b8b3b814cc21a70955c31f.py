"""Deterministic sparse-heuristic ICE loop."""

import time
from dataclasses import dataclass
from itertools import product

from SMT_Solver.Config import config as baseline_config
from SMT_Solver.SMT_verifier import CheckFailureType, SMT_verifier

from SparCE.logging_utils import JsonlLogger, stable_hash
from SparCE.symbolic.monomials import MonomialPool
from SparCE.symbolic.template_solver import IncrementalTemplateSolver
from SparCE.symbolic.templates import PolynomialClause, PolynomialTemplate
from SparCE.symbolic.variables import candidate_variables


@dataclass
class SparseConfig:
    max_degree: int = 2
    max_monomials: int = 12
    max_clauses: int = 1
    coefficient_bounds: tuple = (1, 2, 4, 8)
    timeout_seconds: float = 30.0
    template_timeout_seconds: float = 5.0
    checker_timeout_seconds: float = 10.0
    relations: tuple = ("=", ">=", "<=")
    enable_template_cache: bool = True
    enable_candidate_cache: bool = True
    enable_pruning: bool = False
    max_candidates_per_structure: int = 12
    # Global number of calls to the final SMT checker.  Zero keeps the
    # historical time-budget-only behaviour.
    max_checker_calls: int = 0
    seed: int = 0
    # Monomial-priority feedback (E module): boost pool monomials whose
    # sources match the observed failure type.  Disabling it keeps the
    # initial syntactic ranking fixed for the whole run — the minimal
    # CEGIS base still accumulates positive/negative/implication
    # counterexample constraints on the template solver.
    monomial_feedback: bool = True


@dataclass
class SparseRunResult:
    status: str
    invariant: object
    candidate: object
    total_time: float
    iterations: int
    reason: str = None
    checker_calls: int = 0


class SparseHeuristicEngine:
    def __init__(self, sparse_config=None, log_path=None):
        self.config = sparse_config or SparseConfig()
        self.logger = JsonlLogger(log_path)
        self.template_cache = {}
        self.candidate_cache = set()
        # Absolute task deadline (perf_counter seconds); set by run() so
        # every checker call and template solve is clamped to the
        # configured program budget.
        self._task_deadline = None
        if int(getattr(self.config, "max_checker_calls", 0)) < 0:
            raise ValueError("max_checker_calls must be nonnegative")
        self._pruner = None
        if getattr(self.config, "enable_pruning", False):
            from SparCE.search.pruner import CandidatePruner
            self._pruner = CandidatePruner()

    @staticmethod
    def _kind(failure_type):
        return {
            CheckFailureType.INIT: "p",
            CheckFailureType.STEP: "i",
            CheckFailureType.EXIT: "n",
        }[failure_type]

    def _feedback(self, pool, failure_type, feedback):
        wanted = {
            CheckFailureType.INIT: {"pre"},
            CheckFailureType.STEP: {"update", "dependency"},
            CheckFailureType.EXIT: {"post"},
        }.get(failure_type, set())
        for monomial in pool.ranked():
            if pool.sources(monomial).intersection(wanted):
                feedback[monomial] = feedback.get(monomial, 0.0) + 2.0

    def _solver(
        self,
        variables,
        support,
        relations,
        counterexamples,
        cache_namespace,
    ):
        polynomial_clauses = tuple(
            PolynomialClause(tuple(support), relation) for relation in relations
        )
        template = PolynomialTemplate(
            variables,
            polynomial_clauses,
            coefficient_prefix="sp_{}_{}_{}".format(
                len(relations),
                "_".join(
                    relation.replace("=", "e").replace("<", "l").replace(">", "g")
                    for relation in relations
                ),
                len(support),
            ),
        )
        key = (cache_namespace, template.canonical_key)
        if self.config.enable_template_cache and key in self.template_cache:
            solver = self.template_cache[key]
            solver.add_all(counterexamples)
            return template, solver, True
        # Clamp the template-solver timeout to the remaining task budget
        # so a solve started near the deadline cannot overshoot it.
        template_timeout = self.config.template_timeout_seconds
        if self._task_deadline is not None:
            remaining = self._task_deadline - time.perf_counter()
            template_timeout = max(0.05, min(template_timeout, remaining))
        solver = IncrementalTemplateSolver(
            template, timeout_seconds=template_timeout
        )
        solver.add_all(counterexamples)
        if self.config.enable_template_cache:
            self.template_cache[key] = solver
        return template, solver, False

    def run(self, program_id, c_path, smt_path):
        started = time.perf_counter()
        self._task_deadline = started + self.config.timeout_seconds
        if self._pruner is not None:
            self._pruner.reset()
        variables = candidate_variables(c_path, smt_path)
        if not variables:
            raise ValueError("could not parse program variables from {}".format(c_path))
        pool = MonomialPool.seed_from_program(
            c_path, variables, max_degree=self.config.max_degree
        )
        ranked = pool.ranked(max_items=self.config.max_monomials)
        if len(ranked) < 2:
            raise ValueError("monomial pool contains no nonconstant feature")

        counterexamples = {"p": [], "n": [], "i": []}
        counterexample_keys = {"p": set(), "n": set(), "i": set()}
        feedback = {}
        verifier = SMT_verifier()
        verifier.wall_deadline = self._task_deadline
        previous_checker_timeout = baseline_config.SMT_CHECK_TIME
        baseline_config.SMT_CHECK_TIME = self.config.checker_timeout_seconds
        iteration = 0
        checker_calls = 0
        last_reason = "search-space-exhausted"

        try:
            for clause_count in range(1, self.config.max_clauses + 1):
                phase_deadline = started + self.config.timeout_seconds
                if clause_count < self.config.max_clauses:
                    phase_deadline = started + self.config.timeout_seconds * 0.2
                relation_sets = product(self.config.relations, repeat=clause_count)
                for relations in relation_sets:
                    seeded_size = min(
                        len(ranked), max(2, len(variables) + 2)
                    )
                    support_sizes = sorted(set((seeded_size, len(ranked))))
                    for support_size in support_sizes:
                        support = pool.ranked(
                            max_items=support_size, feedback=feedback
                        )
                        template, solver, template_cache_hit = self._solver(
                            variables,
                            support,
                            relations,
                            counterexamples,
                            (program_id, smt_path),
                        )
                        total_coefficients = sum(
                            len(coefficients) for coefficients in template.coefficients
                        )
                        minimum_nonzero = clause_count
                        structure_attempts = 0
                        for coefficient_bound in self.config.coefficient_bounds:
                            for maximum_nonzero in range(
                                minimum_nonzero, total_coefficients + 1
                            ):
                                while (
                                    time.perf_counter() - started
                                    < self.config.timeout_seconds
                                    and time.perf_counter() < phase_deadline
                                    and structure_attempts
                                    < self.config.max_candidates_per_structure
                                    and (
                                        not self.config.max_checker_calls
                                        or checker_calls
                                        < self.config.max_checker_calls
                                    )
                                ):
                                    iteration += 1
                                    solve_timeout = None
                                    if self._task_deadline is not None:
                                        solve_timeout = max(
                                            0.05,
                                            self._task_deadline
                                            - time.perf_counter(),
                                        )
                                    solve_result = solver.solve(
                                        coefficient_bound,
                                        maximum_nonzero,
                                        timeout_seconds=solve_timeout,
                                    )
                                    base_record = {
                                        "event": "iteration",
                                        "program_id": program_id,
                                        "seed": self.config.seed,
                                        "iteration": iteration,
                                        "template_mode": "sparse-heuristic",
                                        "monomials": [
                                            monomial.pretty_print(variables)
                                            for monomial in support
                                        ],
                                        "relations": list(relations),
                                        "max_degree": template.max_degree,
                                        "coefficient_bound": coefficient_bound,
                                        "maximum_nonzero": maximum_nonzero,
                                        "template_result": solve_result.status,
                                        "template_time_ms": solve_result.solver_time * 1000,
                                        "cache_hit": template_cache_hit,
                                    }
                                    if solve_result.status != "sat":
                                        self.logger.write(base_record)
                                        last_reason = solve_result.status
                                        break

                                    candidate = solve_result.candidate
                                    structure_attempts += 1
                                    candidate_key = (
                                        program_id,
                                        smt_path,
                                        candidate.canonical_key,
                                    )
                                    candidate_cache_hit = (
                                        self.config.enable_candidate_cache
                                        and candidate_key in self.candidate_cache
                                    )
                                    solver.block_coefficients(
                                        solve_result.coefficient_values
                                    )
                                    if candidate_cache_hit:
                                        base_record.update(
                                            {
                                                "checker_result": "skipped-duplicate",
                                                "candidate": candidate.pretty_print(),
                                                "candidate_hash": stable_hash(candidate_key),
                                                "candidate_monomials": candidate.number_of_monomials,
                                                "candidate_ast_size": candidate.ast_size,
                                            }
                                        )
                                        self.logger.write(base_record)
                                        continue
                                    self.candidate_cache.add(candidate_key)

                                    if self._pruner is not None:
                                        if not self._pruner.should_check(candidate):
                                            base_record.update(
                                                {
                                                    "checker_result": "pruned",
                                                    "candidate": candidate.pretty_print(),
                                                    "candidate_hash": stable_hash(candidate_key),
                                                    "candidate_monomials": candidate.number_of_monomials,
                                                    "candidate_ast_size": candidate.ast_size,
                                                }
                                            )
                                            self.logger.write(base_record)
                                            continue

                                    check_result = verifier.check(
                                        candidate.to_z3(), smt_path
                                    )
                                    checker_calls += 1
                                    base_record.update(
                                        {
                                            "checker_result": check_result.status,
                                            "failure_type": check_result.failure_type.value,
                                            "checker_time_ms": check_result.solver_time * 1000,
                                            "query_size": check_result.query_size,
                                            "candidate": candidate.pretty_print(),
                                            "candidate_hash": check_result.candidate_hash,
                                            "candidate_monomials": candidate.number_of_monomials,
                                            "candidate_ast_size": candidate.ast_size,
                                            "counterexample_hash": (
                                                stable_hash(check_result.counterexample)
                                                if check_result.counterexample is not None
                                                else None
                                            ),
                                        }
                                    )
                                    self.logger.write(base_record)

                                    if (
                                        self._pruner is not None
                                        and check_result.counterexample is not None
                                    ):
                                        self._pruner.record_counterexample(
                                            check_result.counterexample
                                        )

                                    if (
                                        check_result.failure_type
                                        == CheckFailureType.SUCCESS
                                    ):
                                        total = time.perf_counter() - started
                                        self.logger.write(
                                            {
                                                "event": "final",
                                                "program_id": program_id,
                                                "status": "solved",
                                                "total_time_seconds": total,
                                                "iterations": iteration,
                                                "candidate": candidate.pretty_print(),
                                            }
                                        )
                                        return SparseRunResult(
                                            "solved",
                                            candidate.to_z3(),
                                            candidate,
                                            total,
                                            iteration,
                                            checker_calls=checker_calls,
                                        )

                                    if check_result.failure_type in (
                                        CheckFailureType.TIMEOUT,
                                        CheckFailureType.UNKNOWN,
                                    ):
                                        last_reason = check_result.failure_type.value.lower()
                                        break

                                    kind = self._kind(check_result.failure_type)
                                    ce_key = stable_hash(check_result.counterexample)
                                    if ce_key not in counterexample_keys[kind]:
                                        counterexample_keys[kind].add(ce_key)
                                        counterexamples[kind].append(
                                            check_result.counterexample
                                        )
                                        solver.add_counterexample(
                                            kind, check_result.counterexample
                                        )
                                    if self.config.monomial_feedback:
                                        self._feedback(
                                            pool,
                                            check_result.failure_type,
                                            feedback,
                                        )
                                if (
                                    time.perf_counter() - started
                                    >= self.config.timeout_seconds
                                    or time.perf_counter() >= phase_deadline
                                    or structure_attempts
                                    >= self.config.max_candidates_per_structure
                                    or last_reason in ("timeout", "unknown")
                                    or (
                                        self.config.max_checker_calls
                                        and checker_calls
                                        >= self.config.max_checker_calls
                                    )
                                ):
                                    break
                            if (
                                time.perf_counter() - started
                                >= self.config.timeout_seconds
                                or time.perf_counter() >= phase_deadline
                                or structure_attempts
                                >= self.config.max_candidates_per_structure
                                or (
                                    self.config.max_checker_calls
                                    and checker_calls
                                    >= self.config.max_checker_calls
                                )
                            ):
                                break
                        if (
                            time.perf_counter() - started
                            >= self.config.timeout_seconds
                            or time.perf_counter() >= phase_deadline
                            or (
                                self.config.max_checker_calls
                                and checker_calls
                                >= self.config.max_checker_calls
                            )
                        ):
                            break
                    if (
                        time.perf_counter() - started >= self.config.timeout_seconds
                        or (
                            self.config.max_checker_calls
                            and checker_calls >= self.config.max_checker_calls
                        )
                    ):
                        break
                if (
                    time.perf_counter() - started >= self.config.timeout_seconds
                    or (
                        self.config.max_checker_calls
                        and checker_calls >= self.config.max_checker_calls
                    )
                ):
                    break
        finally:
            baseline_config.SMT_CHECK_TIME = previous_checker_timeout

        total = time.perf_counter() - started
        status = (
            "timeout" if total >= self.config.timeout_seconds else "failed"
        )
        if (
            self.config.max_checker_calls
            and checker_calls >= self.config.max_checker_calls
        ):
            last_reason = "checker-budget-exhausted"
        self.logger.write(
            {
                "event": "final",
                "program_id": program_id,
                "status": status,
                "reason": last_reason,
                "total_time_seconds": total,
                "iterations": iteration,
                "checker_calls": checker_calls,
            }
        )
        return SparseRunResult(
            status,
            None,
            None,
            total,
            iteration,
            reason=last_reason,
            checker_calls=checker_calls,
        )
