"""Adaptive mechanism prioritizer: replaces hardcoded bonus with empirical rates.

Two layers:
  1. EMPIRICAL_SUCCESS_RATES — static prior from dev traces (P0-A)
  2. AdaptiveMechanismPrioritizer — per-task online UCB-style updates (P0-B)

The combined bonus is:
    bonus = alpha * empirical_rate * 100 + (1 - alpha) * online_bonus(mechanism)

where online_bonus uses UCB-style exploration after >= 3 observations.
"""

from collections import defaultdict


EMPIRICAL_SUCCESS_RATES = {
    "typed-affine-exit-boundary":      0.667,  # 4/6
    "typed-counter-lift":              0.429,  # 12/28
    "postcondition-seed":              0.268,  # 48/179
    "typed-precondition-frame":        0.091,  # 9/99
    "typed-monotone-entry-bounds":     0.068,  # 11/162
    "typed-update-closure":            0.045,  # 4/89
    "typed-remaining-work":            0.000,  # 0/307
    "typed-counter-lift+sync":         0.000,  # 0/3
    "typed-sign-clauses":              0.000,  # 0/124
    "typed-counter-boundary":          0.000,  # 0/3
    "typed-counter-boundary+sync":     0.000,  # 0/1
    "vc-linear-spacer-cover":          0.10,   # default for vc-* (not in dev traces)
    "vc-finite-difference-closure":    0.10,
    "vc-counter-lifted-difference-closure": 0.10,
}

DEFAULT_RATE = 0.05
EMPIRICAL_ALPHA = 0.6
EXPLORE_THRESHOLD = 3
EXPLORE_BONUS = 5.0
EXPLORE_DECAY = 0.5


def empirical_bonus(mechanism):
    """Static bonus from dev trace success rates (P0-A)."""
    rate = EMPIRICAL_SUCCESS_RATES.get(mechanism, DEFAULT_RATE)
    return rate * 100.0


class AdaptiveMechanismPrioritizer:
    """Per-task online mechanism priority with UCB-style exploration (P0-B).

    Call update() after each checker result, call bonus() to get the current
    adaptive bonus for a mechanism.  Within a single task run, mechanisms
    that fail repeatedly are automatically demoted.
    """

    def __init__(self):
        self._stats = defaultdict(lambda: {"tried": 0, "success": 0})
        self._last_failure = {}

    def update(self, mechanism, failure_type_value):
        self._stats[mechanism]["tried"] += 1
        if failure_type_value == "SUCCESS":
            self._stats[mechanism]["success"] += 1
        else:
            self._last_failure[mechanism] = failure_type_value

    def bonus(self, mechanism):
        s = self._stats[mechanism]
        tried = s["tried"]
        if tried < EXPLORE_THRESHOLD:
            return EXPLORE_BONUS * (EXPLORE_DECAY ** tried)
        rate = s["success"] / tried
        explore = EXPLORE_DECAY / (tried ** 0.5)
        return rate * 50.0 + explore * 10.0

    def stats(self):
        return dict(self._stats)

    def reset(self):
        self._stats.clear()
        self._last_failure.clear()


def combined_bonus(mechanism, prioritizer=None):
    """Combine static empirical prior with online adaptive bonus."""
    static = empirical_bonus(mechanism)
    if prioritizer is None:
        return static
    online = prioritizer.bonus(mechanism)
    return EMPIRICAL_ALPHA * static + (1.0 - EMPIRICAL_ALPHA) * online
