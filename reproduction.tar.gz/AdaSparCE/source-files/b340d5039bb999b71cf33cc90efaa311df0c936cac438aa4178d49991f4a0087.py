"""Pinned author DIG: fresh source analysis, no cached traces or invariants."""
from pathlib import Path
import re
import runpy
import sys
import time

from .common import Unsupported, raw_problem, printed_invariant, SPLIT


def instrument(source, parameters):
    """Add one loop-head observation to scalar single-loop C.

    Uninitialized locals become arbitrary mainQ inputs; initializers keep
    their original order. Reject unsupported constructs rather than invent
    transitions, guards, bounds or assumptions. No reference invariant input.
    """
    from pycparser import c_parser, c_ast, c_generator
    if any(sort != 'Int' for _, sort in parameters):
        raise Unsupported('DIG C adapter currently supports scalar integer interfaces only')
    source = re.sub(r'/\*.*?\*/|//[^\n]*', '', source, flags=re.S)
    if '#' in source:
        raise Unsupported('preprocessor input needs a separately audited C frontend')
    try:
        ast = c_parser.CParser().parse(source)
    except Exception as error:
        raise Unsupported('C parser rejected source: ' + type(error).__name__) from error
    if len(ast.ext) != 1 or not isinstance(ast.ext[0], c_ast.FuncDef) or ast.ext[0].decl.name != 'main':
        raise Unsupported('expected one standalone main function')
    function = ast.ext[0]
    body = function.body
    declarations = [node for node in body.block_items or [] if isinstance(node, c_ast.Decl)]
    names = [node.name for node in declarations]
    if not names or len(names) != len(set(names)) or not {name for name, _ in parameters} <= set(names):
        raise Unsupported('loop interface must be represented by unique top-level C locals')
    if any(not isinstance(node.type, c_ast.TypeDecl) or not isinstance(node.type.type, c_ast.IdentifierType)
           or node.type.type.names != ['int'] or node.storage or node.quals for node in declarations):
        raise Unsupported('only plain int local declarations are supported')
    loops = []

    def check(node):
        if isinstance(node, (c_ast.For, c_ast.DoWhile, c_ast.Goto, c_ast.Label, c_ast.ArrayRef,
                             c_ast.StructRef, c_ast.Cast, c_ast.Switch)):
            raise Unsupported('unsupported source construct: ' + type(node).__name__)
        if isinstance(node, c_ast.While):
            loops.append(node)
        if isinstance(node, c_ast.Decl) and node not in declarations and node.name:
            raise Unsupported('nested declarations need an audited scope conversion')
        if isinstance(node, c_ast.BinaryOp) and node.op in ('/', '%', '<<', '>>', '&', '|', '^'):
            raise Unsupported('C division/modulo/bitwise semantics are not silently mapped to mathematical integers')
        if isinstance(node, c_ast.FuncCall) and (not isinstance(node.name, c_ast.ID)
                                               or node.name.name not in ('assume', '__VERIFIER_assume', 'assert')):
            raise Unsupported('unsupported source function call')
        if isinstance(node, c_ast.Constant) and node.type != 'int':
            raise Unsupported('non-integer C literal')
        for _, child in node.children():
            check(child)

    check(body)
    if len(loops) != 1 or loops[0] not in (body.block_items or []):
        raise Unsupported('only one top-level while loop is currently instrumented')
    generator = c_generator.CGenerator()
    statements = []
    for node in body.block_items:
        if isinstance(node, c_ast.Decl):
            if node.init is not None:
                statements.append(node.name + ' = ' + generator.visit(node.init) + ';')
        elif node is loops[0]:
            original = generator.visit(node.stmt)
            statements.append('while (1) {\n vtrace1(' + ', '.join(name for name, _ in parameters) + ');\n'
                              + ' if (!(' + generator.visit(node.cond) + ')) break;\n' + original + '\n}')
        else:
            statements.append(generator.visit(node) + (';' if not isinstance(node, (c_ast.Compound, c_ast.If)) else ''))
    content = '\n'.join(statements)
    content = re.sub(r'\b(?:assume|__VERIFIER_assume)\s*\(', 'vassume(', content)
    main_args = ', '.join('int ' + name for name in names)
    trace_args = ', '.join('int ' + name for name, _ in parameters)
    source = ('#include <stdlib.h>\n#include <assert.h>\n'
              'void vassume(int b) {}\nvoid vtrace1(' + trace_args + ') {}\n'
              'int mainQ(' + main_args + ') {\n' + content + '\nreturn 0;\n}\n'
              'int main(int argc, char **argv) { return mainQ('
              + ', '.join(f'atoi(argv[{i+1}])' for i in range(len(names))) + '); }\n')
    return source


def run(request):
    # The pinned upstream explicitly requires Z3 4.16.0.0. The independent
    # proof checker later uses the experiment environment's Z3 5.1.0.
    import z3
    if z3.get_version_string() != '4.16.0':
        raise RuntimeError('author DIG requires its pinned z3-solver==4.16.0.0 dependency environment')
    text = Path(request['vc']).read_text()
    _, parameters, _ = raw_problem(text)
    work = Path(request['workdir'])
    program = work / 'instrumented.c'
    program.write_text(instrument(Path(request['c']).read_text(), parameters))
    author = Path(request['author_root'])
    sys.path.insert(0, str(author / 'src'))
    sys.argv = [str(author / 'src/dig.py'), str(program), '-seed', str(request['seed']),
                '-log_level', '1', '-tmpdir', str(work), '-writeresults', str(work / 'author-results.txt')]
    namespace = runpy.run_path(str(author / 'src/dig.py'), run_name='__main__')
    result = namespace.get('dinvs')
    if not result or 'vtrace1' not in result:
        return dict(status='unknown', reason='author DIG returned no invariant at the instrumented loop head')
    inferred = sorted([inv.expr for inv in result['vtrace1']], key=lambda expr: expr.sexpr())
    body = z3.And(*inferred).sexpr()
    (work / 'author-invariant.smt2').write_text(body + '\n')
    invariant = printed_invariant(body, parameters)
    # DIG's symbolic-state checks alone do not prove the original postcondition.
    # The natural conjunction of its loop-head invariants must itself discharge
    # all three original obligations within the same search deadline.
    checks = []
    parts = text.split(SPLIT)
    for label, section in zip(('INIT', 'STEP', 'EXIT'), parts[2:]):
        remaining = request['deadline_monotonic'] - time.monotonic()
        if remaining <= 0:
            return dict(status='timeout', reason='deadline reached before original-VC acceptance')
        solver = z3.Solver()
        # Acceptance shares the full outer deadline. An extra four-second
        # slice can reject a valid author formula despite unused task time.
        solver.set(timeout=max(1, int(1000*remaining)), random_seed=request['seed'])
        solver.add(z3.parse_smt2_string(parts[0] + body + parts[1] + section))
        checks.append(dict(vc=label, status=str(solver.check())))
    return dict(status='solved' if all(check['status']=='unsat' for check in checks) else 'unknown',
                reason='author-DIG-conjunction-original-VC', invariant=invariant,
                invariant_smt2=body, in_budget_raw_checks=checks, inferred_invariants=len(inferred))
