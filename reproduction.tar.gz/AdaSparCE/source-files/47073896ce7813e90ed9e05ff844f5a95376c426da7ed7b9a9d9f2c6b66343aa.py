"""Search components for AdaSparCE."""
