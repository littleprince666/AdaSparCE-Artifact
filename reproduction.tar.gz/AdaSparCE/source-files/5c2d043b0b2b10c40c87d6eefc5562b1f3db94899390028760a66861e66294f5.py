"""Canonical monomials and program-guided candidate pools."""

from collections import defaultdict
from dataclasses import dataclass
from itertools import combinations_with_replacement

import z3
from pycparser import c_ast, parse_file


@dataclass(frozen=True, order=True)
class Monomial:
    """A monomial represented uniquely by an exponent vector."""

    exponents: tuple

    def __post_init__(self):
        values = tuple(int(value) for value in self.exponents)
        if any(value < 0 for value in values):
            raise ValueError("monomial exponents must be non-negative")
        object.__setattr__(self, "exponents", values)

    @property
    def degree(self):
        return sum(self.exponents)

    @property
    def variables_used(self):
        return tuple(i for i, exponent in enumerate(self.exponents) if exponent)

    @property
    def canonical_key(self):
        return self.exponents

    def evaluate(self, concrete_state, variables=None):
        if variables is None:
            if not isinstance(concrete_state, (list, tuple)):
                raise ValueError("variables are required for mapping states")
            values = concrete_state
        else:
            values = [concrete_state.get(name, 0) for name in variables]
        result = 1
        for value, exponent in zip(values, self.exponents):
            result *= int(str(value)) ** exponent
        return result

    def to_z3(self, symbolic_variables):
        if len(symbolic_variables) != len(self.exponents):
            raise ValueError("symbol count does not match exponent vector")
        factors = []
        for symbol, exponent in zip(symbolic_variables, self.exponents):
            factors.extend([symbol] * exponent)
        if not factors:
            return z3.IntVal(1)
        return z3.Product(factors)

    def pretty_print(self, variables):
        factors = []
        for name, exponent in zip(variables, self.exponents):
            if exponent == 1:
                factors.append(name)
            elif exponent > 1:
                factors.append("{}^{}".format(name, exponent))
        return "*".join(factors) if factors else "1"


@dataclass(frozen=True, order=True)
class ExtendedTerm:
    """A non-polynomial template term: mod(x, d) or div(x, d).

    The operand is a single-variable monomial (typically a bare variable);
    the divisor is either an integer constant or another single-variable
    monomial.  Terms are evaluated concretely inside the linear template
    solver, so the ICE constraints stay linear in the coefficients.
    """

    op: str
    operand: tuple
    divisor: object

    def __post_init__(self):
        if self.op not in ("mod", "div"):
            raise ValueError("unsupported extended term {}".format(self.op))
        operand_values = tuple(int(value) for value in self.operand)
        object.__setattr__(self, "operand", operand_values)
        if isinstance(self.divisor, int):
            object.__setattr__(self, "divisor", int(self.divisor))
        elif isinstance(self.divisor, (tuple, list)):
            divisor_values = tuple(int(value) for value in self.divisor)
            object.__setattr__(self, "divisor", divisor_values)
        else:
            raise ValueError("divisor must be int or exponent tuple")

    @property
    def degree(self):
        return 1

    @property
    def variables_used(self):
        operand_vars = tuple(
            i for i, exponent in enumerate(self.operand) if exponent
        )
        if isinstance(self.divisor, tuple):
            divisor_vars = tuple(
                i for i, exponent in enumerate(self.divisor) if exponent
            )
            return tuple(sorted(set(operand_vars) | set(divisor_vars)))
        return operand_vars

    @property
    def canonical_key(self):
        if isinstance(self.divisor, int):
            divisor_key = ("c", self.divisor)
        else:
            divisor_key = ("v", self.divisor)
        return (self.op, self.operand, divisor_key)

    def _operand_value(self, concrete_state, variables):
        if variables is None:
            values = concrete_state
        else:
            values = [concrete_state.get(name, 0) for name in variables]
        result = 1
        for value, exponent in zip(values, self.operand):
            result *= int(str(value)) ** exponent
        return result

    def _divisor_value(self, concrete_state, variables):
        if isinstance(self.divisor, int):
            return self.divisor
        if variables is None:
            values = concrete_state
        else:
            values = [concrete_state.get(name, 0) for name in variables]
        result = 1
        for value, exponent in zip(values, self.divisor):
            result *= int(str(value)) ** exponent
        return result

    def evaluate(self, concrete_state, variables=None):
        operand = self._operand_value(concrete_state, variables)
        divisor = self._divisor_value(concrete_state, variables)
        if divisor == 0:
            return 0
        if self.op == "mod":
            return operand % divisor
        return operand // divisor

    def to_z3(self, symbolic_variables):
        if len(symbolic_variables) != len(self.operand):
            raise ValueError("symbol count does not match operand vector")
        operand_factors = []
        for symbol, exponent in zip(symbolic_variables, self.operand):
            operand_factors.extend([symbol] * exponent)
        operand_expr = (
            z3.Product(operand_factors) if operand_factors else z3.IntVal(1)
        )
        if isinstance(self.divisor, int):
            divisor_expr = z3.IntVal(self.divisor)
        else:
            divisor_factors = []
            for symbol, exponent in zip(symbolic_variables, self.divisor):
                divisor_factors.extend([symbol] * exponent)
            divisor_expr = (
                z3.Product(divisor_factors)
                if divisor_factors
                else z3.IntVal(1)
            )
        if self.op == "mod":
            return operand_expr % divisor_expr
        return operand_expr / divisor_expr

    def pretty_print(self, variables):
        operand_parts = []
        for name, exponent in zip(variables, self.operand):
            if exponent == 1:
                operand_parts.append(name)
            elif exponent > 1:
                operand_parts.append("{}^{}".format(name, exponent))
        operand_str = "*".join(operand_parts) if operand_parts else "1"
        if isinstance(self.divisor, int):
            divisor_str = str(self.divisor)
        else:
            divisor_parts = []
            for name, exponent in zip(variables, self.divisor):
                if exponent == 1:
                    divisor_parts.append(name)
                elif exponent > 1:
                    divisor_parts.append("{}^{}".format(name, exponent))
            divisor_str = "*".join(divisor_parts) if divisor_parts else "1"
        return "{}({}, {})".format(self.op, operand_str, divisor_str)


def _term_sort_key(term):
    """Order monomials before extended terms, preserving monomial order."""
    if isinstance(term, Monomial):
        return (0, term.canonical_key)
    return (1, term.canonical_key)


class _ProgramFeatureVisitor(c_ast.NodeVisitor):
    def __init__(self, variable_index):
        self.variable_index = variable_index
        self.sources = defaultdict(set)
        self.sources_extended = defaultdict(set)
        self.dependencies = defaultdict(set)
        self._context = "program"
        self._assignment_target = None

    def _monomial(self, node):
        size = len(self.variable_index)
        if isinstance(node, c_ast.ID) and node.name in self.variable_index:
            exponents = [0] * size
            exponents[self.variable_index[node.name]] = 1
            return tuple(exponents)
        if isinstance(node, c_ast.Constant):
            return (0,) * size
        if isinstance(node, c_ast.UnaryOp):
            return self._monomial(node.expr)
        if isinstance(node, c_ast.BinaryOp) and node.op == "*":
            left = self._monomial(node.left)
            right = self._monomial(node.right)
            if left is not None and right is not None:
                return tuple(a + b for a, b in zip(left, right))
        return None

    def _extended_term(self, node):
        size = len(self.variable_index)
        if not isinstance(node, c_ast.BinaryOp):
            return None
        if node.op not in ("%", "/"):
            return None
        operand = self._monomial(node.left)
        if operand is None:
            return None
        divisor_node = node.right
        if isinstance(divisor_node, c_ast.Constant):
            try:
                divisor = int(divisor_node.value, 0)
            except ValueError:
                return None
        else:
            divisor = self._monomial(divisor_node)
            if divisor is None:
                return None
        return ExtendedTerm("mod" if node.op == "%" else "div", operand, divisor)

    def _collect_expression(self, node, source):
        direct = self._monomial(node)
        if direct is not None:
            self.sources[direct].add(source)
        extended = self._extended_term(node)
        if extended is not None:
            self.sources_extended[extended].add(source)
        if isinstance(node, c_ast.BinaryOp):
            self._collect_expression(node.left, source)
            self._collect_expression(node.right, source)
        elif isinstance(node, c_ast.UnaryOp):
            self._collect_expression(node.expr, source)
        elif isinstance(node, c_ast.FuncCall) and node.args is not None:
            self._collect_expression(node.args, source)
        elif isinstance(node, c_ast.ExprList):
            for expr in node.exprs:
                self._collect_expression(expr, source)

    def _ids(self, node):
        names = set()

        class IDVisitor(c_ast.NodeVisitor):
            def visit_ID(self, child):
                if child.name in self_outer.variable_index:
                    names.add(child.name)

        self_outer = self
        IDVisitor().visit(node)
        return names

    def visit_Assignment(self, node):
        target = node.lvalue.name if isinstance(node.lvalue, c_ast.ID) else None
        self._collect_expression(node.rvalue, "update")
        if target in self.variable_index:
            for dependency in self._ids(node.rvalue):
                self.dependencies[target].add(dependency)
        self.generic_visit(node)

    def visit_While(self, node):
        self._collect_expression(node.cond, "guard")
        self.generic_visit(node)

    def visit_If(self, node):
        self._collect_expression(node.cond, "guard")
        self.generic_visit(node)

    def visit_FuncCall(self, node):
        name = node.name.name if isinstance(node.name, c_ast.ID) else ""
        if node.args is not None:
            if name == "assert":
                self._collect_expression(node.args, "post")
            elif name == "assume":
                self._collect_expression(node.args, "pre")
        self.generic_visit(node)


class MonomialPool:
    """A deterministic pool with source annotations and stable ranking."""

    SOURCE_WEIGHTS = {
        "post": 12.0,
        "update": 10.0,
        "guard": 5.0,
        "pre": 4.0,
        "dependency": 6.0,
        "enumerated": 0.0,
        "base": 8.0,
    }

    def __init__(self, variables):
        self.variables = tuple(variables)
        self._items = {}
        self.dependencies = defaultdict(set)

    def add(self, monomial, source="enumerated"):
        if len(monomial.exponents) != len(self.variables):
            raise ValueError("monomial arity mismatch")
        self._items.setdefault(monomial, set()).add(source)

    def add_extended(self, term, source="enumerated"):
        if len(term.operand) != len(self.variables):
            raise ValueError("extended term operand arity mismatch")
        if isinstance(term.divisor, tuple) and len(term.divisor) != len(self.variables):
            raise ValueError("extended term divisor arity mismatch")
        self._items.setdefault(term, set()).add(source)

    @property
    def constant(self):
        return Monomial((0,) * len(self.variables))

    @classmethod
    def enumerate_all(cls, variables, max_degree):
        pool = cls(variables)
        size = len(variables)
        pool.add(Monomial((0,) * size), "base")
        for degree in range(1, max_degree + 1):
            for indices in combinations_with_replacement(range(size), degree):
                exponents = [0] * size
                for index in indices:
                    exponents[index] += 1
                pool.add(Monomial(tuple(exponents)), "enumerated")
        return pool

    @classmethod
    def seed_from_program(cls, path, variables, max_degree=2):
        pool = cls.enumerate_all(variables, max_degree)
        index = {name: i for i, name in enumerate(variables)}
        ast = parse_file(path, use_cpp=True)
        visitor = _ProgramFeatureVisitor(index)
        visitor.visit(ast)
        pool.dependencies.update(visitor.dependencies)
        for exponents, sources in visitor.sources.items():
            monomial = Monomial(exponents)
            if monomial.degree <= max_degree:
                for source in sources:
                    pool.add(monomial, source)
        for term, sources in visitor.sources_extended.items():
            for source in sources:
                pool.add_extended(term, source)
        pool._add_dependency_candidates(max_degree)
        return pool

    def _add_dependency_candidates(self, max_degree):
        if max_degree < 2:
            return
        index = {name: i for i, name in enumerate(self.variables)}
        for target, dependencies in self.dependencies.items():
            related = set(dependencies)
            related.add(target)
            for degree in range(2, max_degree + 1):
                for names in combinations_with_replacement(
                    sorted(related), degree
                ):
                    exponents = [0] * len(self.variables)
                    for name in names:
                        exponents[index[name]] += 1
                    monomial = Monomial(tuple(exponents))
                    if monomial.degree <= max_degree:
                        self.add(monomial, "dependency")
        related_globally = set(self.dependencies)
        for dependencies in self.dependencies.values():
            related_globally.update(dependencies)
        for degree in range(2, max_degree + 1):
            for names in combinations_with_replacement(
                sorted(related_globally), degree
            ):
                exponents = [0] * len(self.variables)
                for name in names:
                    exponents[index[name]] += 1
                monomial = Monomial(tuple(exponents))
                if monomial.degree <= max_degree:
                    self.add(monomial, "dependency")

    def _z3_monomial(self, expression):
        if z3.is_int_value(expression):
            return (0,) * len(self.variables)
        if z3.is_const(expression) and str(expression) in self.variables:
            exponents = [0] * len(self.variables)
            exponents[self.variables.index(str(expression))] = 1
            return tuple(exponents)
        if z3.is_mul(expression):
            result = [0] * len(self.variables)
            for child in expression.children():
                child_exponents = self._z3_monomial(child)
                if child_exponents is None:
                    return None
                result = [
                    left + right
                    for left, right in zip(result, child_exponents)
                ]
            return tuple(result)
        if z3.is_app_of(expression, z3.Z3_OP_POWER):
            base, exponent = expression.children()
            base_exponents = self._z3_monomial(base)
            if base_exponents is not None and z3.is_int_value(exponent):
                return tuple(value * exponent.as_long() for value in base_exponents)
        return None

    def _seed_from_z3(self, expression, source):
        direct = self._z3_monomial(expression)
        if direct is not None:
            monomial = Monomial(direct)
            self.add(monomial, source)
        for child in expression.children():
            self._seed_from_z3(child, source)
        return self

    def seed_from_postcondition(self, postcondition):
        return self._seed_from_z3(postcondition, "post")

    def seed_from_guard(self, guard):
        return self._seed_from_z3(guard, "guard")

    def dependency_guided_candidates(self):
        return [
            monomial
            for monomial in self.ranked()
            if "dependency" in self.sources(monomial)
        ]

    def sources(self, monomial):
        return frozenset(self._items.get(monomial, ()))

    def score(self, monomial, attempted=None, feedback_score=0.0):
        source_score = sum(
            self.SOURCE_WEIGHTS.get(source, 0.0)
            for source in self._items.get(monomial, ())
        )
        attempted_penalty = 3.0 if attempted and monomial in attempted else 0.0
        extended_penalty = 4.0 if isinstance(monomial, ExtendedTerm) else 0.0
        return (
            source_score
            + feedback_score
            - 1.5 * monomial.degree
            - extended_penalty
            - attempted_penalty
        )

    def ranked(self, max_items=None, attempted=None, feedback=None):
        feedback = feedback or {}
        items = sorted(
            self._items,
            key=lambda monomial: (
                -self.score(
                    monomial,
                    attempted=attempted,
                    feedback_score=feedback.get(monomial, 0.0),
                ),
                monomial.degree,
                _term_sort_key(monomial),
            ),
        )
        constant = self.constant
        if constant in items:
            items.remove(constant)
        items.insert(0, constant)
        return items if max_items is None else items[:max_items]

    def expand(self, current_support, failure_feedback=None, top_k=1):
        current = set(current_support)
        feedback = failure_feedback or {}
        candidates = [
            monomial
            for monomial in self.ranked(attempted=current, feedback=feedback)
            if monomial not in current
        ]
        return list(current_support) + candidates[:top_k]
