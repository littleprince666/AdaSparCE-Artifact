"""Bounded coverage candidates derived from entry, guards and branch maps.

This module proposes formulas only. Original INIT/STEP/EXIT remain the
acceptance authority; no task names, expected answers or corpus constants
are used to construct candidates.
"""

from itertools import combinations
from math import isqrt
import time
import z3

from SparCE.symbolic.candidate import CandidateBranch
from SparCE.generation.transition_kernel import _z3_to_poly, KernelSynthesisError


def conjuncts(expr):
    if z3.is_and(expr):
        return [part for child in expr.children() for part in conjuncts(child)]
    return [expr]


def entry_intervals(analyzer):
    """Finite or one-sided integer intervals from literal entry comparisons."""
    intervals = {}
    atoms = [a for assumption in analyzer.assumptions for a in conjuncts(assumption)]
    atoms += [analyzer.translator.symbols[n] == v
              for n, v in analyzer.initial_values.items()
              if n in analyzer.translator.symbols and z3.is_int_value(v)]
    for atom in atoms:
        if not (z3.is_eq(atom) or z3.is_le(atom) or z3.is_lt(atom)
                or z3.is_ge(atom) or z3.is_gt(atom)):
            continue
        left, right = atom.children()
        reverse = False
        if z3.is_int_value(left) and z3.is_const(right):
            left, right = right, left
            reverse = True
        if not (z3.is_const(left) and str(left) in analyzer.variables
                and z3.is_int_value(right)):
            continue
        value = right.as_long()
        low, high = intervals.get(str(left), (None, None))
        if z3.is_eq(atom):
            lo, hi = value, value
        else:
            upper = z3.is_le(atom) or z3.is_lt(atom)
            if reverse:
                upper = not upper
            strict = z3.is_lt(atom) or z3.is_gt(atom)
            lo = None if upper else value + int(strict)
            hi = value - int(strict) if upper else None
        if lo is not None:
            low = lo if low is None else max(low, lo)
        if hi is not None:
            high = hi if high is None else min(high, hi)
        intervals[str(left)] = (low, high)
    return intervals


def substitute_entry(expr, analyzer):
    substitutions = [(analyzer.translator.symbols[n], v)
                     for n, v in analyzer.initial_values.items()
                     if n in analyzer.translator.symbols]
    current = expr
    for _ in range(len(substitutions) + 1):
        updated = z3.simplify(z3.substitute(current, *substitutions), som=True)
        if z3.eq(current, updated):
            break
        current = updated
    return current


def polynomial_interval(expr, variables, intervals):
    """Conservative interval arithmetic over exact integer polynomials."""
    try:
        polynomial = _z3_to_poly(z3.simplify(expr, som=True), variables)
    except KernelSynthesisError:
        return None
    lower = upper = 0
    for key, coefficient in polynomial.items():
        lo = hi = coefficient
        for name, exponent in zip(variables, key):
            if not exponent:
                continue
            bounds = intervals.get(name)
            if bounds is None or None in bounds:
                return None
            left, right = bounds
            if left > right:
                return None
            powers = [left ** exponent, right ** exponent]
            if exponent % 2 == 0 and left <= 0 <= right:
                powers.append(0)
            products = [lo * min(powers), lo * max(powers),
                        hi * min(powers), hi * max(powers)]
            lo, hi = min(products), max(products)
        lower += lo
        upper += hi
    if lower.denominator != 1 or upper.denominator != 1:
        return None
    return int(lower), int(upper)


class CoverageGeneration:
    def _coverage_bounds(self, analyzer):
        intervals = entry_intervals(analyzer)
        transitions = analyzer.branch_transitions
        symbols = analyzer.translator.symbols
        lower, upper = [], []
        for name in sorted(analyzer.mutated):
            lo, _ = intervals.get(name, (None, None))
            if lo is None:
                continue
            deltas = [z3.simplify(updates.get(name, symbols[name]) - symbols[name], som=True)
                      for _, updates in transitions]
            if deltas and all(z3.is_int_value(d) and d.as_long() >= 0 for d in deltas):
                lower.append(symbols[name] >= lo)
        guard = analyzer.guard_z3
        if guard is None:
            guard = analyzer.translator.expression(analyzer.guard_ast)
        for atom in conjuncts(guard):
            if not (z3.is_le(atom) or z3.is_lt(atom) or z3.is_ge(atom) or z3.is_gt(atom)):
                continue
            left, right = atom.children()
            strict = z3.is_lt(atom) or z3.is_gt(atom)
            if z3.is_ge(atom) or z3.is_gt(atom):
                left, right = right, left
            difference = left - right
            deltas = [z3.simplify(z3.substitute(difference, *[
                (symbols[n], value) for n, value in updates.items()]) - difference, som=True)
                for _, updates in transitions]
            if deltas and all(z3.is_int_value(d) and d.as_long() >= 0 for d in deltas):
                upper.append(difference <= max(d.as_long() for d in deltas) - int(strict))
            if not z3.is_int_value(right):
                continue
            try:
                polynomial = _z3_to_poly(z3.simplify(left, som=True), analyzer.variables)
            except KernelSynthesisError:
                continue
            if len(polynomial) != 1:
                continue
            key, coefficient = next(iter(polynomial.items()))
            if coefficient != 1 or sum(key) != 2 or 2 not in key:
                continue
            name = analyzer.variables[key.index(2)]
            limit = right.as_long() - int(strict)
            if limit < 0:
                continue
            deltas = [z3.simplify(u.get(name, symbols[name]) - symbols[name])
                      for _, u in transitions]
            if deltas and all(z3.is_int_value(d) and d.as_long() >= 0 for d in deltas):
                upper.append(symbols[name] <= isqrt(limit) + max(d.as_long() for d in deltas))
        return lower, upper

    def _coverage_branches(self, analyzer):
        if not (self.config.coverage_optimizations and self.config.semantic_generators_enabled
                and analyzer.branch_transitions):
            return []
        symbols = analyzer.translator.symbols
        intervals = entry_intervals(analyzer)
        lower, upper = self._coverage_bounds(analyzer)
        bounds = lower + upper
        branches = []

        def emit(formula, mechanism, detail):
            formula = z3.simplify(formula, som=True)
            branches.append(CandidateBranch(formula, 225.0, mechanism,
                self._total_degree(formula), len(conjuncts(formula)), (detail,)))

        # Equal-step variables preserve their difference; entry polynomials
        # can bound it even when no entry equality remains invariant.
        for first, second in combinations(sorted(analyzer.mutated), 2):
            difference = symbols[first] - symbols[second]
            images = [z3.simplify(z3.substitute(difference, *[
                (symbols[n], v) for n, v in updates.items()]), som=True)
                for _, updates in analyzer.branch_transitions]
            if not all(z3.is_true(z3.simplify(image == difference, som=True)) for image in images):
                continue
            interval = polynomial_interval(substitute_entry(difference, analyzer),
                                           analyzer.variables, intervals)
            if interval is None:
                continue
            lo, hi = interval
            for relation in (difference <= hi, difference >= lo):
                emit(z3.And(relation, *bounds), "vc-entry-difference-envelope", "entry-interval")
            if len(branches) >= 8:
                break

        # Relations whose common multiplicative updates coincide on some
        # paths become phase predicates, combined with the original target.
        guard = analyzer.guard_z3
        if guard is None:
            guard = analyzer.translator.expression(analyzer.guard_ast)
        affine_bounds = [b.formula for b in self._affine_exit_branches(analyzer)]
        for first, second in combinations(sorted(analyzer.mutated), 2):
            initial = z3.simplify(substitute_entry(symbols[first] - symbols[second], analyzer), som=True)
            if not z3.is_int_value(initial) or initial.as_long() != 0:
                continue
            matches = []
            for _, updates in analyzer.branch_transitions:
                f = updates.get(first, symbols[first])
                s = updates.get(second, symbols[second])
                matches.append(z3.is_true(z3.simplify(
                    z3.substitute(f - s, (symbols[first], symbols[second])) == 0, som=True)))
            if not any(matches) or all(matches):
                continue
            relation = symbols[first] == symbols[second]
            phase = z3.And(z3.Implies(guard, relation),
                           z3.Implies(z3.Not(guard), analyzer.postcondition))
            emit(z3.And(phase, *bounds, *affine_bounds[:4]),
                 "vc-branch-phase-relation", "shared-branch-update")
            if len(branches) >= 12:
                break
        return branches

    def _run_coverage_seed_phase(self, state):
        if not self.config.coverage_optimizations:
            return None
        from SMT_Solver.SMT_verifier import CheckFailureType
        branches = self._coverage_branches(state.analyzer)
        state.all_branches.extend(branches)
        state.composition_bank_branches.extend(branches)
        branches += [b for b in state.all_branches if "target" in b.monomials]
        deadline = min(state.started + self.config.timeout_seconds,
                       time.perf_counter() + self.config.timeout_seconds * 0.2)
        for rank, branch in enumerate(branches[:12], 1):
            if time.perf_counter() >= deadline or self._remaining_check_ms(1) < 1 or self._checker_budget_exhausted(state.checked):
                break
            result = self._check_branch(state.verifier, branch, state.smt_path,
                state.program_id, rank, state.analyzer,
                suppress_timeout_escalation=True,
                checker_timeout=min(self.config.checker_timeout_seconds, deadline - time.perf_counter()))
            if result is None:
                continue
            state.checked += 1
            state.checked_mechanisms.add(branch.mechanism)
            if result.failure_type == CheckFailureType.SUCCESS:
                return self._success(state.program_id, branch, state.started, state.checked)
            self._run_lemma_trials_hook(state, result, branch)
            if result.failure_type in (CheckFailureType.TIMEOUT, CheckFailureType.UNKNOWN):
                self.candidate_cache.discard(str(z3.simplify(branch.formula)))
            state.composition_bank_branches.append(branch)
            state.composition_observations.append((branch, result))
        return None
