"""Unified partial-clause store for conjunction trials and composition.

One shared store records every checked candidate's partial result —
INIT/STEP/EXIT outcome, the counterexample that refuted it, the source
mechanism and the checker cost — and feeds both consumers that were
previously separate:

* the partial-lemma conjunction trials (this module keeps the legacy
  ``PartialLemmaTracker`` API, extended with STEP x EXIT cross pairing
  and bounded full-set step conjunctions so mutually dependent clause
  systems can be proven jointly), and
* the proof-guided clause composer (bank entries with their outcomes
  seed the composer bank instead of only unchecked pool branches).

Every proposal remains a candidate: the frozen INIT/STEP/EXIT checker
is the sole judge of soundness.
"""

import z3

from SMT_Solver.SMT_verifier import CheckFailureType


_PROGRESS = {
    "UNKNOWN": 0,
    "TIMEOUT": 0,
    "INIT": 1,
    "STEP": 2,
    "EXIT": 3,
    "SUCCESS": 4,
}


def _failure_name(failure_type):
    if failure_type is None:
        return "UNKNOWN"
    return getattr(failure_type, "value", str(failure_type)).upper()


class _BankEntry:
    __slots__ = (
        "formula", "key", "score", "mechanism", "degree", "clauses",
        "monomials", "outcome", "counterexample", "checker_time",
        "source",
    )

    def __init__(self, formula, key, score, mechanism, degree, clauses,
                 monomials=(), outcome="UNKNOWN", counterexample=None,
                 checker_time=0.0, source=""):
        self.formula = formula
        self.key = key
        self.score = float(score)
        self.mechanism = str(mechanism)
        self.degree = int(degree)
        self.clauses = int(clauses)
        self.monomials = tuple(monomials)
        self.outcome = outcome
        self.counterexample = counterexample
        self.checker_time = float(checker_time)
        self.source = source


class UnifiedClauseBank:
    """Drop-in superset of :class:`PartialLemmaTracker` semantics."""

    def __init__(
        self,
        max_exit_lemmas=8,
        max_step_partials=12,
        max_init_partials=16,
        max_trials=64,
        max_full_set_size=4,
        max_entries=96,
    ):
        self.max_exit_lemmas = int(max_exit_lemmas)
        self.max_step_partials = int(max_step_partials)
        self.max_init_partials = int(max_init_partials)
        self.max_trials = int(max_trials)
        self.max_full_set_size = int(max_full_set_size)
        self.max_entries = int(max_entries)
        self.trials = 0
        self.tried_keys = set()
        self._entries = {}
        self.exit_lemmas = []
        self.step_partials = []
        self.init_partials = []

    # -- recording -----------------------------------------------------------

    @staticmethod
    def _key(formula):
        return str(z3.simplify(formula))

    def _retain(self, pool, entry, capacity):
        pool.append(entry)
        if len(pool) > capacity:
            pool.sort(key=lambda item: item.score)
            pool.pop(0)

    def note_result(self, branch, result):
        """Record a full check result (outcome, CE, source, cost)."""
        if result is None:
            return []
        outcome = _failure_name(result.failure_type)
        key = self._key(branch.formula)
        counterexample = getattr(result, "counterexample", None)
        checker_time = float(getattr(result, "solver_time", 0.0) or 0.0)
        existing = self._entries.get(key)
        if existing is None:
            entry = _BankEntry(
                branch.formula, key, branch.score, branch.mechanism,
                branch.degree, branch.clauses, branch.monomials,
                outcome, counterexample, checker_time,
                source=branch.mechanism,
            )
            self._entries[key] = entry
            if len(self._entries) > self.max_entries:
                # Evict the lowest-priority entries: INIT-only partials
                # first, then by score.
                victims = sorted(
                    self._entries.values(),
                    key=lambda item: (
                        _PROGRESS.get(item.outcome, 0),
                        item.score,
                    ),
                )
                for victim in victims[: len(self._entries) - self.max_entries]:
                    self._entries.pop(victim.key, None)
        else:
            if _PROGRESS.get(outcome, 0) >= _PROGRESS.get(existing.outcome, 0):
                existing.outcome = outcome
                existing.counterexample = counterexample
                existing.checker_time += checker_time
        return self._register_partial(
            branch.formula, key, branch.score, branch.mechanism,
            branch.degree, branch.clauses, branch.monomials,
            result.failure_type,
        )

    def note(self, formula, score, failure_type):
        """Legacy tracker-compatible observation entry point."""
        key = self._key(formula)
        if failure_type not in (
            CheckFailureType.EXIT,
            CheckFailureType.STEP,
            CheckFailureType.INIT,
        ):
            return []
        if key not in self._entries:
            self._entries[key] = _BankEntry(
                formula, key, score, "partial-lemma-conjunction",
                0, 1, (), _failure_name(failure_type), None, 0.0,
                source="partial-lemma-conjunction",
            )
        return self._register_partial(
            formula, key, score, "partial-lemma-conjunction", 0, 1, (),
            failure_type,
        )

    def _top_set_proposals(self, exclude_key, sizes=(2, 3, 4)):
        """And(top-K partial clauses by score across both pools).

        Mutually dependent clause systems (e.g. a Faulhaber triple plus
        an exit bound) are inductive as a set; pairing-only proposals
        cannot reach them once the pools grow past a handful.
        """
        merged = sorted(
            list(self.step_partials) + list(self.exit_lemmas),
            key=lambda item: -item.score,
        )
        proposals = []
        for size in sizes:
            if len(merged) < size:
                break
            top = merged[:size]
            if any(entry.key == exclude_key for entry in top):
                continue
            proposals.append(z3.And(*[entry.formula for entry in top]))
        return proposals

    def _register_partial(self, formula, key, score, mechanism, degree,
                          clauses, monomials, failure_type):
        if self.trials >= self.max_trials:
            return []
        proposals = []
        if failure_type == CheckFailureType.EXIT:
            entry = _BankEntry(
                formula, key, score, mechanism, degree, clauses, monomials,
                "EXIT", source=mechanism,
            )
            if key not in {e.key for e in self.exit_lemmas}:
                self._retain(self.exit_lemmas, entry, self.max_exit_lemmas)
                for partner in self._partners(self.exit_lemmas):
                    if partner.key != key:
                        proposals.append(z3.And(formula, partner.formula))
                if len(self.exit_lemmas) > 1:
                    proposals.append(
                        z3.And(*[e.formula for e in self.exit_lemmas])
                    )
                # Cross pairing: an inductive EXIT lemma combined with a
                # STEP partial can be jointly inductive.
                for partner in self._partners(self.step_partials):
                    if partner.key != key:
                        proposals.append(z3.And(formula, partner.formula))
                proposals.extend(self._top_set_proposals(key))
        elif failure_type == CheckFailureType.STEP:
            entry = _BankEntry(
                formula, key, score, mechanism, degree, clauses, monomials,
                "STEP", source=mechanism,
            )
            if key not in {e.key for e in self.step_partials}:
                self._retain(
                    self.step_partials, entry, self.max_step_partials
                )
                for partner in self._partners(self.step_partials):
                    if partner.key != key:
                        proposals.append(z3.And(formula, partner.formula))
                # Bounded full-set conjunction of the step pool: mutually
                # dependent clause systems (e.g. Faulhaber triples) are
                # inductive only as a whole set.
                if 2 <= len(self.step_partials) <= self.max_full_set_size:
                    proposals.append(
                        z3.And(*[e.formula for e in self.step_partials])
                    )
                for partner in self._partners(self.exit_lemmas):
                    if partner.key != key:
                        proposals.append(z3.And(formula, partner.formula))
                proposals.extend(self._top_set_proposals(key))
        elif failure_type == CheckFailureType.INIT:
            if key not in {e.key for e in self.init_partials}:
                entry = _BankEntry(
                    formula, key, score, mechanism, degree, clauses,
                    monomials, "INIT", source=mechanism,
                )
                self._retain(
                    self.init_partials, entry, self.max_init_partials
                )
        deduped = []
        for conjunction in proposals:
            ckey = self._key(conjunction)
            if ckey in self.tried_keys or ckey == key:
                continue
            self.tried_keys.add(ckey)
            deduped.append(conjunction)
            self.trials += 1
            if self.trials >= self.max_trials:
                break
        return deduped

    @staticmethod
    def _partners(pool):
        """Full-pool pairing, best-scored first (ordering only)."""
        ranked = sorted(pool, key=lambda item: -item.score)
        return ranked

    # -- composer seeding ------------------------------------------------------

    def entries(self):
        """All recorded clauses with outcomes, best progress first."""
        return sorted(
            self._entries.values(),
            key=lambda item: (
                -_PROGRESS.get(item.outcome, 0),
                -item.score,
            ),
        )

    def summary(self):
        return {
            "entries": len(self._entries),
            "exit_lemmas": len(self.exit_lemmas),
            "step_partials": len(self.step_partials),
            "init_partials": len(self.init_partials),
            "trials": self.trials,
        }
