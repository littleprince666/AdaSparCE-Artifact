"""Prepare/freeze a shared semantic pool, then compare four offline combinators.

All expensive actions are explicit. `prepare` generates Q0 in cold workers;
`run` performs only replay. Do not run either alongside timing studies.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import csv
from importlib.metadata import version
import json
import math
import os
from pathlib import Path
import platform
import random
import shutil
import signal
import statistics
import subprocess
import sys
import time

import z3

from tools.experiments.shared_pool_core import (
    ROOT, VARIANTS, digest, generate_pool, replay_pool, sha, write_json,
)

ENVIRONMENT = {key:'1' for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')}
PROTOCOL = ROOT/'docs/experiments/同候选池组合协议_2026-10-18.md'


def file_hashes(directory):
    return {str(p.relative_to(directory)):sha(p) for p in sorted(directory.rglob('*'))
            if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}


def snapshot(destination):
    destination.mkdir(parents=True)
    for name in ('SparCE','SMT_Solver','Utilities'):
        shutil.copytree(ROOT/name,destination/name,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    shutil.copy2(ROOT/'run_sparse.py',destination/'run_sparse.py')
    (destination/'tools/experiments').mkdir(parents=True)
    for rel in ('tools/__init__.py','tools/run_experiment.py','tools/experiments/__init__.py',
                'tools/experiments/shared_pool_core.py','tools/experiments/shared_pool_study.py'):
        shutil.copy2(ROOT/rel,destination/rel)
    author = destination/'baseline/Clause2Inv-main/combinator'
    author.mkdir(parents=True)
    for name in ('checker.py','cmd_args.py','c_inv_checker.py'):
        shutil.copy2(ROOT/'baseline/Clause2Inv-main/combinator'/name,author/name)


def child(output, arguments, timeout, stdout_path, seed=0):
    env=dict(os.environ,**ENVIRONMENT,PYTHONDONTWRITEBYTECODE='1',PYTHONHASHSEED=str(seed))
    command=[sys.executable,'-m','tools.experiments.shared_pool_study',*arguments]
    stdout_path=Path(stdout_path)
    stdout_path.parent.mkdir(parents=True,exist_ok=True)
    started=time.perf_counter()
    with stdout_path.open('w') as stream:
        process=subprocess.Popen(command,cwd=output/'source',env=env,
            stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
        try:
            process.wait(timeout=timeout)
            status='completed' if process.returncode==0 else 'error'
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGKILL)
            process.wait()
            status='hard-timeout'
    return dict(command=command,returncode=process.returncode,process_status=status,
                process_wall_seconds=time.perf_counter()-started,stdout=str(stdout_path.relative_to(output)),
                stdout_sha256=sha(stdout_path))


def prepare(args):
    output=args.output.resolve()
    if output.exists():
        raise ValueError('Use a new directory; existing material pools stay immutable')
    dataset=args.dataset.resolve()
    manifest=json.loads((dataset/'manifest.json').read_text())
    tasks=[t for t in manifest if t['split']=='test-locked']
    requested=set(args.tasks.split(',')) if args.tasks else None
    if requested:
        if not requested<={t['id'] for t in tasks}:
            raise ValueError('unknown-task-id')
        tasks=[t for t in tasks if t['id'] in requested]
    if not tasks:
        raise ValueError('empty-task-list')
    config=json.loads(args.config.read_text())
    output.mkdir(parents=True)
    snapshot(output/'source')
    (output/'pools').mkdir()
    (output/'protocol.md').write_bytes(PROTOCOL.read_bytes())
    spec=dict(schema='adasparce.shared-pool-study.v1',date='2026-10-18',
        dataset=str(dataset),tasks=tasks,full_collection=not bool(requested),
        seeds=[int(s) for s in args.seeds.split(',')],variants=list(VARIANTS),config=config,
        budget_seconds=args.budget,candidate_seconds=args.candidate_seconds,max_checks=args.max_checks,
        author_representation=args.author_representation,
        generation_budget_seconds=args.budget,preparation_workers=args.workers,
        inputs={str(dataset/t['relative_path']/f):sha(dataset/t['relative_path']/f)
                for t in tasks for f in ('normalized.c','task.c_smt')},
        source_hashes=file_hashes(output/'source'),protocol_sha256=sha(output/'protocol.md'),
        generator_config_sha256=sha(args.config),original_generator_config=str(args.config.resolve()),
        python=sys.version,dependencies={n:version(n) for n in ('z3-solver','sympy','pycparser')},
        hardware=dict(platform=platform.platform(),cpu=Path('/proc/cpuinfo').read_text().split(
            'model name')[1].split('\n')[0].split(':',1)[1].strip()),
        environment=ENVIRONMENT,
        timing='total=generation_once_charged_equally+fresh_replay; replay and process wall also separate',
        generation_scope='Initial semantic/VC/kernel/coverage candidates plus identical immediate Boolean children; no final checks, CE synthesis, C, S, fast-path synthesis or fallback',
        ordering='Q0=(2*degree+clauses,-score,mechanism,SMT); no adaptive S; author retains own ICE ranking',
        result_scope='Diagnostic composition isolation; not end-to-end Full or external-tool performance')
    if len(spec['seeds'])!=len(set(spec['seeds'])) or min(spec['seeds'])<0:
        raise ValueError('invalid-seeds')
    write_json(output/'spec.json',spec)
    if args.reuse_pools:
        origin=args.reuse_pools.resolve()
        prior,_=check(origin)
        for field in ('inputs','tasks','config','budget_seconds','generation_budget_seconds','ordering'):
            if prior[field]!=spec[field]:
                raise ValueError('reused-generation-spec-differs:'+field)
        for task in tasks:
            shutil.copy2(origin/'pools'/f"{task['id']}.json",output/'pools'/f"{task['id']}.json")
        spec['reused_pool_provenance']=dict(origin=str(origin),
            origin_freeze_sha256=sha(origin/'freeze.json'),
            original_spec_sha256=sha(origin/'spec.json'),
            policy='Identical immutable pre-result Q0 and original generation charge; all arms rerun under corrected checker')
        write_json(output/'spec.json',spec)
        print('Reused',len(tasks),'identical immutable pre-result pools',flush=True)
        return
    def one(task):
        identity=task['id']
        log=output/'preparation'/f'{identity}.stdout'
        runtime=child(output,['_generate','--output',str(output),'--task',identity],
                      args.budget+8,log)
        pool_path=output/'pools'/f'{identity}.json'
        if not pool_path.exists():
            write_json(pool_path,dict(schema='adasparce.shared-q0.v1',id=identity,
                status='generation-failed',reason=runtime['process_status'],
                generation_seconds=args.budget,candidates=[],candidate_count=0,
                candidate_content_sha256=digest('[]'),
                c_path=str(dataset/task['relative_path']/'normalized.c'),
                vc_path=str(dataset/task['relative_path']/'task.c_smt')))
        write_json(output/'preparation'/f'{identity}.json',runtime)
        return identity
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as workers:
        for identity in workers.map(one,tasks):
            print('Prepared',identity,flush=True)
    print('Preparation complete; inspect generation failures, then freeze the unchanged study.',flush=True)


def check(output, require_freeze=True):
    output=Path(output)
    spec=json.loads((output/'spec.json').read_text())
    if file_hashes(output/'source')!=spec['source_hashes']:
        raise ValueError('frozen-runtime-source-changed')
    if sha(output/'protocol.md')!=spec['protocol_sha256']:
        raise ValueError('study-protocol-changed')
    if sys.version!=spec['python'] or {n:version(n) for n in spec['dependencies']}!=spec['dependencies']:
        raise ValueError('runtime-dependencies-changed')
    for path,fingerprint in spec['inputs'].items():
        if sha(path)!=fingerprint:
            raise ValueError('input-changed:'+path)
    pools={}
    for task in spec['tasks']:
        path=output/'pools'/f"{task['id']}.json"
        data=json.loads(path.read_text())
        canonical=json.dumps(data['candidates'],ensure_ascii=False,sort_keys=True,separators=(',',':'))
        if digest(canonical)!=data['candidate_content_sha256'] or data['candidate_count']!=len(data['candidates']):
            raise ValueError('pool-content-or-count-mismatch')
        if data['id']!=task['id']:
            raise ValueError('pool-identity-mismatch')
        pools[str(path.relative_to(output))]=sha(path)
    if require_freeze:
        frozen=json.loads((output/'freeze.json').read_text())
        if frozen['spec_sha256']!=sha(output/'spec.json') or frozen['pool_hashes']!=pools:
            raise ValueError('study-spec-or-pools-changed-after-freeze')
    return spec,pools


def freeze(output):
    if (output/'freeze.json').exists():
        raise ValueError('freeze-already-exists')
    spec,pools=check(output,False)
    jobs=[dict(id=t['id'],variant=v,seed=s) for t in spec['tasks']
          for v in spec['variants'] for s in spec['seeds']]
    random.Random(20261018).shuffle(jobs)
    write_json(output/'freeze.json',dict(schema=spec['schema'],date='2026-10-18',
        spec_sha256=sha(output/'spec.json'),pool_hashes=pools,jobs=jobs,expected=len(jobs),
        original_author_sha256=sha(output/'source/baseline/Clause2Inv-main/combinator/checker.py'),
        protocol_sha256=spec['protocol_sha256'],source_hashes=spec['source_hashes']))
    print('Frozen',len(pools),'shared pools and',len(jobs),'replays',flush=True)


def load_rows(output):
    path=output/'results.jsonl'
    return [json.loads(line) for line in path.read_text().splitlines()] if path.exists() else []


def trace_events(path, allow_interrupted=False):
    lines=Path(path).read_text().splitlines()
    result=[]
    for index,line in enumerate(lines):
        try:
            result.append(json.loads(line))
        except json.JSONDecodeError:
            if not allow_interrupted or index!=len(lines)-1:
                raise ValueError('malformed-nonterminal-trace-record')
    return result


def audit_rows(output, frozen, rows):
    allowed={(r['variant'],r['seed'],r['id']) for r in frozen['jobs']}
    seen=set()
    for row in rows:
        key=(row['variant'],row['seed'],row['id'])
        if key not in allowed or key in seen or row['freeze_sha256']!=sha(output/'freeze.json'):
            raise ValueError('duplicate-foreign-or-stale-result')
        for field in ('trace','stdout'):
            if sha(output/row[field])!=row[field+'_sha256']:
                raise ValueError(field+'-changed')
        completed_checks=0
        for event in trace_events(output/row['trace'],row['status']=='hard-timeout'):
            if event['event']=='candidate-check':
                completed_checks+=1
                for vc in event['vc_results']:
                    query=output/'queries'/(vc['query_sha256']+'.smt2')
                    if sha(query)!=vc['query_sha256']:
                        raise ValueError('recorded-query-changed-or-missing')
        if row['status'] not in ('hard-timeout','error') and completed_checks!=row['checker_calls']:
            raise ValueError('completed-check-event-count-mismatch')
        if row['pool_file_sha256']!=frozen['pool_hashes'][f"pools/{row['id']}.json"]:
            raise ValueError('result-pool-does-not-match-frozen-pool')
        seen.add(key)
    return seen


def run(output, workers):
    import fcntl
    spec,_=check(output)
    frozen=json.loads((output/'freeze.json').read_text())
    with (output/'run.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        rows=load_rows(output)
        completed=audit_rows(output,frozen,rows)
        runtime=output/'runtime.json'
        if runtime.exists() and json.loads(runtime.read_text())['workers']!=workers:
            raise ValueError('worker-count-changed')
        if not runtime.exists():
            write_json(runtime,dict(workers=workers,started=time.time(),
                cpu_affinity=sorted(os.sched_getaffinity(0)),environment=ENVIRONMENT,
                tests_concurrent=False,independent_proofs_concurrent=False))
        def one(job):
            stem=Path('runs')/job['variant']/f"seed{job['seed']}"/job['id']
            trace=output/stem.with_suffix('.jsonl')
            result_path=output/stem.with_suffix('.result.json')
            for old in (trace,result_path):
                if old.exists():
                    old.rename(old.with_name(old.name+'.interrupted.'+str(time.time_ns())))
            runtime=child(output,['_replay','--output',str(output),'--task',job['id'],
                '--variant',job['variant'],'--seed',str(job['seed'])],
                spec['budget_seconds']+8,output/stem.with_suffix('.stdout'),job['seed'])
            if result_path.exists():
                result=json.loads(result_path.read_text())
            else:
                result=dict(status=runtime['process_status'],invariant=None,invariant_smtlib=None,
                    total_time=None,replay_seconds=None,generation_seconds=json.loads(
                        (output/'pools'/f"{job['id']}.json").read_text())['generation_seconds'],
                    checker_calls=0,reason='worker-produced-no-result')
            if not trace.exists():
                trace.parent.mkdir(parents=True,exist_ok=True)
                trace.write_text(json.dumps(dict(event='runner-missing-trace',**result))+'\n')
            if not result_path.exists():
                events=trace_events(trace,True)
                checks=[event for event in events if event['event']=='candidate-check']
                result['checker_calls']=len(checks)
                result['attempted_checker_calls']=sum(event['event']=='candidate-start' for event in events)
                result['solver_seconds']=sum(vc['solver_time_seconds'] for event in checks for vc in event['vc_results'])
            result.update(job,**runtime,trace=str(trace.relative_to(output)),trace_sha256=sha(trace),
                pool_file_sha256=frozen['pool_hashes'][f"pools/{job['id']}.json"],
                freeze_sha256=sha(output/'freeze.json'))
            return result
        pending=[j for j in frozen['jobs'] if (j['variant'],j['seed'],j['id']) not in completed]
        print('Running',len(pending),'/',frozen['expected'],'replays',flush=True)
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
            futures=[pool.submit(one,j) for j in pending]
            for future in concurrent.futures.as_completed(futures):
                row=future.result()
                with (output/'results.jsonl').open('a') as stream:
                    stream.write(json.dumps(row,ensure_ascii=False)+'\n')
                rows.append(row)
                print(len(rows),'/',frozen['expected'],row['variant'],row['id'],row['status'],flush=True)
        check(output)
        audit_rows(output,frozen,rows)
        write_json(output/'completion.json',dict(complete=len(rows)==frozen['expected'],
            actual=len(rows),expected=frozen['expected'],results_sha256=sha(output/'results.jsonl'),
            freeze_sha256=sha(output/'freeze.json')))


def proof_worker(job):
    """Independent plain original-text queries, no search/normalization calls."""
    if sha(job['vc_path'])!=job['vc_sha256']:
        raise ValueError('proof-input-changed')
    sections=Path(job['vc_path']).read_text().split('SPLIT_HERE_asdfghjklzxcvbnmqwertyuiop')
    if len(sections)!=5:
        raise ValueError('expected-five-original-sections')
    checks=[]
    for name,index in zip(('INIT','STEP','EXIT'),(2,3,4)):
        query=sections[0]+job['invariant_smtlib']+sections[1]+sections[index]
        solver=z3.Solver()
        solver.set(timeout=int(job['timeout_per_vc']*1000),random_seed=0)
        solver.add(z3.parse_smt2_string(query))
        started=time.perf_counter()
        status=solver.check()
        checks.append(dict(vc=name,status=str(status),seconds=time.perf_counter()-started,
            query_sha256=digest(query),reason_unknown=solver.reason_unknown() if status==z3.unknown else None,
            counterexample=str(solver.model()) if status==z3.sat else None))
    return dict(key=job['key'],status='verified' if all(c['status']=='unsat' for c in checks) else 'unverified',
                checks=checks,z3=z3.get_version_string())


def reverify(output, workers):
    spec,_=check(output)
    frozen=json.loads((output/'freeze.json').read_text())
    rows=load_rows(output)
    audit_rows(output,frozen,rows)
    if len(rows)!=frozen['expected']:
        raise ValueError('finish-all-replays-before-independent-checking')
    jobs={}
    evidence=[]
    for row in rows:
        if row['status']!='solved':
            continue
        pool=json.loads((output/'pools'/f"{row['id']}.json").read_text())
        vc_hash=sha(pool['vc_path'])
        key=digest(json.dumps([vc_hash,row['invariant_smtlib']],separators=(',',':')))
        jobs[key]=dict(key=key,vc_path=pool['vc_path'],vc_sha256=vc_hash,
            invariant_smtlib=row['invariant_smtlib'],timeout_per_vc=60)
        evidence.append(dict(variant=row['variant'],seed=row['seed'],id=row['id'],key=key))
    directory=output/'reverification'
    directory.mkdir(exist_ok=True)
    def one(job):
        path=directory/(job['key']+'.json')
        if path.exists():
            record=json.loads(path.read_text())
            if record['job']!=job:
                raise ValueError('proof-cache-identity-mismatch')
            return record
        try:
            process=subprocess.run([sys.executable,'-m','tools.experiments.shared_pool_study','_proof'],
                input=json.dumps(job),text=True,capture_output=True,cwd=output/'source',
                env=dict(os.environ,**ENVIRONMENT,PYTHONDONTWRITEBYTECODE='1'),timeout=195)
            result=json.loads(process.stdout) if process.returncode==0 else dict(status='error',detail=process.stderr)
        except subprocess.TimeoutExpired:
            result=dict(status='hard-timeout',checks=[])
        record=dict(job=job,result=result)
        write_json(path,record)
        return record
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        records=list(pool.map(one,jobs.values()))
    write_json(directory/'summary.json',dict(freeze_sha256=sha(output/'freeze.json'),
        results_sha256=sha(output/'results.jsonl'),evidence=evidence,distinct_checks=len(records),
        proofs={r['job']['key']:dict(status=r['result']['status'],record_sha256=sha(directory/(r['job']['key']+'.json')))
                for r in records},checker_source_sha256=sha(output/'source/tools/experiments/shared_pool_study.py')))
    print('Independent rechecking complete:',len(records),'distinct original-VC/formula pairs',flush=True)


def report(output):
    spec,_=check(output)
    frozen=json.loads((output/'freeze.json').read_text())
    rows=load_rows(output)
    audit_rows(output,frozen,rows)
    proofs=json.loads((output/'reverification/summary.json').read_text())
    if proofs['results_sha256']!=sha(output/'results.jsonl'):
        raise ValueError('proof-summary-is-stale')
    for key,proof in proofs['proofs'].items():
        path=output/'reverification'/(key+'.json')
        record=json.loads(path.read_text())
        if sha(path)!=proof['record_sha256'] or record['result']['status']!=proof['status']:
            raise ValueError('proof-record-changed')
    confirmed={(r['variant'],r['seed'],r['id']) for r in proofs['evidence']
               if proofs['proofs'][r['key']]['status']=='verified'}
    table={}
    exports=[]
    for row in rows:
        t=row.get('total_time')
        eligible=row['status']=='solved' and isinstance(t,(int,float)) and math.isfinite(t) and 0<=t<=spec['budget_seconds']
        ok=eligible and (row['variant'],row['seed'],row['id']) in confirmed
        exports.append(dict(variant=row['variant'],seed=row['seed'],id=row['id'],
            status=row['status'],confirmed=ok,generation_seconds=row['generation_seconds'],
            replay_seconds=row.get('replay_seconds'),total_seconds=t,checker_calls=row['checker_calls'],
            confirmed_par2_seconds=t if ok else 2*spec['budget_seconds'],pool_file_sha256=row['pool_file_sha256']))
    for variant in spec['variants']:
        group=[r for r in exports if r['variant']==variant]
        solved=[r for r in group if r['confirmed']]
        table[variant]=dict(runs=len(group),confirmed_per_seed=[sum(r['confirmed'] for r in group if r['seed']==s) for s in spec['seeds']],
            confirmed_runs=len(solved),mean_confirmed=len(solved)/len(spec['seeds']),
            confirmed_par2_seconds=statistics.mean(r['confirmed_par2_seconds'] for r in group),
            mean_confirmed_total_seconds=statistics.mean(r['total_seconds'] for r in solved) if solved else None,
            mean_confirmed_replay_seconds=statistics.mean(r['replay_seconds'] for r in solved) if solved else None,
            checker_calls=sum(r['checker_calls'] for r in group))
    own={(r['seed'],r['id']) for r in exports if r['variant']=='ada_c' and r['confirmed']}
    pairs={}
    for variant in spec['variants']:
        other={(r['seed'],r['id']) for r in exports if r['variant']==variant and r['confirmed']}
        pairs[variant]=dict(ada_only=sorted(own-other),comparator_only=sorted(other-own),common=sorted(own&other))
    with (output/'confirmed-results.csv').open('w') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(exports[0]))
        writer.writeheader();writer.writerows(exports)
    write_json(output/'confirmed-summary.json',dict(table=table,pairs=pairs,
        complete=len(rows)==frozen['expected'],full_collection=spec['full_collection'],
        author_representation=spec.get('author_representation','c-infix'),
        transport_by_task={t['id']:json.loads((output/'pools'/f"{t['id']}.json").read_text()).get(
            'author_transport_summary',{}) for t in spec['tasks']},
        generation_charged_to_every_replay=True,search_budget_seconds=spec['budget_seconds'],
        rows=len(rows),expected=frozen['expected'],freeze_sha256=sha(output/'freeze.json'),
        results_sha256=sha(output/'results.jsonl'),proof_summary_sha256=sha(output/'reverification/summary.json'),
        interpretation='Same Q0 and original checker; controls composition algorithm, not end-to-end Full. No advantage is required.'))
    print(json.dumps(table,ensure_ascii=False,indent=2))


def main():
    parser=argparse.ArgumentParser(__doc__)
    parser.add_argument('action',choices=('prepare','freeze','check','run','reverify','report','_generate','_replay','_proof'))
    parser.add_argument('--output',type=Path)
    parser.add_argument('--dataset',type=Path,default=ROOT/'datasets/Clause2Inv-NL-50')
    parser.add_argument('--config',type=Path,default=ROOT/'configs/ablation/nl50_coverage_optimized_30s_20261013.json')
    parser.add_argument('--reuse-pools',type=Path,help='Reuse complete immutable Q0 after a documented checker-only correction')
    parser.add_argument('--tasks',help='Explicit smoke subset only; omitted means complete collection')
    parser.add_argument('--seeds',default='0,1,2,3,4')
    parser.add_argument('--workers',type=int,default=1)
    parser.add_argument('--budget',type=float,default=30)
    parser.add_argument('--candidate-seconds',type=float,default=4)
    parser.add_argument('--max-checks',type=int,default=256)
    parser.add_argument('--author-representation',choices=('c-infix','smt-prefix'),default='c-infix',
        help='Frozen Clause2Inv text transport; prefix is an optional separate-batch sensitivity control')
    parser.add_argument('--task')
    parser.add_argument('--variant',choices=VARIANTS)
    parser.add_argument('--seed',type=int,default=0)
    args=parser.parse_args()
    if args.action=='_proof':
        print(json.dumps(proof_worker(json.load(sys.stdin))))
        return
    if args.output is None:
        parser.error('--output required')
    output=args.output.resolve()
    if not 1<=args.workers<=8 or min(args.budget,args.candidate_seconds,args.max_checks)<=0:
        parser.error('positive budgets and 1--8 workers required')
    if args.action=='prepare':
        prepare(args)
    elif args.action=='freeze':
        freeze(output)
    elif args.action=='check':
        spec,pools=check(output)
        print('Verified',len(pools),'immutable shared pools')
    elif args.action=='run':
        run(output,args.workers)
    elif args.action=='reverify':
        reverify(output,args.workers)
    elif args.action=='report':
        report(output)
    elif args.action=='_generate':
        spec=json.loads((output/'spec.json').read_text())
        task=next(t for t in spec['tasks'] if t['id']==args.task)
        write_json(output/'pools'/f'{args.task}.json',generate_pool(task,spec['dataset'],spec['config'],spec['generation_budget_seconds']))
    elif args.action=='_replay':
        spec=json.loads((output/'spec.json').read_text())
        pool=json.loads((output/'pools'/f'{args.task}.json').read_text())
        stem=output/'runs'/args.variant/f'seed{args.seed}'/args.task
        result=replay_pool(pool,args.variant,args.seed,stem.with_suffix('.jsonl'),output/'queries',
                           spec['budget_seconds'],spec['candidate_seconds'],spec['max_checks'],
                           author_representation=spec.get('author_representation','c-infix'))
        write_json(stem.with_suffix('.result.json'),result)


if __name__=='__main__':
    main()
