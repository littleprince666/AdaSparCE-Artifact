"""Candidate-generation methods shared by the VC analyzer."""

from fractions import Fraction
from itertools import combinations
import z3
from SparCE.generation.vc_polynomial import VCAnalysisError
from SparCE.generation.vc_polynomial import _flatten_and
from SparCE.generation.vc_polynomial import _symbols
from SparCE.generation.vc_polynomial import _nullspace
from SparCE.generation.vc_polynomial import _integer_vector
from SparCE.generation.vc_polynomial import _poly_add
from SparCE.generation.vc_polynomial import _poly_scale
from SparCE.generation.vc_polynomial import _poly_degree
from SparCE.generation.vc_polynomial import _poly_substitute
from SparCE.generation.vc_polynomial import _monomial_exponents


class VCConservation:
    """Polynomial conservation and branch completion candidates."""

    def _conserved_candidates_for_update_sets(
        self,
        update_sets,
        max_degree,
        max_clauses,
        maximum_basis,
        mechanism,
        enforce_initial=True,
    ):
        """Find polynomials conserved by every supplied exact update set."""
        try:
            initial = self._pre_substitutions()
        except VCAnalysisError:
            return []
        if not update_sets:
            return []
        variable_count = len(self.variables)
        monomials = _monomial_exponents(variable_count, max_degree)
        delta_columns_by_update = [[] for _ in update_sets]
        initial_columns = []
        for exponent in monomials:
            monomial = {exponent: 1}
            for columns, updates in zip(
                delta_columns_by_update, update_sets
            ):
                columns.append(self._delta(monomial, updates))
            initial_columns.append(
                _poly_substitute(monomial, initial, variable_count)
            )
        rows = []
        for delta_columns in delta_columns_by_update:
            for output_exponent in sorted(
                set().union(*(set(item) for item in delta_columns))
            ):
                rows.append(
                    [
                        polynomial.get(output_exponent, 0)
                        for polynomial in delta_columns
                    ]
                )
        if enforce_initial:
            for output_exponent in sorted(
                set().union(*(set(item) for item in initial_columns))
            ):
                rows.append(
                    [
                        polynomial.get(output_exponent, 0)
                        for polynomial in initial_columns
                    ]
                )
        basis = [
            _integer_vector(vector)
            for vector in _nullspace(rows, len(monomials))
        ]
        post_symbols = _symbols(self.postcondition)
        ranked = []
        for vector in basis:
            polynomial = {
                exponent: coefficient
                for exponent, coefficient in zip(monomials, vector)
                if coefficient
            }
            if not polynomial:
                continue
            used = {
                self.variables[index]
                for exponent in polynomial
                for index, power in enumerate(exponent)
                if power
            }
            overlap = len(used.intersection(post_symbols))
            score = (
                20 * overlap
                + 3 * len(used)
                - 2 * _poly_degree(polynomial)
                - len(polynomial)
            )
            ranked.append((score, polynomial))
        ranked.sort(key=lambda item: -item[0])
        selected = ranked[:maximum_basis]
        formulas = [
            self._poly_expression(polynomial) == 0
            for _, polynomial in selected
        ]
        candidates = []
        for clauses in range(1, min(max_clauses, len(formulas)) + 1):
            for indices in combinations(range(len(formulas)), clauses):
                formula = z3.simplify(
                    z3.And(*(formulas[index] for index in indices))
                )
                degree = max(
                    _poly_degree(selected[index][1])
                    for index in indices
                )
                candidates.append(
                    (
                        formula,
                        mechanism,
                        degree,
                        clauses,
                        tuple(str(formulas[index]) for index in indices),
                    )
                )
        return candidates

    def conserved_candidates(
        self, max_degree=3, max_clauses=3, maximum_basis=8
    ):
        """Find exact polynomial conservation laws via rational nullspace."""
        try:
            updates = self._update_polynomials()
        except VCAnalysisError:
            return []
        return self._conserved_candidates_for_update_sets(
            (updates,),
            max_degree=max_degree,
            max_clauses=max_clauses,
            maximum_basis=maximum_basis,
            mechanism="vc-polynomial-conservation",
        )

    def branchwise_conserved_candidates(
        self, max_degree=3, max_clauses=3, maximum_basis=8
    ):
        """Find a polynomial conserved across each bounded ITE branch."""
        branches = self._conditional_update_polynomials()
        if len(branches) < 2:
            return []
        return self._conserved_candidates_for_update_sets(
            branches,
            max_degree=max_degree,
            max_clauses=max_clauses,
            maximum_basis=max(maximum_basis, 24),
            mechanism="vc-branchwise-polynomial-conservation",
            enforce_initial=False,
        )

    def _branchwise_conservation_polynomials(self, max_degree):
        """Return a ranked exact basis without Boolean simplification loss."""
        update_sets = self._conditional_update_polynomials()
        if len(update_sets) < 2:
            return []
        variable_count = len(self.variables)
        monomials = _monomial_exponents(variable_count, max_degree)
        rows = []
        for updates in update_sets:
            delta_columns = []
            for exponent in monomials:
                delta_columns.append(self._delta(
                    {exponent: 1}, updates
                ))
            for output_exponent in sorted(
                set().union(*(set(item) for item in delta_columns))
            ):
                rows.append([
                    polynomial.get(output_exponent, 0)
                    for polynomial in delta_columns
                ])
        post_symbols = _symbols(self.postcondition)
        ranked = []
        for vector in _nullspace(rows, len(monomials)):
            vector = _integer_vector(vector)
            polynomial = {
                exponent: coefficient
                for exponent, coefficient in zip(monomials, vector)
                if coefficient
            }
            if not polynomial:
                continue
            used = {
                self.variables[index]
                for exponent in polynomial
                for index, power in enumerate(exponent)
                if power
            }
            overlap = len(used.intersection(post_symbols))
            ranked.append((
                20 * overlap
                + 3 * len(used)
                - 2 * _poly_degree(polynomial)
                - len(polynomial),
                polynomial,
            ))
        ranked.sort(key=lambda item: (-item[0], str(item[1])))
        return [polynomial for _, polynomial in ranked]

    def branchwise_post_completion_candidates(
        self, max_degree=3, maximum_candidates=12
    ):
        """Complete an exit residual with branchwise conserved quantities.

        Branching arithmetic loops often need an invariant such as
        ``exit_residual + 4 * remainder == 0``: the exit residual alone is
        not inductive, while the completed expression is.  Enumerate only
        two-term, small-integer combinations of the bounded conservation
        basis, require the complete precondition to prove initialization, and
        leave STEP/EXIT to the independent VC checker.
        """
        polynomials = self._branchwise_conservation_polynomials(
            max_degree=max_degree
        )[:4]
        if len(polynomials) < 2:
            return []

        def normalize(polynomial):
            exponents = sorted(polynomial)
            vector = _integer_vector([
                Fraction(polynomial[exponent]) for exponent in exponents
            ])
            return {
                exponent: coefficient
                for exponent, coefficient in zip(exponents, vector)
                if coefficient
            }

        post_symbols = _symbols(self.postcondition)
        ranked = []
        seen = set()
        entry_rewrites = self._precondition_state_rewrites()

        def consider(polynomial):
            polynomial = normalize(polynomial)
            if not polynomial:
                return
            key = tuple(sorted(polynomial.items()))
            if key in seen:
                return
            seen.add(key)
            if not self._polynomial_is_zero_at_entry(
                polynomial, entry_rewrites
            ):
                return
            used = {
                self.variables[index]
                for exponent in polynomial
                for index, power in enumerate(exponent)
                if power
            }
            overlap = len(used.intersection(post_symbols))
            ranked.append((
                20 * overlap
                - 2 * _poly_degree(polynomial)
                - len(polynomial),
                polynomial,
            ))

        for polynomial in polynomials:
            consider(polynomial)
        for left_index, left in enumerate(polynomials):
            for right_index, right in enumerate(polynomials):
                if left_index == right_index:
                    continue
                for coefficient in range(-4, 5):
                    if coefficient == 0:
                        continue
                    polynomial = _poly_add(
                        left,
                        _poly_scale(right, coefficient),
                    )
                    consider(polynomial)
        ranked.sort(key=lambda item: (-item[0], str(item[1])))
        candidates = []
        for _, polynomial in ranked[:maximum_candidates]:
            formula = self._poly_expression(polynomial) == 0
            candidates.append((
                formula,
                "vc-branchwise-post-completion",
                _poly_degree(polynomial),
                1,
                (str(formula),),
            ))
        return candidates

    def branchwise_entry_offset_candidates(
        self, max_degree=2, maximum_candidates=12
    ):
        """Center a branchwise conservation law at its parameterized entry.

        The conserved quantity in a Bresenham-style loop can equal an input
        polynomial rather than zero.  This bounded frontend subtracts that
        exact input value and joins it to a one-step affine counter boundary.
        Every formula is still independently checked against all VCs.
        """
        raw = self._branchwise_conservation_polynomials(max_degree)
        if not raw:
            return []
        rewrites = self._precondition_state_rewrites()
        immutable = {
            name for name, update in self.updates.items()
            if z3.eq(z3.simplify(update), self.symbols[name])
        }
        entry_to_current = []
        for name in immutable:
            value = rewrites.get(name)
            if value is not None and z3.is_const(value) and value.num_args() == 0:
                entry_to_current.append((value, self.symbols[name]))
        entry_facts = [
            self.symbols[name] == value
            for name in self.variables
            for value in (self._constant_initial_value(name),)
            if value is not None
        ]
        if not entry_facts:
            return []
        boundaries = []
        for guard in self.guard_terms:
            if not z3.is_le(guard):
                continue
            counter, bound = guard.children()
            if not self._is_named_const(counter, set(self.variables)):
                continue
            update = self.updates.get(str(counter))
            if update is None or not z3.eq(
                z3.simplify(update - counter), z3.IntVal(1)
            ):
                continue
            boundaries.append(z3.Or(
                z3.And(*entry_facts), counter <= bound + 1,
            ))
        candidates, seen = [], set()
        for polynomial in raw[:maximum_candidates]:
            expression = self._poly_expression(polynomial)
            entry_value = z3.simplify(z3.substitute(
                expression,
                *[(self.symbols[name], value)
                  for name, value in rewrites.items()],
            ), som=True)
            if entry_to_current:
                entry_value = z3.simplify(z3.substitute(
                    entry_value, *entry_to_current,
                ), som=True)
            centered = z3.simplify(expression - entry_value, som=True) == 0
            for boundary in boundaries:
                formula = z3.simplify(z3.And(centered, boundary), som=True)
                if str(formula) in seen:
                    continue
                seen.add(str(formula))
                try:
                    degree = self._formula_degree(formula)
                except VCAnalysisError:
                    continue
                candidates.append((
                    formula, "vc-branchwise-entry-offset", degree,
                    len(_flatten_and(formula)),
                    tuple(str(item) for item in _flatten_and(formula)),
                ))
        return candidates
