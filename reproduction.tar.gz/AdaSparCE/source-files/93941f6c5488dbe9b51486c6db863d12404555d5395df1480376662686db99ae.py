"""AdaSparCE configuration; defaults preserve the established CLI behavior."""

from dataclasses import dataclass
from dataclasses import field
from SparCE.engine import SparseConfig
from SparCE.scheduling.strategy_scheduler import DEFAULT_QUOTAS as DEFAULT_STRATEGY_QUOTAS


@dataclass
class AdaSparCEConfig(SparseConfig):
    max_degree: int = 3
    max_clauses: int = 3
    max_monomials: int = 30
    beam_width: int = 5
    # Opt-in coverage pass: target-guided relations, interval/phase
    # candidates, protected proof frontends and candidate-wide budgets.
    coverage_optimizations: bool = False
    fallback_enabled: bool = True
    degree_iterative: bool = True
    clause_iterative: bool = True
    typed_counterexamples: bool = True
    beam_search: bool = True
    # G module master switch (semantic candidate generation).  When
    # False, every program-semantics-specialised generator is disabled:
    # the typed mechanism frontiers (guard-split, counter-lift,
    # update-closure, remaining-work, sign-clauses, constant/monotone
    # entry bounds, affine exit boundaries, post-weakening,
    # term-dropping, precondition frames, divmod), the exact VC
    # frontends (smt-vc, algebraic-recurrence, branchwise-conservation,
    # scaled-division, entry-potential, exit-post-closure), the
    # transition kernel and the linear fast path.  What remains is the
    # Core pipeline: direct postcondition seeding plus the generic
    # sparse polynomial template search.  The per-family flags below
    # only refine which generators run *within* G; they cannot re-enable
    # anything once the master switch is off.  Default True keeps the
    # historical behaviour.
    semantic_generators_enabled: bool = True
    update_closure: bool = True
    precondition_frame: bool = True
    monotone_entry_bounds: bool = True
    affine_exit_boundary: bool = True
    smt_vc_frontend: bool = False
    smt_vc_max_degree: int = 4
    branchwise_conservation_frontend: bool = False
    branchwise_conservation_max_degree: int = 2
    scaled_division_frontend: bool = False
    entry_potential_frontend: bool = False
    exit_post_closure_frontend: bool = False
    divmod_frontend: bool = True
    linear_fast_path: bool = True
    # Guard the linear fast path against nonlinear pre-loop
    # initializations (entry products etc.): such programs need a
    # degree >= 2 invariant even when the loop body is linear.
    linear_fast_path_guard: bool = False
    neural_scorer_enabled: bool = False
    # Kept untyped to avoid importing PyTorch when the optional legacy scorer
    # is disabled (the default for symbolic and graph-strategy experiments).
    neural_scorer_config: object = None
    neural_scorer_checkpoint: str = ""
    neural_scorer_save_path: str = ""
    neural_ranker_enabled: bool = False
    graph_ranker_enabled: bool = False
    random_ranker_enabled: bool = False
    neural_ranker_checkpoint: str = ""
    neural_ranker_alpha: float = 1.0
    neural_ranker_beta: float = 1.0
    neural_ranker_gamma: float = 0.2
    neural_ranker_device: str = "auto"
    neural_ranker_topk_safe: int = 5
    neural_ranker_exploration_ratio: float = 0.1
    neural_ranker_nonlinear_only: bool = False
    neural_ranker_online_updates: bool = False
    graph_strategy_enabled: bool = False
    graph_strategy_weight: float = 8.0
    ranker_trace_enabled: bool = False
    ranker_trace_run_id: str = ""
    ranker_trace_program_hash: str = ""
    clause_composer_enabled: bool = False
    clause_composer_bank_size: int = 64
    clause_composer_max_ast_size: int = 180
    clause_composer_max_proposals: int = 32
    clause_composer_per_failure: int = 4
    clause_composer_generation_budget_ratio: float = 0.15
    # Partial-lemma conjunction trials: retain EXIT-only (inductive) and
    # STEP-failing clauses and verify bounded conjunctions of them, so
    # mutually dependent clause pairs can be proven jointly.
    lemma_conjunction_enabled: bool = True
    lemma_conjunction_max_trials: int = 48
    # Budget-proportional checker timeout escalation: when a candidate's
    # VC check times out and the task budget still has room, retry that
    # check with a timeout scaled to the remaining budget (bounded by
    # timeout_escalation_cap and a per-task retry limit).  Nonlinear
    # conjunctive candidates routinely need tens of seconds in z3 while
    # the static checker budget is tuned for cheap single-clause checks.
    timeout_escalation_limit: int = 3
    timeout_escalation_cap: float = 150.0
    # Layer-exhaustion escalation: after the configured (max_degree,
    # max_clauses) layers have been exhausted without a solution and the
    # typed-phase budget remains, continue the iterative layers up to
    # these caps (0 disables).  Escalated layers only run when lower
    # layers fail, matching the existing degree/clause-iterative order.
    degree_escalation_cap: int = 0
    clause_escalation_cap: int = 0
    algebraic_recurrence_frontend: bool = False
    algebraic_recurrence_max_degree: int = 6
    # Minimum degree for sparse-recurrence closures.  Zero keeps the
    # historical behaviour (smt_vc_max_degree + 1, i.e. only closures
    # strictly above the configured template degree); a positive value
    # lowers the floor and unlocks low-degree algebraic closures for
    # native nonlinear programs where the SMT-side candidate path never
    # runs.
    algebraic_recurrence_minimum_degree: int = 0
    # Branch-aware transition model: collect per-path (guard, updates)
    # transitions instead of the legacy merged sequential updates.  The
    # legacy ``updates`` attribute is untouched; only the new
    # ``branch_transitions`` consumers see the corrected model.
    branch_transitions_enabled: bool = False
    # Transition-kernel equality synthesis: invariant-subspace linear
    # algebra over a degree-bounded monomial basis, driven by the branch
    # transition relations and the initial conditions.  Emits atoms
    # (STEP-partial candidates for joint induction) and greedy minimal
    # invariant-subspace conjunctions; all emissions still pass the full
    # INIT/STEP/EXIT checker.
    transition_kernel_enabled: bool = False
    transition_kernel_max_degree: int = 3
    transition_kernel_max_atoms: int = 8
    transition_kernel_max_conjunctions: int = 3
    # Output-interface controls for attribution.  The common classical
    # invariant-space computation and the complete default emission plan
    # run in every arm; these flags filter only the resulting candidates.
    # This avoids changing basis/atom quotas when one interface is absent.
    transition_kernel_target_enabled: bool = True
    transition_kernel_sparse_groups_enabled: bool = True
    transition_kernel_boundary_partners_enabled: bool = True
    # Unified clause bank: a single shared store of partial clauses with
    # INIT/STEP/EXIT outcomes, counterexamples, source mechanism and
    # checker cost.  The partial-lemma conjunction trials and the clause
    # composer both draw from it (cross STEP x EXIT pairing, full-set
    # step conjunctions) instead of keeping two separate pools.
    unified_clause_bank_enabled: bool = False
    unified_clause_bank_max_trials: int = 64
    # Stagnation-triggered fallback: "fixed" keeps the historical 30/70
    # typed/fallback time split; "stagnation" gives the typed phase the
    # full budget but hands the remainder to the fallback engine after
    # repeated checks without a new counterexample or failure-type change.
    fallback_mode: str = "fixed"
    fallback_stagnation_patience: int = 8
    fallback_stagnation_min_elapsed_ratio: float = 0.2
    # Sound counterexample replay: skip the SMT checker for candidates
    # that a previously observed counterexample already refutes.
    counterexample_prefilter: bool = False
    counterexample_prefilter_max_records: int = 64
    # "topk" freezes the heuristic prefix of the neural ranker (legacy
    # behaviour); "mechanism" replaces the global prefix with one
    # guaranteed heuristic representative per triggered mechanism and
    # lets the ranker order everything else.
    neural_ranker_safety_mode: str = "topk"
    # Cost-aware strategy-level scheduling.  When enabled, mechanism
    # pools (VC frontends, typed mechanisms, CE synthesis), the clause
    # composer, partial-lemma conjunction trials and the fallback
    # hand-over moment are ordered by a StrategyScheduler that picks
    # (strategy category, per-round candidate quota, checker timeout
    # tier) per decision.  Disabled by default: the legacy deterministic
    # pipeline (VC frontend -> seed -> typed 30% -> composer -> fallback
    # with degree-outer/clause-inner layers) is preserved exactly.
    strategy_scheduler_enabled: bool = False
    strategy_scheduler_policy: str = "heuristic"  # heuristic | random
    strategy_scheduler_utility: str = "ratio"  # ratio | linear | success
    # empirical: corpus-derived aggregate priors; cold: zero corpus
    # statistics (uniform success prior + structural cost classes).
    strategy_scheduler_priors: str = "empirical"  # empirical | cold
    strategy_scheduler_epsilon: float = 1.0
    strategy_scheduler_lambda: float = 0.005
    strategy_scheduler_mu: float = 0.1
    strategy_scheduler_exploration_scale: float = 0.05
    strategy_scheduler_min_typed_budget_ratio: float = 0.15
    strategy_scheduler_min_fallback_budget_ratio: float = 0.2
    strategy_scheduler_timeout_tiers: tuple = (4.0, 15.0, 60.0, 150.0)
    strategy_scheduler_quotas: dict = field(
        default_factory=lambda: dict(
            DEFAULT_STRATEGY_QUOTAS
        )
    )
    strategy_scheduler_max_decisions: int = 200
    # Best-first combined complexity ordering inside scheduler pools
    # (replaces the degree-outer / clause-inner layer order).
    strategy_scheduler_complexity_degree_weight: float = 2.0
    strategy_scheduler_complexity_clause_weight: float = 1.0
    # Progress-feedback scheduling: add a per-strategy best-progress
    # bonus to the utility (EXIT > STEP > INIT), so strategies that
    # advance the proof keep their share of the budget.  The exploration
    # floor is unchanged.  Default off (legacy utility).
    strategy_scheduler_progress_feedback: bool = False
    strategy_scheduler_granularity: str = "category21"
    strategy_scheduler_online_updates: bool = True
    strategy_scheduler_quota_mode: str = "legacy"
    strategy_scheduler_round_budget_ratio: float = 0.10
    strategy_scheduler_prior_strength: float = 5.0
    strategy_scheduler_progress_weight: float = 0.05
    strategy_scheduler_disabled_categories: tuple = ()
    # Checker-timeout retry: a candidate whose check timed out (after
    # the budget-proportional escalation) is recorded as UNKNOWN — never
    # as definitive failure evidence — and re-queued once with a higher
    # timeout tier while the task budget allows.
    checker_timeout_retry_enabled: bool = False
    checker_timeout_retry_limit: int = 1
