from __future__ import annotations
import abc
import json
from collections import Counter
from collections.abc import Callable
from enum import StrEnum
import pdb
import random
import shutil
import tempfile
import time
from pathlib import Path
import sys
from beartype import beartype


import settings
from helpers.miscs import Miscs, MP
import helpers.vcommon as CM

import data.prog
from data.symstates import SymStates, SymStatesMakerC
from data.traces import DTraces

from infer.inv import DInvs
import infer.nested_array
import infer.eqt
import infer.oct
import infer.mp
import infer.congruence
import infer.recurrence
import infer.kapur

DBG = pdb.set_trace

mlog = CM.getLogger(__name__, settings.LOGGER_LEVEL)


class InferType(StrEnum):
    EQTS = "eqts"
    IEQS = "ieqs"
    MINMAX = "minmax"
    CONGRUENCE = "congruence"


class Dig(metaclass=abc.ABCMeta):
    EQTS = InferType.EQTS
    IEQS = InferType.IEQS
    MINMAX = InferType.MINMAX
    CONGRUENCE = InferType.CONGRUENCE

    @beartype
    def __init__(self, filename: Path) -> None:
        
        mlog.info(f"analyzing '{filename}'")
        self.filename = filename
        self.time_d = {}  # time results

    @beartype        
    @abc.abstractmethod
    def start(self, seed: float, maxdeg: int | None) -> None:
        self.seed = seed
        random.seed(seed)
        mlog.debug(f"{seed=} (test {random.randint(0, 100)})")

    @beartype
    def get_auto_deg(self, maxdeg: int | None) -> int:
        maxvars = max(self.inv_decls.values(), key=len)
        deg = Miscs.get_auto_deg(maxdeg, len(maxvars), settings.MAX_TERM)
        return deg

    @beartype
    def sanitize(self, dinvs: DInvs, dtraces: DTraces) -> DInvs:
        if not dinvs.siz:
            return dinvs

        msg = f"check {dinvs.siz} invs using {dtraces.siz} traces"
        mlog.debug(msg)
        st = time.time()
        dinvs = dinvs.test(dtraces)
        mlog.info(f"{msg} ({time.time() - st:.2f}s)")
        if not dinvs.siz:
            return dinvs

        if settings.DO_SIMPLIFY:
            try:
                self.symstates.get_solver_stats()
            except AttributeError:
                # DigTraces does not have symbolic states
                pass

            msg = f"simplify {dinvs.siz} invs"
            mlog.debug(msg)
            mlog.debug(dinvs.__str__(print_stat=False, print_first_n=20))
            st1 = time.time()
            dinvs = dinvs.simplify()
            mlog.info(f"{msg} ({time.time() - st1:.2f}s)")

        self.time_d["simplify"] = time.time() - st

        return dinvs


class DigSymStates(Dig, metaclass=abc.ABCMeta):
    
    @beartype
    def __init__(self, filename: Path) -> None:
        super().__init__(filename)

    @beartype
    def start(self, seed: float, maxdeg: int | None) -> None | DInvs:

        if not (maxdeg is None or maxdeg >= 1):
            raise ValueError(f"maxdeg has invalid value {maxdeg}")

        super().start(seed, maxdeg)

        assert settings.TMPDIR.is_dir()

        seed_str = str(int(self.seed)) if isinstance(self.seed, (int, float)) and float(self.seed).is_integer() else str(hash(self.seed))
        self.tmpdir = Path(
            tempfile.mkdtemp(dir=settings.TMPDIR, prefix=f"Dig_{seed_str}_")
        )
        self.tmpdir_del = self.tmpdir / "delete_me"
        self.tmpdir_del.mkdir()
        (self.tmpdir / "settings.json").write_text(
            json.dumps(settings.effective_settings(), indent=2) + "\n")

        self.mysrc = self.mysrc_cls(self.filename, self.tmpdir_del)
        self.inp_decls = self.mysrc.inp_decls
        self.inv_decls = self.mysrc.inv_decls

        self.prog = data.prog.Prog(
            self.exe_cmd, self.inp_decls, self.inv_decls, source=self.filename)

        if not settings.DO_SS:  # use traces from running the program on random inputs
            rinps = self.prog.gen_rand_inps(n_needed=settings.N_RAND_INPS)
            inps = data.traces.Inps().merge(rinps, self.inp_decls.names)
            mlog.debug(f"gen {len(inps)} random inps")
            if not inps:
                return

            assert isinstance(inps, data.traces.Inps), inps
            dtraces = self.prog.get_traces(inps)
            if not dtraces:
                return

            digtraces = DigTraces(
                self.filename, self.inv_decls, dtraces, test_dtraces=None)

            dinvs = digtraces.start(self.seed, maxdeg)

        else:  # use symbolic states
            st = time.time()
            self.symstates = self.get_symbolic_states()
            et = time.time() - st
            self.time_d["symbolic_states"] = et

            self.locs = self.prog.locs
            # remove locations with no symbolic states
            for loc in list(self.prog.locs):
                if loc not in self.symstates:
                    mlog.warning(f"{loc}: no symbolic states. Skip")
                    self.inv_decls.pop(loc)
            
            mlog.info(
                f"got {self.symstates.siz} symstates for {len(self.symstates)} "
                f"locs {list(map(str, self.symstates))} in {et:.2f}s")

            self._deg_hints = {}
            if settings.DO_EQTS:
                self._deg_hints = self._estimate_degrees(maxdeg)

            tasks = []
            if settings.DO_EQTS:
                def f():
                    return self._infer(self.EQTS, lambda: self._infer_eqts(maxdeg))
                tasks.append(f)

            if settings.DO_IEQS:
                def f():
                    return self._infer(self.IEQS, self._infer_ieqs)
                tasks.append(f)

            if settings.DO_MINMAXPLUS:
                def f():
                    return self._infer(self.MINMAX, self._infer_minmax)
                tasks.append(f)

            def f(tasks):
                rs = [_f() for _f in tasks]
                return rs

            # Run domains sequentially so their candidate/term workers can
            # use the full internal pool. Forking domains as daemon workers
            # forces every nested pool to run serially, leaving hundreds of
            # nonlinear min/max queries on a single worker.
            wrs = f(tasks)

            dinvs = DInvs()
            dtraces = DTraces.mk(self.locs)

            for typ, (dinvs_, dtraces_), et in wrs:
                self.time_d[typ] = et
                dinvs.merge(dinvs_)
                if dtraces_:
                    dtraces.merge(dtraces_)

            dinvs.merge(self._infer_trace_based(dtraces))
            dinvs.merge(self._infer_recurrence())
            dinvs.merge(self._infer_kapur())
            dinvs = self.sanitize(dinvs, dtraces)

            self.time_d["total"] = time.time() - st
            self.cleanup(dinvs, dtraces)

        if settings.WRITE_VTRACES:
            tracefile = Path(settings.WRITE_VTRACES)
            dtraces.vwrite(self.inv_decls, tracefile)
            mlog.info(f"{dtraces.siz} traces written to {tracefile}")

        mlog.debug(f"tmpdir: {self.tmpdir}")
        return dinvs

    @beartype
    def cleanup(self, dinvs: DInvs, dtraces: DTraces) -> None:
        """
        Save and analyze result
        Clean up tmpdir
        """
        # analyze and save results
        from analysis import Result, Analysis

        result = Result(
            self.filename,
            self.seed,
            dinvs,
            dtraces,
            self.symstates.solver_stats_,
            self.time_d,
        )
        result.save(self.tmpdir)
        (self.tmpdir / "evidence.json").write_text(json.dumps({
            "symbolic_exploration": self.symstates.exploration_info,
            "concrete_execution_outcomes": dict(Counter(self.prog.execution_outcomes.values())),
            "numerical_checks": "bounded symbolic states and collected traces",
        }, indent=2) + "\n")
        Analysis(self.tmpdir).start()  # output stats

        # Clean up scratch compilation/trace artifacts
        if hasattr(self, "tmpdir_del") and self.tmpdir_del.exists():
            shutil.rmtree(self.tmpdir_del, ignore_errors=True)

        # If using default system temporary dir (not a user-provided -tmpdir), clean up self.tmpdir
        if Path(tempfile.gettempdir()).resolve() == settings.TMPDIR.resolve():
            shutil.rmtree(self.tmpdir, ignore_errors=True)

    @beartype
    def _infer(self, typ: str, _get_invs: Callable) -> tuple:
        assert typ in {self.EQTS, self.IEQS, self.MINMAX,
                       self.CONGRUENCE}, typ
        
        mlog.debug(f"infer '{typ}' at {len(self.locs)} locs")

        st = time.time()

        dinvs, dtraces = _get_invs()
        et = time.time() - st
        if dinvs.siz:
            mlog.info(f"got {dinvs.siz} {typ} in {et:.2f}s")
            mlog.debug(dinvs.__str__(print_stat=True, print_first_n=20))

        return typ, (dinvs, dtraces),  et

    @beartype
    def _infer_eqts(self, maxdeg: int | None) -> tuple[DInvs, DTraces]:
        ceilings = {loc: Miscs.get_auto_deg(maxdeg, len(symbols), settings.MAX_TERM)
                    for loc, symbols in self.inv_decls.items()}
        initial_traces = data.traces.DTraces.parse(
            [line for lines in self.prog._cache.values() for line in lines], self.inv_decls)
        dinvs, dtraces = infer.eqt.Infer(self.symstates, self.prog).gen(
            max(ceilings.values()), getattr(self, "_deg_hints", {}),
            complete=maxdeg is not None, initial_traces=initial_traces, ceilings=ceilings)
        return dinvs, dtraces

    def _infer_ieqs(self) -> tuple[DInvs, None]:
        return infer.oct.Infer(self.symstates, self.prog).gen(), None

    def _infer_minmax(self) -> tuple[DInvs, None]:
        return infer.mp.Infer(self.symstates, self.prog).gen(), None

    def _infer_trace_based(self, dtraces: DTraces) -> DInvs:
        """Run trace-only inference types on dtraces."""
        result = DInvs()
        locs = [loc for loc in dtraces
                if loc in self.inv_decls and not self.inv_decls[loc].array_only]

        checks = [
            (settings.DO_CONGRUENCES, "congruences", infer.congruence.Infer.gen_from_traces),
        ]
        for enabled, label, gen_fn in checks:
            if not enabled:
                continue
            st = time.time()
            batch = DInvs()
            for loc in locs:
                for inv in gen_fn(dtraces[loc], self.inv_decls[loc]):
                    batch.add(loc, inv)
            et = time.time() - st
            if batch.siz:
                mlog.info(f"got {batch.siz} {label} in {et:.2f}s")
            result.merge(batch)
            self.time_d[label] = et

        return result

    @beartype
    def _keep_local(self, eqts: list, loc: str) -> list:
        """Drop static-engine equalities that mention variables not observed at
        `loc`. A solvable loop can carry locals (e.g. ps2's counter `c`) that
        are not in the vtrace's argument list; an invariant over them can't be
        tested against traces (the variable is unbound) and isn't reportable at
        this location. Branching loops (multi-path) have more such locals, so
        this guard matters for both the single- and multi-path engines.
        """
        allowed = set(self.inv_decls[loc].names)
        kept = []
        for eqt in eqts:
            if {str(s) for s in eqt.inv.free_symbols}.issubset(allowed):
                kept.append(eqt)
        return kept

    @beartype
    def _infer_recurrence(self) -> DInvs:
        """Static, recurrence-based equalities for solvable loops.

        Reads each loop's transition relation directly (no traces), solves the
        induced recurrences to closed forms, eliminates the loop counter to
        polynomial equalities, and proves them by unbounded k-induction. The
        results are already PROVED, so they complement the dynamic engine and
        cover cases its degree budget or trace sampling can miss. Loops that
        are not solvable single-path recurrences are skipped.
        """
        result = DInvs()
        if not settings.DO_RECURRENCE:
            return result

        st = time.time()
        try:
            per_loc = infer.recurrence.gen_all(self.filename)
        except Exception as ex:
            mlog.debug(f"recurrence inference failed: {ex}")
            per_loc = {}

        batch = DInvs()
        for loc, eqts in per_loc.items():
            if loc in self.inv_decls and not self.inv_decls[loc].array_only:
                for eqt in self._keep_local(eqts, loc):
                    batch.add(loc, eqt)
        et = time.time() - st
        if batch.siz:
            mlog.info(f"got {batch.siz} recurrence eqts in {et:.2f}s")
            mlog.debug(batch.__str__(print_stat=True, print_first_n=20))
        self.time_d["recurrence"] = et
        return batch

    @beartype
    def _infer_kapur(self) -> DInvs:
        """Static equalities via the Rodriguez-Carbonell & Kapur bounded-degree
        invariant-ideal method (opt-in, -dokapur). Complementary to the
        recurrence engine: it computes the degree-bounded polynomial invariant
        ideal directly from the reachable-state null space, proving each
        generator by k-induction. Loops that are not single polynomial maps are
        skipped.
        """
        result = DInvs()
        if not settings.DO_KAPUR:
            return result

        st = time.time()
        try:
            per_loc = infer.kapur.gen_all(self.filename)
        except Exception as ex:
            mlog.debug(f"kapur inference failed: {ex}")
            per_loc = {}

        batch = DInvs()
        for loc, eqts in per_loc.items():
            if loc in self.inv_decls and not self.inv_decls[loc].array_only:
                for eqt in self._keep_local(eqts, loc):
                    batch.add(loc, eqt)
        et = time.time() - st
        if batch.siz:
            mlog.info(f"got {batch.siz} kapur eqts in {et:.2f}s")
            mlog.debug(batch.__str__(print_stat=True, print_first_n=20))
        self.time_d["kapur"] = et
        return batch

    @beartype
    def get_symbolic_states(self) -> SymStates:
        symstates = SymStates(self.inp_decls, self.inv_decls)

        if settings.READ_SSTATES:
            sstatesfile = Path(settings.READ_SSTATES)
            symstates.vread(sstatesfile)
            mlog.info(f"{symstates.siz} symstates read from '{sstatesfile}'")

        else:
            symstates.compute(
                self.symstatesmaker_cls,
                self.symexefile,
                self.mysrc.mainQ_name,
                self.mysrc.funname,
                self.mysrc.symexedir,
            )

            if settings.WRITE_SSTATES:
                sstatesfile = Path(settings.WRITE_SSTATES)
                symstates.vwrite(sstatesfile)
                mlog.info(f"{symstates.siz} symstates written to '{sstatesfile}'")
                sys.exit(0)

        return symstates

    @beartype
    def _estimate_degrees(self, maxdeg: int | None) -> dict[str, int]:
        """
        Per-location finite-difference degree estimate from traces, used as a
        *floor* hint for eqt degree selection (never an upper cap). Runs a few
        inputs and reads each execution's ordered vtrace sequence.

        Side-effect-free wrt determinism: the RNG state and the prog's
        valid-range cache are saved and restored, so this does not change the
        inputs/traces later inference would generate.
        """
        hints: dict[str, int] = {}
        rng_state = random.getstate()
        had_ranges = hasattr(self.prog, "_valid_ranges")
        try:
            ceiling = self.get_auto_deg(maxdeg)
            rinps = self.prog.gen_rand_inps(n_needed=5)
            inps = data.traces.Inps().merge(rinps, self.inp_decls.names)

            # loc -> list of executions, each an ordered list of {var: val} rows
            exec_rows: dict[str, list] = {}
            for inp in inps:
                rows_by_loc: dict[str, list] = {}
                for line in self.prog._get_traces(inp):
                    parts = [p.strip() for p in line.split(";") if p.strip()]
                    if not parts or parts[0] not in self.inv_decls:
                        continue
                    loc, vals = parts[0], parts[1:]
                    names = self.inv_decls[loc].names
                    if len(vals) != len(names):
                        continue
                    rows_by_loc.setdefault(loc, []).append(dict(zip(names, vals)))
                for loc, rows in rows_by_loc.items():
                    exec_rows.setdefault(loc, []).append(rows)

            parts = []
            for loc in sorted(exec_rows):
                per_var, mx = Miscs.estimate_degree(exec_rows[loc])
                if mx is not None:
                    hints[loc] = mx
                parts.append(f"{loc} max {mx} {per_var}")
            if parts:
                mlog.info(f"deg-est (ceiling {ceiling}): " + "; ".join(parts))
        except Exception as ex:
            mlog.debug(f"degree estimate failed: {ex}")
        finally:
            random.setstate(rng_state)
            if not had_ranges and hasattr(self.prog, "_valid_ranges"):
                del self.prog._valid_ranges
        return hints


class DigSymStatesC(DigSymStates):
    mysrc_cls = data.prog.C
    symstatesmaker_cls = SymStatesMakerC

    @beartype
    @property
    def symexefile(self) -> Path:
        # the Python symex engine reads the original source directly
        return self.filename

    @beartype
    @property
    def exe_cmd(self) -> str:
        return settings.C.C_RUN(exe=self.mysrc.traceexe)


class DigTraces(Dig):
    @beartype
    def __init__(self, filename: Path, inv_decls: data.prog.DSymbs,
                 dtraces: DTraces, test_dtraces: DTraces | None) -> None:
        super().__init__(filename)

        self.inv_decls = inv_decls
        self.dtraces = dtraces
        if test_dtraces:
            self.test_dtraces = test_dtraces

    @beartype
    def start(self, seed: float, maxdeg: int | None) -> DInvs:
        assert maxdeg is None or maxdeg >= 1, maxdeg

        super().start(seed, maxdeg)
        mlog.info(
            f"got {self.dtraces.siz} traces over {len(self.dtraces)} locs")
        mlog.debug(f"{self.dtraces}")

        tasks = (self._nested_arrays_tasks() +
                 self._eqts_tasks(maxdeg) +
                 self._ieqs_tasks() +
                 self._minmax_tasks() +
                 self._congruences_tasks())

        def f(tasks):
            rs = [(loc, _f(loc)) for loc, _f in tasks]
            return rs

        wrs = MP.run_mp("(pure) dynamic inference", tasks, f, settings.DO_MP)

        dinvs = DInvs()
        for loc, invs in wrs:
            for inv in invs:
                dinvs.add(loc, inv)

        try:
            new_traces = self.dtraces.merge(self.test_dtraces)
            mlog.debug(f"added {new_traces.siz} test traces")
        except AttributeError:
            pass  # no test traces

        dinvs = self.sanitize(dinvs, self.dtraces)
        return dinvs

    def _nested_arrays_tasks(self) -> list:
        def _f(l):
            return infer.nested_array.Infer.gen_from_traces(self.dtraces[l])

        def _g(l):
            return self.inv_decls[l].array_only
        return self._mk_tasks(settings.DO_ARRAYS, _g,  _f)

    def _eqts_tasks(self, maxdeg: int | None) -> list:
        def _f(l):
            return infer.eqt.Infer.gen_from_traces(
                Miscs.get_auto_deg(maxdeg, len(self.inv_decls[l]), settings.MAX_TERM),
                self.dtraces[l], self.inv_decls[l])

        def _g(l):
            return not self.inv_decls[l].array_only
        return self._mk_tasks(settings.DO_EQTS, _g, _f)

    def _ieqs_tasks(self) -> list:
        def _f(l):
            return infer.oct.Infer.gen_from_traces(
                self.dtraces[l], self.inv_decls[l])

        def _g(l):
            return not self.inv_decls[l].array_only
        return self._mk_tasks(settings.DO_IEQS, _g,  _f)

    def _minmax_tasks(self) -> list:
        def _f(l):
            return infer.mp.Infer.gen_from_traces(
                self.dtraces[l], self.inv_decls[l])

        def _g(l):
            return not self.inv_decls[l].array_only
        return self._mk_tasks(settings.DO_MINMAXPLUS, _g, _f)

    def _congruences_tasks(self) -> list:
        def _f(l):
            return infer.congruence.Infer.gen_from_traces(
                self.dtraces[l], self.inv_decls[l])

        def _g(l):
            return not self.inv_decls[l].array_only
        return self._mk_tasks(settings.DO_CONGRUENCES, _g,  _f)

    def _mk_tasks(self, cond1, cond2, _f: Callable) -> list:
        if not cond1:
            return []
        return [(loc, _f) for loc in self.dtraces if cond2(loc)]

    @classmethod
    def mk(cls, tracefile: Path, test_tracefile: Path | None) -> DigTraces:
        assert tracefile.is_file(), tracefile
        assert test_tracefile is None or test_tracefile.is_file()

        inv_decls, dtraces = DTraces.vread(tracefile)

        test_dtraces = None
        if test_tracefile:
            _, test_dtraces = DTraces.vread(test_tracefile)

        return cls(tracefile, inv_decls, dtraces, test_dtraces)
