"""Canonical scheduling taxonomy; independent of the solver and ML libraries.

System modules G/C/E/S are architectural responsibilities, not action groups.
The coarse4 and middle8 partitions below group actions by proof construction.
Their order and membership are fixed before the supplementary experiments.
"""

from dataclasses import dataclass

SCHEMA_VERSION = "adasparce.strategy-catalog.v1"
SYSTEM_MODULES = {"G": "semantic generation", "C": "clause composition",
                  "E": "counterexample guidance", "S": "budget scheduling"}


@dataclass(frozen=True)
class StrategySpec:
    name: str
    coarse: str
    middle: str
    cost_class: int
    legacy_quota: int
    principle: str
    trigger: str
    output: str
    implementation: str


# General mathematical motivations are not claims that the concrete portfolio
# was derived before seeing NL50. See docs/method/strategy_sources.md.
STRATEGIES = (
    StrategySpec("postcondition-seed", "specification", "specification", 0, 1,
                 "直接检验目标是否已经归纳", "存在后置条件", "后置公式",
                 "SparCE/search/frontend.py"),
    StrategySpec("guard-split", "specification", "boundary", 1, 4,
                 "循环守卫与退出边界分解", "可识别计数器/守卫", "守卫、边界与关系子句",
                 "SparCE/generation/semantic.py"),
    StrategySpec("precondition-entry-bound", "specification", "boundary", 0, 4,
                 "初始事实保留与单调界传播", "初始值或单调变量", "frame、常数界、入口界",
                 "SparCE/generation/semantic.py"),
    StrategySpec("update-closure", "algebra", "recurrence", 1, 3,
                 "对转移代入寻求闭包", "可解析变量更新", "更新关系及其闭包候选",
                 "SparCE/generation/semantic.py"),
    StrategySpec("remaining-work", "specification", "boundary", 1, 3,
                 "累计量与剩余量的关系", "计数器/剩余工作量可识别", "累计量界与关系",
                 "SparCE/generation/semantic.py"),
    StrategySpec("sign-clauses", "specification", "boundary", 0, 3,
                 "符号与区间抽象", "可识别符号约束", "非负/非正原子",
                 "SparCE/generation/semantic.py"),
    StrategySpec("divmod", "arithmetic", "division", 2, 3,
                 "整除与余数约束", "div/mod 结构", "商余关系与余数界",
                 "SparCE/generation/division.py"),
    StrategySpec("counter-lift", "algebra", "recurrence", 1, 4,
                 "引入计数器消去递推步数", "同步计数器与累计更新", "计数器提升关系",
                 "SparCE/generation/semantic.py"),
    StrategySpec("affine-exit-boundary", "specification", "boundary", 0, 3,
                 "仿射更新与退出边界", "等式目标及同步计数器", "仿射边界候选",
                 "SparCE/generation/semantic.py"),
    StrategySpec("transition-kernel", "algebra", "conservation", 1, 3,
                 "有界单项式基上的转移不变子空间", "多项式分支转移", "初值消失核、闭包合取及过冲界",
                 "SparCE/generation/transition_kernel.py"),
    StrategySpec("post-weakening", "specification", "specification", 1, 4,
                 "目标弱化、项删除及析取分解", "后置条件结构可解析", "弱化等式/不等式/分支目标",
                 "SparCE/generation/semantic.py"),
    StrategySpec("algebraic-recurrence", "algebra", "recurrence", 2, 3,
                 "有限差分与稀疏递推闭包", "多项式递推", "代数等式及提升闭包",
                 "SparCE/generation/vc_recurrence.py"),
    StrategySpec("branchwise-conservation", "algebra", "conservation", 2, 3,
                 "逐分支守恒检验与关系补全", "多个分支转移", "分支共同守恒关系",
                 "SparCE/generation/vc_conservation.py"),
    StrategySpec("scaled-division", "arithmetic", "division", 2, 3,
                 "带尺度除法更新的关系构造", "可支持的除法更新", "尺度/差分闭包候选",
                 "SparCE/generation/vc_recurrence.py"),
    StrategySpec("entry-potential-exit-post-closure", "algebra", "conservation", 2, 3,
                 "入口势函数与目标闭包", "初始势或退出关系可构造", "势函数包络及目标闭包",
                 "SparCE/generation/vc_analyzer.py"),
    StrategySpec("vc-frontend", "arithmetic", "generic", 2, 3,
                 "验证条件驱动的通用符号前端", "可解析 SMT VC", "其余 VC 前端候选（残余类别）",
                 "SparCE/generation/vc_analyzer.py"),
    StrategySpec("ce-synthesis", "feedback-composition", "counterexample", 1, 2,
                 "反例约束驱动候选修正", "有反例观测", "边界/关系拟合候选",
                 "SparCE/generation/ce_synthesis.py"),
    StrategySpec("partial-lemma-conjunction", "feedback-composition", "composition", 2, 4,
                 "部分证明义务互补的合取", "部分归纳引理或 STEP 候选", "跨候选合取",
                 "SparCE/feedback/partial_lemma.py"),
    StrategySpec("clause-composer", "feedback-composition", "composition", 1, 4,
                 "共享子句库的类型化组合", "可用原子子句", "合取/受限组合候选",
                 "SparCE/feedback/clause_composer.py"),
    StrategySpec("fallback", "arithmetic", "generic", 2, 1,
                 "稀疏模板枚举与 SMT 系数求解", "保留预算或候选池耗尽", "度数/子句受界多项式模板",
                 "SparCE/engine.py"),
    StrategySpec("other", "arithmetic", "generic", 1, 2,
                 "未知机制的显式保留槽", "尚无登记映射", "原样保留候选；不代表独立证明原理",
                 "SparCE/scheduling/strategy_scheduler.py"),
)

CATALOG = {spec.name: spec for spec in STRATEGIES}
STRATEGY_CATEGORIES = tuple(CATALOG)
STRATEGY_COST_CLASS = {s.name: s.cost_class for s in STRATEGIES}
DEFAULT_QUOTAS = {s.name: s.legacy_quota for s in STRATEGIES}
GRANULARITIES = ("category21", "coarse4", "middle8", "mechanism")


def category_group(category, granularity):
    spec = CATALOG[category]
    if granularity == "coarse4":
        return spec.coarse
    if granularity == "middle8":
        return spec.middle
    return category
