"""Mechanism registry: single source of truth for mechanism metadata.

AdaSparCE generates candidates through a set of named mechanisms
(postcondition seeds, typed closure branches, VC frontends, ...).  This
module is a thin, dependency-free registry that attaches stable metadata
to each mechanism *prefix*:

* ``category``    – human-readable mechanism family;
* ``cost_class``  – expected relative checker cost (0 = cheap structural
  seed, 1 = typed composition, 2 = expensive frontend / CE machinery);
* ``strategy``    – the strategy category the prefix normalizes to in
  ``SparCE.scheduling.strategy_scheduler`` (the scheduler derives its prefix rules
  from this registry, so a new mechanism only needs to be registered
  here).

The registry never changes proof semantics.  It is used for

1. ordering the mechanism-representative round of the
   ``neural_ranker_safety_mode="mechanism"`` scheduler (cheap
   representatives are probed first so the run maximises information per
   second), and
2. observability: cost classes are logged with scheduling events so
   experiments can attribute time to mechanism classes.

Mechanism names are matched by longest prefix so variants such as
``typed-post-weakening-le``/``-ge`` or ``typed-divmod-euclidean`` resolve
through a single entry.  Unknown mechanisms default to the medium cost
class, which keeps scheduling conservative for new mechanisms.

The ``vc-`` and ``program-`` catch-all prefixes are deliberately NOT
strategy rules: the scheduler resolves them with its own twin-frontend
recursion (see ``normalize_strategy``).
"""

REGISTRY = {
    "typed-clause-compose": {
        "category": "composition", "cost_class": 1,
        "strategy": "clause-composer",
    },
    # cost_class 0: cheap structural seeds, no solver-side preparation
    "postcondition-seed": {
        "category": "seed", "cost_class": 0,
        "strategy": "postcondition-seed",
    },
    "typed-precondition-frame": {
        "category": "typed", "cost_class": 0,
        "strategy": "precondition-entry-bound",
    },
    "typed-constant-entry-bounds": {
        "category": "typed", "cost_class": 0,
        "strategy": "precondition-entry-bound",
    },
    "typed-monotone-entry-bounds": {
        "category": "typed", "cost_class": 0,
        "strategy": "precondition-entry-bound",
    },
    "typed-sign-clauses": {
        "category": "typed", "cost_class": 0,
        "strategy": "sign-clauses",
    },
    "typed-affine-exit-boundary": {
        "category": "typed", "cost_class": 0,
        "strategy": "affine-exit-boundary",
    },
    # cost_class 1: typed composition / CE-guided branches
    "typed-counter-lift": {
        "category": "typed", "cost_class": 1,
        "strategy": "counter-lift",
    },
    "typed-counter-boundary": {
        "category": "typed", "cost_class": 1,
        "strategy": "counter-lift",
    },
    "typed-counter-accumulator": {
        "category": "typed", "cost_class": 1,
        "strategy": "counter-lift",
    },
    "typed-guard-split": {
        "category": "typed", "cost_class": 1,
        "strategy": "guard-split",
    },
    "typed-update-closure": {
        "category": "typed", "cost_class": 1,
        "strategy": "update-closure",
    },
    "typed-remaining-work": {
        "category": "typed", "cost_class": 1,
        "strategy": "remaining-work",
    },
    "typed-post-weakening": {
        "category": "typed", "cost_class": 1,
        "strategy": "post-weakening",
    },
    "typed-term-dropping": {
        "category": "typed", "cost_class": 1,
        "strategy": "post-weakening",
    },
    "typed-disjunctive-post": {
        "category": "typed", "cost_class": 1,
        "strategy": "post-weakening",
    },
    "ce-": {
        "category": "ce-synthesis", "cost_class": 1,
        "strategy": "ce-synthesis",
    },
    "ce-synthesized": {
        "category": "ce-synthesis", "cost_class": 1,
        "strategy": "ce-synthesis",
    },
    "partial-lemma-conjunction": {
        "category": "partial-lemma", "cost_class": 1,
        "strategy": "partial-lemma-conjunction",
    },
    # cost_class 2: expensive frontends and solver-heavy machinery
    "typed-divmod": {
        "category": "divmod", "cost_class": 2,
        "strategy": "divmod",
    },
    "vc-": {
        "category": "vc-frontend", "cost_class": 2,
        "strategy": "vc-frontend",
    },
    "program-": {
        "category": "vc-frontend", "cost_class": 2,
        "strategy": "vc-frontend",
    },
    "linear-fast-path": {
        "category": "fast-path", "cost_class": 2,
        # never a pool member; resolves to "other" like before
        "strategy": "other",
    },
    "fallback": {
        "category": "fallback", "cost_class": 2,
        "strategy": "fallback",
    },
    # algebraic-recurrence frontend family (prefix twins, one strategy)
    "typed-transition-kernel": {
        "category": "typed", "cost_class": 1,
        "strategy": "transition-kernel",
    },
    "vc-counter-lifted-sparse-recurrence-closure": {
        "category": "vc-frontend", "cost_class": 2,
        "strategy": "algebraic-recurrence",
    },
    "program-counter-lifted-sparse-recurrence-closure": {
        "category": "vc-frontend", "cost_class": 2,
        "strategy": "algebraic-recurrence",
    },
    "vc-sparse-recurrence-closure": {
        "category": "vc-frontend", "cost_class": 2,
        "strategy": "algebraic-recurrence",
    },
    "program-sparse-recurrence-closure": {
        "category": "vc-frontend", "cost_class": 2,
        "strategy": "algebraic-recurrence",
    },
    "sparse-recurrence-closure": {
        "category": "algebraic-recurrence", "cost_class": 2,
        "strategy": "algebraic-recurrence",
    },
    "algebraic-recurrence": {
        "category": "algebraic-recurrence", "cost_class": 2,
        "strategy": "algebraic-recurrence",
    },
    # branchwise-conservation frontends
    "vc-branchwise": {
        "category": "vc-frontend", "cost_class": 2,
        "strategy": "branchwise-conservation",
    },
    "program-branchwise": {
        "category": "vc-frontend", "cost_class": 2,
        "strategy": "branchwise-conservation",
    },
    # scaled-division frontends
    "program-counter-lifted-scaled-division": {
        "category": "vc-frontend", "cost_class": 2,
        "strategy": "scaled-division",
    },
    "program-scaled-division": {
        "category": "vc-frontend", "cost_class": 2,
        "strategy": "scaled-division",
    },
    # entry-potential / exit-post-closure frontends
    "vc-entry-potential": {
        "category": "vc-frontend", "cost_class": 2,
        "strategy": "entry-potential-exit-post-closure",
    },
    "program-entry-potential": {
        "category": "vc-frontend", "cost_class": 2,
        "strategy": "entry-potential-exit-post-closure",
    },
    "vc-exit-post-closure": {
        "category": "vc-frontend", "cost_class": 2,
        "strategy": "entry-potential-exit-post-closure",
    },
    "program-exit-post-closure": {
        "category": "vc-frontend", "cost_class": 2,
        "strategy": "entry-potential-exit-post-closure",
    },
}

DEFAULT_COST_CLASS = 1
DEFAULT_CATEGORY = "unknown"

_SORTED_PREFIXES = sorted(
    REGISTRY.items(), key=lambda item: -len(item[0])
)

# Catch-all frontend prefixes that must stay out of the derived strategy
# rules: the scheduler resolves them via its own twin-frontend recursion.
NON_RULE_PREFIXES = frozenset({"vc-", "program-"})


def mechanism_prefix_rules():
    """(prefix, strategy) rules for the scheduler, derived from REGISTRY."""
    return tuple(
        (prefix, entry["strategy"])
        for prefix, entry in sorted(
            REGISTRY.items(), key=lambda item: -len(item[0])
        )
        if prefix not in NON_RULE_PREFIXES
    )


def mechanism_cost_class(mechanism):
    """Expected relative checker cost of ``mechanism`` (0, 1 or 2)."""
    if not mechanism:
        return DEFAULT_COST_CLASS
    for prefix, entry in _SORTED_PREFIXES:
        if mechanism.startswith(prefix):
            return entry["cost_class"]
    return DEFAULT_COST_CLASS


def mechanism_category(mechanism):
    """Stable mechanism-family label for reporting."""
    if not mechanism:
        return DEFAULT_CATEGORY
    for prefix, entry in _SORTED_PREFIXES:
        if mechanism.startswith(prefix):
            return entry["category"]
    return DEFAULT_CATEGORY
