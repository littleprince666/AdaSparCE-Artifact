"""Symbolic components for AdaSparCE."""
