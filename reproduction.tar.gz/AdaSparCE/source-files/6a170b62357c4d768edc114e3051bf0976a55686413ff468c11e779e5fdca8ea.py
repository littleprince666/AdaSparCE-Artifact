"""CE-Guided Branch Synthesis: generate new candidate formulas from counterexamples.

This module creates CandidateBranch objects by analyzing the concrete variable
assignments in counterexamples (CEs).  The deterministic AdaSparCE engine only
uses CE *type* (INIT/STEP/EXIT) for re-ranking; this module uses the actual
*values* to synthesize new formulas that the deterministic generators would
never produce.
"""

import z3
from itertools import combinations

from SparCE.symbolic.candidate import CandidateBranch


# ---------------------------------------------------------------------------
# CE analysis helpers
# ---------------------------------------------------------------------------


def _normalize_ce(counterexample):
    """Normalize a CE from CheckResult into (before_dict, after_dict).

    INIT/EXIT CEs return as (assignment, {}).
    STEP CEs return as (before, after).
    """
    if counterexample is None:
        return {}, {}
    if isinstance(counterexample, tuple) and len(counterexample) == 2:
        before, after = counterexample
        if isinstance(before, dict) and isinstance(after, dict):
            return dict(before), dict(after)
    if isinstance(counterexample, dict):
        return dict(counterexample), {}
    return {}, {}


def _int_or_none(value):
    """Extract a Python int from a Z3 IntNumRef or Python int."""
    if value is None:
        return None
    if isinstance(value, int):
        return value
    if hasattr(value, "as_long"):
        try:
            return value.as_long()
        except Exception:
            return None
    if hasattr(value, "as_string"):
        try:
            return int(value.as_string())
        except Exception:
            return None
    return None


def _ce_deltas(before, after):
    """Compute variable deltas (after - before) for a STEP counterexample."""
    deltas = {}
    for var in set(before.keys()) | set(after.keys()):
        b = _int_or_none(before.get(var))
        a = _int_or_none(after.get(var))
        if b is not None and a is not None:
            deltas[var] = a - b
    return deltas


# ---------------------------------------------------------------------------
# Synthesis strategies
# ---------------------------------------------------------------------------


class CESynthesizer:
    """Synthesize new CandidateBranch formulas from counterexample values."""

    def __init__(self, variables, symbols, analyzer=None, max_degree=3):
        self.variables = tuple(variables)
        self.symbols = dict(symbols)
        self.analyzer = analyzer
        self.max_degree = max_degree
        self._synth_count = 0

    def _next_score(self):
        self._synth_count += 1
        return 140.0 + self._synth_count * 0.5

    def _make_branch(self, formula, mechanism, degree=1, clauses=1):
        formula = z3.simplify(formula)
        if z3.is_true(formula):
            return None
        return CandidateBranch(
            formula=formula,
            score=self._next_score(),
            mechanism=mechanism,
            degree=degree,
            clauses=clauses,
        )

    # -- Strategy 1: Boundary from CE values --------------------------------

    def synth_boundary_from_ce(self, ce, failure_type):
        """From a CE, infer variable bounds that exclude the CE.

        If CE says x=7 and the candidate failed INIT (x=7 violates entry),
        synthesize x <= 6 or x != 7 style constraints.
        """
        before, after = _normalize_ce(ce)
        if not before:
            return []
        branches = []
        for var, value in sorted(before.items()):
            if var not in self.symbols:
                continue
            val = _int_or_none(value)
            if val is None:
                continue
            sym = self.symbols[var]
            if failure_type == "INIT":
                if val > 0:
                    b = self._make_branch(sym >= 0, "ce-boundary-nonneg")
                    if b:
                        branches.append(b)
                if val <= 0:
                    b = self._make_branch(sym <= 0, "ce-boundary-nonpos")
                    if b:
                        branches.append(b)
                b = self._make_branch(sym != val, "ce-exclusion")
                if b:
                    branches.append(b)
            elif failure_type == "EXIT":
                if val > 0:
                    b = self._make_branch(sym > 0, "ce-exit-positive")
                    if b:
                        branches.append(b)
                b = self._make_branch(sym >= val, "ce-exit-lower")
                if b:
                    branches.append(b)
            elif failure_type == "STEP":
                after_val = _int_or_none(after.get(var))
                if after_val is not None and after_val > val:
                    b = self._make_branch(sym <= val, "ce-step-upper")
                    if b:
                        branches.append(b)
                elif after_val is not None and after_val < val:
                    b = self._make_branch(sym >= val, "ce-step-lower")
                    if b:
                        branches.append(b)
        return branches

    # -- Strategy 2: Delta-based invariant ----------------------------------

    def synth_delta_invariant(self, ce, failure_type):
        """From a STEP CE, infer delta-based invariants like x' - x == delta.

        If the transition increments x by 1 (CE: before x=3, after x=4),
        synthesize x' - x == 1 as an invariant hint.
        """
        if failure_type != "STEP":
            return []
        before, after = _normalize_ce(ce)
        deltas = _ce_deltas(before, after)
        if not deltas:
            return []
        branches = []
        for var, delta in sorted(deltas.items()):
            if var not in self.symbols or delta == 0:
                continue
            sym = self.symbols[var]
            if delta == 1:
                formula = z3.Implies(True, sym >= 0)
                b = self._make_branch(formula, "ce-delta-monotone-inc")
                if b:
                    branches.append(b)
            elif delta == -1:
                formula = z3.Implies(True, sym <= 0)
                b = self._make_branch(formula, "ce-delta-monotone-dec")
                if b:
                    branches.append(b)
            elif delta > 0:
                formula = (sym % delta == 0) if delta > 1 else None
                if formula is not None:
                    b = self._make_branch(formula, "ce-delta-modular")
                    if b:
                        branches.append(b)
        return branches

    # -- Strategy 3: Pairwise relation from CE -------------------------------

    def synth_pairwise_relation(self, ce, failure_type):
        """From a CE, infer pairwise variable relations.

        If CE shows x=3, n=5, synthesize x <= n or x < n (if x < n in CE).
        """
        before, after = _normalize_ce(ce)
        assignment = before if before else after
        if len(assignment) < 2:
            return []
        branches = []
        pairs = list(combinations(sorted(assignment.keys()), 2))
        for var1, var2 in pairs:
            if var1 not in self.symbols or var2 not in self.symbols:
                continue
            val1 = _int_or_none(assignment.get(var1))
            val2 = _int_or_none(assignment.get(var2))
            if val1 is None or val2 is None:
                continue
            s1 = self.symbols[var1]
            s2 = self.symbols[var2]
            if val1 < val2:
                b = self._make_branch(s1 <= s2, "ce-pairwise-le")
                if b:
                    branches.append(b)
            elif val1 > val2:
                b = self._make_branch(s1 >= s2, "ce-pairwise-ge")
                if b:
                    branches.append(b)
            else:
                b = self._make_branch(s1 == s2, "ce-pairwise-eq")
                if b:
                    branches.append(b)
            diff = abs(val1 - val2)
            if diff > 0 and diff <= 10:
                if val1 > val2:
                    b = self._make_branch(s1 - s2 == diff, "ce-pairwise-diff")
                    if b:
                        branches.append(b)
        return branches

    # -- Strategy 4: Combine with postcondition ------------------------------

    def synth_conjunction_with_post(self, ce, failure_type, postcondition):
        """Combine a CE-derived constraint with the postcondition.

        If the postcondition is x <= n and CE shows x=10, n=5 (EXIT fail),
        synthesize And(x <= n, x <= 10) or And(x <= n, n >= 5).
        """
        if postcondition is None:
            return []
        before, after = _normalize_ce(ce)
        assignment = before if before else after
        if not assignment:
            return []
        branches = []
        for var, value in sorted(assignment.items()):
            if var not in self.symbols:
                continue
            val = _int_or_none(value)
            if val is None:
                continue
            sym = self.symbols[var]
            combined = z3.And(postcondition, sym >= val)
            b = self._make_branch(combined, "ce-conj-post-lower", degree=2, clauses=2)
            if b:
                branches.append(b)
            combined = z3.And(postcondition, sym <= val + 10)
            b = self._make_branch(combined, "ce-conj-post-upper", degree=2, clauses=2)
            if b:
                branches.append(b)
        return branches[:2]

    # -- Strategy 5: Conic/linear combination from CE ------------------------

    def synth_linear_combo(self, ce, failure_type):
        """From a CE, try small linear combinations that are consistent.

        If CE shows x=3, y=4, try x + y == 7, x - y == -1, 2*x - y == 2.
        """
        before, after = _normalize_ce(ce)
        assignment = before if before else after
        if len(assignment) < 2:
            return []
        branches = []
        vars_sorted = sorted(
            v for v in assignment
            if v in self.symbols and _int_or_none(assignment[v]) is not None
        )
        if len(vars_sorted) < 2:
            return []
        for var1, var2 in list(combinations(vars_sorted, 2))[:3]:
            val1 = _int_or_none(assignment[var1])
            val2 = _int_or_none(assignment[var2])
            s1 = self.symbols[var1]
            s2 = self.symbols[var2]
            for a_coeff, b_coeff in [(1, 1), (1, -1), (2, -1), (1, -2)]:
                rhs = a_coeff * val1 + b_coeff * val2
                if abs(rhs) > 100:
                    continue
                formula = (a_coeff * s1 + b_coeff * s2 == rhs)
                b = self._make_branch(formula, "ce-linear-combo", degree=1, clauses=1)
                if b:
                    branches.append(b)
                if len(branches) >= 4:
                    return branches
        return branches

    # -- Strategy 6: Multi-point linear fitting --------------------------------

    def synth_multipoint_linear(self, counterexamples, failure_type):
        """Fit linear invariants from multiple counterexample points.

        Given several INIT counterexamples (x=2,y=3), (x=5,y=7), (x=8,y=11),
        try to find a relation a*x + b*y == c that holds for all of them.
        Uses integer Gaussian elimination on the augmented matrix.
        """
        if len(counterexamples) < 2:
            return []
        points = []
        for ce in counterexamples:
            before, _ = _normalize_ce(ce)
            if not before:
                continue
            row = {}
            for var in sorted(self.variables):
                if var in self.symbols:
                    val = _int_or_none(before.get(var))
                    if val is not None:
                        row[var] = val
            if len(row) >= 2:
                points.append(row)
        if len(points) < 2:
            return []
        var_names = sorted(
            set().union(*[set(p.keys()) for p in points])
        )
        var_names = [v for v in var_names if v in self.symbols]
        if len(var_names) < 2:
            return []
        branches = []
        for v1, v2 in combinations(var_names, 2):
            pairs = []
            for p in points:
                a = p.get(v1)
                b = p.get(v2)
                if a is not None and b is not None:
                    pairs.append((a, b))
            if len(pairs) < 2:
                continue
            # Try a*v1 + b*v2 == c for small a,b
            for a_coeff in range(-3, 4):
                for b_coeff in range(-3, 4):
                    if a_coeff == 0 and b_coeff == 0:
                        continue
                    c_vals = set(
                        a_coeff * x + b_coeff * y
                        for x, y in pairs
                    )
                    if len(c_vals) == 1:
                        c = c_vals.pop()
                        if abs(c) > 100:
                            continue
                        s1 = self.symbols[v1]
                        s2 = self.symbols[v2]
                        formula = (a_coeff * s1 + b_coeff * s2 == c)
                        b = self._make_branch(
                            formula, "ce-multipoint-linear",
                            degree=1, clauses=1,
                        )
                        if b:
                            branches.append(b)
        return branches[:6]

    # -- Strategy 7: Polynomial delta from STEP CEs ----------------------------

    def synth_polynomial_delta(self, counterexamples, failure_type):
        """From multiple STEP CEs, infer polynomial delta relations.

        If every STEP CE shows x' - x == y (i.e. x increments by y),
        synthesize x - y == const as an invariant hint.
        Also tries x*y patterns and quadratic deltas.
        """
        if failure_type != "STEP":
            return []
        step_ces = []
        for ce in counterexamples:
            before, after = _normalize_ce(ce)
            if before and after:
                step_ces.append((before, after))
        if len(step_ces) < 1:
            return []
        branches = []
        deltas = {}
        for before, after in step_ces:
            for var in set(before.keys()) | set(after.keys()):
                b = _int_or_none(before.get(var))
                a = _int_or_none(after.get(var))
                if b is not None and a is not None:
                    deltas.setdefault(var, []).append(a - b)
        for var, delta_list in deltas.items():
            if var not in self.symbols:
                continue
            if len(set(delta_list)) == 1:
                delta = delta_list[0]
                sym = self.symbols[var]
                if delta > 0:
                    formula = (sym >= 0)
                    b = self._make_branch(formula, "ce-poly-delta-monotone")
                    if b:
                        branches.append(b)
                # Try: var == delta * counter + const
                for other in self.variables:
                    if other == var or other not in self.symbols:
                        continue
                    other_sym = self.symbols[other]
                    other_vals = []
                    for before, _ in step_ces:
                        v = _int_or_none(before.get(other))
                        if v is not None:
                            other_vals.append(v)
                    if len(other_vals) == len(step_ces):
                        # Check if var - delta*other is constant
                        diffs = set()
                        for i, (before, _) in enumerate(step_ces):
                            v = _int_or_none(before.get(var))
                            if v is not None and other_vals[i] is not None:
                                diffs.add(v - delta * other_vals[i])
                        if len(diffs) == 1:
                            const = diffs.pop()
                            if abs(const) <= 50:
                                formula = (sym - delta * other_sym == const)
                                b = self._make_branch(
                                    formula, "ce-poly-delta-affine",
                                    degree=2, clauses=1,
                                )
                                if b:
                                    branches.append(b)
        return branches[:4]

    # -- Master synthesis ----------------------------------------------------

    def synthesize(self, ce, failure_type, postcondition=None, max_results=8,
                   all_counterexamples=None):
        """Run all synthesis strategies and return deduplicated branches.

        If ``all_counterexamples`` is provided (a list of CE objects from the
        current task), multi-point strategies use them for fitting.
        """
        all_branches = []
        try:
            all_branches.extend(self.synth_boundary_from_ce(ce, failure_type))
        except Exception:
            pass
        try:
            all_branches.extend(self.synth_delta_invariant(ce, failure_type))
        except Exception:
            pass
        try:
            all_branches.extend(self.synth_pairwise_relation(ce, failure_type))
        except Exception:
            pass
        if postcondition is not None:
            try:
                all_branches.extend(
                    self.synth_conjunction_with_post(ce, failure_type, postcondition)
                )
            except Exception:
                pass
        try:
            all_branches.extend(self.synth_linear_combo(ce, failure_type))
        except Exception:
            pass
        if all_counterexamples:
            try:
                all_branches.extend(
                    self.synth_multipoint_linear(
                        all_counterexamples, failure_type
                    )
                )
            except Exception:
                pass
            try:
                all_branches.extend(
                    self.synth_polynomial_delta(
                        all_counterexamples, failure_type
                    )
                )
            except Exception:
                pass

        # Deduplicate by formula string
        seen = set()
        unique = []
        for branch in all_branches:
            key = str(branch.formula)
            if key not in seen:
                seen.add(key)
                unique.append(branch)

        return unique[:max_results]
