"""Add a joint-induction control without changing earlier frozen studies.

Reuses the audited shared-pool orchestration by explicit dependency injection.
The three replay arms are all rerun, with the original 50 immutable pools.
"""
import os
import json
from pathlib import Path
import random
import shutil
import signal
import subprocess
import sys
import time

from tools.experiments import shared_pool_study as study
from tools.experiments.joint_pool_core import VARIANTS, replay_pool
from tools.experiments.shared_pool_core import ROOT, sha, write_json

PROTOCOL = ROOT / 'docs/experiments/联合归纳同池对照协议_2026-10-19.md'
_snapshot = study.snapshot
_prepare = study.prepare


def snapshot(destination):
    _snapshot(destination)
    for relative in ('tools/experiments/joint_pool_core.py', 'tools/experiments/joint_pool_study.py'):
        shutil.copy2(ROOT / relative, destination / relative)


def child(output, arguments, timeout, stdout_path, seed=0):
    env = dict(os.environ, **study.ENVIRONMENT, PYTHONDONTWRITEBYTECODE='1', PYTHONHASHSEED=str(seed))
    command = [sys.executable, '-m', 'tools.experiments.joint_pool_study', *arguments]
    stdout_path = Path(stdout_path)
    stdout_path.parent.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    with stdout_path.open('w') as stream:
        process = subprocess.Popen(command, cwd=output / 'source', env=env,
                                   stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            process.wait(timeout=timeout)
            status = 'completed' if process.returncode == 0 else 'error'
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
            status = 'hard-timeout'
    return dict(command=command, returncode=process.returncode, process_status=status,
                process_wall_seconds=time.perf_counter() - started,
                stdout=str(stdout_path.relative_to(output)), stdout_sha256=sha(stdout_path))


def prepare(args):
    if args.reuse_pools is None:
        raise ValueError('This control requires the existing pre-result immutable Q0; use --reuse-pools')
    _prepare(args)
    path = args.output.resolve() / 'spec.json'
    spec = json.loads(path.read_text())
    spec.update(schema='adasparce.joint-pool-study.v1', date='2026-10-19',
                generation_scope='Reuse exact pre-result shared-r3 Q0 and original equal generation fees',
                result_scope='Same-pool joint induction vs Ada C and direct checking; not ESC/Java performance',
                joint_induction='All pool formulas conjoined; INIT then STEP model pruning; never prune on UNKNOWN/EXIT',
                primary_comparison='joint_houdini minus ada_c; no_composition minus ada_c is a matched diagnostic')
    write_json(path, spec)


def freeze(output):
    if (output / 'freeze.json').exists():
        raise ValueError('freeze-already-exists')
    spec, pools = study.check(output, False)
    jobs = [dict(id=task['id'], variant=variant, seed=seed)
            for task in spec['tasks'] for variant in spec['variants'] for seed in spec['seeds']]
    random.Random(20261019).shuffle(jobs)
    write_json(output / 'freeze.json', dict(schema=spec['schema'], date='2026-10-19',
        spec_sha256=sha(output / 'spec.json'), pool_hashes=pools, jobs=jobs, expected=len(jobs),
        protocol_sha256=spec['protocol_sha256'], source_hashes=spec['source_hashes']))
    print('Frozen', len(pools), 'unchanged pools and', len(jobs), 'new matched replays', flush=True)


def install():
    study.VARIANTS = VARIANTS
    study.PROTOCOL = PROTOCOL
    study.snapshot = snapshot
    study.child = child
    study.replay_pool = replay_pool
    study.prepare = prepare
    study.freeze = freeze


if __name__ == '__main__':
    install()
    study.main()
