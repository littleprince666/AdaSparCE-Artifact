import pdb
from functools import reduce
from math import gcd
from typing import NamedTuple
from beartype import beartype

import sympy
import z3

import settings
import helpers.vcommon as CM
from helpers.miscs import Miscs
from helpers.z3utils import Z3
import infer.infer
import data.prog
import data.traces


DBG = pdb.set_trace
mlog = CM.getLogger(__name__, settings.LOGGER_LEVEL)


class MyCongruence(NamedTuple):
    """
    a === b (mod n)

    x == 0 (mod 4)      #0,4,8,12,..
    x + y == 1 (mod 5)   # 1,6,11,16 ...
    """
    a: sympy.Expr
    b: int
    n: int

    @beartype
    def __str__(self) -> str:
        s = f"{self.a} === {self.b} (mod {self.n})"
        return s

    @beartype
    @property
    def expr(self) -> z3.ExprRef:
        """
        # x === 2 (mod 5) ~   x % 5 == 2
        """
        a = Z3.parse(str(self.a))
        b = Z3.parse(str(self.b))
        c = Z3.parse(str(self.n))
        return a % c == b

    @beartype
    def _eval(self, trace: data.traces.Trace) -> bool:
        v = int(self.a.xreplace(trace.mydict))
        b = (v % self.n) == self.b
        return b


class Congruence(infer.inv.Inv):
    
    @beartype
    def __init__(self, mycongruence, stat=None) -> None:
        assert isinstance(mycongruence, MyCongruence), mycongruence

        super().__init__(mycongruence, stat)

    @beartype
    @classmethod
    def mk(cls, term, b, n) -> infer.inv.Inv:
        return cls(MyCongruence(term, b, n))

    @beartype
    @property
    def mystr(self) -> str:
        return str(self.inv)

    @property
    def cinvs_category(self) -> str:
        return 'congruences'

    @property
    def expr(self) -> z3.ExprRef:
        return self.inv.expr

    def test_single_trace(self, trace: data.traces.Trace) -> bool:
        assert isinstance(trace, data.traces.Trace), trace
        b = self.inv._eval(trace)
        return b


class Infer(infer.infer._Infer):

    def gen(self) -> infer.inv.DInvs:
        raise NotImplementedError("congruence symbolic-states path not implemented; use gen_from_traces")

    @classmethod
    def gen_from_traces(cls, traces: data.traces.Traces, symbols: data.prog.Symbs) -> list:
        ps = []
        syms = symbols.symbolic
        terms = Miscs.get_terms_fixed_coefs(syms, settings.ITERMS, settings.ICOEFS)

        # degree-2 monomials (x*x, x*y, y*y, ...)
        vars_ = [s for s in syms if not s.is_number]
        for i, x in enumerate(vars_):
            for y in vars_[i:]:
                terms.add(x * y)

        for term in terms:
            term_vals = infer.inv.RelTerm(term).eval_traces(traces)
            # need enough distinct values to trust the inferred modulus;
            # too few and the gcd-of-differences overfits (see _solve).
            if len(set(term_vals)) < settings.CONGRUENCE_MIN_NVALS:
                continue
            b, n = cls._solve(term_vals)
            if b is None:
                continue
            p = Congruence.mk(term, b, n)
            ps.append(p)

        return ps

    @classmethod
    def _solve(cls, X: list[int]) -> tuple[int | None, int | None]:
        assert(X), X
        b = None
        Y = [X[0] - v for v in X]
        try:
            g = reduce(gcd, Y)
        except TypeError:
            return None, None
        
        if g == 0:
            return None, None
        if g == 1 or g == -1:
            g = None
        else:
            b = X[0] % g
        return b, g


if __name__ == "__main__":
    import doctest
    doctest.testmod()
