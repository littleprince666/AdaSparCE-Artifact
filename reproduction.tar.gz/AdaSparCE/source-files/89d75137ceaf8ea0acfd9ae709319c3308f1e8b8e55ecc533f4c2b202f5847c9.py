"""
CEGIR alg for inferring equalities
"""
import pdb
import sympy
from beartype import beartype

import settings
import helpers.vcommon as CM
from helpers.miscs import Miscs, MP

import data.prog
import data.traces
import infer.inv
import infer.infer

DBG = pdb.set_trace
mlog = CM.getLogger(__name__, settings.LOGGER_LEVEL)


class Eqt(infer.inv.Inv):

    @beartype
    def __init__(self, eqt: sympy.Equality, stat: infer.inv.InvStat | None = None) -> None:
        assert eqt.rhs == 0, eqt

        super().__init__(eqt, stat)

    @beartype
    @property
    def mystr(self) -> str:
        return f"{self.inv.lhs} == {self.inv.rhs}"

    @property
    def cinvs_category(self) -> str:
        return 'eqts_largecoefs' if len(Miscs.get_coefs(self.inv.lhs)) > 10 else 'eqts'


class Infer(infer.infer._Infer):

    @beartype
    @classmethod
    def gen_from_traces(cls, deg: int,
                        traces: data.traces.Traces, symbols: data.prog.Symbs) -> list[Eqt]:

        mydeg = deg
        eqts = []
        while not eqts and mydeg:
            ts, uks, n_eqts_needed = Miscs.init_terms(
                symbols.names, mydeg, settings.EQT_RATE
            )

            template = sum(t*u for t, u in zip(ts, uks))
            # canonical row order: instantiate returns a set, and the eqt
            # basis the null-space solve produces depends on row order
            exprs = sorted(traces.instantiate(template, n_eqts_needed), key=str)
            #print(exprs)
            #CM.pause()

            eqts = Miscs.solve_eqts(exprs, ts, uks)
            if not eqts:
                mydeg -= 1
                mlog.warning(f"NO EQTS RESULTS, reducing deg to {mydeg}")

        return [Eqt(eqt) for eqt in eqts]

    @beartype
    def gen(self, deg: int,
            deg_hints: dict[str, int] | None = None,
            complete: bool = False,
            initial_traces: data.traces.DTraces | None = None,
            ceilings: dict[str, int] | None = None
            ) -> tuple[infer.inv.DInvs, data.traces.DTraces]:
        assert deg >= 1, deg

        locs = self.prog.locs
        inps = data.traces.Inps()
        dtraces = data.traces.DTraces.mk(locs)
        if initial_traces:
            dtraces.merge(initial_traces)
        deg_hints = deg_hints or {}
        ceilings = ceilings or {loc: deg for loc in locs}

        # Ascending degrees with per-loc early stop (traces accumulate across
        # attempts). Always include 2 (cheap warm-up + common case) and the
        # budget ceiling `deg` (safety net). The finite-difference estimate adds
        # intermediate target degrees, so high-degree power-sum loops can find
        # and stop *below* the ceiling (e.g. ps6 at 6 instead of 7) without
        # losing anything: the ceiling pass still runs for any loc the estimate
        # under-shoots (e.g. geo3's degree-4 eqts).
        degrees = {min(2, deg), *ceilings.values()}
        for loc in locs:
            est = deg_hints.get(loc)
            if est is not None:
                degrees.add(min(deg, max(2, est)))
        degrees = sorted(degrees)

        dinvs = infer.inv.DInvs()
        attempted = {loc: set() for loc in locs}
        for cur_deg in degrees:
            # Only process locs that haven't yielded invariants yet
            remaining = [loc for loc in locs if (complete or not dinvs.get(loc))
                         and min(cur_deg, ceilings[loc]) not in attempted[loc]]
            if not remaining:
                break

            tasks = [
                (loc, self._get_init_traces(loc, min(cur_deg, ceilings[loc]), dtraces, inps, settings.EQT_RATE))
                for loc in remaining
            ]
            for loc in remaining:
                attempted[loc].add(min(cur_deg, ceilings[loc]))
            tasks = [(loc, tcs) for loc, tcs in tasks if tcs]

            def f(tasks):
                return [
                    (loc, self._infer(loc, template, uks, exprs, dtraces[loc]))
                    for loc, (template, uks, exprs) in tasks
                ]

            wrs = MP.run_mp("find eqts", tasks, f, settings.DO_MP)
            for loc, eqts in wrs:
                mlog.debug(f"{loc}: got {len(eqts)} eqts at deg {cur_deg}")
                if eqts:
                    mlog.debug("\n".join(map(str, eqts)))
                dinvs.setdefault(loc, infer.inv.Invs()).update(eqts)

        return dinvs, dtraces

    # PRIVATE
    
    @beartype
    @classmethod
    def _add_exprs(cls, template, 
                   n_eqts_needed: int, traces: data.traces.Traces, exprs) -> None:
    
        mlog.debug(f"got {len(traces)} new traces")
        new_exprs = traces.instantiate(template, n_eqts_needed - len(exprs))
        for expr in new_exprs:
            assert expr not in exprs
            exprs.add(expr)
    
    @beartype
    def _while(self, loc: str, 
               ts: list[int | sympy.core.symbol.Symbol|sympy.core.power.Pow | sympy.core.mul.Mul], 
               uks: list[sympy.core.symbol.Symbol], 
               n_eqts_needed: int, inps:data.traces.Inps, 
               traces: data.traces.DTraces):
        """
        repeatedly get more inps using random method
        """
        template = sum(t*u for t, u in zip(ts, uks))
        exprs = traces[loc].instantiate(template, n_eqts_needed)

        do_rand = True
        while n_eqts_needed > len(exprs):
            new_traces = {}
            mlog.debug(
                f"{loc}: need more traces ({len(exprs)} eqts, "
                f"need >= {n_eqts_needed}, inps {len(inps)})"
            )
            if do_rand:
                r_inps = self.prog.gen_rand_inps(n_eqts_needed - len(exprs))
                mlog.debug(f"gen {len(r_inps)} random inps")
                r_inps = inps.merge(r_inps, self.inp_decls.names)
                if r_inps:
                    new_traces = self.get_traces(r_inps, traces)

            if loc not in new_traces:
                do_rand = False

                dinvsFalse = infer.inv.DInvs.mk_false_invs([loc])
                cexs, _ = self.symstates.check(dinvsFalse, inps)

                # cannot find new inputs
                if loc not in cexs:
                    mlog.debug(
                        f"{loc}: cannot find new inps (currently has {len(inps)} inps)")
                    return exprs or None

                new_inps = inps.merge(cexs, self.inp_decls.names,
                                      model_ss=tuple(map(str, self.symstates.inp_exprs)))
                new_traces = self.get_traces(new_inps, traces)

                # cannot find new traces (new inps do not produce new traces)
                if loc not in new_traces:
                    mlog.debug(
                        f"{loc}: cannot find new traces (need {n_eqts_needed}) "
                        f"(new inps {len(new_inps)}, "
                        f"curr traces {len(traces[loc]) if loc in traces else 0})"
                    )
                    return exprs or None

            self._add_exprs(template, n_eqts_needed, new_traces[loc], exprs)

        return exprs

    @beartype
    def _get_init_traces(self, loc: str, deg: int,
                         dtraces: data.traces.DTraces,
                         inps: data.traces.Inps, rate: float) -> tuple[list, list[sympy.core.symbol.Symbol], set] | None:
        """
        Initial loop to obtain (random) traces to bootstrap eqt solving
        """

        assert deg >= 1, deg
        assert rate >= 0.1, rate

        mlog.debug(
            f"{loc}: generate random initial inps "
            f"(curr inps {len(inps)}, traces {dtraces[loc]})"
        )

        ts, uks, n_eqts_needed = Miscs.init_terms(
            self.inv_decls[loc].names, deg, rate)

        exprs = self._while(loc, ts, uks, n_eqts_needed, inps, dtraces)

        # if cannot generate sufficient traces, adjust degree
        while not exprs:
            if deg <= 1:
                mlog.warning(f"deg {deg}, unable to generate sufficient traces")
                return  # cannot generate enough traces

            deg -= 1
            mlog.info(
                f"Reduce polynomial degree to {deg}, terms {len(ts)}, uks {len(uks)}"
            )
            ts, uks, n_eqts_needed = Miscs.init_terms(
                self.inv_decls[loc].names, deg, rate
            )
            exprs = self._while(loc, ts, uks, n_eqts_needed, inps, dtraces)
                
        return ts, uks, exprs

    @beartype
    def _infer(self, loc: str, 
               ts: list[int | sympy.core.symbol.Symbol | sympy.core.power.Pow | sympy.core.mul.Mul], 
               uks: list[sympy.core.symbol.Symbol], 
               exprs: set[sympy.Expr],
               sampled_traces: data.traces.Traces | None = None) -> set:
        
        assert loc, loc
        assert len(ts) == len(uks), (ts, uks)
        assert exprs, exprs

        template = sum(t*u for t, u in zip(ts, uks))
        cache = set()
        eqts = set()  # results
        # canonical row order (exprs is a set; see gen_from_traces)
        exprs = sorted(exprs, key=str)

        curIter = 0
        prev_rank = -1
        ordered_traces = sorted(sampled_traces, key=str) if sampled_traces else []
        diverse_rows = None

        while True:
            curIter += 1

            # skip solve if no new linearly independent rows since last iteration
            curr_rank = Miscs.coef_matrix_rank(exprs, uks)
            if curr_rank >= 0 and curr_rank == prev_rank:
                mlog.debug(f"{loc}: rank unchanged ({curr_rank}), skipping solve")
                break
            prev_rank = curr_rank

            mlog.debug(f"{loc}, iter {curIter} infer using {len(exprs)} exprs")
            # Keep the full fitting basis until concrete refinement is done:
            # coefficient-size filtering can otherwise discard every basis
            # vector before enough samples expose a small genuine relation.
            new_eqts = Miscs.solve_eqts(exprs, ts, uks, do_refine=False)

            # A small fitting subset can describe only initial/early states.
            # Bounded symbolic checking may accept those spurious equations;
            # dropping them only during final sanitization can also lose the
            # genuine relation hidden by their reduced polynomial basis.
            # Feed concrete counterexamples from all collected traces back
            # into fitting before accepting any candidate.
            if sampled_traces:
                counterexample_rows = set()
                for eqt in new_eqts:
                    for trace in ordered_traces:
                        if eqt.lhs.xreplace(trace.mydict) != 0:
                            counterexample_rows.add(template.xreplace(trace.mydict))
                            break
                if counterexample_rows:
                    if diverse_rows is None:
                        count = min(len(ordered_traces), max(32, 2*len(uks)))
                        indices = {i*(len(ordered_traces)-1)//max(1, count-1)
                                   for i in range(count)}
                        diverse_rows = {template.xreplace(ordered_traces[i].mydict)
                                        for i in indices}
                    # Refuting one early-state equation often exposes a whole
                    # underdetermined basis. Add a spread of existing states
                    # now instead of performing dozens of one-row solves.
                    counterexample_rows.update(diverse_rows)
                    new_rows = counterexample_rows - set(exprs)
                    if not new_rows:
                        break
                    exprs.extend(sorted(new_rows, key=str))
                    # These rows contradict the exact candidate space, even
                    # if the floating-point rank heuristic misses the change.
                    prev_rank = -1
                    continue

            new_eqts = [sympy.Eq(p, 0) for p in
                        Miscs.refine([eqt.lhs for eqt in new_eqts], do_filter=False)]
            new_eqts = [eqt for eqt in new_eqts if isinstance(eqt, sympy.Equality)]
            unchecks = [eqt for eqt in new_eqts if eqt not in cache]

            if not unchecks:
                mlog.debug(f"{loc}: no new results -- break")
                break

            new_eqts = infer.inv.Invs(list(map(Eqt, unchecks)))

            mlog.debug(
                f"{loc}: {len(new_eqts)} candidates: {'; '.join(map(str, new_eqts))}")

            mlog.debug(
                f"{loc}: check {len(unchecks)} unchecked ({len(new_eqts)} candidates)"
            )

            dinvs = infer.inv.DInvs.mk(loc, new_eqts)
            cexs, dinvs = self.check(dinvs, None)

            for inv in dinvs[loc]:
                if not inv.is_disproved:
                    eqts.add(inv)
                if inv.stat is not None:
                    cache.add(inv.inv)

            if loc not in cexs:
                mlog.debug(f"{loc}: no disproved candidates -- break")
                break

            cexs = data.traces.Traces.extract(cexs[loc])
            cexs = cexs.padzeros(set(self.inv_decls[loc].names))
            exprs_ = cexs.instantiate(template, None)
            mlog.debug(f"{loc}: {len(exprs_)} new cex exprs")
            exprs.extend(sorted(exprs_, key=str))

        return eqts
