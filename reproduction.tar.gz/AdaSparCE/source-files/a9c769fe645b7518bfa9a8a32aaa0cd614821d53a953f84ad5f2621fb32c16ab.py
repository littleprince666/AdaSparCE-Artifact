"""Shared candidate value object for the AdaSparCE search.

``CandidateBranch`` is the single currency of the engine: every mechanism
generator, ranker, trace recorder and clause composer produces and
consumes this type.  It lives outside ``ada_engine`` so that generator
modules (``ce_synthesis``) do not need to import the 6k-line engine.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class CandidateBranch:
    formula: object
    score: float
    mechanism: str
    degree: int
    clauses: int
    monomials: tuple = ()
