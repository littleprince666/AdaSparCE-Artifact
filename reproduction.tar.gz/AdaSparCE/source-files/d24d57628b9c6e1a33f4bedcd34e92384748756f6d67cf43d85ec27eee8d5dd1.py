"""Original input assertions are the sole source of proof obligations.

C-derived program models are candidate-generation aids, never substitutes
for the supplied checker semantics. Preserve actual call arguments, sorts,
guards and auxiliary constraints by parsing the original assertion sections.
"""
from pathlib import Path
import z3

SPLIT = "SPLIT_HERE_asdfghjklzxcvbnmqwertyuiop"


def original_queries(smt_path, candidate):
    sections = Path(smt_path).read_text(encoding="utf-8").split(SPLIT)
    if len(sections) != 5:
        raise ValueError("expected-five-original-vc-sections")
    return tuple(z3.And(*z3.parse_smt2_string(
        sections[0] + candidate.sexpr() + sections[1] + sections[i]
    )) for i in (2, 3, 4))


def split_query(query):
    """Split one top-level OR in an NNF conjunction, exactly and boundedly.

    This is a disjunction of branch queries, so every branch must be UNSAT.
    Other disjunctions stay in each query; no exponential expansion is used.
    """
    transformed = z3.Then("simplify", "nnf")(query)
    if len(transformed) != 1:
        return (query,)
    normalized = transformed[0].as_expr()
    terms = list(normalized.children()) if z3.is_and(normalized) else [normalized]
    for index, term in enumerate(terms):
        if z3.is_or(term) and term.num_args() <= 64:
            return tuple(z3.And(*(terms[:index] + [branch] + terms[index+1:])) for branch in term.children())
    return (normalized,)
