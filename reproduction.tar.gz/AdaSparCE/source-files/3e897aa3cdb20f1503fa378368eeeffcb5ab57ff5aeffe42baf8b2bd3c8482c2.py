"""Exact polynomial arithmetic and VC expression helpers."""

from fractions import Fraction
from functools import reduce
from itertools import combinations_with_replacement
from itertools import product
from math import gcd
import z3


SPLIT = "SPLIT_HERE_asdfghjklzxcvbnmqwertyuiop"


class VCAnalysisError(ValueError):
    pass


def _flatten_and(expression):
    if z3.is_and(expression):
        result = []
        for child in expression.children():
            result.extend(_flatten_and(child))
        return result
    return [expression]


def _flatten_or(expression):
    if z3.is_or(expression):
        result = []
        for child in expression.children():
            result.extend(_flatten_or(child))
        return result
    return [expression]


def _symbols(expression):
    result = set()

    def visit(node):
        if (
            z3.is_const(node)
            and node.num_args() == 0
            and not z3.is_int_value(node)
            and not z3.is_rational_value(node)
        ):
            result.add(str(node))
        for child in node.children():
            visit(child)

    visit(expression)
    return result


def _lcm(left, right):
    if not left or not right:
        return 0
    return abs(left * right) // gcd(left, right)


def _rref(matrix, columns):
    rows = [
        [Fraction(value) for value in row]
        for row in matrix
        if any(value != 0 for value in row)
    ]
    pivots = []
    pivot_row = 0
    for column in range(columns):
        selected = next(
            (
                row
                for row in range(pivot_row, len(rows))
                if rows[row][column] != 0
            ),
            None,
        )
        if selected is None:
            continue
        rows[pivot_row], rows[selected] = rows[selected], rows[pivot_row]
        pivot = rows[pivot_row][column]
        rows[pivot_row] = [value / pivot for value in rows[pivot_row]]
        for row in range(len(rows)):
            if row == pivot_row or rows[row][column] == 0:
                continue
            factor = rows[row][column]
            rows[row] = [
                value - factor * pivot_value
                for value, pivot_value in zip(rows[row], rows[pivot_row])
            ]
        pivots.append(column)
        pivot_row += 1
        if pivot_row == len(rows):
            break
    return rows, pivots


def _nullspace(matrix, columns):
    rows, pivots = _rref(matrix, columns)
    free = [column for column in range(columns) if column not in pivots]
    basis = []
    for free_column in free:
        vector = [Fraction(0) for _ in range(columns)]
        vector[free_column] = Fraction(1)
        for row, pivot in enumerate(pivots):
            vector[pivot] = -rows[row][free_column]
        basis.append(vector)
    return basis


def _integer_vector(vector):
    denominator = reduce(
        _lcm, (value.denominator for value in vector), 1
    )
    values = [int(value * denominator) for value in vector]
    divisor = reduce(gcd, (abs(value) for value in values if value), 0) or 1
    values = [value // divisor for value in values]
    first = next((value for value in values if value), 1)
    if first < 0:
        values = [-value for value in values]
    return values


def _poly_add(left, right, scale=1):
    result = dict(left)
    for exponent, coefficient in right.items():
        result[exponent] = result.get(exponent, 0) + scale * coefficient
        if result[exponent] == 0:
            del result[exponent]
    return result


def _poly_scale(polynomial, coefficient):
    return {
        exponent: coefficient * value
        for exponent, value in polynomial.items()
        if coefficient * value
    }


def _poly_mul(left, right):
    result = {}
    for left_exponent, left_coefficient in left.items():
        for right_exponent, right_coefficient in right.items():
            exponent = tuple(
                a + b for a, b in zip(left_exponent, right_exponent)
            )
            result[exponent] = (
                result.get(exponent, 0)
                + left_coefficient * right_coefficient
            )
    return {
        exponent: coefficient
        for exponent, coefficient in result.items()
        if coefficient
    }


def _poly_power(polynomial, exponent, variable_count):
    result = {(0,) * variable_count: 1}
    factor = polynomial
    power = exponent
    while power:
        if power & 1:
            result = _poly_mul(result, factor)
        power //= 2
        if power:
            factor = _poly_mul(factor, factor)
    return result


def _poly_degree(polynomial):
    return max((sum(exponent) for exponent in polynomial), default=0)


def _poly_exactly_divides(divisor, dividend):
    """Whether ``dividend`` is an exact polynomial multiple of ``divisor``.

    This small graded-lexicographic divider is enough for proof-preserving
    closure minimization such as ``(c-y) | y*(c-y)``.  It is not used to
    establish an invariant: dropping the multiple is logically sound because
    ``divisor == 0`` already implies ``dividend == 0``.
    """
    if not divisor or not dividend:
        return False
    if _poly_degree(divisor) == 0:
        return False
    remainder = {
        exponent: Fraction(coefficient)
        for exponent, coefficient in dividend.items()
        if coefficient
    }
    normalized_divisor = {
        exponent: Fraction(coefficient)
        for exponent, coefficient in divisor.items()
        if coefficient
    }

    def leading(polynomial):
        exponent = max(
            polynomial,
            key=lambda item: (sum(item), item),
        )
        return exponent, polynomial[exponent]

    divisor_exponent, divisor_coefficient = leading(normalized_divisor)
    while remainder:
        remainder_exponent, remainder_coefficient = leading(remainder)
        if any(
            left < right
            for left, right in zip(remainder_exponent, divisor_exponent)
        ):
            return False
        quotient_exponent = tuple(
            left - right
            for left, right in zip(remainder_exponent, divisor_exponent)
        )
        quotient_coefficient = remainder_coefficient / divisor_coefficient
        product = _poly_mul(
            normalized_divisor,
            {quotient_exponent: quotient_coefficient},
        )
        remainder = _poly_add(remainder, product, scale=-1)
    return True


def _reduce_divisible_polynomials(polynomials):
    """Remove equality generators implied by a simpler exact factor."""
    ranked = sorted(
        (polynomial for polynomial in polynomials if polynomial),
        key=lambda item: (_poly_degree(item), len(item), sorted(item.items())),
    )
    reduced = []
    for polynomial in ranked:
        if any(
            _poly_exactly_divides(existing, polynomial)
            for existing in reduced
        ):
            continue
        reduced = [
            existing
            for existing in reduced
            if not _poly_exactly_divides(polynomial, existing)
        ]
        reduced.append(polynomial)
    return tuple(reduced)


def _poly_substitute(polynomial, substitutions, variable_count):
    result = {}
    for exponent, coefficient in polynomial.items():
        term = {(0,) * variable_count: coefficient}
        for index, power in enumerate(exponent):
            if power:
                term = _poly_mul(
                    term,
                    _poly_power(
                        substitutions[index], power, variable_count
                    ),
                )
        result = _poly_add(result, term)
    return result


def _monomial_exponents(variable_count, degree):
    result = [(0,) * variable_count]
    for current_degree in range(1, degree + 1):
        for selected in combinations_with_replacement(
            range(variable_count), current_degree
        ):
            exponent = [0] * variable_count
            for index in selected:
                exponent[index] += 1
            result.append(tuple(exponent))
    return result
