"""Task-local search state and typed-failure expansion preferences."""

from SMT_Solver.SMT_verifier import CheckFailureType


FAILURE_TYPE_PREFERRED_MECHANISMS = {
    CheckFailureType.INIT: (
        "typed-counter-boundary",
        "typed-counter-lift",
        "typed-post-weakening-le",
        "typed-post-weakening-ge",
        "typed-term-dropping",
    ),
    CheckFailureType.STEP: (
        "typed-update-closure",
        "typed-remaining-work",
    ),
    CheckFailureType.EXIT: (
        "typed-counter-lift",
        "typed-sign-clauses",
        "typed-remaining-work",
    ),
}


class _RunState:
    """Shared mutable state for the typed-search phases of ``run()``.

    ``run()`` previously carried these as ~35 locals threaded through
    nested closures (``scheduled_phase`` alone shared 15 via ``nonlocal``).
    The phase extraction turns them into one explicit state object so
    each phase method is independently readable and testable.  All field
    defaults mirror the original local initializations in ``run()``.
    """

    def __init__(self, program_id, c_path, smt_path, started, analyzer,
                 verifier, scheduler, search_variables, base):
        # immutable task context
        self.program_id = program_id
        self.c_path = c_path
        self.smt_path = smt_path
        self.started = started
        self.analyzer = analyzer
        self.verifier = verifier
        self.scheduler = scheduler
        self.search_variables = search_variables
        self.base = base
        # shared search state
        self.checked = 0
        self.failure_type = CheckFailureType.UNKNOWN
        self.failure_counts = {
            failure: 0 for failure in CheckFailureType
        }
        self.last_counterexample = None
        self.all_counterexamples = []
        self.active_keys = set()
        self.stagnation_mode = False
        self.stagnation_counter = 0
        self.stagnation_last_failure = None
        self.stagnation_signatures = set()
        self.stagnation_exit = False
        self.checked_mechanisms = set()
        self.lemma_tracker = None
        self.clause_bank = None
        self.pending_conjunctions = []
        self.degree_cap = 0
        self.clause_cap = 0
        self.degrees = ()
        self.clause_levels = ()
        self.typed_phase_budget = 0.0
        self.vc_limit = 0
        self.rank_vc_frontend = False
        self.mechanism_safety_mode = False
        self.vc_branches = []
        self.scheduled_vc_branches = []
        self.vc_count = 0
        self.pool = None
        self.all_branches = []
        self.reserve_branches = []
        self.clause_composer = None
        self.composition_branches = []
        self.composition_observations = []
        self.composition_bank_branches = []
