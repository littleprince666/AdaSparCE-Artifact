"""Configuration validation and optional component construction."""

import math
from SparCE.logging_utils import JsonlLogger
from SparCE.scheduling.mechanism_prioritizer import AdaptiveMechanismPrioritizer
from SparCE.scheduling.strategy_scheduler import StrategySchedulerConfig
from SparCE.scheduling.strategy_scheduler import normalize_strategy
from SparCE.config import AdaSparCEConfig
from SparCE.search.state import FAILURE_TYPE_PREFERRED_MECHANISMS


class EngineInitialization:
    """Configuration validation and optional component construction."""

    def __init__(self, config=None, log_path=None):
        self.config = config or AdaSparCEConfig()
        if int(getattr(self.config, "max_checker_calls", 0)) < 0:
            raise ValueError("max_checker_calls must be nonnegative")
        # Registry-consistency check: every preferred-feedback mechanism
        # must still resolve to a registered strategy family.  A typo or
        # a renamed mechanism previously degraded silently (the reserve
        # expansion just never matched); now it fails at construction.
        for preferred_names in FAILURE_TYPE_PREFERRED_MECHANISMS.values():
            for name in preferred_names:
                if normalize_strategy(name) == "other":
                    raise ValueError(
                        "FAILURE_TYPE_PREFERRED_MECHANISMS entry %r does "
                        "not resolve to a registered mechanism strategy" % name
                    )
        self.logger = JsonlLogger(log_path)
        self.candidate_cache = set()
        # Per-task timeout-control state; both are (re)set at the top
        # of run() so a reused engine instance cannot inherit the
        # previous task's clock or escalation budget.
        self._task_started = None
        self._task_wall_deadline = None
        self._timeout_escalations = 0
        self._pruner = None
        if getattr(self.config, "enable_pruning", False):
            from SparCE.search.pruner import CandidatePruner
            self._pruner = CandidatePruner()
        self._mechanism_prioritizer = AdaptiveMechanismPrioritizer()
        ranker_mode_count = sum(bool(value) for value in (
            getattr(self.config, "neural_ranker_enabled", False),
            getattr(self.config, "graph_ranker_enabled", False),
            getattr(self.config, "random_ranker_enabled", False),
        ))
        if ranker_mode_count > 1:
            raise ValueError(
                "DeepSets, graph, and random rankers are mutually exclusive"
            )
        if (
            ranker_mode_count
            and getattr(self.config, "neural_scorer_enabled", False)
        ):
            raise ValueError(
                "legacy neural scorer and candidate rankers are mutually exclusive"
            )
        if getattr(self.config, "neural_ranker_online_updates", False):
            raise ValueError(
                "DeepSets ranker online updates are not supported"
            )
        if getattr(self.config, "neural_ranker_topk_safe", 5) < 0:
            raise ValueError("neural ranker safe top-K must be nonnegative")
        exploration_ratio = getattr(
            self.config, "neural_ranker_exploration_ratio", 0.1
        )
        if not 0.0 <= exploration_ratio <= 1.0:
            raise ValueError(
                "neural ranker exploration ratio must be in [0, 1]"
            )
        for name in (
            "neural_ranker_alpha",
            "neural_ranker_beta",
            "neural_ranker_gamma",
            "graph_strategy_weight",
        ):
            value = float(getattr(self.config, name, 0.0))
            if not math.isfinite(value) or value < 0:
                raise ValueError(
                    "{} must be finite and nonnegative".format(name)
                )
        composer_generation_ratio = float(getattr(
            self.config, "clause_composer_generation_budget_ratio", 0.15
        ))
        if not 0.0 < composer_generation_ratio <= 1.0:
            raise ValueError(
                "clause composer generation budget ratio must be in (0, 1]"
            )
        recurrence_degree = int(getattr(
            self.config, "algebraic_recurrence_max_degree", 6
        ))
        if recurrence_degree < 4:
            raise ValueError(
                "algebraic recurrence max degree must be at least four"
            )
        branchwise_degree = int(getattr(
            self.config, "branchwise_conservation_max_degree", 2
        ))
        if not 2 <= branchwise_degree <= 3:
            raise ValueError(
                "branchwise conservation max degree must be two or three"
            )
        fallback_mode = str(getattr(self.config, "fallback_mode", "fixed"))
        if fallback_mode not in ("fixed", "stagnation"):
            raise ValueError(
                "fallback_mode must be 'fixed' or 'stagnation'"
            )
        if int(getattr(
            self.config, "fallback_stagnation_patience", 8
        )) < 1:
            raise ValueError(
                "fallback_stagnation_patience must be positive"
            )
        if not 0.0 <= float(getattr(
            self.config, "fallback_stagnation_min_elapsed_ratio", 0.2
        )) <= 1.0:
            raise ValueError(
                "fallback_stagnation_min_elapsed_ratio must be in [0, 1]"
            )
        if str(getattr(
            self.config, "neural_ranker_safety_mode", "topk"
        )) not in ("topk", "mechanism"):
            raise ValueError(
                "neural_ranker_safety_mode must be 'topk' or 'mechanism'"
            )
        if int(getattr(
            self.config, "counterexample_prefilter_max_records", 64
        )) < 1:
            raise ValueError(
                "counterexample_prefilter_max_records must be positive"
            )
        if getattr(self.config, "strategy_scheduler_enabled", False):
            if ranker_mode_count or getattr(
                self.config, "neural_scorer_enabled", False
            ):
                raise ValueError(
                    "the strategy scheduler is mutually exclusive with "
                    "candidate-level rankers and the legacy neural scorer"
                )
            try:
                StrategySchedulerConfig(
                    **self._scheduler_experiment_kwargs(),
                    policy=str(getattr(
                        self.config, "strategy_scheduler_policy", "heuristic"
                    )),
                    utility_form=str(getattr(
                        self.config, "strategy_scheduler_utility", "ratio"
                    )),
                    priors=str(getattr(
                        self.config, "strategy_scheduler_priors", "empirical"
                    )),
                    epsilon=float(getattr(
                        self.config, "strategy_scheduler_epsilon", 1.0
                    )),
                    lambda_cost=float(getattr(
                        self.config, "strategy_scheduler_lambda", 0.005
                    )),
                    mu=float(getattr(
                        self.config, "strategy_scheduler_mu", 0.1
                    )),
                    exploration_scale=float(getattr(
                        self.config,
                        "strategy_scheduler_exploration_scale",
                        0.05,
                    )),
                    timeout_tiers=tuple(getattr(
                        self.config,
                        "strategy_scheduler_timeout_tiers",
                        (4.0, 15.0, 60.0, 150.0),
                    )),
                    quotas=dict(getattr(
                        self.config,
                        "strategy_scheduler_quotas",
                        {},
                    )),
                    min_typed_budget_ratio=float(getattr(
                        self.config,
                        "strategy_scheduler_min_typed_budget_ratio",
                        0.15,
                    )),
                    min_fallback_budget_ratio=float(getattr(
                        self.config,
                        "strategy_scheduler_min_fallback_budget_ratio",
                        0.2,
                    )),
                    timeout_escalation_cap=float(getattr(
                        self.config, "timeout_escalation_cap", 150.0
                    )),
                    max_decisions=int(getattr(
                        self.config, "strategy_scheduler_max_decisions", 200
                    )),
                    seed=int(getattr(self.config, "seed", 0)),
                ).validate()
            except ValueError as error:
                raise ValueError(
                    f"invalid strategy scheduler config: {error}"
                ) from error
        self._prefilter_counterexamples = []
        self._prefilter_signatures = set()
        self._prefilter_rejections = 0
        self.neural_scorer = None
        if getattr(self.config, "neural_scorer_enabled", False):
            from SparCE.ranking.neural_scorer import NeuralScorer, NeuralScorerConfig

            ns_config = self.config.neural_scorer_config or NeuralScorerConfig()
            checkpoint = self.config.neural_scorer_checkpoint
            if checkpoint:
                self.neural_scorer = NeuralScorer.load(checkpoint, ns_config)
            if self.neural_scorer is None:
                self.neural_scorer = NeuralScorer(ns_config)
        self.neural_ranker = None
        self._ranker_kind = "none"
        self._neural_ranker_load_error = None
        if getattr(self.config, "graph_ranker_enabled", False):
            try:
                checkpoint = self.config.neural_ranker_checkpoint
                if not checkpoint:
                    raise ValueError("graph ranker checkpoint is required")
                from SparCE.ranking.graph_ranker import GraphRankerInference

                self.neural_ranker = GraphRankerInference.load(
                    checkpoint, device=self.config.neural_ranker_device
                )
                self._ranker_kind = "graph"
                self.logger.write({
                    "event": "neural_ranker_load",
                    "status": "loaded",
                    "model_version": "program_vc_graph_candidate_ranker.v1",
                    "checkpoint_sha256": self.neural_ranker.checkpoint_metadata.get(
                        "checkpoint_sha256"
                    ),
                    "device": str(self.neural_ranker.device),
                    "online_updates": False,
                    "ranker_kind": self._ranker_kind,
                })
            except Exception as error:
                self._neural_ranker_load_error = str(error)
                self.neural_ranker = None
                self.logger.write({
                    "event": "neural_ranker_load",
                    "status": "heuristic-fallback",
                    "reason": str(error),
                    "online_updates": False,
                    "ranker_kind": "graph",
                })
        elif getattr(self.config, "neural_ranker_enabled", False):
            try:
                checkpoint = self.config.neural_ranker_checkpoint
                if not checkpoint:
                    raise ValueError("neural ranker checkpoint is required")
                from SparCE.ranking.neural_ranker import NeuralRankerInference

                self.neural_ranker = NeuralRankerInference.load(
                    checkpoint,
                    device=self.config.neural_ranker_device,
                    alpha=self.config.neural_ranker_alpha,
                    beta=self.config.neural_ranker_beta,
                    gamma=self.config.neural_ranker_gamma,
                )
                self._ranker_kind = "deepsets"
                self.logger.write({
                    "event": "neural_ranker_load",
                    "status": "loaded",
                    "model_version": self.neural_ranker.checkpoint_metadata.get(
                        "model_version"
                    ),
                    "feature_schema_hash": (
                        self.neural_ranker.checkpoint_metadata.get(
                            "feature_schema_hash"
                        )
                    ),
                    "checkpoint_sha256": (
                        self.neural_ranker.checkpoint_metadata.get(
                            "checkpoint_sha256"
                        )
                    ),
                    "device": str(self.neural_ranker.device),
                    "online_updates": False,
                    "ranker_kind": self._ranker_kind,
                })
            except Exception as error:
                self._neural_ranker_load_error = str(error)
                self.neural_ranker = None
                self.logger.write({
                    "event": "neural_ranker_load",
                    "status": "heuristic-fallback",
                    "reason": str(error),
                    "online_updates": False,
                    "ranker_kind": "deepsets",
                })
        elif getattr(self.config, "random_ranker_enabled", False):
            from SparCE.ranking.neural_ranker import RandomRankerInference

            self.neural_ranker = RandomRankerInference(self.config.seed)
            self._ranker_kind = "random"
            self.logger.write({
                "event": "neural_ranker_load",
                "status": "loaded",
                "model_version": (
                    self.neural_ranker.checkpoint_metadata["model_version"]
                ),
                "feature_schema_hash": (
                    self.neural_ranker.checkpoint_metadata[
                        "feature_schema_hash"
                    ]
                ),
                "checkpoint_sha256": None,
                "device": "cpu",
                "online_updates": False,
                "ranker_kind": self._ranker_kind,
            })
        self._trace_program_hash = ""
        self._trace_run_id = ""
        self._trace_group_index = 0
        self._trace_candidate_occurrences = {}
        self._trace_counterexample_hashes = set()
        self._trace_repeat_counterexamples = 0
        self._trace_mechanism_history = {}
        self._trace_program_context = None
        self._ranker_program_context = None
        self._ranker_candidate_checks = {}
        self._ranker_counterexample_hashes = set()
        self._ranker_repeat_counterexamples = 0
        self._ranker_mechanism_history = {}
        self._ranker_inference_calls = 0
        self._ranker_inference_seconds = 0.0
        self._ranker_runtime_fallback = None
        self._ranker_task_gate = None
        self._program_vc_graph = None
