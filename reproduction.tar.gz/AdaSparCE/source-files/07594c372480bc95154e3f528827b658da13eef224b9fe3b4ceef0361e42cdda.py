"""Strategy pools and the budgeted scheduler execution loop."""

import time
import z3
from SMT_Solver.SMT_verifier import CheckFailureType
from SparCE.feedback.clause_composer import ProofGuidedClauseComposer
from SparCE.symbolic.monomials import MonomialPool
from SparCE.symbolic.candidate import CandidateBranch


class ScheduledSearch:
    """Strategy pools and the budgeted scheduler execution loop."""

    def _build_branch_pools(self, state):
        """Monomial pool, mechanism frontiers, reserve beam and the
        clause-composer bank (shared by legacy and scheduled paths)."""
        # Exact VC frontends and the direct postcondition seed do not use
        # the monomial pool.  Build the potentially expensive pool only
        # after those proof-directed paths have had their budgeted turn.
        state.pool = MonomialPool.seed_from_program(
            state.c_path, state.search_variables, max_degree=state.degree_cap
        )
        state.all_branches = [state.base]
        # Checked-formula deduplication is handled by the engine-level
        # candidate cache at check time; pools keep their own keys.
        state.all_branches.extend(
            self._transition_kernel_branches(state.analyzer)
        )
        for frontier in self._frontiers(
            state.analyzer,
            state.pool,
            CheckFailureType.UNKNOWN,
            ranker_failure_type=state.failure_type,
            failure_counts=state.failure_counts,
            checked=state.checked,
            elapsed_time_ratio=(
                (time.perf_counter() - state.started)
                / self.config.timeout_seconds
            ),
        ):
            state.all_branches.extend(frontier)
        state.reserve_branches = []
        state.active_keys = {
            str(z3.simplify(branch.formula)) for branch in state.all_branches
        }
        if self.config.beam_search:
            for frontier in self._frontiers(
                state.analyzer,
                state.pool,
                CheckFailureType.UNKNOWN,
                apply_beam=False,
            ):
                state.reserve_branches.extend(
                    branch
                    for branch in frontier
                    if str(z3.simplify(branch.formula)) not in state.active_keys
                )
        if self._ranker_trace_enabled():
            self._trace_generation_pool(
                state.all_branches[1:] + state.reserve_branches,
                state.active_keys,
                state.analyzer,
                state.failure_type,
                state.failure_counts,
                state.checked,
                (
                    time.perf_counter() - state.started
                ) / self.config.timeout_seconds,
            )

        state.clause_composer = None
        state.composition_branches = []
        state.composition_observations = []
        state.composition_bank_branches = list(
            state.all_branches + state.reserve_branches
        )

    def _filter_strategy_outputs(self, state):
        """Ablation removes outputs both from direct pools and composition.

        Generation still runs and is charged. This is an output-availability
        intervention, not a claim that the generator's compute was removed.
        The shared seed, linear fast path and fallback remain shared controls.
        """
        if not state.scheduler.config.disabled_categories:
            return
        removed = {}
        for name in ("scheduled_vc_branches", "all_branches", "reserve_branches",
                     "composition_bank_branches"):
            before = getattr(state, name)
            after = [b for b in before if state.scheduler.is_enabled(
                state.scheduler.key_for_mechanism(b.mechanism))]
            setattr(state, name, after)
            removed[name] = len(before) - len(after)
        state.active_keys = {
            str(z3.simplify(b.formula)) for b in state.all_branches + state.reserve_branches
        }
        self.logger.write({"event": "strategy_output_ablation", "removed": removed,
                           "disabled_categories": list(state.scheduler.config.disabled_categories)})

    def _run_scheduled_phase(self, state):
        """Cost-aware strategy-scheduled search phase.

        Replaces the legacy degree-outer/clause-inner typed loop,
        the fixed upfront VC-frontend loop and the fixed
        clause-composer phase: every mechanism pool, reactive CE
        synthesis branches, the partial-lemma conjunction queue,
        the clause composer and the fallback hand-over moment
        are ordered by the StrategyScheduler through
        (strategy, quota, checker-timeout tier) actions.

        Except for explicit output-removal ablations, unchecked candidates
        remain in their pools: scheduling changes order and budget.
        Every accepted invariant is still judged by
        the frozen INIT/STEP/EXIT checker inside _check_branch.
        Returns a SparseRunResult on success, otherwise None so
        the shared fallback tail can spend the remaining budget.
        """

        self._filter_strategy_outputs(state)
        static_state = self._scheduler_static_features(state.analyzer)
        complexity_degree = float(getattr(
            self.config,
            "strategy_scheduler_complexity_degree_weight",
            2.0,
        ))
        complexity_clause = float(getattr(
            self.config,
            "strategy_scheduler_complexity_clause_weight",
            1.0,
        ))

        def complexity_key(branch):
            # Best-first by combined complexity (replaces the
            # degree-outer / clause-inner layer order).
            return (
                complexity_degree * branch.degree
                + complexity_clause * branch.clauses,
                -branch.score,
            )

        pools = {}
        seen_keys = set()

        def pool_add(branch):
            strategy = state.scheduler.key_for_mechanism(branch.mechanism)
            if not state.scheduler.is_enabled(strategy):
                return False
            key = str(z3.simplify(branch.formula))
            if key in self.candidate_cache or key in seen_keys:
                return False
            seen_keys.add(key)
            pools.setdefault(
                strategy, []
            ).append(branch)
            return True

        for branch in state.scheduled_vc_branches:
            pool_add(branch)
        for branch in state.all_branches:
            if branch is state.base:
                continue
            pool_add(branch)
        for branch in state.reserve_branches:
            pool_add(branch)
        for category in pools:
            pools[category].sort(key=complexity_key)

        progress_scores = {
            CheckFailureType.SUCCESS: 1.0,
            CheckFailureType.EXIT: 0.6,
            CheckFailureType.STEP: 0.3,
            CheckFailureType.INIT: 0.1,
            CheckFailureType.TIMEOUT: 0.0,
            CheckFailureType.UNKNOWN: 0.0,
        }
        best_progress = 0.0
        current_layer_degree = 0
        current_layer_clauses = 0
        sched_rank = 0
        fallback_selected = False
        # Checker-timeout retry state: a timed-out candidate is
        # re-checked once with a higher tier while the task budget
        # allows; the original TIMEOUT observation stays censored
        # (never counts as definitive failure evidence).
        retry_queue = []
        retry_keys = set()
        retries_used = 0
        scheduler_observations = []

        def observe_scheduled_result(strategy, result):
            state.scheduler.observe_candidate(
                strategy, result.failure_type.value, result.solver_time)
            scheduler_observations.append((result.failure_type.value, result.solver_time))

        def process_timeout_retries():
            """Re-check timed-out candidates at a higher timeout tier."""
            nonlocal retries_used
            while retry_queue:
                remaining = (
                    self.config.timeout_seconds
                    - (time.perf_counter() - state.started)
                )
                branch, strategy, old_timeout = retry_queue[0]
                tiers = tuple(
                    float(tier)
                    for tier in getattr(
                        state.scheduler.config, "timeout_tiers", ()
                    ) or (4.0, 15.0, 60.0, 150.0)
                )
                higher = [t for t in tiers if t > old_timeout + 1e-9]
                escalated = (
                    min(higher) if higher else old_timeout * 4.0
                )
                escalated = min(
                    escalated,
                    max(0.5, remaining * 0.6),
                    float(getattr(
                        state.scheduler.config,
                        "timeout_escalation_cap",
                        150.0,
                    )),
                )
                if escalated <= old_timeout + 1e-9 or (
                    remaining < escalated * 1.5
                ):
                    return None
                retry_queue.pop(0)
                retries_used += 1
                branch_key = str(z3.simplify(branch.formula))
                self.candidate_cache.discard(branch_key)
                self.logger.write({
                    "event": "checker_timeout_retry",
                    "program_id": state.program_id,
                    "template_mode": "adasparce",
                    "mechanism": branch.mechanism,
                    "strategy": strategy,
                    "original_timeout_seconds": old_timeout,
                    "retry_timeout_seconds": escalated,
                    "retries_used": retries_used,
                })
                result = check_scheduled_candidate(
                    branch, escalated, strategy
                )
                if (
                    result is not None
                    and result.failure_type == CheckFailureType.SUCCESS
                ):
                    return branch
            return None

        def lemma_pool_size():
            if state.lemma_tracker is None:
                return 0
            return (
                len(state.lemma_tracker.exit_lemmas)
                + len(state.lemma_tracker.step_partials)
            )

        def scheduler_state():
            return {
                **static_state,
                "current_degree": current_layer_degree,
                "current_clauses": current_layer_clauses,
                "degree_cap": state.degree_cap,
                "clause_cap": state.clause_cap,
                "init_count": state.failure_counts[CheckFailureType.INIT],
                "step_count": state.failure_counts[CheckFailureType.STEP],
                "exit_count": state.failure_counts[CheckFailureType.EXIT],
                "timeout_count": (
                    state.failure_counts[CheckFailureType.TIMEOUT]
                ),
                "last_failure_type": (
                    state.failure_type.value if state.failure_type else "NONE"
                ),
                "elapsed_seconds": (
                    time.perf_counter() - state.started
                ),
                "total_seconds": self.config.timeout_seconds,
                "checked": state.checked,
                "max_checker_calls": (
                    self.config.max_checker_calls or 0
                ),
                "partial_lemma_pool_size": lemma_pool_size(),
                "best_progress": best_progress,
            }

        def check_scheduled_candidate(branch, checker_timeout,
                                      strategy):
            nonlocal best_progress
            nonlocal current_layer_degree, current_layer_clauses
            nonlocal sched_rank
            nonlocal retry_queue, retry_keys, retries_used
            if self.config.coverage_optimizations and self.config.fallback_enabled:
                reserved = self.config.timeout_seconds * state.scheduler.config.min_fallback_budget_ratio
                remaining = self.config.timeout_seconds - (time.perf_counter() - state.started)
                checker_timeout = min(checker_timeout, max(0.5, remaining - reserved))
            sched_rank += 1
            result = self._check_branch(
                state.verifier, branch, state.smt_path, state.program_id, sched_rank,
                state.analyzer, None, checker_timeout=checker_timeout,
            )
            if result is None:
                return None
            state.checked += 1
            state.checked_mechanisms.add(branch.mechanism)
            self._note_stagnation_progress(state, result)
            self._mechanism_prioritizer.update(
                branch.mechanism, result.failure_type.value
            )
            observe_scheduled_result(strategy, result)
            best_progress = max(
                best_progress,
                progress_scores.get(result.failure_type, 0.0),
            )
            current_layer_degree = max(
                current_layer_degree, branch.degree
            )
            current_layer_clauses = max(
                current_layer_clauses, branch.clauses
            )
            if result.failure_type == CheckFailureType.SUCCESS:
                return result
            if (
                result.failure_type == CheckFailureType.TIMEOUT
                and self.config.checker_timeout_retry_enabled
                and retries_used < self.config.checker_timeout_retry_limit
            ):
                branch_key = str(z3.simplify(branch.formula))
                if branch_key not in retry_keys:
                    retry_keys.add(branch_key)
                    retry_queue.append(
                        (branch, strategy, float(checker_timeout))
                    )
                    self.logger.write({
                        "event": "checker_timeout_retry_queued",
                        "program_id": state.program_id,
                        "template_mode": "adasparce",
                        "mechanism": branch.mechanism,
                        "strategy": strategy,
                        "timed_out_seconds": checker_timeout,
                    })
            state.failure_type = result.failure_type
            state.failure_counts[state.failure_type] += 1
            if state.lemma_tracker is not None and (
                result.failure_type in (
                    CheckFailureType.EXIT,
                    CheckFailureType.STEP,
                )
            ):
                if state.clause_bank is not None:
                    tracker_conjunctions = state.clause_bank.note_result(
                        branch, result
                    )
                else:
                    tracker_conjunctions = state.lemma_tracker.note(
                        branch.formula, branch.score, result.failure_type
                    )
                for conjunction in tracker_conjunctions:
                    state.pending_conjunctions.append(
                        (conjunction, branch.degree, branch.clauses)
                    )
            if result.counterexample is not None:
                state.last_counterexample = result.counterexample
                state.all_counterexamples.append(result.counterexample)
            if self.config.clause_composer_enabled:
                state.composition_observations.append((branch, result))
                if self.config.coverage_optimizations and state.clause_composer is not None:
                    state.clause_composer.ingest(branch.formula, score=branch.score,
                        mechanism=branch.mechanism, degree=branch.degree,
                        clauses=branch.clauses, monomials=branch.monomials)
                    state.clause_composer.observe(branch.formula, result.failure_type)
            if (
                self.config.typed_counterexamples
                and state.failure_counts[state.failure_type] > 1
                and state.last_counterexample is not None
            ):
                # Same reactive trigger as the legacy typed
                # loop; synthesized branches join the
                # ce-synthesis pool instead of a running list.
                try:
                    from SparCE.generation.ce_synthesis import CESynthesizer

                    synthesizer = CESynthesizer(
                        state.analyzer.variables,
                        state.analyzer.translator.symbols,
                        analyzer=state.analyzer,
                        max_degree=self.config.max_degree,
                    )
                    ce_branches = synthesizer.synthesize(
                        state.last_counterexample,
                        state.failure_type.value,
                        postcondition=state.analyzer.postcondition,
                        max_results=4,
                        all_counterexamples=state.all_counterexamples,
                    )
                except Exception:
                    ce_branches = []
                for cb in ce_branches:
                    key = str(z3.simplify(cb.formula))
                    if key in state.active_keys or key in seen_keys:
                        continue
                    if not pool_add(cb):
                        continue
                    state.active_keys.add(key)
                    if self.config.clause_composer_enabled:
                        state.composition_bank_branches.append(cb)
                for category in pools:
                    if state.scheduler.category(category) == "ce-synthesis":
                        pools[category].sort(key=complexity_key)
            return result

        def composer_round(quota, checker_timeout):
            """One quota-bounded clause-composer round."""
            if state.clause_composer is None:
                generation_started = time.perf_counter()
                generation_budget = (
                    self.config.timeout_seconds
                    * (
                        self.config
                        .clause_composer_generation_budget_ratio
                    )
                )
                generation_deadline = min(
                    state.started + self.config.timeout_seconds,
                    generation_started + generation_budget,
                )
                state.clause_composer = ProofGuidedClauseComposer(
                    max_bank_size=(
                        self.config.clause_composer_bank_size
                    ),
                    max_ast_size=(
                        self.config.clause_composer_max_ast_size
                    ),
                    max_clauses=self.config.max_clauses,
                    max_total_proposals=(
                        self.config.clause_composer_max_proposals
                    ),
                )
                for candidate in state.composition_bank_branches:
                    if time.perf_counter() >= generation_deadline:
                        break
                    state.clause_composer.ingest(
                        candidate.formula,
                        score=candidate.score,
                        mechanism=candidate.mechanism,
                        degree=candidate.degree,
                        clauses=candidate.clauses,
                        monomials=candidate.monomials,
                    )
                if self.config.coverage_optimizations:
                    for candidate in self._prefilter_materials:
                        # A replay failure is repair material, not a
                        # certificate that other obligations passed.
                        state.clause_composer.ingest(candidate.formula,
                            score=candidate.score, mechanism=candidate.mechanism,
                            degree=candidate.degree, clauses=candidate.clauses,
                            monomials=candidate.monomials)
                if state.clause_bank is not None:
                    # Unified clause bank: every checked candidate's
                    # partial outcome (with counterexample and source)
                    # seeds the composer bank, so composition sees the
                    # same state as the conjunction trials.
                    for entry in state.clause_bank.entries():
                        if time.perf_counter() >= generation_deadline:
                            break
                        state.clause_composer.ingest(
                            entry.formula,
                            score=entry.score,
                            mechanism=entry.mechanism,
                            degree=entry.degree,
                            clauses=entry.clauses,
                            monomials=entry.monomials,
                        )
                        if entry.outcome in ("INIT", "STEP", "EXIT"):
                            state.clause_composer.observe(
                                entry.formula, entry.outcome
                            )
                for source_branch, source_result in (
                    state.composition_observations
                ):
                    state.clause_composer.observe(
                        source_branch.formula,
                        source_result.failure_type,
                    )
                observation_priority = {
                    CheckFailureType.EXIT: 3,
                    CheckFailureType.STEP: 2,
                    CheckFailureType.INIT: 1,
                }
                ordered_observations = sorted(
                    state.composition_observations,
                    key=lambda item: (
                        observation_priority.get(
                            item[1].failure_type, 0
                        ),
                        item[0].score,
                    ),
                    reverse=True,
                )
                for _ in range(
                    self.config.clause_composer_per_failure
                ):
                    for source_branch, source_result in (
                        ordered_observations
                    ):
                        if (
                            state.clause_composer.emitted_count
                            >= (
                                self.config
                                .clause_composer_max_proposals
                            )
                            or (
                                time.perf_counter()
                                >= generation_deadline
                            )
                        ):
                            break
                        composed = state.clause_composer.propose(
                            source_branch.formula,
                            score=source_branch.score,
                            mechanism=source_branch.mechanism,
                            degree=source_branch.degree,
                            clauses=source_branch.clauses,
                            monomials=source_branch.monomials,
                            failure_type=(
                                source_result.failure_type
                            ),
                            counterexample=(
                                source_result.counterexample
                            ),
                            max_results=1,
                        )
                        for proposal in composed:
                            if proposal.key in state.active_keys:
                                continue
                            candidate = CandidateBranch(
                                proposal.formula,
                                proposal.score,
                                proposal.mechanism,
                                proposal.degree,
                                proposal.clauses,
                                proposal.monomials,
                            )
                            state.active_keys.add(proposal.key)
                            state.composition_branches.append(candidate)
                    if (
                        state.clause_composer.emitted_count
                        >= self.config.clause_composer_max_proposals
                        or time.perf_counter() >= generation_deadline
                    ):
                        break
                self.logger.write({
                    "event": "clause_composer_initialized",
                    "program_id": state.program_id,
                    "bank_size": state.clause_composer.bank_size,
                    "max_bank_size": (
                        self.config.clause_composer_bank_size
                    ),
                    "max_ast_size": (
                        self.config.clause_composer_max_ast_size
                    ),
                    "max_clauses": self.config.max_clauses,
                    "max_total_proposals": (
                        self.config.clause_composer_max_proposals
                    ),
                })
            taken = 0
            success_branch = None
            while (
                state.composition_branches
                and taken < quota
                and time.perf_counter() - state.started
                < self.config.timeout_seconds
                and not self._checker_budget_exhausted(state.checked)
            ):
                branch = max(
                    state.composition_branches,
                    key=lambda candidate: candidate.score,
                )
                state.composition_branches.remove(branch)
                result = check_scheduled_candidate(
                    branch, checker_timeout, "clause-composer"
                )
                if result is None:
                    continue
                taken += 1
                if result.failure_type == (
                    CheckFailureType.SUCCESS
                ):
                    success_branch = branch
                    break
                state.clause_composer.observe(
                    branch.formula, result.failure_type
                )
                chained = state.clause_composer.propose(
                    branch.formula,
                    score=branch.score,
                    mechanism=branch.mechanism,
                    degree=branch.degree,
                    clauses=branch.clauses,
                    monomials=branch.monomials,
                    failure_type=result.failure_type,
                    counterexample=result.counterexample,
                    max_results=(
                        self.config.clause_composer_per_failure
                    ),
                )
                for proposal in chained:
                    if proposal.key in state.active_keys:
                        continue
                    candidate = CandidateBranch(
                        proposal.formula,
                        proposal.score,
                        proposal.mechanism,
                        proposal.degree,
                        proposal.clauses,
                        proposal.monomials,
                    )
                    state.active_keys.add(proposal.key)
                    state.composition_branches.append(candidate)
            return success_branch

        max_decisions = int(getattr(
            self.config, "strategy_scheduler_max_decisions", 200
        ))
        while True:
            elapsed = time.perf_counter() - state.started
            remaining = self.config.timeout_seconds - elapsed
            if remaining <= 0 or self._checker_budget_exhausted(
                state.checked
            ):
                break
            if retry_queue:
                retry_branch = process_timeout_retries()
                if retry_branch is not None:
                    return self._success(
                        state.program_id, retry_branch,
                        state.started, state.checked,
                    )
            if state.scheduler.decision_count >= max_decisions:
                self.logger.write({
                    "event": "strategy_scheduler_stop",
                    "program_id": state.program_id,
                    "reason": "max-decisions",
                    "decisions": state.scheduler.decision_count,
                })
                break
            sched_state = scheduler_state()
            pool_sizes = {
                category: len(pool)
                for category, pool in pools.items()
                if pool
            }
            virtual = []
            if state.pending_conjunctions:
                virtual.append("partial-lemma-conjunction")
            if self.config.clause_composer_enabled and (
                state.clause_composer is None
                or state.composition_branches
            ):
                # Only offer the composer while it can actually run a
                # check: an exhausted composer must not spin empty
                # rounds against the decision budget and starve the
                # remaining real pools.
                virtual.append("clause-composer")
            others = sorted(pool_sizes) + [
                category for category in virtual
                if category not in pool_sizes
            ]
            others = [s for s in others if state.scheduler.is_enabled(s)]
            if (
                not fallback_selected
                and self.config.fallback_enabled
                and others
                and state.scheduler.fallback_deadline_reached(
                    sched_state, fallback_selected
                )
            ):
                fallback_selected = True
                self.logger.write({
                    "event": "strategy_scheduler_forced_fallback",
                    "program_id": state.program_id,
                    "reason": "fallback-budget-deadline",
                    "remaining_seconds": remaining,
                })
                break
            fallback_ok = (
                self.config.fallback_enabled
                and state.scheduler.is_enabled("fallback")
                and state.scheduler.fallback_window_open(
                    sched_state, bool(others)
                )
            )
            available = others + (
                ["fallback"] if fallback_ok else []
            )
            if not available:
                break

            decision = state.scheduler.select(
                sched_state, available, pool_sizes, remaining
            )
            for category in pool_sizes:
                state.scheduler.observe_offer(
                    category, pool_sizes[category]
                )

            if decision.strategy == "fallback":
                fallback_selected = True
                self._scheduler_fallback_timeout = (
                    decision.checker_timeout
                )
                self.logger.write({
                    "event": "strategy_scheduler_fallback_selected",
                    "program_id": state.program_id,
                    "decision_index": state.scheduler.decision_count,
                    "checker_timeout_seconds": (
                        decision.checker_timeout
                    ),
                    "remaining_seconds": remaining,
                    "policy": decision.policy,
                })
                break

            round_started = time.perf_counter()
            observation_start = len(scheduler_observations)
            pending_before = len(state.pending_conjunctions)
            round_results = []
            round_times = []
            new_counterexample = False
            success_branch = None
            budget_cut = False
            lemma_delta = 0

            if decision.strategy == "partial-lemma-conjunction":
                trial_count = min(
                    decision.quota, len(state.pending_conjunctions)
                )
                batch = state.pending_conjunctions[:trial_count]
                del state.pending_conjunctions[:trial_count]
                if batch and state.lemma_tracker is not None:
                    trial_branch, lemma_delta = (
                        self._run_conjunction_trials(
                            state.lemma_tracker,
                            [item[0] for item in batch],
                            state.verifier,
                            state.smt_path,
                            state.program_id,
                            state.started,
                            state.checked,
                            batch[0][1],
                            batch[0][2],
                            state.analyzer,
                            fixed_checker_timeout=(
                                decision.checker_timeout
                            ),
                            on_result=lambda result: observe_scheduled_result(
                                "partial-lemma-conjunction", result),
                        )
                    )
                    state.checked += lemma_delta
                    if trial_branch is not None:
                        success_branch = trial_branch
            elif decision.strategy == "clause-composer":
                success_branch = composer_round(
                    decision.quota, decision.checker_timeout
                )
            else:
                pool = pools.get(decision.strategy, [])
                taken = 0
                while pool and taken < decision.quota:
                    if (
                        time.perf_counter() - state.started
                        >= self.config.timeout_seconds
                        or self._checker_budget_exhausted(state.checked)
                    ):
                        budget_cut = True
                        break
                    branch = pool.pop(0)
                    result = check_scheduled_candidate(
                        branch,
                        decision.checker_timeout,
                        decision.strategy,
                    )
                    if result is None:
                        continue
                    taken += 1
                    if result.counterexample is not None:
                        new_counterexample = True
                    if result.failure_type == (
                        CheckFailureType.SUCCESS
                    ):
                        success_branch = branch
                        break

            final_proof = success_branch is not None
            round_results = [r[0] for r in scheduler_observations[observation_start:]]
            round_times = [r[1] for r in scheduler_observations[observation_start:]]
            new_partial_lemma = (
                len(state.pending_conjunctions) > pending_before
            )
            checked_in_round = len(round_results)
            if checked_in_round:
                if final_proof:
                    observation_status = "observed-success"
                elif round_results and all(
                    value in ("TIMEOUT", "UNKNOWN") for value in round_results
                ):
                    observation_status = "timeout"
                elif (
                    round_results
                    and all(
                        value not in ("TIMEOUT", "UNKNOWN")
                        for value in round_results
                    )
                    and not budget_cut
                ):
                    observation_status = "negative"
                else:
                    # mixed outcomes, budget-cut rounds, or
                    # conjunction trials whose per-trial results
                    # are not individually attributable
                    observation_status = "censored"
            else:
                observation_status = "unobserved"
            self.logger.write({
                "event": "strategy_decision",
                "program_id": state.program_id,
                "template_mode": "adasparce",
                "decision_index": state.scheduler.decision_count,
                "policy": decision.policy,
                "reason": decision.reason,
                "state": sched_state,
                "available_strategies": list(
                    decision.available_strategies
                ),
                "pool_sizes": pool_sizes,
                "state_features": decision.state_features,
                "predictions": decision.predictions,
                "selected": {
                    "strategy": decision.strategy,
                    "quota": decision.quota,
                    "checker_timeout_seconds": (
                        decision.checker_timeout
                    ),
                    "utility": decision.utility,
                },
                "outcome": {
                    "candidates_checked": checked_in_round,
                    "failure_types": round_results,
                    "checker_times_seconds": round_times,
                    "round_time_seconds": (
                        time.perf_counter() - round_started
                    ),
                    "budget_cut": budget_cut,
                    "new_counterexample": new_counterexample,
                    "new_partial_lemma": new_partial_lemma,
                    "final_proof": final_proof,
                },
                "arm_label": {
                    "strategy": decision.strategy,
                    "observation_status": observation_status,
                    "success": True if final_proof else None,
                    "checker_time": (
                        sum(round_times) / len(round_times)
                        if round_times else None
                    ),
                    "timeout": bool(round_results) and all(
                        value == "TIMEOUT"
                        for value in round_results
                    ),
                },
                "unobserved_strategies": [
                    category
                    for category in decision.available_strategies
                    if category != decision.strategy
                ],
            })
            if final_proof:
                self.logger.write({
                    "event": "strategy_scheduler_phase_end",
                    "program_id": state.program_id,
                    "solved": True,
                    "decisions": state.scheduler.decision_count,
                    "checked": state.checked,
                    "remaining_pool_sizes": {
                        category: len(pool)
                        for category, pool in pools.items()
                        if pool
                    },
                    "pending_conjunctions": len(
                        state.pending_conjunctions
                    ),
                    "elapsed_seconds": (
                        time.perf_counter() - state.started
                    ),
                })
                return self._success(
                    state.program_id, success_branch, state.started, state.checked
                )

        self.logger.write({
            "event": "strategy_scheduler_phase_end",
            "program_id": state.program_id,
            "decisions": state.scheduler.decision_count,
            "checked": state.checked,
            "remaining_pool_sizes": {
                category: len(pool)
                for category, pool in pools.items()
                if pool
            },
            "pending_conjunctions": len(state.pending_conjunctions),
            "elapsed_seconds": time.perf_counter() - state.started,
        })
        return None
