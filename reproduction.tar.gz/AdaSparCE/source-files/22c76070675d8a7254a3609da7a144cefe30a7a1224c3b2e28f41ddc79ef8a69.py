"""One timed cold process; no imports of the legacy baseline/__init__.py."""
import json
import os
from pathlib import Path
import sys
import time

from .common import Unsupported


def main():
    request = json.load(sys.stdin)
    started = time.monotonic()
    try:
        if request['method'] == 'ada':
            from .ada_adapter import run
        elif request['method'] == 'cvc5':
            from .cvc5_adapter import run
        elif request['method'] == 'dig':
            from .dig_adapter import run
        elif request['method'] == 'clause2inv':
            from .clause2inv_adapter import run
        else:
            raise ValueError('unknown method')
        result = run(request)
    except Unsupported as error:
        result = dict(status='unsupported', reason=str(error))
    except Exception as error:
        # Do not echo exception messages from HTTP clients: they can contain
        # endpoint/credential details. Author stdout stays in local artifacts.
        result = dict(status='error', reason=type(error).__name__)
    result['worker_seconds'] = time.monotonic() - started
    path = Path(request['result_file'])
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    temporary.replace(path)


if __name__ == '__main__':
    main()
