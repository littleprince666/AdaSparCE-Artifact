"""Optional candidate ranking and reproducible candidate traces."""

import math
import time
import z3
from SparCE.ranking.ranker_trace import TRACE_SCHEMA_VERSION
from SparCE.ranking.ranker_trace import candidate_formula_hash
from SparCE.ranking.ranker_trace import candidate_record
from SparCE.ranking.ranker_trace import make_group_id
from SparCE.ranking.ranker_trace import make_state_id
from SparCE.ranking.ranker_trace import outcome_labels
from SparCE.ranking.ranker_trace import program_content_hash
from SparCE.ranking.ranker_trace import stable_json_hash
from SparCE.ranking.ranker_features import extract_program_context


class CandidateRanking:
    """Optional candidate ranking and reproducible candidate traces."""

    def _ranker_trace_enabled(self):
        return bool(getattr(self.config, "ranker_trace_enabled", False))

    def _ranker_requested(self):
        return bool(
            getattr(self.config, "neural_ranker_enabled", False)
            or getattr(self.config, "graph_ranker_enabled", False)
            or getattr(self.config, "random_ranker_enabled", False)
        )

    def _reset_neural_ranker_task(self):
        self._ranker_program_context = None
        self._ranker_candidate_checks = {}
        self._ranker_counterexample_hashes = set()
        self._ranker_repeat_counterexamples = 0
        self._ranker_mechanism_history = {}
        self._ranker_inference_calls = 0
        self._ranker_inference_seconds = 0.0
        self._ranker_runtime_fallback = None
        self._ranker_task_gate = None
        self._program_vc_graph = None

    def _graph_bonus(self, branch):
        """Structural tie-break value; never changes proof semantics."""
        if not getattr(self.config, "graph_strategy_enabled", False):
            return 0.0
        if self._program_vc_graph is None:
            return 0.0
        return float(self.config.graph_strategy_weight) * (
            self._program_vc_graph.candidate_bonus(
                branch.formula, branch.mechanism
            )
        )

    def _neural_ranker_state(
        self,
        failure_type,
        failure_counts,
        checked,
        elapsed_time_ratio,
        candidate_count,
        degree=None,
        clauses=None,
        coefficient_bound=None,
    ):
        observed_counts = {
            self._failure_name(key): int(value)
            for key, value in (failure_counts or {}).items()
        }
        return {
            "current_failure_type": self._failure_name(failure_type),
            "failure_set": sorted(
                name for name, count in observed_counts.items() if count > 0
            ),
            "failure_counts": observed_counts,
            "distinct_counterexamples": len(
                self._ranker_counterexample_hashes
            ),
            "repeat_counterexamples": self._ranker_repeat_counterexamples,
            "elapsed_time_ratio": max(
                0.0, min(1.0, float(elapsed_time_ratio))
            ),
            "degree": degree,
            "clauses": clauses,
            "coefficient_bound": coefficient_bound,
            "current_candidate_count": int(candidate_count),
            "verified_candidate_count": int(checked),
        }

    def _neural_ranker_predictions(
        self,
        phase,
        candidates,
        analyzer,
        failure_type,
        failure_counts,
        checked,
        elapsed_time_ratio,
        degree=None,
        clauses=None,
    ):
        if self.neural_ranker is None or not candidates:
            return None, 0.0
        state = self._neural_ranker_state(
            failure_type,
            failure_counts,
            checked,
            elapsed_time_ratio,
            len(candidates),
            degree=degree,
            clauses=clauses,
        )
        started = time.perf_counter()
        try:
            predictions = self.neural_ranker.score_candidates(
                candidates,
                analyzer,
                self._ranker_program_context,
                state,
                mechanism_history=self._ranker_mechanism_history,
                candidate_occurrences=self._ranker_candidate_checks,
            )
            # A frozen DeepSets checkpoint keeps its calibrated ordering.
            # Graph topology is used only by the heuristic tie-break path
            # until a graph encoder is trained on development data.
            prediction_vectors = (
                predictions.ranking_scores,
                predictions.success_scores,
                predictions.progress_scores,
                predictions.cost_scores,
            )
            if any(len(values) != len(candidates) for values in prediction_vectors):
                raise ValueError(
                    "neural ranker prediction count mismatch"
                )
            if not all(
                math.isfinite(float(value))
                for values in prediction_vectors
                for value in values
            ):
                raise FloatingPointError(
                    "neural ranker output is NaN or infinity"
                )
        except Exception as error:
            elapsed = time.perf_counter() - started
            self._ranker_inference_seconds += elapsed
            self._ranker_runtime_fallback = str(error)
            self.neural_ranker = None
            self.logger.write({
                "event": "neural_ranker_fallback",
                "phase": phase,
                "reason": str(error),
                "candidate_count": len(candidates),
                "inference_time_seconds": elapsed,
                "fallback": "adaptive-heuristic",
            })
            return None, elapsed
        elapsed = time.perf_counter() - started
        self._ranker_inference_calls += 1
        self._ranker_inference_seconds += elapsed
        return predictions, elapsed

    def _record_neural_ranker_outcome(self, branch, result):
        if not self._ranker_requested():
            return
        digest = candidate_formula_hash(branch.formula)
        self._ranker_candidate_checks[digest] = (
            self._ranker_candidate_checks.get(digest, 0) + 1
        )
        history = self._ranker_mechanism_history.setdefault(
            branch.mechanism,
            {"success": 0, "failure": 0, "timeout": 0},
        )
        failure_name = self._failure_name(result.failure_type)
        if failure_name == "SUCCESS":
            history["success"] += 1
        elif failure_name in ("TIMEOUT", "UNKNOWN"):
            history["timeout"] += 1
        else:
            history["failure"] += 1
        if result.counterexample is not None:
            counterexample = stable_json_hash(result.counterexample)
            if counterexample in self._ranker_counterexample_hashes:
                self._ranker_repeat_counterexamples += 1
            else:
                self._ranker_counterexample_hashes.add(counterexample)

    def _neural_ranker_metrics(self):
        if not self._ranker_requested():
            return {}
        return {
            "neural_ranker_requested": True,
            "neural_ranker_kind": self._ranker_kind,
            "neural_ranker_inference_calls": self._ranker_inference_calls,
            "neural_ranker_inference_time_seconds": (
                self._ranker_inference_seconds
            ),
            "neural_ranker_load_fallback": self._neural_ranker_load_error,
            "neural_ranker_runtime_fallback": self._ranker_runtime_fallback,
            "neural_ranker_task_gate": self._ranker_task_gate,
            "neural_ranker_online_updates": False,
        }

    def _reset_ranker_trace(self, c_path, smt_path):
        if not self._ranker_trace_enabled():
            return
        computed_hash = program_content_hash(c_path, smt_path)
        configured_hash = getattr(
            self.config, "ranker_trace_program_hash", ""
        )
        if configured_hash and configured_hash != computed_hash:
            raise ValueError(
                "ranker trace program hash does not match input contents"
            )
        self._trace_program_hash = computed_hash
        self._trace_run_id = (
            getattr(self.config, "ranker_trace_run_id", "")
            or stable_json_hash(
                {
                    "program_content_hash": computed_hash,
                    "seed": self.config.seed,
                }
            )
        )
        self._trace_group_index = 0
        self._trace_candidate_occurrences = {}
        self._trace_counterexample_hashes = set()
        self._trace_repeat_counterexamples = 0
        self._trace_mechanism_history = {}
        self._trace_program_context = None
        self.logger.write({
            "event": "neural_ranker_trace_start",
            "trace_schema_version": TRACE_SCHEMA_VERSION,
            "run_id": self._trace_run_id,
            "program_content_hash": self._trace_program_hash,
            "seed": self.config.seed,
        })

    @staticmethod
    def _failure_name(failure_type):
        if failure_type is None:
            return "NONE"
        return getattr(failure_type, "value", str(failure_type))

    def _trace_candidate_group(
        self,
        phase,
        candidates,
        selected,
        analyzer,
        failure_type,
        failure_counts,
        checked,
        elapsed_time_ratio,
        degree=None,
        clauses=None,
        score_components=None,
        coefficient_bounds=None,
        selection_policy="heuristic",
    ):
        if not self._ranker_trace_enabled():
            return None
        candidates = list(candidates)
        if not candidates or selected is None:
            return None
        selected_ordinal = next(
            (
                ordinal
                for ordinal, candidate in enumerate(candidates)
                if candidate is selected
            ),
            None,
        )
        if selected_ordinal is None:
            raise ValueError("selected candidate is absent from trace group")
        score_components = score_components or {}
        coefficient_bounds = coefficient_bounds or {}
        records = []
        candidate_keys = []
        for ordinal, candidate in enumerate(candidates):
            formula_hash = candidate_formula_hash(candidate.formula)
            candidate_keys.append(
                (formula_hash, candidate.mechanism, ordinal)
            )
            records.append(
                candidate_record(
                    candidate,
                    analyzer,
                    ordinal,
                    score_components=score_components.get(candidate),
                    mechanism_history=self._trace_mechanism_history.get(
                        candidate.mechanism
                    ),
                    historical_occurrences=(
                        self._trace_candidate_occurrences.get(
                            formula_hash, 0
                        )
                    ),
                    coefficient_bound=coefficient_bounds.get(candidate),
                )
            )
        observed_counts = {
            self._failure_name(key): int(value)
            for key, value in (failure_counts or {}).items()
        }
        failure_set = sorted(
            name for name, count in observed_counts.items() if count > 0
        )
        selected_record = records[selected_ordinal]
        state = {
            "current_failure_type": self._failure_name(failure_type),
            "failure_set": failure_set,
            "failure_counts": observed_counts,
            "distinct_counterexamples": len(
                self._trace_counterexample_hashes
            ),
            "repeat_counterexamples": self._trace_repeat_counterexamples,
            "elapsed_time_ratio": max(
                0.0, min(1.0, float(elapsed_time_ratio))
            ),
            "degree": degree,
            "clauses": clauses,
            "coefficient_bound": selected_record.get("coefficient_bound"),
            "current_candidate_count": len(candidates),
            "verified_candidate_count": int(checked),
            "candidate_pool_hash": stable_json_hash(candidate_keys),
        }
        state_id = make_state_id(self._trace_program_hash, state)
        group_id = make_group_id(
            self._trace_run_id,
            self._trace_program_hash,
            state_id,
            self._trace_group_index,
            phase,
        )
        heuristic_ordinal = max(
            range(len(candidates)),
            key=lambda ordinal: candidates[ordinal].score,
        )
        self.logger.write({
            "event": "neural_ranker_candidate_group",
            "trace_schema_version": TRACE_SCHEMA_VERSION,
            "run_id": self._trace_run_id,
            "program_content_hash": self._trace_program_hash,
            "search_state_id": state_id,
            "candidate_group_id": group_id,
            "group_index": self._trace_group_index,
            "phase": phase,
            "selection_policy": selection_policy,
            "program_context": (
                self._trace_program_context
                or extract_program_context(analyzer)
            ),
            "program_graph": (
                {
                    **self._program_vc_graph.topology(),
                    "candidate_variable_nodes": [
                        self._program_vc_graph.candidate_attachment(
                            candidate.formula
                        )
                        for candidate in candidates
                    ],
                }
                if self._program_vc_graph is not None
                else None
            ),
            "search_state": state,
            "candidates": records,
            "selected_candidate_instance_id": selected_record[
                "candidate_instance_id"
            ],
            "selected_candidate_hash": selected_record["candidate_hash"],
            "heuristic_selected_candidate_instance_id": records[
                heuristic_ordinal
            ]["candidate_instance_id"],
        })
        for formula_hash, _, _ in candidate_keys:
            self._trace_candidate_occurrences[formula_hash] = (
                self._trace_candidate_occurrences.get(formula_hash, 0) + 1
            )
        self._trace_group_index += 1
        return {
            "run_id": self._trace_run_id,
            "program_content_hash": self._trace_program_hash,
            "search_state_id": state_id,
            "candidate_group_id": group_id,
            "candidate_instance_id": selected_record[
                "candidate_instance_id"
            ],
            "candidate_hash": selected_record["candidate_hash"],
            "current_failure_type": state["current_failure_type"],
            "phase": phase,
        }

    def _trace_candidate_outcome(
        self, branch, result, trace_context, skip_reason=None
    ):
        if not self._ranker_trace_enabled() or trace_context is None:
            return
        record = {
            "event": "neural_ranker_candidate_outcome",
            "trace_schema_version": TRACE_SCHEMA_VERSION,
            **trace_context,
            "mechanism": branch.mechanism,
            "skip_reason": skip_reason,
        }
        if result is None:
            record.update({
                "checker_result": "skipped",
                "failure_type": None,
                "checker_time_seconds": 0.0,
                "query_size": 0,
                "vc_results": [],
                "labels": None,
            })
            self.logger.write(record)
            return
        failure_name = self._failure_name(result.failure_type)
        history = self._trace_mechanism_history.setdefault(
            branch.mechanism,
            {"success": 0, "failure": 0, "timeout": 0},
        )
        if failure_name == "SUCCESS":
            history["success"] += 1
        elif failure_name in ("TIMEOUT", "UNKNOWN"):
            history["timeout"] += 1
        else:
            history["failure"] += 1
        counterexample_digest = None
        repeated_counterexample = False
        if result.counterexample is not None:
            counterexample_digest = stable_json_hash(result.counterexample)
            repeated_counterexample = (
                counterexample_digest in self._trace_counterexample_hashes
            )
            if repeated_counterexample:
                self._trace_repeat_counterexamples += 1
            else:
                self._trace_counterexample_hashes.add(
                    counterexample_digest
                )
        record.update({
            "candidate_hash": result.candidate_hash,
            "checker_result": result.status,
            "failure_type": failure_name,
            "checker_time_seconds": float(result.solver_time),
            "solver_name": result.solver_name,
            "query_size": int(result.query_size),
            "raw_solver_status": result.raw_solver_status,
            "vc_results": list(result.vc_results),
            "vc_trace_complete": bool(result.vc_results),
            "counterexample_hash": counterexample_digest,
            "repeated_counterexample": repeated_counterexample,
            "labels": outcome_labels(
                failure_name,
                result.solver_time,
                trace_context["current_failure_type"],
            ),
        })
        self.logger.write(record)

    def _trace_generation_pool(
        self,
        candidates,
        retained_formula_keys,
        analyzer,
        failure_type,
        failure_counts,
        checked,
        elapsed_time_ratio,
    ):
        """Log the complete generated pool before the legacy beam cut."""
        if not self._ranker_trace_enabled() or not candidates:
            return
        records = []
        pool_keys = []
        for ordinal, candidate in enumerate(candidates):
            formula_hash = candidate_formula_hash(candidate.formula)
            pool_keys.append((formula_hash, candidate.mechanism, ordinal))
            item = candidate_record(
                candidate,
                analyzer,
                ordinal,
                score_components={
                    "heuristic": float(candidate.score),
                    "mechanism_bonus": None,
                    "legacy_neural_bonus": None,
                    "selection_score": float(candidate.score),
                },
                mechanism_history=self._trace_mechanism_history.get(
                    candidate.mechanism
                ),
                historical_occurrences=(
                    self._trace_candidate_occurrences.get(formula_hash, 0)
                ),
            )
            item["retained_by_legacy_beam"] = (
                str(z3.simplify(candidate.formula))
                in retained_formula_keys
            )
            records.append(item)
        observed_counts = {
            self._failure_name(key): int(value)
            for key, value in (failure_counts or {}).items()
        }
        state = {
            "current_failure_type": self._failure_name(failure_type),
            "failure_set": sorted(
                name
                for name, count in observed_counts.items()
                if count > 0
            ),
            "failure_counts": observed_counts,
            "distinct_counterexamples": len(
                self._trace_counterexample_hashes
            ),
            "repeat_counterexamples": self._trace_repeat_counterexamples,
            "elapsed_time_ratio": max(
                0.0, min(1.0, float(elapsed_time_ratio))
            ),
            "current_candidate_count": len(candidates),
            "verified_candidate_count": int(checked),
            "candidate_pool_hash": stable_json_hash(pool_keys),
        }
        state_id = make_state_id(self._trace_program_hash, state)
        pool_id = stable_json_hash({
            "run_id": self._trace_run_id,
            "program_content_hash": self._trace_program_hash,
            "search_state_id": state_id,
            "kind": "pre-legacy-beam",
        })
        self.logger.write({
            "event": "neural_ranker_candidate_pool",
            "trace_schema_version": TRACE_SCHEMA_VERSION,
            "run_id": self._trace_run_id,
            "program_content_hash": self._trace_program_hash,
            "search_state_id": state_id,
            "candidate_pool_id": pool_id,
            "pool_kind": "pre-legacy-beam",
            "program_context": (
                self._trace_program_context
                or extract_program_context(analyzer)
            ),
            "search_state": state,
            "candidates": records,
            "generated_candidate_count": len(records),
            "retained_candidate_count": sum(
                item["retained_by_legacy_beam"] for item in records
            ),
        })

    def _save_neural_scorer(self):
        if (
            self.neural_scorer is not None
            and getattr(self.config, "neural_scorer_save_path", "")
        ):
            try:
                self.neural_scorer.save(self.config.neural_scorer_save_path)
            except Exception as exc:
                self.logger.write({
                    "event": "neural_scorer_save_error",
                    "error": str(exc),
                })
