"""Ranking components for AdaSparCE."""
