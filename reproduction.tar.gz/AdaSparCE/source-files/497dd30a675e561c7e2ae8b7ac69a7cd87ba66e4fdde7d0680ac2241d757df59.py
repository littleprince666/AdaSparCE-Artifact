"""Parallel runner for AdaSparCE experiments on any dataset.

Usage:
    python tools/run_experiment.py \
        --root datasets/External-Generalization-Holdout-v2 \
        --config configs/legacy/external_v2_adasparce_improved.json \
        --output-dir Result/ExternalGen-v2/adasparce_improved/test-locked \
        --workers 8 --splits test-locked \
        --template-mode adasparce
"""

import argparse
import concurrent.futures
import json
import os
import signal
import subprocess
import sys
import tempfile
import time
from pathlib import Path


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def task_problem_class(task):
    problem_class = task.get("problem_class")
    if problem_class:
        return problem_class
    legacy = task.get("nonlinearity_class") or task.get("legacy_n_class")
    if legacy == "N0":
        return "linear"
    if legacy in ("N1", "N2", "N3"):
        return "polynomial-nonlinear"
    return "nonpolynomial"


def task_linearity(task):
    return "linear" if task_problem_class(task) == "linear" else "nonlinear"


def result_metrics(records):
    solved = sum(record.get("status") == "solved" for record in records)
    total = len(records)
    return {
        "solved": solved,
        "total": total,
        "rate": 100 * solved / total if total else 0,
    }


def grouped_metrics(records, key):
    names = sorted({record.get(key) or "unknown" for record in records})
    return {
        name: result_metrics([
            record for record in records
            if (record.get(key) or "unknown") == name
        ])
        for name in names
    }


# ---------------------------------------------------------------------------
# Config-key validation
#
# The JSON -> CLI translation below used to silently ignore unknown keys:
# a config field whose flag did not exist yet would no-op without any
# diagnostics (this actually happened with timeout_escalation_limit/cap).
# validate_config_keys() reports such fields; --strict-config turns them
# into hard errors so a typo cannot quietly change an experiment.
# ---------------------------------------------------------------------------

# Keys that carry experiment metadata but never map to engine flags.
METADATA_CONFIG_KEYS = frozenset({
    "algorithm", "dataset_version", "success_criterion",
})

# Blocks belonging to removed features; kept in some archived configs.
REMOVED_LEGACY_CONFIG_KEYS = frozenset({"rl"})

KNOWN_CONFIG_KEYS = frozenset({
    "max_degree", "max_monomials", "max_clauses", "coefficient_bounds",
    "program_timeout_seconds", "template_timeout_seconds",
    "checker_timeout_seconds", "max_candidates_per_structure",
    "beam_width", "timeout_escalation_limit", "timeout_escalation_cap",
    "degree_escalation_cap", "clause_escalation_cap", "seed",
    "fallback_enabled", "fallback_mode", "fallback_stagnation_patience",
    "fallback_stagnation_min_elapsed_ratio", "counterexample_prefilter",
    "neural_ranker_safety_mode", "template_cache", "degree_iterative",
    "clause_iterative", "typed_counterexamples", "beam_search",
    "update_closure", "precondition_frame", "monotone_entry_bounds",
    "affine_exit_boundary", "smt_vc_frontend", "smt_vc_max_degree",
    "branchwise_conservation_frontend",
    "branchwise_conservation_max_degree", "scaled_division_frontend",
    "entry_potential_frontend", "exit_post_closure_frontend",
    "algebraic_recurrence_frontend", "algebraic_recurrence_max_degree",
    "algebraic_recurrence_minimum_degree", "branch_transitions_enabled",
    "transition_kernel_enabled", "transition_kernel_max_degree",
    "transition_kernel_max_atoms", "transition_kernel_max_conjunctions",
    "unified_clause_bank_enabled", "unified_clause_bank_max_trials",
    "strategy_scheduler_progress_feedback",
    "checker_timeout_retry_enabled", "checker_timeout_retry_limit",
    "divmod_frontend", "linear_fast_path", "linear_fast_path_guard",
    "semantic_generators", "monomial_feedback", "coverage_optimizations",
    "lemma_conjunction",
    "lemma_conjunction_max_trials", "clause_composer",
    "strategy_scheduler", "graph_ranker", "template_mode",
}) | METADATA_CONFIG_KEYS | REMOVED_LEGACY_CONFIG_KEYS

KNOWN_SCHEDULER_KEYS = frozenset({
    "enabled", "policy", "utility", "priors", "epsilon", "lambda", "mu",
    "exploration_scale", "min_typed_budget_ratio",
    "min_fallback_budget_ratio", "timeout_tiers", "quotas",
    "max_decisions", "complexity_degree_weight",
    "complexity_clause_weight", "progress_feedback",
    "granularity", "online_updates", "quota_mode", "round_budget_ratio",
    "prior_strength", "progress_weight", "disabled_categories",
})

# Scheduler sub-keys of removed/never-consumed features (MLP policy).
LEGACY_SCHEDULER_KEYS = frozenset({
    "checkpoint", "min_confidence", "mlp_shrinkage",
})


def validate_config_keys(config, strict=False):
    """Return a list of human-readable config problems (empty if valid).

    ``strict=True`` is used by --strict-config: unknown keys raise
    SystemExit instead of only being reported.
    """
    issues = []
    unknown = sorted(set(config) - KNOWN_CONFIG_KEYS)
    if unknown:
        issues.append(
            "unknown config keys (no engine flag consumes them): "
            + ", ".join(unknown)
        )
    removed = sorted(set(config) & REMOVED_LEGACY_CONFIG_KEYS)
    if removed:
        issues.append(
            "legacy keys for removed features (ignored): "
            + ", ".join(removed)
        )
    scheduler = config.get("strategy_scheduler")
    if isinstance(scheduler, dict):
        unknown_sched = sorted(
            set(scheduler) - KNOWN_SCHEDULER_KEYS - LEGACY_SCHEDULER_KEYS
        )
        if unknown_sched:
            issues.append(
                "unknown strategy_scheduler keys: "
                + ", ".join(unknown_sched)
            )
        legacy_sched = sorted(set(scheduler) & LEGACY_SCHEDULER_KEYS)
        if legacy_sched:
            issues.append(
                "legacy strategy_scheduler keys (MLP policy removed): "
                + ", ".join(legacy_sched)
            )
    for issue in issues:
        print(f"[config-warning] {issue}", file=sys.stderr)
    if strict and issues:
        raise SystemExit(
            "--strict-config: refusing to run with config issues above"
        )
    return issues


def command_for(task, root, config, log_path, template_mode, seed=None):
    task_dir = root / task["relative_path"]
    if seed is not None:
        config = dict(config, seed=seed)
    cmd = [
        sys.executable, "run_sparse.py",
        "--template-mode", template_mode,
        "--program-id", task["id"],
        "--c", str(task_dir / "normalized.c"),
        "--smt", str(task_dir / "task.c_smt"),
        "--max-degree", str(config["max_degree"]),
        "--max-monomials", str(config["max_monomials"]),
        "--max-clauses", str(config["max_clauses"]),
        "--coefficient-bounds",
        ",".join(str(v) for v in config["coefficient_bounds"]),
        "--timeout", str(config["program_timeout_seconds"]),
        "--template-timeout", str(config["template_timeout_seconds"]),
        "--checker-timeout", str(config["checker_timeout_seconds"]),
        "--max-candidates-per-structure",
        str(config["max_candidates_per_structure"]),
        "--beam-width", str(config["beam_width"]),
        "--timeout-escalation-limit",
        str(config.get("timeout_escalation_limit", 3)),
        "--timeout-escalation-cap",
        str(config.get("timeout_escalation_cap", 150.0)),
        "--degree-escalation-cap",
        str(config.get("degree_escalation_cap", 0)),
        "--clause-escalation-cap",
        str(config.get("clause_escalation_cap", 0)),
        "--seed", str(config["seed"]),
        "--log-jsonl", str(log_path),
    ]
    if not config.get("fallback_enabled", True):
        cmd.append("--disable-fallback")
    if config.get("fallback_mode", "fixed") != "fixed":
        cmd.append("--fallback-mode")
        cmd.append(str(config["fallback_mode"]))
    if config.get("fallback_stagnation_patience"):
        cmd.append("--fallback-stagnation-patience")
        cmd.append(str(config["fallback_stagnation_patience"]))
    if config.get("fallback_stagnation_min_elapsed_ratio") is not None:
        cmd.append("--fallback-stagnation-min-elapsed-ratio")
        cmd.append(str(config["fallback_stagnation_min_elapsed_ratio"]))
    if config.get("counterexample_prefilter"):
        cmd.append("--enable-ce-prefilter")
    if config.get("coverage_optimizations"):
        cmd.append("--enable-coverage-optimizations")
    if config.get("neural_ranker_safety_mode", "topk") != "topk":
        cmd.append("--neural-ranker-safety-mode")
        cmd.append(str(config["neural_ranker_safety_mode"]))
    if not config.get("template_cache", True):
        cmd.append("--disable-template-cache")
    if not config.get("degree_iterative", True):
        cmd.append("--disable-degree-iterative")
    if not config.get("clause_iterative", True):
        cmd.append("--disable-clause-iterative")
    if not config.get("typed_counterexamples", True):
        cmd.append("--disable-typed-counterexamples")
    if not config.get("semantic_generators", True):
        cmd.append("--disable-semantic-generators")
    if not config.get("monomial_feedback", True):
        cmd.append("--disable-monomial-feedback")
    if not config.get("beam_search", True):
        cmd.append("--disable-beam-search")
    if not config.get("update_closure", True):
        cmd.append("--disable-update-closure")
    if not config.get("precondition_frame", True):
        cmd.append("--disable-precondition-frame")
    if not config.get("monotone_entry_bounds", True):
        cmd.append("--disable-monotone-entry-bounds")
    if not config.get("affine_exit_boundary", True):
        cmd.append("--disable-affine-exit-boundary")
    if config.get("smt_vc_frontend"):
        cmd.append("--enable-smt-vc-frontend")
        cmd.append("--smt-vc-max-degree")
        cmd.append(str(config.get("smt_vc_max_degree", 4)))
    if config.get("branchwise_conservation_frontend"):
        cmd.append("--enable-branchwise-conservation-frontend")
        cmd.append("--branchwise-conservation-max-degree")
        cmd.append(str(config.get("branchwise_conservation_max_degree", 2)))
    if config.get("scaled_division_frontend"):
        cmd.append("--enable-scaled-division-frontend")
    if config.get("entry_potential_frontend"):
        cmd.append("--enable-entry-potential-frontend")
    if config.get("exit_post_closure_frontend"):
        cmd.append("--enable-exit-post-closure-frontend")
    if config.get("algebraic_recurrence_frontend"):
        cmd.append("--enable-algebraic-recurrence-frontend")
        cmd.append("--algebraic-recurrence-max-degree")
        cmd.append(str(config.get("algebraic_recurrence_max_degree", 6)))
    if config.get("algebraic_recurrence_minimum_degree"):
        cmd.extend([
            "--algebraic-recurrence-minimum-degree",
            str(config["algebraic_recurrence_minimum_degree"]),
        ])
    if config.get("branch_transitions_enabled"):
        cmd.append("--enable-branch-transitions")
    if config.get("transition_kernel_enabled"):
        cmd.append("--enable-transition-kernel")
        cmd.extend([
            "--transition-kernel-max-degree",
            str(config.get("transition_kernel_max_degree", 3)),
        ])
        cmd.extend([
            "--transition-kernel-max-atoms",
            str(config.get("transition_kernel_max_atoms", 8)),
        ])
        cmd.extend([
            "--transition-kernel-max-conjunctions",
            str(config.get("transition_kernel_max_conjunctions", 3)),
        ])
    if config.get("unified_clause_bank_enabled"):
        cmd.append("--enable-unified-clause-bank")
        cmd.extend([
            "--unified-clause-bank-max-trials",
            str(config.get("unified_clause_bank_max_trials", 64)),
        ])
    if config.get("checker_timeout_retry_enabled"):
        cmd.append("--enable-checker-timeout-retry")
        cmd.extend([
            "--checker-timeout-retry-limit",
            str(config.get("checker_timeout_retry_limit", 1)),
        ])
    if not config.get("divmod_frontend", True):
        cmd.append("--disable-divmod-frontend")
    if not config.get("linear_fast_path", True):
        cmd.append("--disable-linear-fast-path")
    if config.get("linear_fast_path_guard"):
        cmd.append("--enable-linear-fast-path-guard")
    if not config.get("lemma_conjunction", True):
        cmd.append("--disable-lemma-conjunction")
    if config.get("lemma_conjunction_max_trials") is not None:
        cmd.extend([
            "--lemma-conjunction-max-trials",
            str(config["lemma_conjunction_max_trials"]),
        ])
    composer = config.get("clause_composer")
    if composer:
        cmd.append("--enable-clause-composer")
        cmd.extend([
            "--clause-composer-bank-size",
            str(composer.get("bank_size", 64)),
        ])
        cmd.extend([
            "--clause-composer-max-ast-size",
            str(composer.get("max_ast_size", 180)),
        ])
        cmd.extend([
            "--clause-composer-max-proposals",
            str(composer.get("max_proposals", 32)),
        ])
        cmd.extend([
            "--clause-composer-per-failure",
            str(composer.get("per_failure", 4)),
        ])
        cmd.extend([
            "--clause-composer-generation-budget-ratio",
            str(composer.get("generation_budget_ratio", 0.15)),
        ])
    scheduler = config.get("strategy_scheduler")
    if scheduler:
        for key in ("granularity", "quota_mode", "round_budget_ratio", "prior_strength", "progress_weight"):
            if key in scheduler:
                cmd.extend(["--strategy-scheduler-" + key.replace("_", "-"), str(scheduler[key])])
        if scheduler.get("online_updates") is False:
            cmd.append("--strategy-scheduler-no-online-updates")
        if scheduler.get("disabled_categories"):
            cmd.extend(["--strategy-scheduler-disabled-categories", ",".join(scheduler["disabled_categories"])])
        if scheduler.get("enabled"):
            cmd.append("--enable-strategy-scheduler")
        cmd.extend([
            "--strategy-scheduler-policy",
            str(scheduler.get("policy", "heuristic")),
        ])
        cmd.extend([
            "--strategy-scheduler-utility",
            str(scheduler.get("utility", "ratio")),
        ])
        cmd.extend([
            "--strategy-scheduler-priors",
            str(scheduler.get("priors", "empirical")),
        ])
        cmd.extend([
            "--strategy-scheduler-epsilon",
            str(scheduler.get("epsilon", 1.0)),
        ])
        cmd.extend([
            "--strategy-scheduler-lambda",
            str(scheduler.get("lambda", 0.005)),
        ])
        cmd.extend([
            "--strategy-scheduler-mu",
            str(scheduler.get("mu", 0.1)),
        ])
        cmd.extend([
            "--strategy-scheduler-exploration-scale",
            str(scheduler.get("exploration_scale", 0.05)),
        ])
        cmd.extend([
            "--strategy-scheduler-min-typed-budget-ratio",
            str(scheduler.get("min_typed_budget_ratio", 0.15)),
        ])
        cmd.extend([
            "--strategy-scheduler-min-fallback-budget-ratio",
            str(scheduler.get("min_fallback_budget_ratio", 0.2)),
        ])
        if scheduler.get("timeout_tiers"):
            cmd.extend([
                "--strategy-scheduler-timeout-tiers",
                ",".join(str(t) for t in scheduler["timeout_tiers"]),
            ])
        if scheduler.get("quotas"):
            cmd.extend([
                "--strategy-scheduler-quotas",
                ",".join(
                    f"{name}={quota}"
                    for name, quota in scheduler["quotas"].items()
                ),
            ])
        cmd.extend([
            "--strategy-scheduler-max-decisions",
            str(scheduler.get("max_decisions", 200)),
        ])
        if scheduler.get("progress_feedback"):
            cmd.append("--strategy-scheduler-progress-feedback")
        cmd.extend([
            "--strategy-scheduler-complexity-degree-weight",
            str(scheduler.get("complexity_degree_weight", 2.0)),
        ])
        cmd.extend([
            "--strategy-scheduler-complexity-clause-weight",
            str(scheduler.get("complexity_clause_weight", 1.0)),
        ])
    graph = config.get("graph_ranker")
    if graph:
        cmd.append("--graph-ranker")
        cmd.extend(["--neural-ranker-checkpoint", graph["checkpoint"]])
        cmd.extend(["--neural-ranker-device", graph.get("device", "cpu")])
        cmd.extend([
            "--neural-ranker-topk-safe",
            str(graph.get("topk_safe", 5)),
        ])
        cmd.extend([
            "--neural-ranker-exploration-ratio",
            str(graph.get("exploration_ratio", 0.1)),
        ])
    return cmd


def run_one(task, root, config, output, template_mode, seed=None):
    log_path = output / "traces" / (task["id"] + ".jsonl")
    cmd = command_for(
        task, root, config, log_path, template_mode, seed=seed
    )
    env = dict(os.environ)
    env.update({
        "PYTHONDONTWRITEBYTECODE": "1",
        "OMP_NUM_THREADS": "1",
        "OPENBLAS_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
    })
    hard_timeout = config["program_timeout_seconds"]
    hard_timeout += 2 * config["checker_timeout_seconds"] + 15
    started = time.perf_counter()
    try:
        repo = Path(__file__).resolve().parents[1]
        # Keep the solver and every descendant in one process group.  Some
        # linear benchmarks invoke helper processes that inherit stdout; a
        # plain subprocess.run(timeout=...) can then wait forever for the
        # captured pipe after the leader times out.
        # Capture into a file rather than a PIPE: escaped descendants can
        # retain a pipe descriptor after the leader exits and make
        # communicate() wait forever.  A process group still lets us cleanly
        # terminate descendants on the hard deadline.
        with tempfile.TemporaryFile(mode="w+t") as capture:
            process = subprocess.Popen(
                cmd, cwd=str(repo), env=env, text=True,
                stdout=capture, stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            timed_out = False
            try:
                process.wait(timeout=hard_timeout)
            except subprocess.TimeoutExpired:
                timed_out = True
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.wait()
            capture.seek(0)
            stdout = capture.read()
        if timed_out:
            result = {"status": "hard-timeout", "reason": "subprocess-timeout"}
            raise StopIteration
        parsed = None
        for line in reversed(stdout.splitlines()):
            try:
                parsed = json.loads(line)
                break
            except json.JSONDecodeError:
                continue
        # A few highly parallel runs can fail during interpreter/solver
        # startup (returncode 1) without producing a JSON result.  Retry once
        # in a fresh process group; deterministic parser failures remain
        # errors and are still visible in the audit.
        if (process.returncode != 0 or parsed is None) and not timed_out:
            with tempfile.TemporaryFile(mode="w+t") as retry_capture:
                retry = subprocess.Popen(
                    cmd, cwd=str(repo), env=env, text=True,
                    stdout=retry_capture, stderr=subprocess.STDOUT,
                    start_new_session=True,
                )
                retry_timed_out = False
                try:
                    retry.wait(timeout=hard_timeout)
                except subprocess.TimeoutExpired:
                    retry_timed_out = True
                    try:
                        os.killpg(retry.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    retry.wait()
                retry_capture.seek(0)
                retry_stdout = retry_capture.read()
            if not retry_timed_out:
                retry_parsed = None
                for line in reversed(retry_stdout.splitlines()):
                    try:
                        retry_parsed = json.loads(line)
                        break
                    except json.JSONDecodeError:
                        continue
                if retry.returncode == 0 and retry_parsed is not None:
                    process, stdout, parsed, timed_out = retry, retry_stdout, retry_parsed, False
        if process.returncode != 0 or parsed is None:
            result = {
                "status": "error",
                "reason": f"returncode-{process.returncode}",
            }
        else:
            result = parsed
    except StopIteration:
        pass
    wall = time.perf_counter() - started
    return {
        "id": task["id"],
        "problem_class": task_problem_class(task),
        "linearity": task_linearity(task),
        "experiment_scope": task.get("experiment_scope"),
        "legacy_n_class": task.get("legacy_n_class"),
        "status": result.get("status", "error"),
        "reason": result.get("reason"),
        "invariant": result.get("invariant"),
        "total_time": result.get("total_time"),
        "iterations": result.get("iterations"),
        # Checker-call counts were previously dropped here, which forced
        # the summarizers to report iteration counts under a
        # checker-calls label.
        "checker_calls": result.get("checker_calls"),
        "method": result.get("method"),
        "wall_time": wall,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    parser.add_argument("--config", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--splits", default="test-locked")
    parser.add_argument("--template-mode", default=None,
                        help="override config template_mode")
    parser.add_argument("--scopes", default=None,
                        help="filter by experiment_scope (comma-separated)")
    parser.add_argument("--classes", default=None,
                        help="filter by problem_class (comma-separated)")
    parser.add_argument("--seed", type=int, default=None,
                        help="override the config seed (multi-seed studies)")
    parser.add_argument("--strict-config", action="store_true",
                        help="abort when the config contains unknown or "
                        "legacy-removed keys (they would silently "
                        "no-op)")
    parser.add_argument("--ids", default=None,
                        help="comma-separated task-id allowlist")
    parser.add_argument("--exclude-ids", default=None,
                        help="comma-separated task-id blocklist")
    args = parser.parse_args()

    root = Path(args.root).resolve()
    output = Path(args.output_dir).resolve()
    output.mkdir(parents=True, exist_ok=True)
    (output / "traces").mkdir(exist_ok=True)
    config = read_json(args.config)
    validate_config_keys(config, strict=args.strict_config)
    template_mode = args.template_mode or config["template_mode"]

    manifest = read_json(root / "manifest.json")
    splits = set(args.splits.split(","))
    tasks = [t for t in manifest if t["split"] in splits]
    if args.scopes:
        scopes = set(args.scopes.split(","))
        tasks = [t for t in tasks if t.get("experiment_scope") in scopes]
    if args.classes:
        classes = set(args.classes.split(","))
        tasks = [t for t in tasks if t.get("problem_class") in classes]
    if args.ids:
        allow = set(s.strip() for s in args.ids.split(",") if s.strip())
        tasks = [t for t in tasks if t["id"] in allow]
    if args.exclude_ids:
        block = set(s.strip() for s in args.exclude_ids.split(",") if s.strip())
        tasks = [t for t in tasks if t["id"] not in block]
    print(f"Running {len(tasks)} tasks with {args.workers} workers (mode={template_mode})...")

    results = []
    completed = set()
    results_path = output / "results.jsonl"
    if results_path.exists():
        for line in results_path.read_text().splitlines():
            try:
                rec = json.loads(line)
                completed.add(rec["id"])
                results.append(rec)
            except (json.JSONDecodeError, KeyError):
                pass
    remaining = [t for t in tasks if t["id"] not in completed]
    print(f"Already completed: {len(completed)}, remaining: {len(remaining)}")

    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        future_map = {
            pool.submit(
                run_one, t, root, config, output, template_mode,
                seed=args.seed,
            ): t
            for t in remaining
        }
        for future in concurrent.futures.as_completed(future_map):
            task = future_map[future]
            try:
                result = future.result()
            except Exception as e:
                result = {"id": task["id"], "status": "error", "reason": str(e)}
            results.append(result)
            with results_path.open("a") as f:
                f.write(json.dumps(result, default=str) + "\n")
            solved = sum(1 for r in results if r["status"] == "solved")
            total = len(results)
            print(f"  [{total}/{len(tasks)}] {result['id']:40s} "
                  f"{result['status']:12s} solved={solved}/{total} "
                  f"({100*solved/total:.1f}%)")

    task_by_id = {task["id"]: task for task in tasks}
    for result in results:
        task = task_by_id.get(result.get("id"))
        if task:
            if not result.get("problem_class"):
                result["problem_class"] = task_problem_class(task)
            if not result.get("linearity"):
                result["linearity"] = task_linearity(task)
    summary = result_metrics(results)
    summary["by_linearity"] = grouped_metrics(results, "linearity")
    summary["by_problem_class"] = grouped_metrics(
        results, "problem_class"
    )
    (output / "summary.json").write_text(json.dumps(summary, indent=2))
    print(f"\n=== FINAL: {summary['solved']}/{summary['total']} "
          f"= {summary['rate']:.1f}% ===")


if __name__ == "__main__":
    main()
