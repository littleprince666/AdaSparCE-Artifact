"""Fresh complete pinned author Clause2Inv; transport instrumentation only."""
import importlib
import os
from pathlib import Path
import random
import sys

from .common import from_infix


def author_import(request):
    import numpy
    author = Path(request['author_root'])
    sys.path[:0] = [str(author/'combinator'), str(author/'generator')]
    os.chdir(request['workdir'])
    sys.argv = [str(author/'combinator/main.py'), '-input_code', request['c'],
                '-input_vcs', request['vc']]
    random.seed(request['seed'])
    numpy.random.seed(request['seed'])
    return importlib.import_module('checker')


def run(request):
    if request.get('action') == 'offline-doctor':
        checker = author_import(request)
        return dict(status='ready-offline', entrypoint='checker.boogie_result',
                    author_model=checker.llm.llm.value,
                    temperature=checker.llm.temperature, max_tokens=checker.llm.max_tokens,
                    sample=checker.llm.sample, inference_started=False)
    from .online_transport import install_transport
    install_transport(request['authorization'], request['ledger'], request['journal'],
                      dict(variant='clause2inv', seed=request['seed'], id=request['task']['id']),
                      request['deadline_monotonic'])
    checker = author_import(request)
    checker.boogie_result()
    if not checker.expr_ans:
        return dict(status='unknown', reason='complete author pipeline returned no candidate')
    return dict(status='solved', invariant=from_infix(checker.expr_ans),
                reason='complete pinned author Clause2Inv; fresh online generation',
                model=request['authorization']['model'], temperature=.8,
                llm_seed_policy='author API has no seed; local Python/NumPy seed fixed',
                algorithm_changes=False, transport='SDK retries disabled; original five author attempts retained')
