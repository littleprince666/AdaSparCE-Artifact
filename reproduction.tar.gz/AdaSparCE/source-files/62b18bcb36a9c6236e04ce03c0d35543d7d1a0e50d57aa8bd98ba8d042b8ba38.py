"""Initial VC candidate and postcondition-seed search phases."""

import time
import z3
from SMT_Solver.SMT_verifier import CheckFailureType
from SparCE.logging_utils import stable_hash
from SparCE.ranking.ranker_trace import candidate_formula_hash


class FrontendSearch:
    """Initial VC candidate and postcondition-seed search phases."""

    def _run_vc_frontend_phase(self, state):
        """Exact VC frontends: fixed upfront check loop (legacy path).

        Under strategy scheduling the VC frontends are not checked here;
        they were moved to ``state.scheduled_vc_branches`` and become
        ordinary scheduler pools.
        """
        protected_deadline = time.perf_counter() + self.config.timeout_seconds * 0.2
        state.vc_limit = max(
            self.config.beam_width * 2,
            self.config.beam_width,
        )
        state.rank_vc_frontend = self.neural_ranker is not None
        state.mechanism_safety_mode = (
            self.neural_ranker is not None
            and str(getattr(
                self.config, "neural_ranker_safety_mode", "topk"
            )) == "mechanism"
        )
        state.vc_branches = self._vc_branches(
            state.smt_path,
            state.analyzer,
            apply_limit=not state.rank_vc_frontend,
        )
        if self._program_vc_graph is not None:
            state.vc_branches = sorted(
                state.vc_branches,
                key=lambda branch: (-branch.score, -self._graph_bonus(branch)),
            )
        state.scheduled_vc_branches = []
        if state.scheduler is not None and not self.config.coverage_optimizations:
            # Under strategy scheduling the VC frontends are not
            # checked in a fixed upfront loop; they become ordinary
            # scheduler pools ordered by cost-aware utility.
            state.scheduled_vc_branches = state.vc_branches
            state.vc_branches = []
        elif state.scheduler is not None:
            state.scheduled_vc_branches = list(state.vc_branches)
        if state.rank_vc_frontend and state.vc_branches:
            if (
                self.config.neural_ranker_topk_safe >= state.vc_limit
                and not state.mechanism_safety_mode
            ):
                original_count = len(state.vc_branches)
                state.vc_branches = state.vc_branches[:state.vc_limit]
                self.logger.write({
                    "event": "neural_ranker_prebeam",
                    "phase": "vc-frontend",
                    "generated_candidate_count": original_count,
                    "retained_candidate_count": len(state.vc_branches),
                    "active_candidate_count": len(state.vc_branches),
                    "beam_width": state.vc_limit,
                    "heuristic_safe_count": len(state.vc_branches),
                    "mechanism_safe_count": 0,
                    "exploration_count": 0,
                    "reserve_candidate_count": (
                        original_count - len(state.vc_branches)
                    ),
                    "inference_time_seconds": 0.0,
                    "inference_skipped": "safe-prefix-covers-beam",
                })
                predictions = None
            else:
                predictions, inference_time = (
                    self._neural_ranker_predictions(
                        "vc-frontend-prebeam",
                        state.vc_branches,
                        state.analyzer,
                        state.failure_type,
                        state.failure_counts,
                        state.checked,
                        (
                            (time.perf_counter() - state.started)
                            / self.config.timeout_seconds
                        ),
                    )
                )
            if predictions is None:
                # _vc_branches returned the complete legacy-sorted list so
                # a failed model must restore the old bounded prefix.
                state.vc_branches = state.vc_branches[:state.vc_limit]
            else:
                try:
                    from SparCE.ranking.neural_ranker import safe_ranker_selection

                    selection_seed = int(stable_hash({
                        "seed": self.config.seed,
                        "phase": "vc-frontend",
                        "candidate_hashes": [
                            candidate_formula_hash(candidate.formula)
                            for candidate in state.vc_branches
                        ],
                    })[:16], 16)
                    selection = safe_ranker_selection(
                        state.vc_branches,
                        predictions.ranking_scores,
                        beam_width=state.vc_limit,
                        topk_safe=(
                            0
                            if state.mechanism_safety_mode
                            else self.config.neural_ranker_topk_safe
                        ),
                        exploration_ratio=(
                            self.config
                            .neural_ranker_exploration_ratio
                        ),
                        seed=selection_seed,
                    )
                    original = list(state.vc_branches)
                    state.vc_branches = list(
                        selection.ordered_candidates
                    ) + [
                        original[index]
                        for index in selection.reserve_indices
                    ]
                    self.logger.write({
                        "event": "neural_ranker_prebeam",
                        "phase": "vc-frontend",
                        "safety_mode": (
                            "mechanism"
                            if state.mechanism_safety_mode else "topk"
                        ),
                        "generated_candidate_count": len(original),
                        "retained_candidate_count": len(state.vc_branches),
                        "active_candidate_count": len(
                            selection.selected_indices
                        ),
                        "beam_width": state.vc_limit,
                        "heuristic_safe_count": len(
                            selection.heuristic_safe_indices
                        ),
                        "mechanism_safe_count": len(
                            selection.mechanism_safe_indices
                        ),
                        "exploration_count": len(
                            selection.exploration_indices
                        ),
                        "reserve_candidate_count": len(
                            selection.reserve_indices
                        ),
                        "inference_time_seconds": inference_time,
                    })
                except Exception as error:
                    self._ranker_runtime_fallback = str(error)
                    self.neural_ranker = None
                    self.logger.write({
                        "event": "neural_ranker_fallback",
                        "phase": "vc-frontend-prebeam-safety",
                        "reason": str(error),
                        "candidate_count": len(state.vc_branches),
                        "fallback": "legacy-vc-prefix",
                    })
                    state.vc_branches = state.vc_branches[:state.vc_limit]
        for rank, branch in enumerate(state.vc_branches, 1):
            if (
                time.perf_counter() - state.started >= self.config.timeout_seconds
                or self._checker_budget_exhausted(state.checked)
                or (self.config.coverage_optimizations and time.perf_counter() >= protected_deadline)
            ):
                break
            trace_context = None
            if self._ranker_trace_enabled():
                vc_remaining = state.vc_branches[rank - 1:]
                trace_context = self._trace_candidate_group(
                    "vc-frontend",
                    vc_remaining,
                    branch,
                    state.analyzer,
                    state.failure_type,
                    state.failure_counts,
                    state.checked,
                    (
                        time.perf_counter() - state.started
                    ) / self.config.timeout_seconds,
                    score_components={
                        candidate: {
                            "heuristic": float(candidate.score),
                            "mechanism_bonus": 0.0,
                            "legacy_neural_bonus": 0.0,
                            "selection_score": float(candidate.score),
                        }
                        for candidate in vc_remaining
                    },
                    selection_policy="direct-frontend-order",
                )
            result = self._check_branch(
                state.verifier, branch, state.smt_path, state.program_id, rank, state.analyzer,
                trace_context,
                checker_timeout=(min(self.config.checker_timeout_seconds,
                    protected_deadline - time.perf_counter())
                    if self.config.coverage_optimizations else None),
            )
            if result is None:
                continue
            state.checked += 1
            state.checked_mechanisms.add(branch.mechanism)
            self._note_stagnation_progress(state, result)
            if result.failure_type == CheckFailureType.SUCCESS:
                return self._success(state.program_id, branch, state.started, state.checked)
            state.failure_type = result.failure_type
            state.failure_counts[state.failure_type] += 1
            if self.config.coverage_optimizations and result.failure_type in (
                    CheckFailureType.TIMEOUT, CheckFailureType.UNKNOWN):
                self.candidate_cache.discard(str(z3.simplify(branch.formula)))
            trial_branch, trial_delta = self._run_lemma_trials_hook(state,
                result, branch
            )
            if trial_branch is not None:
                state.checked += trial_delta
                return self._success(
                    state.program_id, trial_branch, state.started, state.checked
                )
            state.checked += trial_delta

    def _run_postcondition_seed_phase(self, state):
        """Direct postcondition-seed check (legacy path)."""
        state.vc_count = len(state.vc_branches)
        if (
            time.perf_counter() - state.started < self.config.timeout_seconds
            and not self._checker_budget_exhausted(state.checked)
        ):
            trace_context = None
            if self._ranker_trace_enabled():
                trace_context = self._trace_candidate_group(
                    "postcondition-seed",
                    [state.base],
                    state.base,
                    state.analyzer,
                    state.failure_type,
                    state.failure_counts,
                    state.checked,
                    (
                        time.perf_counter() - state.started
                    ) / self.config.timeout_seconds,
                    degree=state.base.degree,
                    clauses=state.base.clauses,
                    score_components={
                        state.base: {
                            "heuristic": float(state.base.score),
                            "mechanism_bonus": 0.0,
                            "legacy_neural_bonus": 0.0,
                            "selection_score": float(state.base.score),
                        }
                    },
                    selection_policy="direct-postcondition-seed",
                )
            result = self._check_branch(
                state.verifier,
                state.base,
                state.smt_path,
                state.program_id,
                state.vc_count + 1,
                state.analyzer,
                trace_context,
            )
            if result is not None:
                state.checked += 1
                state.checked_mechanisms.add(state.base.mechanism)
                self._note_stagnation_progress(state, result)
                if result.failure_type == CheckFailureType.SUCCESS:
                    return self._success(
                        state.program_id, state.base, state.started, state.checked
                    )
                state.failure_type = result.failure_type
                state.failure_counts[state.failure_type] += 1
                trial_branch, trial_delta = self._run_lemma_trials_hook(state,
                    result, state.base
                )
                if trial_branch is not None:
                    state.checked += trial_delta
                    return self._success(
                        state.program_id, trial_branch, state.started, state.checked
                    )
                state.checked += trial_delta
