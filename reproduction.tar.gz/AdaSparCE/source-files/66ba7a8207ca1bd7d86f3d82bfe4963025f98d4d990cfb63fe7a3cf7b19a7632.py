import sys
import re
from pycparser import c_generator, c_ast, c_parser 
from helpers.vcommon import vwrite
from beartype import beartype
from pathlib import Path
import pdb
DBG = pdb.set_trace


def comment_remover(text):
    def replacer(match):
        s = match.group(0)
        if s.startswith('/'):
            return " " # note: a space and not an empty string
        else:
            return s
    pattern = re.compile(
        r'//.*?$|/\*.*?\*/|\'(?:\\.|[^\\\'])*\'|"(?:\\.|[^\\"])*"',
        re.DOTALL | re.MULTILINE
    )
    return re.sub(pattern, replacer, text)


class AddPrintfVisitor(c_ast.NodeVisitor):
    """
    add printf() calls to vtrace definitions
    """
    @beartype
    def __init__(self, vtrace: str) -> None:
        self.vtrace = vtrace

    @beartype
    def visit_FuncDef(self, node: c_ast.Node) -> None:
        if node.decl.name.startswith(self.vtrace) and not node.body.block_items:
            self._insert_funccall(node)

    @beartype
    def _insert_funccall(self, node: c_ast.FuncDef)-> None:
        myvars = [(p.name, p.type.type.names[0])
                  for p in node.decl.type.args.params]
        funcalls  = self._create_new_funs(node.decl.name, myvars)
        node.body.block_items = funcalls



class AddPrintfInstr(AddPrintfVisitor):
    @beartype
    def _create_new_funs(self, myname: str,
                         myvars: list[tuple[str, str]]) -> list[c_ast.FuncCall]:
        # pick the printf conversion by C type: integers as %d, real types
        # (float/double) as %.17g so the value round-trips exactly to a rational
        def fmt(typ: str) -> str:
            return "%d" if typ == "int" else "%.17g"
        value = "; ".join(fmt(t) for _, t in myvars) + "\\n"
        myvars_ = [c_ast.ID(name=n) for n, _ in myvars]
        exprs = [c_ast.Constant(type="string",
                                value=f'\"{myname}; {value}"')] + myvars_
        funcCall = c_ast.FuncCall(name=c_ast.ID(name="printf"),
                                  args=c_ast.ExprList(exprs=exprs))
        return [funcCall]
    
class ChangeVassertVisitor(c_ast.NodeVisitor):
    # change vassert call to assert or $assert calls

    @beartype
    def __init__(self, fname:str, changeto:str) -> None:
        self.fname = fname
        self.changeto = changeto
        
    @beartype
    def visit_FuncCall(self, node:c_ast.Node) -> None:
        if node.name.name == self.fname:
            self._change(node)

    @beartype
    def _change(self, fd:c_ast.FuncCall) -> None:
        fd.name.name = self.changeto


class PrintTypeVisitor(c_ast.NodeVisitor):
    # print vtrace1; I x; I y; I r; I q
    # also collect $input type name
    
    def __init__(self, vtrace:str, mainQ:str) -> None:
        self.vtrace = vtrace
        self.mainQ = mainQ
        self.mainQ_params = []
        self.typ_info = []
        
    def visit_FuncDef(self, node:c_ast.Node) -> None:
        
        if node.decl.name.startswith(self.vtrace) or node.decl.name == self.mainQ:
            params = node.decl.type.args.params if (node.decl.type.args and node.decl.type.args.params) else []
            nts = [(p.name, p.type.type.names[0]) for p in params if p.name is not None]
            nts_str = '; '.join(("I " if t == "int" else "D ") + n for n, t in nts)
            self.typ_info.append(f"{node.decl.name}; {nts_str}")

        if node.decl.name == self.mainQ:
            params = node.decl.type.args.params if (node.decl.type.args and node.decl.type.args.params) else []
            self.mainQ_params = [(p.name, p.type.type.names[0]) for p in params if p.name is not None]


@beartype
def gen(filename: Path, myast: c_ast.FileAST, includes: list[str]) -> None:
    generator = c_generator.CGenerator()
    instr = generator.visit(myast)
    instr = '\n'.join(includes + [instr])
    vwrite(filename, instr)

@beartype    
def instrument(filename: Path, tracefile: Path) -> list[str]:
    includes = []
    src = []
    text = filename.read_text()
    text = comment_remover(text)
    
    for l in text.split('\n'):
        l = l.strip()
        if l.startswith("#include"):
            includes.append(l)
        else:
            src.append(l)

    # Instrumentation adds printf/assert calls even when the input program
    # itself does not use these headers.
    for header in ("stdio.h", "assert.h"):
        if not any(header in include for include in includes):
            includes.append(f"#include <{header}>")

    src = '\n'.join(src)
    parser = c_parser.CParser()
    
    #trace instrumentation
    ast_instr = parser.parse(src)
    AddPrintfInstr("vtrace").visit(ast_instr)
    ChangeVassertVisitor("vassume", "assert").visit(ast_instr)
    gen(tracefile, ast_instr, includes)

    # collect variable type info (vtrace/mainQ signatures) for inp/inv decls
    ast_typ = parser.parse(src)
    vis = PrintTypeVisitor("vtrace", "mainQ")
    vis.visit(ast_typ)
    return vis.typ_info


if __name__ == '__main__':
    filename = Path(sys.argv[1])
    tracefile = Path(sys.argv[2])
    typ_output = instrument(filename, tracefile)
    print('\n'.join(typ_output))
