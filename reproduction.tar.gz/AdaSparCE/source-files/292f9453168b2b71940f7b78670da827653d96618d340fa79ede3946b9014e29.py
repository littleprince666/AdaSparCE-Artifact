"""Identifier-free structural features for the VC-conditioned ranker.

Only the allow-listed aggregate fields defined here may reach the neural
model.  Trace identifiers and content hashes remain useful for joining and
auditing samples, but this module deliberately never reads them.
"""

from __future__ import annotations

import hashlib
import json
import math

import z3


FEATURE_SCHEMA_VERSION = "vc_deepsets_ranker_features.v1"

GUARD_TYPES = (
    "missing",
    "constant",
    "var_const",
    "var_var",
    "conjunction",
    "disjunction",
    "negation",
    "other",
)
COMPARISON_TYPES = ("lt", "le", "gt", "ge", "eq", "ne")
FAILURE_TYPES = ("INIT", "STEP", "EXIT", "TIMEOUT", "UNKNOWN")

PROGRAM_FEATURE_NAMES = (
    "base_variable_count",
    "ssa_auxiliary_variable_count",
    *("guard_type_" + name for name in GUARD_TYPES),
    *("comparison_count_" + name for name in COMPARISON_TYPES),
    "update_count",
    "mutated_variable_count",
    "constant_additive_update_count",
    "affine_update_count",
    "variable_multiplication_update_count",
    "div_count",
    "mod_count",
    "branch_count",
    "has_disjunction",
    "has_synchronization_counter",
    "has_monotone_variable",
    "has_constant_initial_bound",
    "has_conservation_hint",
    "precondition_clause_count",
    "transition_branch_count",
    "postcondition_clause_count",
    "precondition_ast_size",
    "guard_ast_size",
    "transition_ast_size",
    "postcondition_ast_size",
    "estimated_vc_query_count",
    "estimated_postcondition_query_count",
    *("failure_set_" + name.lower() for name in FAILURE_TYPES),
    "distinct_counterexample_count",
    "repeat_counterexample_count",
    "elapsed_time_ratio",
    "current_degree",
    "current_clauses",
    "current_log1p_coefficient_bound",
    "current_candidate_count",
    "verified_candidate_count",
    "c_analysis_available",
    "vc_analysis_available",
    "update_analysis_available",
    "postcondition_analysis_available",
)

MONOMIAL_FEATURE_NAMES = (
    "degree",
    "variables_used",
    "max_exponent",
    "is_constant",
    "is_linear",
    "is_square",
    "is_high_power",
    "is_cross_term",
    "has_guard_role",
    "has_mutated_role",
    "has_monotone_role",
    "has_postcondition_role",
    "has_synchronization_counter_role",
    "from_update_closure",
    "from_counterexample_repair",
    "from_postcondition_seed",
    "historical_monomial_occurrence_count",
    "current_counterexample_relevance",
    "has_accumulator_role",
    "has_initialized_constant_role",
)

CANDIDATE_FEATURE_NAMES = (
    "heuristic_score",
    "degree",
    "clauses",
    "monomial_count",
    "coefficient_bound",
    "candidate_ast_size",
    "estimated_query_size",
    "contains_guard_role",
    "contains_postcondition_role",
    "responds_to_current_counterexample",
    "is_repeated_candidate",
    "specialized_frontend",
    "linear_fast_path",
    "spacer",
    "fallback",
    "mechanism_history_success",
    "mechanism_history_failure",
    "mechanism_history_timeout",
    "coefficient_bound_available",
)

# Fixed categorical vocabularies.  Prefix canonicalization handles mechanism
# variants without learning an integer ordering or growing the checkpoint.
MECHANISM_VOCAB = (
    "unknown",
    "postcondition-seed",
    "linear-fast-path",
    "typed-precondition-frame",
    "typed-monotone-entry-bounds",
    "typed-affine-exit-boundary",
    "typed-counter-lift",
    "typed-counter-boundary",
    "typed-counter-accumulator",
    "typed-guard-split",
    "typed-update-closure",
    "typed-remaining-work",
    "typed-sign-clauses",
    "typed-term-dropping",
    "typed-post-weakening",
    "typed-disjunctive-post",
    "typed-divmod",
    "ce-synthesized",
    "vc-linear-spacer-cover",
    "vc-finite-difference-closure",
    "vc-counter-lifted-difference-closure",
    "fallback",
)
RELATION_VOCAB = (
    "unknown",
    "eq",
    "le",
    "lt",
    "ge",
    "gt",
    "conjunction",
    "disjunction",
    "implication",
    "other",
)

PROGRAM_DIM = len(PROGRAM_FEATURE_NAMES)
MONOMIAL_DIM = len(MONOMIAL_FEATURE_NAMES)
CANDIDATE_DIM = len(CANDIDATE_FEATURE_NAMES)

if PROGRAM_DIM != 55 or MONOMIAL_DIM != 20 or CANDIDATE_DIM != 19:
    raise AssertionError("neural-ranker feature dimensions changed")


def _schema_payload():
    return {
        "version": FEATURE_SCHEMA_VERSION,
        "program": PROGRAM_FEATURE_NAMES,
        "monomial": MONOMIAL_FEATURE_NAMES,
        "candidate": CANDIDATE_FEATURE_NAMES,
        "mechanisms": MECHANISM_VOCAB,
        "relations": RELATION_VOCAB,
        "normalization": "signed-log1p-counts-then-train-zscore.v1",
    }


FEATURE_SCHEMA_HASH = hashlib.sha256(
    json.dumps(
        _schema_payload(), sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
).hexdigest()


def _symbols(expression):
    result = set()

    def visit(node):
        if (
            z3.is_const(node)
            and node.num_args() == 0
            and not z3.is_int_value(node)
            and not z3.is_rational_value(node)
            and node.sort().kind() != z3.Z3_BOOL_SORT
        ):
            result.add(str(node))
            return
        for child in node.children():
            visit(child)

    if expression is not None:
        visit(expression)
    return result


def _ast_size(expression):
    if expression is None:
        return 0
    seen = set()

    def visit(node):
        identity = node.get_id()
        if identity in seen:
            return 0
        seen.add(identity)
        return 1 + sum(visit(child) for child in node.children())

    return visit(expression)


def _flatten_and(expression):
    if expression is None:
        return []
    if z3.is_and(expression):
        result = []
        for child in expression.children():
            result.extend(_flatten_and(child))
        return result
    return [expression]


def _guard_type(expression):
    if expression is None:
        return "missing"
    expression = z3.simplify(expression)
    if z3.is_true(expression) or z3.is_false(expression):
        return "constant"
    if z3.is_and(expression):
        return "conjunction"
    if z3.is_or(expression):
        return "disjunction"
    if z3.is_not(expression):
        return "negation"
    if (
        z3.is_eq(expression)
        or z3.is_distinct(expression)
        or z3.is_lt(expression)
        or z3.is_le(expression)
        or z3.is_gt(expression)
        or z3.is_ge(expression)
    ):
        left, right = expression.children()[:2]
        left_symbols = _symbols(left)
        right_symbols = _symbols(right)
        if left_symbols and right_symbols:
            return "var_var"
        if left_symbols or right_symbols:
            return "var_const"
    return "other"


def _comparison_counts(expressions):
    result = {name: 0 for name in COMPARISON_TYPES}

    def visit(node):
        predicates = (
            (z3.is_lt, "lt"),
            (z3.is_le, "le"),
            (z3.is_gt, "gt"),
            (z3.is_ge, "ge"),
            (z3.is_eq, "eq"),
            (z3.is_distinct, "ne"),
        )
        for predicate, name in predicates:
            if predicate(node):
                result[name] += 1
                break
        for child in node.children():
            visit(child)

    for expression in expressions:
        if expression is not None:
            visit(expression)
    return result


def _operator_counts(expressions):
    div_count = 0
    mod_count = 0
    has_disjunction = False

    def visit(node):
        nonlocal div_count, mod_count, has_disjunction
        kind = node.decl().kind()
        if kind in (z3.Z3_OP_DIV, z3.Z3_OP_IDIV):
            div_count += 1
        elif kind in (z3.Z3_OP_MOD, z3.Z3_OP_REM):
            mod_count += 1
        if z3.is_or(node):
            has_disjunction = True
        for child in node.children():
            visit(child)

    for expression in expressions:
        if expression is not None:
            visit(expression)
    return div_count, mod_count, has_disjunction


def _degree(expression):
    if z3.is_int_value(expression) or z3.is_rational_value(expression):
        return 0
    if z3.is_const(expression) and expression.num_args() == 0:
        return 1
    kind = expression.decl().kind()
    children = expression.children()
    if z3.is_add(expression):
        return max((_degree(child) for child in children), default=0)
    if z3.is_mul(expression):
        return sum(_degree(child) for child in children)
    if kind == z3.Z3_OP_POWER and len(children) == 2:
        if z3.is_int_value(children[1]):
            return _degree(children[0]) * max(0, children[1].as_long())
        return 99
    if kind in (
        z3.Z3_OP_DIV,
        z3.Z3_OP_IDIV,
        z3.Z3_OP_MOD,
        z3.Z3_OP_REM,
    ):
        return 99
    return max((_degree(child) for child in children), default=0)


def _has_variable_multiplication(expression):
    found = False

    def visit(node):
        nonlocal found
        if found:
            return
        if z3.is_mul(node):
            symbolic = sum(bool(_symbols(child)) for child in node.children())
            if symbolic >= 2:
                found = True
                return
        for child in node.children():
            visit(child)

    visit(expression)
    return found


def _guard_expression(analyzer):
    guard = getattr(analyzer, "guard_z3", None)
    if guard is not None:
        return guard
    try:
        return analyzer.translator.expression(analyzer.guard_ast)
    except (AttributeError, TypeError, ValueError, z3.Z3Exception):
        return None


def _vc_analysis(smt_path):
    if not smt_path:
        return None
    try:
        from SparCE.generation.vc_analyzer import VCAnalyzer

        return VCAnalyzer(smt_path)
    except (OSError, ValueError, z3.Z3Exception):
        return None


def extract_program_context(analyzer, smt_path=None):
    """Return aggregate program/VC facts with no identifiers or names."""
    vc = _vc_analysis(smt_path)
    variables = tuple(getattr(analyzer, "variables", ()))
    guard = _guard_expression(analyzer)
    assumptions = list(getattr(analyzer, "assumptions", ()))
    updates = dict(getattr(analyzer, "updates", {}))
    postcondition = getattr(analyzer, "postcondition", None)

    if vc is not None:
        precondition = vc.precondition
        transition = vc.transition
        vc_postcondition = vc.postcondition
        comparison_expressions = (
            precondition, transition, vc_postcondition
        )
        operator_expressions = comparison_expressions
        ssa_count = max(0, len(vc.variables) - len(variables))
        transition_branches = (
            len(transition.children()) if z3.is_or(transition) else 1
        )
    else:
        precondition = z3.And(*assumptions) if assumptions else None
        transition = None
        vc_postcondition = postcondition
        comparison_expressions = tuple(
            [*assumptions, guard, *updates.values(), postcondition]
        )
        operator_expressions = comparison_expressions
        ssa_count = int(
            getattr(analyzer, "ranker_ssa_auxiliary_variable_count", 0)
        )
        transition_branches = 1 if updates else 0

    try:
        constant_additive = analyzer.constant_additive_updates()
    except (AttributeError, TypeError, z3.Z3Exception):
        constant_additive = {}
    affine_updates = sum(_degree(value) <= 1 for value in updates.values())
    variable_multiplication_updates = sum(
        _has_variable_multiplication(value) for value in updates.values()
    )
    div_count, mod_count, has_disjunction = _operator_counts(
        operator_expressions
    )
    guard_symbols = _symbols(guard)
    mutated = set(getattr(analyzer, "mutated", ()))
    synchronization = bool(guard_symbols.intersection(mutated))
    monotone = bool(constant_additive)
    constant_initial_count = 0
    for name in variables:
        try:
            constant_initial_count += analyzer.constant_initial(name) is not None
        except (AttributeError, KeyError, TypeError, z3.Z3Exception):
            pass
    conservation_hint = False
    if len(constant_additive) >= 2:
        deltas = list(constant_additive.values())
        conservation_hint = (
            any(left + right == 0 for left in deltas for right in deltas)
            or constant_initial_count >= 2
        )
    comparison_counts = _comparison_counts(comparison_expressions)
    pre_clauses = len(_flatten_and(precondition))
    post_clauses = len(_flatten_and(vc_postcondition))
    branch_count = max(
        transition_branches,
        len(guard.children()) if guard is not None and z3.is_or(guard) else 0,
    )
    update_available = bool(updates) or bool(
        vc is not None and getattr(vc, "updates", {})
    )

    return {
        "feature_schema_version": FEATURE_SCHEMA_VERSION,
        "base_variable_count": len(variables),
        "ssa_auxiliary_variable_count": ssa_count,
        "guard_type": _guard_type(guard),
        "comparison_counts": comparison_counts,
        "update_count": len(updates),
        "mutated_variable_count": len(mutated),
        "constant_additive_update_count": len(constant_additive),
        "affine_update_count": affine_updates,
        "variable_multiplication_update_count": (
            variable_multiplication_updates
        ),
        "div_count": div_count,
        "mod_count": mod_count,
        "branch_count": branch_count,
        "has_disjunction": has_disjunction,
        "has_synchronization_counter": synchronization,
        "has_monotone_variable": monotone,
        "has_constant_initial_bound": constant_initial_count > 0,
        "has_conservation_hint": conservation_hint,
        "precondition_clause_count": pre_clauses,
        "transition_branch_count": transition_branches,
        "postcondition_clause_count": post_clauses,
        "precondition_ast_size": _ast_size(precondition),
        "guard_ast_size": _ast_size(guard),
        "transition_ast_size": (
            _ast_size(transition)
            if transition is not None
            else sum(_ast_size(value) for value in updates.values())
        ),
        "postcondition_ast_size": _ast_size(vc_postcondition),
        "estimated_vc_query_count": 3 if vc_postcondition is not None else 0,
        "estimated_postcondition_query_count": post_clauses,
        "availability": {
            "c_analysis": bool(variables),
            "vc_analysis": vc is not None,
            "update_analysis": update_available,
            "postcondition_analysis": vc_postcondition is not None,
        },
    }


def _number(value, default=0.0):
    if value is None:
        return float(default)
    try:
        result = float(value)
    except (TypeError, ValueError):
        return float(default)
    return result if math.isfinite(result) else float(default)


def _signed_log1p(value):
    value = _number(value)
    return math.copysign(math.log1p(abs(value)), value)


_PROGRAM_LOG_FEATURES = {
    "base_variable_count",
    "ssa_auxiliary_variable_count",
    "update_count",
    "mutated_variable_count",
    "constant_additive_update_count",
    "affine_update_count",
    "variable_multiplication_update_count",
    "div_count",
    "mod_count",
    "branch_count",
    "precondition_clause_count",
    "transition_branch_count",
    "postcondition_clause_count",
    "precondition_ast_size",
    "guard_ast_size",
    "transition_ast_size",
    "postcondition_ast_size",
    "estimated_vc_query_count",
    "estimated_postcondition_query_count",
    "distinct_counterexample_count",
    "repeat_counterexample_count",
    "current_degree",
    "current_clauses",
    "current_candidate_count",
    "verified_candidate_count",
}
_MONOMIAL_LOG_FEATURES = {
    "degree", "variables_used", "max_exponent",
    "historical_monomial_occurrence_count",
}
_CANDIDATE_LOG_FEATURES = {
    "heuristic_score",
    "degree",
    "clauses",
    "monomial_count",
    "coefficient_bound",
    "candidate_ast_size",
    "estimated_query_size",
    "mechanism_history_success",
    "mechanism_history_failure",
    "mechanism_history_timeout",
}


def program_feature_vector(group):
    """Build the 55-vector using only context and search-state allowlists."""
    context = group.get("program_context")
    if not isinstance(context, dict):
        raise ValueError("candidate group is missing program_context")
    if context.get("feature_schema_version") != FEATURE_SCHEMA_VERSION:
        raise ValueError("candidate group feature schema is incompatible")
    state = group.get("search_state") or {}
    guard_type = context.get("guard_type", "missing")
    if guard_type not in GUARD_TYPES:
        guard_type = "other"
    comparisons = context.get("comparison_counts") or {}
    failure_set = set(state.get("failure_set") or ())
    current_failure = state.get("current_failure_type")
    if current_failure in FAILURE_TYPES:
        failure_set.add(current_failure)
    availability = context.get("availability") or {}
    coefficient = _number(state.get("coefficient_bound"))
    values = {
        **{
            name: context.get(name, 0.0)
            for name in PROGRAM_FEATURE_NAMES
        },
        **{"guard_type_" + name: name == guard_type for name in GUARD_TYPES},
        **{
            "comparison_count_" + name: comparisons.get(name, 0)
            for name in COMPARISON_TYPES
        },
        **{
            "failure_set_" + name.lower(): name in failure_set
            for name in FAILURE_TYPES
        },
        "distinct_counterexample_count": state.get(
            "distinct_counterexamples", 0
        ),
        "repeat_counterexample_count": state.get(
            "repeat_counterexamples", 0
        ),
        "elapsed_time_ratio": max(
            0.0, min(1.0, _number(state.get("elapsed_time_ratio")))
        ),
        "current_degree": state.get("degree", 0),
        "current_clauses": state.get("clauses", 0),
        "current_log1p_coefficient_bound": math.log1p(
            max(0.0, coefficient)
        ),
        "current_candidate_count": state.get(
            "current_candidate_count", 0
        ),
        "verified_candidate_count": state.get(
            "verified_candidate_count", 0
        ),
        "c_analysis_available": availability.get("c_analysis", False),
        "vc_analysis_available": availability.get("vc_analysis", False),
        "update_analysis_available": availability.get(
            "update_analysis", False
        ),
        "postcondition_analysis_available": availability.get(
            "postcondition_analysis", False
        ),
    }
    return [
        _signed_log1p(values[name])
        if name in _PROGRAM_LOG_FEATURES
        else _number(values[name])
        for name in PROGRAM_FEATURE_NAMES
    ]


def monomial_feature_vector(record):
    values = {
        "degree": record.get("degree", 0),
        "variables_used": record.get("variables_used", 0),
        "max_exponent": record.get("max_exponent", 0),
        "is_constant": record.get("is_constant", False),
        "is_linear": record.get("is_linear", False),
        "is_square": record.get("is_square", False),
        "is_high_power": record.get("is_high_power", False),
        "is_cross_term": record.get("is_cross_term", False),
        "has_guard_role": record.get("has_guard_role", False),
        "has_mutated_role": record.get("has_mutated_role", False),
        "has_monotone_role": record.get("has_monotone_role", False),
        "has_postcondition_role": record.get(
            "has_postcondition_role", False
        ),
        "has_synchronization_counter_role": record.get(
            "has_synchronization_counter_role", False
        ),
        "from_update_closure": record.get("from_update_closure", False),
        "from_counterexample_repair": record.get(
            "from_counterexample_repair", False
        ),
        "from_postcondition_seed": record.get(
            "from_postcondition_seed", False
        ),
        "historical_monomial_occurrence_count": record.get(
            "occurrence_count", 0
        ),
        "current_counterexample_relevance": record.get(
            "current_counterexample_relevance",
            record.get("from_counterexample_repair", False),
        ),
        "has_accumulator_role": record.get("has_accumulator_role", False),
        "has_initialized_constant_role": record.get(
            "has_initialized_constant_role", False
        ),
    }
    return [
        _signed_log1p(values[name])
        if name in _MONOMIAL_LOG_FEATURES
        else _number(values[name])
        for name in MONOMIAL_FEATURE_NAMES
    ]


def candidate_feature_vector(candidate):
    monomials = candidate.get("structural_monomials") or ()
    flags = candidate.get("flags") or {}
    history = candidate.get("mechanism_history") or {}
    values = {
        "heuristic_score": candidate.get("heuristic_score", 0),
        "degree": candidate.get("degree", 0),
        "clauses": candidate.get("clauses", 0),
        "monomial_count": candidate.get("monomial_count", len(monomials)),
        "coefficient_bound": candidate.get("coefficient_bound", 0),
        "candidate_ast_size": candidate.get("candidate_ast_size", 0),
        "estimated_query_size": candidate.get("estimated_query_size", 0),
        "contains_guard_role": any(
            item.get("has_guard_role", False) for item in monomials
        ),
        "contains_postcondition_role": any(
            item.get("has_postcondition_role", False) for item in monomials
        ),
        "responds_to_current_counterexample": flags.get(
            "counterexample_repair", False
        ),
        "is_repeated_candidate": (
            _number(candidate.get("historical_candidate_occurrences")) > 0
        ),
        "specialized_frontend": flags.get("specialized_frontend", False),
        "linear_fast_path": flags.get("linear_fast_path", False),
        "spacer": flags.get("spacer", False),
        "fallback": flags.get("fallback", False),
        "mechanism_history_success": history.get("success", 0),
        "mechanism_history_failure": history.get("failure", 0),
        "mechanism_history_timeout": history.get("timeout", 0),
        "coefficient_bound_available": candidate.get(
            "coefficient_bound_available", False
        ),
    }
    return [
        _signed_log1p(values[name])
        if name in _CANDIDATE_LOG_FEATURES
        else _number(values[name])
        for name in CANDIDATE_FEATURE_NAMES
    ]


def canonical_mechanism(value):
    value = str(value or "").split("+", 1)[0]
    if value in MECHANISM_VOCAB:
        return value
    prefixes = (
        "typed-counter-accumulator",
        "typed-guard-split",
        "typed-post-weakening",
        "typed-disjunctive-post",
        "typed-divmod",
        "typed-term-dropping",
        "fallback",
    )
    for prefix in prefixes:
        if value.startswith(prefix):
            return prefix
    return "unknown"


def mechanism_index(value):
    return MECHANISM_VOCAB.index(canonical_mechanism(value))


def relation_index(value):
    value = str(value or "unknown")
    return RELATION_VOCAB.index(
        value if value in RELATION_VOCAB else "unknown"
    )


def feature_contract():
    """Serializable schema record used by reports and checkpoints."""
    return {
        **_schema_payload(),
        "schema_hash": FEATURE_SCHEMA_HASH,
        "dimensions": {
            "program": PROGRAM_DIM,
            "monomial": MONOMIAL_DIM,
            "candidate": CANDIDATE_DIM,
        },
        "forbidden_inputs": (
            "program_id",
            "task_id",
            "source_task_id",
            "dataset",
            "path",
            "program_content_hash",
            "candidate_hash",
            "variable_name",
            "variable_position",
        ),
    }
