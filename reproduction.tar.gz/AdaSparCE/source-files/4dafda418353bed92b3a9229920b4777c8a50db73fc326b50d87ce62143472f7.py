"""Author cvc5 1.3.4, default SyGuS grammar; exact raw-VC constraints."""
from pathlib import Path
import time

from .common import to_sygus, solution_body, printed_invariant


def run(request):
    import cvc5
    if cvc5.__version__ != '1.3.4':
        raise RuntimeError('the frozen adapter requires cvc5 1.3.4')
    text = Path(request['vc']).read_text()
    converted, parameters = to_sygus(text)
    Path(request['workdir'], 'input.sy').write_text(converted)
    solver = cvc5.Solver()
    solver.setOption('sygus', 'true')
    solver.setOption('incremental', 'false')
    solver.setOption('seed', str(request['seed']))
    # The parent enforces the absolute 30-second process deadline, charging
    # imports and conversion. This internal limit is only an extra guard.
    remaining = max(1, int(1000 * (request['deadline_monotonic'] - time.monotonic() - .02)))
    solver.setOption('tlimit', str(remaining))
    parser = cvc5.InputParser(solver)
    parser.setStringInput(cvc5.InputLanguage.SYGUS_2_1, converted, 'original-VC-constraints')
    output = ''
    while not parser.done():
        command = parser.nextCommand()
        if command.isNull():
            break
        output += command.invoke(solver, parser.getSymbolManager())
    Path(request['workdir'], 'synthesis-output.smt2').write_text(output)
    body = solution_body(output, parameters)
    if body is None:
        return dict(status='unknown', reason='cvc5 returned no synthesis solution')
    return dict(status='solved', invariant=printed_invariant(body, parameters), invariant_smt2=body,
                reason='cvc5-default-sygus', acceptance='cvc5 synthesis of all original VC constraints')
