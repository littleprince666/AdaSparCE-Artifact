"""Partial-lemma trials and proof-guided clause composition phase."""

import time
from SMT_Solver.SMT_verifier import CheckFailureType
from SparCE.feedback.clause_composer import ProofGuidedClauseComposer
from SparCE.logging_utils import stable_hash
from SparCE.symbolic.candidate import CandidateBranch


class CompositionSearch:
    """Partial-lemma trials and proof-guided clause composition phase."""

    def _run_lemma_trials_hook(self, state, result, branch):
        """Shared hook for the three VC check sites."""
        if state.lemma_tracker is None or result is None:
            return None, 0
        if state.clause_bank is not None:
            if result.failure_type not in (
                CheckFailureType.EXIT,
                CheckFailureType.STEP,
                CheckFailureType.INIT,
            ):
                return None, 0
            conjunctions = state.clause_bank.note_result(branch, result)
        else:
            if result.failure_type not in (
                CheckFailureType.EXIT,
                CheckFailureType.STEP,
            ):
                return None, 0
            conjunctions = state.lemma_tracker.note(
                branch.formula, branch.score, result.failure_type
            )
        if not conjunctions:
            return None, 0
        if state.scheduler is not None:
            for conjunction in conjunctions:
                state.pending_conjunctions.append(
                    (conjunction, branch.degree, branch.clauses)
                )
            return None, 0
        return self._run_conjunction_trials(
            state.lemma_tracker,
            conjunctions,
            state.verifier,
            state.smt_path,
            state.program_id,
            state.started,
            state.checked,
            branch.degree,
            branch.clauses,
            state.analyzer,
        )

    def _note_stagnation_progress(self, state, result):
        """A check makes progress when it produces a new
        counterexample; failure-type switches alone do not."""
        progressed = False
        if result.counterexample is not None:
            signature = stable_hash(result.counterexample)
            if signature not in state.stagnation_signatures:
                state.stagnation_signatures.add(signature)
                progressed = True
        state.stagnation_last_failure = result.failure_type
        state.stagnation_counter = (
            0 if progressed else state.stagnation_counter + 1
        )

    def _run_clause_composer_phase(self, state):
        """Clause-composer generation and check loop (legacy path)."""
        if (
            self.config.clause_composer_enabled
            and not state.stagnation_exit
            and state.scheduler is None
        ):
            generation_started = time.perf_counter()
            generation_budget = (
                state.typed_phase_budget
                * self.config.clause_composer_generation_budget_ratio
            )
            generation_deadline = min(
                state.started + state.typed_phase_budget,
                generation_started + generation_budget,
            )
            state.clause_composer = ProofGuidedClauseComposer(
                max_bank_size=self.config.clause_composer_bank_size,
                max_ast_size=self.config.clause_composer_max_ast_size,
                max_clauses=self.config.max_clauses,
                max_total_proposals=(
                    self.config.clause_composer_max_proposals
                ),
            )
            for candidate in state.composition_bank_branches:
                if time.perf_counter() >= generation_deadline:
                    break
                state.clause_composer.ingest(
                    candidate.formula,
                    score=candidate.score,
                    mechanism=candidate.mechanism,
                    degree=candidate.degree,
                    clauses=candidate.clauses,
                    monomials=candidate.monomials,
                )
            if state.clause_bank is not None:
                for entry in state.clause_bank.entries():
                    if time.perf_counter() >= generation_deadline:
                        break
                    state.clause_composer.ingest(
                        entry.formula,
                        score=entry.score,
                        mechanism=entry.mechanism,
                        degree=entry.degree,
                        clauses=entry.clauses,
                        monomials=entry.monomials,
                    )
                    if entry.outcome in ("INIT", "STEP", "EXIT"):
                        state.clause_composer.observe(
                            entry.formula, entry.outcome
                        )
            for source_branch, source_result in state.composition_observations:
                state.clause_composer.observe(
                    source_branch.formula, source_result.failure_type
                )
            self.logger.write({
                "event": "clause_composer_initialized",
                "program_id": state.program_id,
                "bank_size": state.clause_composer.bank_size,
                "max_bank_size": (
                    self.config.clause_composer_bank_size
                ),
                "max_ast_size": (
                    self.config.clause_composer_max_ast_size
                ),
                "max_clauses": self.config.max_clauses,
                "max_total_proposals": (
                    self.config.clause_composer_max_proposals
                ),
            })
            observation_priority = {
                CheckFailureType.EXIT: 3,
                CheckFailureType.STEP: 2,
                CheckFailureType.INIT: 1,
            }
            ordered_observations = sorted(
                state.composition_observations,
                key=lambda item: (
                    observation_priority.get(
                        item[1].failure_type, 0
                    ),
                    item[0].score,
                ),
                reverse=True,
            )
            # Round-robin over failed source candidates.  Taking four
            # repairs from the first few failures filled the bounded
            # budget before later EXIT candidates were ever considered.
            for _ in range(self.config.clause_composer_per_failure):
                for source_branch, source_result in ordered_observations:
                    if (
                        state.clause_composer.emitted_count
                        >= self.config.clause_composer_max_proposals
                        or time.perf_counter() >= generation_deadline
                    ):
                        break
                    composed = state.clause_composer.propose(
                        source_branch.formula,
                        score=source_branch.score,
                        mechanism=source_branch.mechanism,
                        degree=source_branch.degree,
                        clauses=source_branch.clauses,
                        monomials=source_branch.monomials,
                        failure_type=source_result.failure_type,
                        counterexample=source_result.counterexample,
                        max_results=1,
                    )
                    for proposal in composed:
                        if (
                            proposal.key in state.active_keys
                        ):
                            continue
                        candidate = CandidateBranch(
                            proposal.formula,
                            proposal.score,
                            proposal.mechanism,
                            proposal.degree,
                            proposal.clauses,
                            proposal.monomials,
                        )
                        state.active_keys.add(proposal.key)
                        state.composition_branches.append(candidate)
                if (
                    state.clause_composer.emitted_count
                    >= self.config.clause_composer_max_proposals
                    or time.perf_counter() >= generation_deadline
                ):
                    break
            self.logger.write({
                "event": "clause_composer_proposals",
                "program_id": state.program_id,
                "observation_count": len(state.composition_observations),
                "added_count": len(state.composition_branches),
                "bank_size": state.clause_composer.bank_size,
                "emitted_count": state.clause_composer.emitted_count,
                "generation_time_seconds": (
                    time.perf_counter() - generation_started
                ),
                "generation_budget_seconds": generation_budget,
            })
        if (
            state.clause_composer is not None
            and state.composition_branches
            and state.scheduler is None
        ):
            self.logger.write({
                "event": "clause_composer_phase",
                "program_id": state.program_id,
                "candidate_count": len(state.composition_branches),
                "checked_before_phase": state.checked,
            })
            composition_remaining = list(state.composition_branches)
            composition_rank = 0
            while (
                composition_remaining
                and time.perf_counter() - state.started < state.typed_phase_budget
                and not self._checker_budget_exhausted(state.checked)
            ):
                branch = max(
                    composition_remaining,
                    key=lambda candidate: candidate.score,
                )
                composition_remaining.remove(branch)
                composition_rank += 1
                result = self._check_branch(
                    state.verifier,
                    branch,
                    state.smt_path,
                    state.program_id,
                    composition_rank,
                    state.analyzer,
                )
                if result is None:
                    continue
                state.checked += 1
                state.checked_mechanisms.add(branch.mechanism)
                self._note_stagnation_progress(state, result)
                self._mechanism_prioritizer.update(
                    branch.mechanism,
                    result.failure_type.value,
                )
                if result.failure_type == CheckFailureType.SUCCESS:
                    return self._success(
                        state.program_id, branch, state.started, state.checked
                    )
                state.failure_type = result.failure_type
                state.failure_counts[state.failure_type] += 1
                trial_branch, trial_delta = self._run_lemma_trials_hook(state, 
                    result, branch
                )
                if trial_branch is not None:
                    state.checked += trial_delta
                    return self._success(
                        state.program_id, trial_branch, state.started, state.checked
                    )
                state.checked += trial_delta
                state.clause_composer.observe(
                    branch.formula, result.failure_type
                )
                chained = state.clause_composer.propose(
                    branch.formula,
                    score=branch.score,
                    mechanism=branch.mechanism,
                    degree=branch.degree,
                    clauses=branch.clauses,
                    monomials=branch.monomials,
                    failure_type=result.failure_type,
                    counterexample=result.counterexample,
                    max_results=(
                        self.config.clause_composer_per_failure
                    ),
                )
                for proposal in chained:
                    if proposal.key in state.active_keys:
                        continue
                    candidate = CandidateBranch(
                        proposal.formula,
                        proposal.score,
                        proposal.mechanism,
                        proposal.degree,
                        proposal.clauses,
                        proposal.monomials,
                    )
                    state.active_keys.add(proposal.key)
                    composition_remaining.append(candidate)
                    state.clause_composer.ingest(
                        candidate.formula,
                        score=candidate.score,
                        mechanism=candidate.mechanism,
                        degree=candidate.degree,
                        clauses=candidate.clauses,
                        monomials=candidate.monomials,
                    )
