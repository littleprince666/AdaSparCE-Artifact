"""Audited OpenAI transport for unchanged author pipelines.

No connection is made by importing this module. The conservative accounting
ledger reserves a complete model context at the larger token price before
every HTTP attempt, and never releases that reservation after an interruption.
It is a spending ceiling under the explicitly supplied tariff/context bound,
not a promise about a provider's invoice.
"""
from __future__ import annotations

from decimal import Decimal
import hashlib
import json
import os
from pathlib import Path
import time
from urllib.parse import urlsplit


class OnlineAuthorizationError(ValueError):
    pass


class OnlineBudgetExhausted(BaseException):
    """Deliberately bypass the author's catch-Exception retry loop."""


class OnlineTaskDeadline(BaseException):
    """One task timed out; this must not halt the entire monetary study."""


def validate_config(config):
    required = {'schema', 'authorize_fresh_online_requests', 'method', 'model',
                'endpoint', 'api_key_env', 'currency', 'max_total_cost_usd',
                'input_usd_per_million', 'output_usd_per_million',
                'max_context_tokens', 'max_requests', 'model_policy', 'budget_scope'}
    if set(config) != required:
        raise OnlineAuthorizationError('configuration keys differ: ' + str(sorted(set(config) ^ required)))
    if config['schema'] != 'adasparce.online-authorization.v1' or config['authorize_fresh_online_requests'] is not True:
        raise OnlineAuthorizationError('explicit fresh online request authorization required')
    if config['method'] != 'clause2inv':
        raise OnlineAuthorizationError('only the pinned Clause2Inv artifact is currently installed; LimICE author artifact required')
    if config['budget_scope'] != 'this-frozen-dataset-study':
        raise OnlineAuthorizationError('explicit per-study budget scope required; allocate total user budget across all dataset/preflight/secondary studies')
    if config['currency'] != 'USD' or config['model_policy'] not in ('author-default', 'explicit-model-substitution'):
        raise OnlineAuthorizationError('unsupported currency or model policy')
    if config['model_policy'] == 'author-default' and config['model'] != 'gpt-4o-mini':
        raise OnlineAuthorizationError('author-default model must be gpt-4o-mini')
    if not isinstance(config['model'], str) or not config['model'].strip():
        raise OnlineAuthorizationError('nonempty explicit model required')
    url = urlsplit(config['endpoint'])
    if url.scheme != 'https' or not url.netloc or url.username or url.password or url.query or url.fragment:
        raise OnlineAuthorizationError('endpoint must be HTTPS without credentials/query/fragment')
    if not isinstance(config['api_key_env'], str) or not config['api_key_env'].isidentifier():
        raise OnlineAuthorizationError('api_key_env must name an environment variable, never contain its value')
    for name in ('max_total_cost_usd', 'input_usd_per_million', 'output_usd_per_million'):
        try:
            value = Decimal(str(config[name]))
        except Exception as error:
            raise OnlineAuthorizationError('invalid decimal: '+name) from error
        if not value.is_finite() or value <= 0:
            raise OnlineAuthorizationError('positive finite amount required: '+name)
    for name in ('max_context_tokens', 'max_requests'):
        if type(config[name]) is not int or config[name] <= 0:
            raise OnlineAuthorizationError('positive integer required: '+name)
    return config


def reservation_usd(config):
    """All prompt and completion tokens fit within the supplied context bound."""
    validate_config(config)
    price = max(Decimal(str(config['input_usd_per_million'])),
                Decimal(str(config['output_usd_per_million'])))
    return Decimal(config['max_context_tokens']) * price / Decimal(1_000_000)


def append_event(path, event):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a') as stream:
        stream.write(json.dumps(event, ensure_ascii=False, sort_keys=True)+'\n')
        stream.flush()
        os.fsync(stream.fileno())


def read_events(path):
    path = Path(path)
    return [json.loads(line) for line in path.read_text().splitlines()] if path.exists() else []


def complete_usage(prompt, completion, total):
    return (all(type(value) is int and value>=0 for value in (prompt,completion,total))
            and total==prompt+completion)


def ledger_state(config, events):
    """Known tariff charges plus unreleased reservations bound study exposure."""
    amount=reservation_usd(config);reservations=[];settled={};ceiling=Decimal(0)
    for event in events:
        if event.get('event')=='reserve':
            if event.get('request_index')!=len(reservations) or Decimal(event['reserved_usd'])!=amount:
                raise ValueError('cost reservation sequence or amount differs')
            ceiling+=amount
            if Decimal(event['committed_ceiling_usd'])!=ceiling:
                raise ValueError('cost ledger cumulative ceiling differs')
            reservations.append(event)
        elif event.get('event')=='settle':
            index=event.get('request_index');cost=Decimal(event['tariff_cost_usd'])
            if type(index) is not int or not 0<=index<len(reservations) or index in settled or not cost.is_finite() or not 0<=cost<=amount:
                raise ValueError('invalid or duplicate reservation settlement')
            settled[index]=cost;ceiling-=amount-cost
            if Decimal(event['committed_ceiling_usd'])!=ceiling:
                raise ValueError('settlement cumulative ceiling differs')
        else:raise ValueError('unknown cost ledger event')
        if ceiling>Decimal(str(config['max_total_cost_usd'])):
            raise ValueError('authorized committed ceiling exceeded')
    return dict(reservations=reservations,settled=settled,committed_ceiling=ceiling)


def reserve(config, ledger, identity):
    """Lock the shared study ledger, then durably reserve before any request."""
    import fcntl
    ledger = Path(ledger)
    ledger.parent.mkdir(parents=True, exist_ok=True)
    with ledger.with_suffix('.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        state=ledger_state(config,read_events(ledger));prior=state['reservations']
        reserved=state['committed_ceiling']
        amount = reservation_usd(config)
        if len(prior) >= config['max_requests'] or reserved + amount > Decimal(str(config['max_total_cost_usd'])):
            raise OnlineBudgetExhausted('study request/spending reservation ceiling reached')
        event = dict(event='reserve', request_index=len(prior), identity=identity,
                     reserved_usd=str(amount), committed_ceiling_usd=str(reserved+amount))
        append_event(ledger, event)
        return event


def settle(config, ledger, request_index, tariff_cost):
    """Release only a response with complete usage and a bounded known tariff."""
    import fcntl
    ledger=Path(ledger)
    with ledger.with_suffix('.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        state=ledger_state(config,read_events(ledger));cost=Decimal(tariff_cost)
        if (request_index in state['settled'] or not 0<=request_index<len(state['reservations']) or
                not cost.is_finite() or not 0<=cost<=reservation_usd(config)):
            raise OnlineBudgetExhausted('invalid usage settlement; reservation retained')
        ceiling=state['committed_ceiling']-reservation_usd(config)+cost
        append_event(ledger,dict(event='settle',request_index=request_index,
                               tariff_cost_usd=str(cost),committed_ceiling_usd=str(ceiling)))


def install_transport(config, ledger, journal, identity, deadline_monotonic):
    """Replace only SDK construction; preserve author prompts and search code."""
    validate_config(config)
    import openai
    original = openai.OpenAI
    credential = os.environ.get(config['api_key_env'])
    if not credential:
        raise OnlineAuthorizationError('credential environment variable absent; no request attempted')

    class AuditedCompletions:
        def create(self, **kwargs):
            if kwargs.get('model') != 'gpt-4o-mini' or kwargs.get('n') != 1:
                raise OnlineAuthorizationError('pinned author model/sample call differs from expected interface')
            if config['model_policy'] == 'explicit-model-substitution':
                kwargs['model'] = config['model']
            remaining = deadline_monotonic-time.monotonic()
            if remaining <= 0:
                raise OnlineTaskDeadline('cold task deadline reached before API request')
            event = reserve(config, ledger, identity)
            payload = json.dumps(kwargs, ensure_ascii=False, sort_keys=True).encode()
            append_event(journal, dict(event='request', request_index=event['request_index'],
                request_sha256=hashlib.sha256(payload).hexdigest(), model=kwargs['model'],
                temperature=kwargs.get('temperature'), max_tokens=kwargs.get('max_tokens'),
                n=kwargs.get('n'), sdk_max_retries=0, reserved_usd=event['reserved_usd'],
                started_monotonic=time.monotonic(),
                started_utc=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat()))
            started = time.monotonic()
            # SDK retries are disabled so every potentially billed attempt is
            # visible. The author's original five-attempt loop remains intact.
            try:
                with original(api_key=credential, base_url=config['endpoint'], max_retries=0,
                              timeout=max(.001, remaining)) as client:
                    response = client.chat.completions.create(**kwargs)
            except Exception as error:
                append_event(journal, dict(event='request-error', request_index=event['request_index'],
                    seconds=time.monotonic()-started, error_type=type(error).__name__,
                    billed_usage='unknown; conservative reservation retained'))
                # The author prints caught errors; never allow HTTP exception
                # strings, headers, or credential-bearing endpoints into logs.
                raise RuntimeError('online transport failed; sanitized metadata recorded') from None
            usage = getattr(response, 'usage', None)
            prompt = getattr(usage, 'prompt_tokens', None)
            completion = getattr(usage, 'completion_tokens', None)
            total = getattr(usage, 'total_tokens', None)
            actual = None
            if type(prompt) is int and type(completion) is int and prompt>=0 and completion>=0:
                actual = (Decimal(prompt)*Decimal(str(config['input_usd_per_million'])) +
                          Decimal(completion)*Decimal(str(config['output_usd_per_million'])))/Decimal(1_000_000)
            append_event(journal, dict(event='response', request_index=event['request_index'],
                seconds=time.monotonic()-started, provider_response_id=getattr(response,'id',None),
                requested_model=kwargs['model'], returned_model=getattr(response,'model',None),
                prompt_tokens=prompt, completion_tokens=completion, total_tokens=total,
                estimated_tariff_cost_usd=str(actual) if actual is not None else None,
                content_sha256=hashlib.sha256((response.choices[0].message.content or '').encode()).hexdigest(),
                finish_reason=response.choices[0].finish_reason))
            if total is not None and (type(total) is not int or total > config['max_context_tokens']):
                raise OnlineBudgetExhausted('provider usage exceeded authorized context assumption; stop study')
            if actual is not None and actual > Decimal(event['reserved_usd']):
                raise OnlineBudgetExhausted('provider tariff estimate exceeded reservation; stop study')
            if actual is not None and complete_usage(prompt,completion,total):
                settle(config,ledger,event['request_index'],actual)
            return response

    class AuditedClient:
        def __init__(self, *args, **kwargs):
            if args or kwargs:
                raise OnlineAuthorizationError('author SDK constructor unexpectedly changed')
            from types import SimpleNamespace
            self.chat = SimpleNamespace(completions=AuditedCompletions())

    openai.OpenAI = AuditedClient
    return original
