"""Auditable adapters for independently obtained external tools."""
