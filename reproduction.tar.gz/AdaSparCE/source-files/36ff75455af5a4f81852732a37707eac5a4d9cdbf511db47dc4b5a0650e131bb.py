import hashlib
import re
import threading
import time
from dataclasses import dataclass
from enum import Enum

import z3
from SMT_Solver.Config import config

# Portfolio parallelism makes QF_NIA outcomes and runtimes highly variable
# across otherwise identical cold runs.  AdaSparCE uses an explicit,
# deterministic solver portfolio below, so keep each member single-threaded.
z3.set_param('parallel.enable', False)


def _is_linear_candidate(expr):
    """Check whether a z3 expression contains only linear arithmetic
    (no multiplication of two or more variables)."""
    try:
        return _expr_degree(expr) <= 1
    except Exception:
        return False


def expr_degree(expr):
    """Return the syntactic polynomial degree of a z3 expression."""
    if z3.is_true(expr) or z3.is_false(expr):
        return 0
    if z3.is_int_value(expr):
        return 0
    if z3.is_const(expr) and expr.num_args() == 0:
        return 1 if expr.sort().kind() != z3.Z3_BOOL_SORT else 0
    kind = expr.decl().kind()
    child_degrees = [expr_degree(c) for c in expr.children()]
    if kind == z3.Z3_OP_MUL:
        return sum(child_degrees)
    if kind == z3.Z3_OP_POWER:
        children = expr.children()
        if len(children) == 2 and z3.is_int_value(children[1]):
            return expr_degree(children[0]) * children[1].as_long()
        return 99
    if kind in (z3.Z3_OP_DIV, z3.Z3_OP_IDIV, z3.Z3_OP_MOD, z3.Z3_OP_REM):
        return 99
    return max(child_degrees, default=0)


# Backward-compatible alias: this degree function is shared with the
# SparCE engine (AdaSparCEEngine._z3_degree delegates here).
_expr_degree = expr_degree


class Counterexample:
    def __init__(self, kind="?", assignment=None):
        self.kind = kind
        self.assignment = {} if assignment is None else assignment


class CheckFailureType(Enum):
    INIT = "INIT"
    STEP = "STEP"
    EXIT = "EXIT"
    TIMEOUT = "TIMEOUT"
    UNKNOWN = "UNKNOWN"
    SUCCESS = "SUCCESS"


@dataclass
class CheckResult:
    status: str
    failure_type: CheckFailureType
    counterexample: object
    solver_time: float
    solver_name: str
    query_size: int
    candidate_hash: str
    raw_solver_status: str
    vc_results: tuple = ()


class SMT_verifier:
    def __init__(self):
        self.tpl = []
        self.state_variables = None
        # Optional absolute wall-clock deadline in time.perf_counter()
        # seconds, set once per task by the engine.  When set, every
        # solver/tactic call inside check() is clamped to the remaining
        # wall budget, so one candidate check (3 VCs x portfolio
        # retries, each otherwise entitled to the full per-call
        # timeout) cannot push the task past its program budget.
        # None keeps the historical behaviour (per-call timeout only).
        self.wall_deadline = None

    def _wall_remaining(self):
        if self.wall_deadline is None:
            return None
        return self.wall_deadline - time.perf_counter()

    def _clamp_timeout(self, requested_seconds):
        """Cap a per-call timeout at the remaining wall budget.

        A small floor keeps Z3 from seeing a zero/negative millisecond
        timeout (which it treats as 'no limit'), bounding the total
        overshoot of a check to well under a second.
        """
        remaining = self._wall_remaining()
        if remaining is None:
            return max(0.001, float(requested_seconds))
        return max(0.05, min(float(requested_seconds), remaining))

    @staticmethod
    def _check_with_watchdog(solver, timeout_seconds):
        """Interrupt a non-cooperative Z3 call without moving it off-thread."""
        interrupted = threading.Event()

        def interrupt():
            interrupted.set()
            solver.ctx.interrupt()

        timer = threading.Timer(max(0.001, timeout_seconds), interrupt)
        timer.daemon = True
        timer.start()
        try:
            result = solver.check()
        finally:
            timer.cancel()
            # Joining prevents a late watchdog from interrupting the next
            # query in the same Z3 context.
            timer.join()
        return result, interrupted.is_set()

    def initTpl(self, path2SMT):
        vc_sections = [""]
        with open(path2SMT, 'r') as vc:
            for vc_line in vc.readlines():
                if "SPLIT_HERE_asdfghjklzxcvbnmqwertyuiop" in vc_line:
                    vc_sections.append("")
                else:
                    vc_sections[-1] += vc_line
        assert len(vc_sections) == 5

        self.tpl = [vc_sections[0]]
        interface = re.search(
            r"\(\s*define-fun\s+inv-f\s*\((.*?)\)\s*Bool",
            vc_sections[0], re.DOTALL,
        )
        if interface is None:
            raise ValueError("missing invariant state interface")
        self.state_variables = frozenset(re.findall(
            r"\(\s*([^\s()]+)\s+(?:Int|Real|Bool)\s*\)", interface.group(1)
        ))

        for i in range(2, 5):
            self.tpl.append(vc_sections[1] + vc_sections[i])

    @staticmethod
    def _extract_counterexample(model, query_index, state_variables=None):
        # Select the declared state interface, not a naming heuristic: names
        # such as prev_guess (and even x_1) may be real program variables.
        def is_state(symbol, name):
            return (symbol.arity() == 0 and
                    (state_variables is None or name in state_variables))

        if query_index == 0 or query_index == 2:
            assignment = {}
            for symbol in model:
                name = str(symbol)
                if not is_state(symbol, name):
                    continue
                assignment[name] = model[symbol]
            return assignment

        before, after = {}, {}
        for symbol in model:
            name = str(symbol)
            base_name = name[:-1] if name.endswith("!") else name
            if not is_state(symbol, base_name):
                continue
            value = model[symbol]
            if name.endswith("!"):
                after[name[:-1]] = value
            else:
                before[name] = value
        return before, after

    def check(self, Can_I, path2SMT, normalize_polynomials=False,
              timeout_seconds=None):
        # Per-call timeout: the engine threads its (possibly escalated or
        # scheduler-tiered) checker budget through this parameter instead
        # of mutating the process-global config between calls.  ``None``
        # keeps the config default (set once per task by the engine).
        check_time = (
            config.SMT_CHECK_TIME
            if timeout_seconds is None
            else float(timeout_seconds)
        )
        sol = z3.Solver()
        sol.set(auto_config=False)
        sol.set("random_seed", 0)

        if len(self.tpl) <= 0:
            self.initTpl(path2SMT)

        Can_I_smt = \
            z3.Z3_benchmark_to_smtlib_string(Can_I.ctx_ref(), "benchmark", "NIA", "unknown", "", 0, (z3.Ast * 0)() , Can_I.as_ast())
        Can_I_smt = Can_I_smt.split('(assert\n')[-1].split('(check-sat)')[0][:-2]
        candidate_hash = hashlib.sha256(str(Can_I).encode("utf-8")).hexdigest()
        total_time = 0.0
        total_query_size = 0
        used_portfolio = False
        used_polynomial_normalization = False
        used_tactic = False
        vc_results = []
        failure_types = (
            CheckFailureType.INIT,
            CheckFailureType.STEP,
            CheckFailureType.EXIT,
        )
        is_linear_inv = _is_linear_candidate(Can_I)
        for i in range(3):
            s = self.tpl[0] + Can_I_smt + self.tpl[i + 1]  # wait to see
            total_query_size += len(s)
            query_normalization_time = 0.0
            query_solver_name = "z3"
            query_used_portfolio = False
            query_used_tactic = False
            query_used_polynomial_normalization = False
            sol.reset()
            try:
                decl = z3.parse_smt2_string(s)
            except Exception as exc:
                # Candidate formulas are untrusted synthesis output.  A
                # malformed SMT fragment must be treated as an UNKNOWN
                # candidate, not crash the experiment worker and invalidate
                # an otherwise complete batch.
                parse_reason = "parse-error:" + str(exc).splitlines()[-1][:240]
                vc_results.append({
                    "vc": failure_types[i].value,
                    "status": "unknown",
                    "failure_type": CheckFailureType.UNKNOWN.value,
                    "solver_time_seconds": 0.0,
                    "normalization_time_seconds": 0.0,
                    "query_size": len(s),
                    "solver_name": "z3-parse",
                    "portfolio_used": False,
                    "tactic_used": False,
                    "polynomial_normalization_used": False,
                    "watchdog_interrupted": False,
                    "raw_solver_status": parse_reason,
                })
                return CheckResult(
                    status="unknown",
                    failure_type=CheckFailureType.UNKNOWN,
                    counterexample=None,
                    solver_time=total_time,
                    solver_name="z3-parse",
                    query_size=total_query_size,
                    candidate_hash=candidate_hash,
                    raw_solver_status=parse_reason,
                    vc_results=tuple(vc_results),
                )
            if normalize_polynomials:
                normalization_started = time.perf_counter()
                polynomial_simplifier = z3.With(
                    z3.Tactic("simplify"),
                    som=True,
                    sort_sums=True,
                )
                normalized = z3.Then(
                    polynomial_simplifier,
                    z3.Tactic("solve-eqs"),
                    polynomial_simplifier,
                    z3.Tactic("propagate-values"),
                    polynomial_simplifier,
                )(z3.And(*decl))
                query_normalization_time = (
                    time.perf_counter() - normalization_started
                )
                total_time += query_normalization_time
                if len(normalized) == 1:
                    decl = list(normalized[0])
                    used_polynomial_normalization = True
                    query_used_polynomial_normalization = True
            sol.add(decl)
            # Z3 expects milliseconds; the experiment configuration is in
            # seconds.  The effective timeout is additionally clamped to
            # the remaining task wall budget (when a deadline is set), so
            # the 3-VC portfolio cannot multiply the per-call budget into
            # a program-budget overshoot.
            effective_check_time = self._clamp_timeout(check_time)
            sol.set("timeout", int(effective_check_time * 1000))
            started = time.perf_counter()
            # The solver already has an internal millisecond timeout. Calling
            # it through a daemon thread can leave a timed-out Z3 call alive
            # and cancel later solvers that share the process context.
            r, watchdog_interrupted = self._check_with_watchdog(
                sol, effective_check_time
            )
            query_time = time.perf_counter() - started
            total_time += query_time
            if z3.unknown == r:
                # The default solver with auto_config disabled can return
                # "incomplete" immediately on polynomial transition queries
                # that a dedicated tactic proves quickly.  For linear
                # candidates, QF_LIA is much more complete than QF_NIA.
                is_linear = _is_linear_candidate(Can_I)
                if is_linear:
                    fallback = z3.SolverFor("QF_LIA")
                    fallback_lia_timeout = self._clamp_timeout(check_time)
                    fallback.set(
                        "timeout", int(fallback_lia_timeout * 1000)
                    )
                    fallback.set("random_seed", 0)
                    fallback.add(decl)
                    fallback_started = time.perf_counter()
                    fallback_result, fallback_interrupted = (
                        self._check_with_watchdog(
                            fallback, fallback_lia_timeout
                        )
                    )
                    fallback_time = time.perf_counter() - fallback_started
                    total_time += fallback_time
                    query_time += fallback_time
                    if fallback_result != z3.unknown:
                        sol = fallback
                        r = fallback_result
                        used_portfolio = True
                        query_used_portfolio = True
                        query_solver_name = "z3-qflia"
                        watchdog_interrupted = (
                            watchdog_interrupted or fallback_interrupted
                        )
                if r == z3.unknown:
                    # QF_LIA did not help (or candidate is nonlinear);
                    # fall back to QF_NIA with multi-seed portfolio.
                    # Z3's QF_NIA heuristics are seed-sensitive; trying
                    # multiple seeds can decide otherwise-unknown queries.
                    for retry_seed in (0, 1, 2, 3):
                        per_seed_timeout = self._clamp_timeout(
                            max(0.5, check_time / 4.0)
                        )
                        fallback = z3.SolverFor("QF_NIA")
                        fallback.set(
                            "timeout", int(per_seed_timeout * 1000)
                        )
                        fallback.set("random_seed", retry_seed)
                        fallback.add(decl)
                        fallback_started = time.perf_counter()
                        fallback_result, fallback_interrupted = (
                            self._check_with_watchdog(
                                fallback, per_seed_timeout
                            )
                        )
                        fallback_time = (
                            time.perf_counter() - fallback_started
                        )
                        total_time += fallback_time
                        query_time += fallback_time
                        if fallback_result != z3.unknown:
                            sol = fallback
                            r = fallback_result
                            used_portfolio = True
                            query_used_portfolio = True
                            query_solver_name = "z3-qfnia-seed-{}".format(
                                retry_seed
                            )
                            break
                        watchdog_interrupted = (
                            watchdog_interrupted or fallback_interrupted
                        )
                if r == z3.unknown:
                    # Last resort: try a tactic-based approach that can
                    # handle nonlinear arithmetic via quantifier elimination
                    # and nlsat.  This catches cases where the default
                    # solver returns incomplete but nlsat can decide.
                    try:
                        tactic_timeout = self._clamp_timeout(
                            max(0.5, check_time)
                        )
                        if is_linear_inv:
                            tac = z3.Then(
                                z3.Tactic("simplify"),
                                z3.Tactic("solve-eqs"),
                                z3.Tactic("propagate-values"),
                                z3.Tactic("qe"),
                                z3.Tactic("smt"),
                            )
                        else:
                            tac = z3.Then(
                                z3.Tactic("simplify"),
                                z3.Tactic("propagate-values"),
                                z3.Tactic("nlsat"),
                            )
                        tac_solver = tac.solver()
                        tac_solver.set("timeout", int(tactic_timeout * 1000))
                        tac_solver.add(decl)
                        tac_started = time.perf_counter()
                        tac_result, tac_interrupted = (
                            self._check_with_watchdog(
                                tac_solver, tactic_timeout
                            )
                        )
                        tac_time = time.perf_counter() - tac_started
                        total_time += tac_time
                        query_time += tac_time
                        if tac_result != z3.unknown:
                            sol = tac_solver
                            r = tac_result
                            used_tactic = True
                            query_used_tactic = True
                            query_solver_name = "z3-tactic"
                            watchdog_interrupted = (
                                watchdog_interrupted or tac_interrupted
                            )
                    except Exception:
                        pass
            if z3.sat == r:  # we got a counterexample
                m = sol.model()
                vc_results.append({
                    "vc": failure_types[i].value,
                    "status": "sat",
                    "failure_type": failure_types[i].value,
                    "solver_time_seconds": query_time,
                    "normalization_time_seconds": query_normalization_time,
                    "query_size": len(s),
                    "solver_name": query_solver_name,
                    "portfolio_used": query_used_portfolio,
                    "tactic_used": query_used_tactic,
                    "polynomial_normalization_used": (
                        query_used_polynomial_normalization
                    ),
                    "watchdog_interrupted": watchdog_interrupted,
                    "raw_solver_status": "sat",
                })
                return CheckResult(
                    status="counterexample",
                    failure_type=failure_types[i],
                    counterexample=self._extract_counterexample(m, i, self.state_variables),
                    solver_time=total_time,
                    solver_name=(
                        ("z3+qfnia" if used_portfolio else "z3")
                        + ("+tactic" if used_tactic else "")
                        + (
                            "+poly-normalized"
                            if used_polynomial_normalization
                            else ""
                        )
                    ),
                    query_size=total_query_size,
                    candidate_hash=candidate_hash,
                    raw_solver_status="sat",
                    vc_results=tuple(vc_results),
                )
            if z3.unknown == r:
                reason = sol.reason_unknown()
                failure_type = (
                    CheckFailureType.TIMEOUT
                    if reason == "timeout"
                    or watchdog_interrupted
                    or query_time >= effective_check_time * 0.95
                    else CheckFailureType.UNKNOWN
                )
                vc_results.append({
                    "vc": failure_types[i].value,
                    "status": failure_type.value.lower(),
                    "failure_type": failure_type.value,
                    "solver_time_seconds": query_time,
                    "normalization_time_seconds": query_normalization_time,
                    "query_size": len(s),
                    "solver_name": query_solver_name,
                    "portfolio_used": query_used_portfolio,
                    "tactic_used": query_used_tactic,
                    "polynomial_normalization_used": (
                        query_used_polynomial_normalization
                    ),
                    "watchdog_interrupted": watchdog_interrupted,
                    "raw_solver_status": "unknown:{}".format(reason),
                })
                return CheckResult(
                    status=failure_type.value.lower(),
                    failure_type=failure_type,
                    counterexample=None,
                    solver_time=total_time,
                    solver_name=(
                        ("z3+qfnia" if used_portfolio else "z3")
                        + ("+tactic" if used_tactic else "")
                        + (
                            "+poly-normalized"
                            if used_polynomial_normalization
                            else ""
                        )
                    ),
                    query_size=total_query_size,
                    candidate_hash=candidate_hash,
                    raw_solver_status="unknown:{}".format(reason),
                    vc_results=tuple(vc_results),
                )
            assert z3.unsat == r
            vc_results.append({
                "vc": failure_types[i].value,
                "status": "unsat",
                "failure_type": None,
                "solver_time_seconds": query_time,
                "normalization_time_seconds": query_normalization_time,
                "query_size": len(s),
                "solver_name": query_solver_name,
                "portfolio_used": query_used_portfolio,
                "tactic_used": query_used_tactic,
                "polynomial_normalization_used": (
                    query_used_polynomial_normalization
                ),
                "watchdog_interrupted": watchdog_interrupted,
                "raw_solver_status": "unsat",
            })

        return CheckResult(
            status="success",
            failure_type=CheckFailureType.SUCCESS,
            counterexample=None,
            solver_time=total_time,
            solver_name=(
                ("z3+qfnia" if used_portfolio else "z3")
                + ("+tactic" if used_tactic else "")
                + (
                    "+poly-normalized"
                    if used_polynomial_normalization
                    else ""
                )
            ),
            query_size=total_query_size,
            candidate_hash=candidate_hash,
            raw_solver_status="unsat,unsat,unsat",
            vc_results=tuple(vc_results),
        )

    def verify(self, Can_I, path2SMT):
        """Backward-compatible Baseline API."""
        result = self.check(Can_I, path2SMT)
        if result.failure_type == CheckFailureType.SUCCESS:
            return None
        if result.failure_type in (
            CheckFailureType.TIMEOUT,
            CheckFailureType.UNKNOWN,
        ):
            raise TimeoutError("SMT Checking is OOT:    " + str(Can_I))
        kind = {
            CheckFailureType.INIT: "p",
            CheckFailureType.STEP: "i",
            CheckFailureType.EXIT: "n",
        }[result.failure_type]
        return Counterexample(kind, result.counterexample)
