"""Generation components for AdaSparCE."""
