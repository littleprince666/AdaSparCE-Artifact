"""Candidate-generation methods shared by the VC analyzer."""

from itertools import combinations
import z3
from SparCE.generation.vc_polynomial import VCAnalysisError
from SparCE.generation.vc_polynomial import _flatten_and
from SparCE.generation.vc_polynomial import _flatten_or
from SparCE.generation.vc_polynomial import _symbols
from SparCE.generation.vc_polynomial import _rref
from SparCE.generation.vc_polynomial import _poly_degree
from SparCE.generation.vc_polynomial import _reduce_divisible_polynomials


class VCRecurrence:
    """Recurrence and exit-property candidate construction."""

    def _scaled_division_equalities(self, expression):
        """Lift ``q = dividend div constant`` to a polynomial equality.

        The lifted equality is stronger than the quotient equality and is
        emitted only as a candidate.  It is useful when a loop maintains the
        exact divisibility witness (for example a triangular-sum accumulator)
        but the checker postcondition uses integer division.
        """
        equalities = []
        seen = set()
        for atom in self._equality_atoms(expression):
            left, right = atom.children()
            for quotient, other in ((left, right), (right, left)):
                if not z3.is_app_of(quotient, z3.Z3_OP_IDIV):
                    continue
                dividend, divisor = quotient.children()
                if (
                    not z3.is_int_value(divisor)
                    or divisor.as_long() == 0
                    or abs(divisor.as_long()) > 16
                ):
                    continue
                lifted = z3.simplify(
                    divisor * other == dividend, som=True
                )
                key = str(lifted)
                if key not in seen:
                    seen.add(key)
                    equalities.append(lifted)
        return equalities

    def _linear_span_contains(self, polynomial, basis):
        exponents = sorted(
            set(polynomial).union(
                *(set(item) for item in basis)
            )
        )
        if not exponents:
            return True
        matrix = [
            [item.get(exponent, 0) for item in basis]
            + [-polynomial.get(exponent, 0)]
            for exponent in exponents
        ]
        # A solution with the final coefficient fixed to one exists iff the
        # basis rank is unchanged after appending the target.
        _, original_pivots = _rref(
            [row[:-1] for row in matrix], len(basis)
        )
        _, augmented_pivots = _rref(matrix, len(basis) + 1)
        return len(original_pivots) == len(augmented_pivots)

    def _finite_difference_closure(self, residuals, max_degree, max_clauses):
        try:
            updates = self._update_polynomials()
            polynomials = [
                self._expression_poly(residual)
                for residual in residuals
            ]
        except VCAnalysisError:
            return None
        polynomials = [polynomial for polynomial in polynomials if polynomial]
        if (
            not polynomials
            or len(polynomials) > max_clauses
            or any(
                _poly_degree(polynomial) > max_degree
                or (
                    _poly_degree(polynomial) == 0
                    and polynomial
                )
                for polynomial in polynomials
            )
        ):
            return None
        # A closure can temporarily contain a polynomial that becomes
        # redundant after its lower-degree factor is discovered.  Allow a
        # small bounded surplus, then minimize the final equality basis.
        intermediate_limit = max(
            max_clauses + 2,
            2 * max_clauses,
            max_degree + 1,
        )
        cursor = 0
        while cursor < len(polynomials):
            difference = self._delta(polynomials[cursor], updates)
            cursor += 1
            if not difference or self._linear_span_contains(
                difference, polynomials
            ):
                continue
            if (
                _poly_degree(difference) > max_degree
                or _poly_degree(difference) == 0
                or len(polynomials) >= intermediate_limit
            ):
                return None
            polynomials.append(difference)
        reduced = _reduce_divisible_polynomials(polynomials)
        if len(reduced) > max_clauses:
            return None
        return reduced

    def _counter_lifts(self, property_expression):
        if not self.updates:
            return []
        lifts = []
        for raw_guard in self.guard_terms:
            guard = raw_guard
            if z3.is_not(guard):
                child = guard.children()[0]
                if (
                    z3.is_le(child)
                    or z3.is_lt(child)
                    or z3.is_ge(child)
                    or z3.is_gt(child)
                ):
                    left, right = child.children()
                    if z3.is_le(child):
                        guard = left > right
                    elif z3.is_lt(child):
                        guard = left >= right
                    elif z3.is_ge(child):
                        guard = left < right
                    else:
                        guard = left <= right
            if not (
                z3.is_lt(guard)
                or z3.is_le(guard)
                or z3.is_gt(guard)
                or z3.is_ge(guard)
            ):
                continue
            left, right = guard.children()
            if not (
                self._is_named_const(left, set(self.variables))
                and self._is_named_const(right, set(self.variables))
            ):
                continue
            left_name, right_name = str(left), str(right)
            left_delta = z3.simplify(self.updates[left_name] - left)
            if (
                not z3.is_int_value(left_delta)
                or left_delta.as_long() not in (-1, 1)
            ):
                right_delta = z3.simplify(
                    self.updates[right_name] - right
                )
                if (
                    not z3.is_int_value(right_delta)
                    or right_delta.as_long() not in (-1, 1)
                ):
                    continue
                if z3.is_lt(guard):
                    guard = right > left
                elif z3.is_le(guard):
                    guard = right >= left
                elif z3.is_gt(guard):
                    guard = right < left
                else:
                    guard = right <= left
                left, right = guard.children()
            counter_name, bound_name = str(left), str(right)
            counter = self.symbols[counter_name]
            bound = self.symbols[bound_name]
            delta = z3.simplify(self.updates[counter_name] - counter)
            if not z3.is_int_value(delta):
                continue
            step = delta.as_long()
            replacement = None
            boundary = None
            if z3.is_lt(guard) and step == 1:
                replacement, boundary = counter, counter <= bound
            elif z3.is_le(guard) and step == 1:
                replacement, boundary = counter - 1, counter <= bound + 1
            elif z3.is_gt(guard) and step == -1:
                replacement, boundary = counter, counter >= bound
            elif z3.is_ge(guard) and step == -1:
                replacement, boundary = counter + 1, counter >= bound - 1
            if replacement is None:
                continue
            initial_value = self._constant_initial_value(counter_name)
            if (
                initial_value is not None
                and not self._precondition_implies(boundary)
            ):
                boundary = z3.simplify(z3.Or(
                    counter == initial_value,
                    boundary,
                ))
            lifted = z3.simplify(
                z3.substitute(
                    property_expression, (bound, replacement)
                ),
                som=True,
            )
            lifts.append((lifted, z3.simplify(boundary)))
        return lifts

    def finite_difference_candidates(self, max_degree=3, max_clauses=3):
        """Return (formula, mechanism, degree, clauses, details) tuples."""
        candidates = []
        seen = set()

        def add(property_expression, boundary, mechanism):
            atoms = self._equality_atoms(property_expression)
            if not atoms:
                return
            residuals = [
                self._residual(atom) for atom in atoms
            ]
            closure = self._finite_difference_closure(
                residuals, max_degree, max_clauses - int(boundary is not None)
            )
            if closure is None:
                return
            clauses = [
                self._poly_expression(polynomial) == 0
                for polynomial in closure
            ]
            if boundary is not None:
                clauses.append(boundary)
            formula = z3.simplify(z3.And(*clauses))
            key = str(formula)
            if key in seen:
                return
            seen.add(key)
            candidates.append(
                (
                    formula,
                    mechanism,
                    max(_poly_degree(item) for item in closure),
                    len(clauses),
                    tuple(str(clause) for clause in clauses),
                )
            )

        for property_expression in self._exit_properties():
            add(
                property_expression,
                None,
                "vc-finite-difference-closure",
            )
            for lifted, boundary in self._counter_lifts(
                property_expression
            ):
                add(
                    lifted,
                    boundary,
                    "vc-counter-lifted-difference-closure",
                )
            for lifted_property in self._scaled_division_equalities(
                property_expression
            ):
                add(
                    lifted_property,
                    None,
                    "vc-scaled-division-difference-closure",
                )
                for lifted, boundary in self._counter_lifts(
                    lifted_property
                ):
                    add(
                        lifted,
                        boundary,
                        "vc-counter-lifted-scaled-division-closure",
                    )
        return candidates

    def sparse_recurrence_candidates(
        self, max_degree=6, max_clauses=3, minimum_degree=4
    ):
        """Recover sparse high-degree C-finite/Faulhaber-style closures.

        Unlike ``conserved_candidates``, this method never enumerates the full
        monomial space through ``max_degree``.  It starts only from polynomial
        equalities already present in the exit specification, follows exact
        finite differences, and minimizes factor-redundant generators.  The
        ordinary verifier remains responsible for all three proof obligations.
        """
        candidates = []
        mechanism_names = {
            "vc-finite-difference-closure": (
                "vc-sparse-recurrence-closure"
            ),
            "vc-counter-lifted-difference-closure": (
                "vc-counter-lifted-sparse-recurrence-closure"
            ),
        }
        for formula, mechanism, degree, clauses, details in (
            self.finite_difference_candidates(
                max_degree=max_degree,
                max_clauses=max_clauses,
            )
        ):
            if degree < minimum_degree:
                continue
            candidates.append((
                formula,
                mechanism_names.get(mechanism, mechanism),
                degree,
                clauses,
                details,
            ))
        return candidates

    def scaled_division_candidates(self, max_degree=3, max_clauses=3):
        """Return only exact constant-divisor finite-difference candidates."""
        return [
            candidate
            for candidate in self.finite_difference_candidates(
                max_degree=max_degree,
                max_clauses=max_clauses,
            )
            if "scaled-division" in candidate[1]
        ]

    def entry_potential_envelope_candidates(self):
        """Lift a frozen-entry exit bound into a current-state envelope.

        This targets normalized nondeterministic loops whose postcondition has
        the shape ``exit_guard => entry_frame => counter <= B(entry)``.  If
        ``B`` mentions paired ``x_0``/``x`` variables, the candidate keeps the
        entry frame and uses ``counter + B(current) <= B(entry)`` while the
        exit guard remains true.  It is a bounded syntactic template, not a
        general nonlinear invariant synthesizer.
        """
        antecedents = []
        target = self.postcondition
        while z3.is_implies(target):
            antecedent, target = target.children()
            antecedents.append(antecedent)
        if len(antecedents) < 2 or not z3.is_le(target):
            return []
        counter, entry_bound = target.children()
        if not self._is_named_const(counter, set(self.variables)):
            return []
        substitutions = []
        for name in self.variables:
            if name.endswith("_0"):
                current = name[:-2]
            elif name.endswith("0"):
                current = name[:-1]
            else:
                continue
            if current in self.symbols and name in self.symbols:
                substitutions.append((
                    self.symbols[name], self.symbols[current]
                ))
        if not substitutions or not any(
            str(symbol) in _symbols(entry_bound)
            for symbol, _ in substitutions
        ):
            return []
        current_bound = z3.simplify(
            z3.substitute(entry_bound, *substitutions), som=True
        )
        exit_guard = antecedents[0]
        entry_frame = z3.And(*antecedents[1:])
        formula = z3.simplify(z3.And(
            entry_frame,
            z3.Or(
                z3.Not(exit_guard),
                counter + current_bound <= entry_bound,
            ),
        ), som=True)
        try:
            degree = self._formula_degree(formula)
        except VCAnalysisError:
            return []
        return [(
            formula,
            "vc-entry-potential-envelope",
            degree,
            len(_flatten_and(formula)),
            tuple(str(clause) for clause in _flatten_and(formula)),
        )]

    def exit_post_closure_candidates(self, maximum_entry_atoms=3):
        """Close an SSA-guarded exit postcondition with entry facts.

        Some translated integer loops have an unconditional stuttering edge.
        Their only useful invariant is consequently the exit obligation itself
        (for example ``x != old_x or x*x <= n``), plus a small fact such as
        ``n > 0`` that makes the arithmetic update inductive.  This routine
        removes the postcondition's SSA frame exactly, rewrites entry atoms
        back to current-state names, and enumerates only bounded conjunctions
        of those atoms.  It does not reason by examples or use a language
        model; every returned formula is checked against INIT/STEP/EXIT.
        """
        # Keep this narrowly assigned to integer-division fixed-point loops.
        # Polynomial exits already have dedicated recurrence/conservation
        # generators, and broad postcondition closure would crowd them out of
        # the bounded frontend prefix.
        def has_division(expression):
            kind = expression.decl().kind()
            if kind in (
                z3.Z3_OP_DIV,
                z3.Z3_OP_IDIV,
                z3.Z3_OP_TO_REAL,
            ):
                return True
            return any(has_division(child) for child in expression.children())

        if not any(has_division(expression) for expression in (
            self.precondition, self.transition,
        )):
            return []
        state_names = set(self.variables)

        # The common checker encoding is ``not(frame) or not(not(exit and
        # not(property)))``.  Equational atoms in ``frame`` identify the
        # post-state SSA aliases with the invariant variables.
        frame = None
        obligation = None
        for child in _flatten_or(self.postcondition):
            if z3.is_not(child) and z3.is_and(child.children()[0]):
                candidate = child.children()[0]
                if any(
                    self._is_named_const(left, state_names)
                    or self._is_named_const(right, state_names)
                    for atom in _flatten_and(candidate)
                    if z3.is_eq(atom)
                    for left, right in (atom.children(),)
                ):
                    frame = candidate
                else:
                    obligation = child
            elif z3.is_not(child):
                obligation = child
        if frame is None or obligation is None:
            return []

        aliases = {}
        for atom in _flatten_and(frame):
            if not z3.is_eq(atom):
                continue
            left, right = atom.children()
            if self._is_named_const(left, state_names):
                aliases[right] = left
            elif self._is_named_const(right, state_names):
                aliases[left] = right
        if not aliases:
            return []
        normalized_post = z3.simplify(
            z3.substitute(obligation, *aliases.items()), som=True
        )
        if not _symbols(normalized_post).issubset(state_names):
            return []

        entry_aliases = dict(aliases)
        for atom in _flatten_and(self.precondition):
            if not z3.is_eq(atom):
                continue
            left, right = atom.children()
            if self._is_named_const(left, state_names):
                entry_aliases[right] = left
            elif self._is_named_const(right, state_names):
                entry_aliases[left] = right
        entry_atoms = []
        for atom in _flatten_and(self.precondition):
            normalized = z3.simplify(
                z3.substitute(atom, *entry_aliases.items()), som=True
            )
            if (
                z3.is_true(normalized)
                or not _symbols(normalized).issubset(state_names)
            ):
                continue
            try:
                if self._formula_degree(normalized) > 1:
                    continue
            except VCAnalysisError:
                continue
            if all(not z3.eq(normalized, present) for present in entry_atoms):
                entry_atoms.append(normalized)
        entry_atoms.sort(key=str)
        entry_atoms = entry_atoms[:maximum_entry_atoms]

        candidates = []
        for size in range(len(entry_atoms) + 1):
            for facts in combinations(entry_atoms, size):
                formula = z3.simplify(z3.And(*(facts + (normalized_post,))),
                                      som=True)
                try:
                    degree = self._formula_degree(formula)
                except VCAnalysisError:
                    continue
                candidates.append((
                    formula,
                    "vc-exit-post-closure",
                    degree,
                    len(_flatten_and(formula)),
                    tuple(str(clause) for clause in _flatten_and(formula)),
                ))
        return candidates
