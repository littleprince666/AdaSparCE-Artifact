"""Transition-relation and initial-condition driven equality synthesis.

Generic invariant-subspace method over a degree-bounded monomial basis:

1.  For every branch transition ``(guard, updates)`` collected by the
    branch-aware front end, build the linear composition map
    ``phi_b: p -> p . updates_b`` on the basis.
2.  Compute the maximal subspace ``V`` of the basis span with
    ``phi_b(V) <= V`` for every branch (classic invariant-subspace
    iteration; purely rational linear algebra, no corpus statistics).
3.  Filter basis members by the initial conditions (symbolic
    substitution, then a bounded z3 check against the assumptions) and
    re-run the subspace iteration inside the initial-satisfied span.
4.  Emit (a) individual equalities — candidate atoms that may only be
    *jointly* inductive, exactly the shape the partial-lemma bank is
    designed to retain — and (b) the conjunction of an invariant
    subspace basis, which is inductive by construction.

Nothing here is specialized to a benchmark, variable naming or target
answer: the inputs are the branch transition relations, the initial
conditions and a degree bound.  Every emission is only a candidate; the
frozen INIT/STEP/EXIT SMT checker remains the sole judge of soundness.
"""

from fractions import Fraction

import hashlib
import json
import math

import z3


class KernelSynthesisError(ValueError):
    """Raised when the program shape is outside the polynomial fragment."""


# ---------------------------------------------------------------------------
# Polynomial arithmetic over exponent-vector keys
# ---------------------------------------------------------------------------

def _poly_add(left, right, scale=Fraction(1)):
    result = dict(left)
    for key, value in right.items():
        result[key] = result.get(key, Fraction(0)) + scale * value
    return {k: v for k, v in result.items() if v}


def _poly_mul(left, right):
    result = {}
    for lk, lv in left.items():
        for rk, rv in right.items():
            key = tuple(a + b for a, b in zip(lk, rk))
            result[key] = result.get(key, Fraction(0)) + lv * rv
    return {k: v for k, v in result.items() if v}


def _poly_degree(polynomial):
    return max((sum(key) for key in polynomial), default=0)


def _poly_term_count(polynomial):
    return sum(1 for v in polynomial.values() if v)


def _integer_scale(polynomial):
    """Scale to integer coefficients (equality p == 0 is scale-invariant)."""
    denominator = 1
    for value in polynomial.values():
        denominator = denominator * value.denominator // math.gcd(
            denominator, value.denominator
        )
    if denominator == 1:
        return polynomial
    return {
        key: value * denominator
        for key, value in polynomial.items()
    }


def _poly_to_z3(polynomial, symbols):
    terms = []
    for key, value in sorted(polynomial.items()):
        coefficient = value
        if coefficient == 0:
            continue
        factors = []
        for symbol, exponent in zip(symbols, key):
            factors.extend([symbol] * exponent)
        if factors:
            monomial = z3.Product(factors) if len(factors) > 1 else factors[0]
        else:
            monomial = None
        if monomial is None:
            terms.append(z3.IntVal(int(coefficient)))
        elif coefficient == 1:
            terms.append(monomial)
        else:
            terms.append(monomial * int(coefficient))
    if not terms:
        return z3.IntVal(0)
    total = terms[0]
    for term in terms[1:]:
        total = total + term
    return total


def _z3_to_poly(expression, variables, rational_div=False):
    """Expand a z3 integer expression into {exponent tuple: Fraction}.

    The constant term uses the all-zero exponent tuple so that every
    key has uniform length.  With ``rational_div`` constant-denominator
    divisions expand as multiplication by the inverse constant (exact
    for the divisibility-guaranteed initial values, e.g. ``x = a/2``
    under ``a % 2 == 0``; the checker remains the sole judge).  Raises
    KernelSynthesisError on other div/mod/ite structure so callers can
    fail open.
    """
    zero_key = (0,) * len(variables)
    if z3.is_int_value(expression):
        return {zero_key: Fraction(expression.as_long())}
    if z3.is_const(expression) and expression.num_args() == 0:
        name = str(expression)
        if name in variables:
            key = tuple(
                1 if v == name else 0 for v in variables
            )
            return {key: Fraction(1)}
        raise KernelSynthesisError("uninterpreted symbol: " + name)
    if rational_div and z3.is_app_of(expression, z3.Z3_OP_IDIV):
        dividend, divisor = expression.children()
        if not z3.is_int_value(divisor) or divisor.as_long() == 0:
            raise KernelSynthesisError("non-constant divisor")
        dividend_poly = _z3_to_poly(dividend, variables, rational_div)
        inverse = Fraction(1, abs(divisor.as_long()))
        if divisor.as_long() < 0:
            inverse = -inverse
        return {
            key: value * inverse for key, value in dividend_poly.items()
        }
    if z3.is_add(expression):
        total = {}
        for child in expression.children():
            total = _poly_add(total, _z3_to_poly(child, variables, rational_div))
        return total
    if z3.is_sub(expression):
        children = expression.children()
        total = _z3_to_poly(children[0], variables, rational_div)
        for child in children[1:]:
            total = _poly_add(
                total, _z3_to_poly(child, variables, rational_div), Fraction(-1)
            )
        return total
    if z3.is_mul(expression):
        total = {zero_key: Fraction(1)}
        for child in expression.children():
            total = _poly_mul(
                total, _z3_to_poly(child, variables, rational_div)
            )
        return total
    if (
        z3.is_app_of(expression, z3.Z3_OP_UMINUS)
        and len(expression.children()) == 1
    ):
        return _poly_add(
            {},
            _z3_to_poly(expression.children()[0], variables, rational_div),
            Fraction(-1),
        )
    if z3.is_app_of(expression, z3.Z3_OP_POWER):
        base, exponent = expression.children()
        if not (z3.is_int_value(exponent) and exponent.as_long() >= 0):
            raise KernelSynthesisError("non-constant exponent")
        base_poly = _z3_to_poly(base, variables, rational_div)
        total = {zero_key: Fraction(1)}
        for _ in range(exponent.as_long()):
            total = _poly_mul(total, base_poly)
        return total
    raise KernelSynthesisError(
        "unsupported arithmetic: {}".format(expression.decl())
    )


# ---------------------------------------------------------------------------
# Rational linear algebra
# ---------------------------------------------------------------------------

def _nullspace(rows, width):
    """Basis of {x : rows . x = 0} over the rationals."""
    matrix = [list(row) for row in rows if any(row)]
    if not matrix:
        return [
            [Fraction(1) if i == j else Fraction(0) for j in range(width)]
            for i in range(width)
        ]
    pivots = []
    row_index = 0
    for column in range(width):
        pivot_row = None
        for candidate in range(row_index, len(matrix)):
            if matrix[candidate][column] != 0:
                pivot_row = candidate
                break
        if pivot_row is None:
            continue
        matrix[row_index], matrix[pivot_row] = (
            matrix[pivot_row], matrix[row_index]
        )
        pivot = matrix[row_index][column]
        matrix[row_index] = [v / pivot for v in matrix[row_index]]
        for other in range(len(matrix)):
            if other != row_index and matrix[other][column] != 0:
                factor = matrix[other][column]
                matrix[other] = [
                    a - factor * b
                    for a, b in zip(matrix[other], matrix[row_index])
                ]
        pivots.append(column)
        row_index += 1
        if row_index == len(matrix):
            break
    free = [c for c in range(width) if c not in pivots]
    basis = []
    for free_column in free:
        vector = [Fraction(0)] * width
        vector[free_column] = Fraction(1)
        for row, pivot_column in enumerate(pivots):
            vector[pivot_column] = -matrix[row][free_column]
        basis.append(vector)
    return basis


def _sparsify_basis(members, rounds=3):
    """Greedy pairwise reduction towards a sparser basis.

    Echelon/nullspace bases mix semantic atoms into dense
    combinations; cancelling shared monomials between basis members
    frequently recovers the sparse generator atoms (e.g. coupled
    update-conservation pairs) without changing the span.
    """
    current = [dict(p) for p in members]
    for _ in range(rounds):
        improved = False
        for i in range(len(current)):
            best = current[i]
            best_terms = _poly_term_count(best)
            for j in range(len(current)):
                if i == j:
                    continue
                other = current[j]
                for key, value in best.items():
                    if key not in other or other[key] == 0:
                        continue
                    scale = -value / other[key]
                    candidate = _poly_add(best, other, scale)
                    terms = _poly_term_count(candidate)
                    if 0 < terms < best_terms:
                        best = candidate
                        best_terms = terms
            if best != current[i] and best:
                current[i] = best
                improved = True
        if not improved:
            break
    return [p for p in current if p]


class _EchelonBasis:
    """Row-echelon polynomial basis with reduction-based membership."""

    def __init__(self):
        self.rows = []  # list of (pivot_key, poly)

    def add(self, polynomial):
        reduced = self.reduce(polynomial)
        if not reduced:
            return False
        pivot = min(reduced)
        inverse = Fraction(1) / reduced[pivot]
        normalized = {k: v * inverse for k, v in reduced.items()}
        self.rows.append((pivot, normalized))
        self.rows.sort(key=lambda item: item[0])
        return True

    def reduce(self, polynomial):
        current = dict(polynomial)
        for pivot, row in self.rows:
            coefficient = current.get(pivot)
            if coefficient is None or coefficient == 0:
                continue
            for key, value in row.items():
                current[key] = current.get(key, Fraction(0)) - coefficient * value
            current = {k: v for k, v in current.items() if v}
        return current


# ---------------------------------------------------------------------------
# Kernel synthesis
# ---------------------------------------------------------------------------

def _self_and_children(formula):
    """Yield the arithmetic leaves of a (possibly boolean) formula."""
    if formula.children():
        for child in formula.children():
            yield from _self_and_children(child)
    else:
        yield formula


class TransitionKernelSynthesizer:
    """Synthesize equality candidates preserved by all branch updates."""

    def __init__(
        self,
        variables,
        branch_transitions,
        initial_substitutions,
        assumption,
        max_degree=3,
        basis_dimension_cap=220,
        init_check_timeout_ms=2000,
    ):
        self.variables = tuple(variables)
        self.symbols = {name: z3.Int(name) for name in self.variables}
        self.max_degree = int(max_degree)
        self.basis_dimension_cap = int(basis_dimension_cap)
        self.init_check_timeout_ms = int(init_check_timeout_ms)
        self.initial_substitutions = list(initial_substitutions or [])
        self.assumption = assumption
        self.branch_maps = []
        self.branch_guards = []
        for guard, updates in branch_transitions:
            if not updates:
                continue
            substitution = [
                (self.symbols[name], z3.simplify(rhs))
                for name, rhs in updates.items()
                if name in self.symbols
            ]
            self.branch_maps.append(substitution)
            self.branch_guards.append(guard)
        if not self.branch_maps:
            raise KernelSynthesisError("no branch transitions")
        self._phi_cache = {}
        # Ordered expression tuple matching exponent-vector positions.
        self.symbol_vector = tuple(
            self.symbols[name] for name in self.variables
        )
        self._zero_key = (0,) * len(self.variables)

    # -- basis ------------------------------------------------------------

    def _monomial_basis(self):
        size = len(self.variables)
        basis = []
        from itertools import combinations_with_replacement

        for degree in range(0, self.max_degree + 1):
            for indices in combinations_with_replacement(range(size), degree):
                exponents = [0] * size
                for index in indices:
                    exponents[index] += 1
                basis.append(tuple(exponents))
        return basis

    def _phi(self, monomial, branch_index):
        cache_key = (monomial, branch_index)
        cached = self._phi_cache.get(cache_key)
        if cached is not None:
            return cached
        substitution = self.branch_maps[branch_index]
        expression = _poly_to_z3({monomial: Fraction(1)}, self.symbol_vector)
        substituted = z3.substitute(expression, *substitution)
        result = _z3_to_poly(z3.simplify(substituted), self.variables)
        self._phi_cache[cache_key] = result
        return result

    # -- subspace iteration -------------------------------------------------

    def _image(self, polynomial, branch_index):
        """phi_b(polynomial) as a polynomial (exact expansion)."""
        total = {}
        for key, value in polynomial.items():
            total = _poly_add(
                total, self._phi(key, branch_index), value
            )
        return total

    def _invariant_subspace(self, generators):
        """Maximal subspace of span(generators) invariant under all phis."""
        current = [dict(g) for g in generators]
        while True:
            echelon = _EchelonBasis()
            for poly in current:
                echelon.add(poly)
            if not echelon.rows:
                return []
            basis_polys = [row for _, row in echelon.rows]
            width = len(basis_polys)
            constraints = []
            for branch_index in range(len(self.branch_maps)):
                images = [
                    self._image(poly, branch_index)
                    for poly in basis_polys
                ]
                residuals = [echelon.reduce(image) for image in images]
                monomial_keys = set()
                for residual in residuals:
                    monomial_keys.update(residual)
                for key in monomial_keys:
                    constraints.append(
                        [
                            residuals[i].get(key, Fraction(0))
                            for i in range(width)
                        ]
                    )
            solutions = _nullspace(constraints, width)
            if len(solutions) == width:
                return basis_polys
            new_basis = []
            for solution in solutions:
                combined = {}
                for coefficient, poly in zip(solution, basis_polys):
                    combined = _poly_add(combined, poly, coefficient)
                if combined:
                    new_basis.append(combined)
            if len(new_basis) == len(current):
                # Same dimension: canonicalize once to guarantee
                # progress, then stop (the space is invariant).
                canonical = []
                echelon2 = _EchelonBasis()
                for poly in new_basis:
                    if echelon2.add(poly):
                        canonical.append(echelon2.rows[-1][1])
                return canonical
            current = new_basis
            if not current:
                return []

    # -- initial-condition filter -------------------------------------------

    # -- initial-condition map ----------------------------------------------

    def _substitution_map(self):
        """sigma: variable -> polynomial over the remaining free vars.

        Initial assignments (including assume-recorded equalities) map
        variables to their entry values; unassigned variables stay
        free.  Chained initializations are resolved by repeated
        composition.  Constant-denominator divisions expand rationally
        (exact when divisibility is assumed, e.g. ``a % 2 == 0``); any
        other shape fails open.
        """
        sigma = {}
        for symbol, value in self.initial_substitutions:
            try:
                sigma[str(symbol)] = _z3_to_poly(
                    value, self.variables, rational_div=True
                )
            except KernelSynthesisError:
                sigma[str(symbol)] = None
        identity = {
            name: {self._exponent_key(name): Fraction(1)}
            for name in self.variables
        }
        # Resolve chains (a = b, b = 0) to a fixpoint.
        for _ in range(len(self.variables) + 1):
            changed = False
            for name, mapped in list(sigma.items()):
                if mapped is None:
                    continue
                composed = {}
                for key, coefficient in mapped.items():
                    substituted = {self._zero_key: Fraction(1)}
                    for index, exponent in enumerate(key):
                        factor = sigma.get(self.variables[index])
                        if factor is None:
                            factor = identity[self.variables[index]]
                        for _ in range(exponent):
                            substituted = _poly_mul(substituted, factor)
                    composed = _poly_add(composed, substituted, coefficient)
                if composed != mapped:
                    sigma[name] = composed
                    changed = True
            if not changed:
                break
        full = {}
        for name in self.variables:
            mapped = sigma.get(name)
            full[name] = (
                mapped if mapped is not None else identity[name]
            )
        return full

    def _exponent_key(self, name):
        return tuple(
            1 if v == name else 0 for v in self.variables
        )

    def _apply_sigma(self, polynomial, sigma):
        """Compose a polynomial through the initial substitution map."""
        composed = {}
        for key, coefficient in polynomial.items():
            term = {self._zero_key: Fraction(1)}
            for index, exponent in enumerate(key):
                factor = sigma[self.variables[index]]
                for _ in range(exponent):
                    term = _poly_mul(term, factor)
            composed = _poly_add(composed, term, coefficient)
        return composed

    def _init_zero_variables(self, sigma):
        """Variables whose initial value is the literal constant 0."""
        zeros = set()
        for name in self.variables:
            values = {
                key: value
                for key, value in sigma[name].items()
                if value != 0
            }
            if not values:
                zeros.add(name)
        return zeros

    def _init_vanishing_subspace(self, basis_polys):
        """Subspace of span(basis) vanishing on the initial states.

        Exact linear algebra: compose every basis member through the
        initial substitution map and require the result to be the zero
        polynomial over the free variables.  (On initial sets with
        nonempty interior the polynomial identity is equivalent to
        vanishing on the set; equality-constrained entries are captured
        exactly by the substitution itself.)
        """
        sigma = self._substitution_map()
        width = len(basis_polys)
        if width == 0:
            return [], sigma
        substituted = [
            self._apply_sigma(poly, sigma) for poly in basis_polys
        ]
        keys = set()
        for poly in substituted:
            keys.update(poly)
        rows = [
            [poly.get(key, Fraction(0)) for poly in substituted]
            for key in keys
        ]
        solutions = _nullspace(rows, width)
        vanishing = []
        for solution in solutions:
            combined = {}
            for coefficient, poly in zip(solution, basis_polys):
                combined = _poly_add(combined, poly, coefficient)
            if combined:
                vanishing.append(combined)
        return vanishing, sigma

    # -- guard-overshoot boundaries -------------------------------------------

    @staticmethod
    def _conjuncts(expression):
        """Flatten a z3 And-tree into its atoms."""
        if expression is None:
            return []
        if z3.is_and(expression):
            result = []
            for child in expression.children():
                result.extend(
                    TransitionKernelSynthesizer._conjuncts(child)
                )
            return result
        return [expression]

    def _boundary_candidates(self):
        """Guard-overshoot bounds driven by the branch transitions.

        For a loop-guard atom ``L REL R`` where the difference
        ``d = L - R`` changes by a *constant* delta under every branch,
        ``d <= max(delta)`` (resp. ``>=``) is inductive under the guard:
        entering the loop satisfies ``REL``, one step overshoots by at
        most the branch delta.  Initial validity stays the checker's
        responsibility — these are candidates only.
        """
        guards = [
            z3.simplify(g) for g in self.branch_guards
            if g is not None
        ]
        if not guards:
            return []
        common = {
            str(atom): atom for atom in self._conjuncts(guards[0])
        }
        for guard in guards[1:]:
            atoms = {
                str(atom) for atom in self._conjuncts(guard)
            }
            common = {
                key: atom for key, atom in common.items()
                if key in atoms
            }
        candidates = []
        for atom in common.values():
            if not (
                z3.is_le(atom) or z3.is_lt(atom)
                or z3.is_ge(atom) or z3.is_gt(atom)
            ):
                continue
            left, right = atom.children()
            try:
                difference = _poly_add(
                    _z3_to_poly(left, self.variables),
                    _z3_to_poly(right, self.variables),
                    Fraction(-1),
                )
            except KernelSynthesisError:
                continue
            deltas = []
            feasible = True
            for branch_index in range(len(self.branch_maps)):
                image = self._image(difference, branch_index)
                delta = _poly_add(image, difference, Fraction(-1))
                values = {
                    key: value for key, value in delta.items()
                    if value != 0
                }
                if len(values) != 1 or (
                    next(iter(values)) != self._zero_key
                ):
                    feasible = False
                    break
                deltas.append(
                    int(next(iter(values.values())))
                )
            if not feasible or not deltas or all(d == 0 for d in deltas):
                continue
            scaled = _integer_scale(difference)
            difference_expr = _poly_to_z3(
                scaled, self.symbol_vector
            )
            if z3.is_le(atom) or z3.is_lt(atom):
                # d REL 0 with REL in {<=, <}: overshoot bound.
                slack = 0 if z3.is_le(atom) else -1
                bound = max(deltas) + slack
                candidates.append(difference_expr <= bound)
            else:
                slack = 0 if z3.is_ge(atom) else 1
                bound = min(deltas) + slack
                candidates.append(difference_expr >= bound)
        return candidates

    def _support_scan_atoms(self, invariant, max_support_degree=2,
                            max_results=8):
        """Sparse atoms by direct support enumeration over the invariant
        subspace.

        The (nullspace + sparsified) basis need not contain every
        sparse member; scanning small supports (constant + up to two
        low-degree monomials) with a membership test recovers the
        individual generator atoms directly.
        """
        echelon = _EchelonBasis()
        for poly in invariant:
            echelon.add(poly)
        monomials = [
            key for key in self._monomial_basis()
            if 1 <= sum(key) <= max_support_degree
        ]
        zero = self._zero_key
        supports = [(zero, m) for m in monomials]
        supports += [
            (zero, m1, m2)
            for i, m1 in enumerate(monomials)
            for m2 in monomials[i + 1:]
        ]
        found = []
        seen = set()
        for support in supports:
            # Solve c . support in span(invariant): the reduction of the
            # combination must vanish, a linear system in c.
            reductions = [
                echelon.reduce({m: Fraction(1)}) for m in support
            ]
            keys = set()
            for reduction in reductions:
                keys.update(reduction)
            rows = [
                [
                    reduction.get(key, Fraction(0))
                    for reduction in reductions
                ]
                for key in keys
            ]
            solutions = _nullspace(rows, len(support))
            for solution in solutions:
                combined = {}
                for coefficient, monomial in zip(solution, support):
                    combined = _poly_add(
                        combined, {monomial: Fraction(1)}, coefficient
                    )
                combined = {
                    k: v for k, v in combined.items() if v != 0
                }
                if not combined or all(
                    sum(k) == 0 for k in combined
                ):
                    continue
                scaled = _integer_scale(combined)
                expression = _poly_to_z3(scaled, self.symbol_vector)
                key = str(expression)
                if key in seen:
                    continue
                seen.add(key)
                found.append(
                    (expression == 0, combined, "scan")
                )
                if len(found) >= max_results:
                    return found
        return found

    # -- public API ---------------------------------------------------------

    def _minimal_invariant_closure(self, seed, init_span, term_cap):
        """Greedily close span(seed) into an invariant subspace.

        Extends the current subspace by any branch images that escape
        it, but only with members that stay inside ``init_span`` (the
        initial-condition-satisfied space).  Returns the closed basis
        or ``None`` when the closure escapes or exceeds ``term_cap``.
        """
        current = [dict(seed)]
        echelon = _EchelonBasis()
        echelon.add(seed)
        init_echelon = _EchelonBasis()
        for poly in init_span:
            init_echelon.add(poly)
        for _ in range(term_cap + 1):
            escape = None
            for branch_index in range(len(self.branch_maps)):
                for poly in current:
                    image = self._image(poly, branch_index)
                    residual = echelon.reduce(image)
                    if residual:
                        escape = residual
                        break
                if escape is not None:
                    break
            if escape is None:
                return current
            # The escaping image must itself be initial-satisfied for
            # the conjunction to stay inductive over the init space.
            if init_echelon.reduce(escape):
                return None
            if not echelon.add(escape):
                return None
            current.append(escape)
            if len(current) > term_cap:
                return None
        return None

    def _is_degenerate_atom(self, polynomial, init_zero):
        """True when p factors as v * g for some init-zero variable v.

        Such multiples are trivially init-passing and carry no new
        constraint beyond v == 0; the atoms worth emitting mix monomials
        with and without init-zero variables.
        """
        if not init_zero:
            return False
        for name in init_zero:
            index = self.variables.index(name)
            if all(key[index] >= 1 for key in polynomial):
                return True
        return False

    def candidates(self, max_atoms=8, max_conjunctions=3,
                   max_conjunction_terms=6, max_seeds=12, target=None,
                   target_enabled=True, sparse_groups_enabled=True,
                   boundary_partners_enabled=True):
        """Return (formula, degree, clauses, detail) candidate tuples.

        The three interface flags filter a common, fully computed emission
        plan.  They do not change the classical entry-vanishing/pullback
        space, support scanning, atom quotas, or standalone guard bounds.
        Generation cost is deliberately retained in the disabled arms;
        this isolates the candidate interface rather than its computation
        time.  All emitted formulas still require raw-VC acceptance.
        """
        basis = self._monomial_basis()
        if len(basis) > self.basis_dimension_cap:
            raise KernelSynthesisError(
                "monomial basis too large ({} > {})".format(
                    len(basis), self.basis_dimension_cap
                )
            )
        # Ambient generators: the full monomial basis (constant included).
        ambient = self._invariant_subspace(
            [{m: Fraction(1)} for m in basis]
        )
        if not ambient:
            return []
        # Exact initial-condition subspace: combinations of the
        # ambient basis that vanish on the initial states ...
        init_vanishing, sigma = self._init_vanishing_subspace(ambient)
        if not init_vanishing:
            return []
        # ... then the maximal invariant subspace *inside* it.  Running
        # the iteration within the init-satisfied space (instead of
        # filtering the full invariant space afterwards) eliminates
        # init-only truths (e.g. entry equalities) that are not
        # preserved by any branch, and keeps exactly the jointly
        # inductive, initially-valid equality atoms.
        invariant = self._invariant_subspace(init_vanishing)
        if not invariant:
            return []
        invariant = _sparsify_basis(invariant)
        # Direct support enumeration recovers sparse generator atoms
        # that no basis need contain; degenerate multiples are filtered
        # by the same init-zero criterion as the basis atoms.
        init_zero = self._init_zero_variables(sigma)
        scanned = []
        seen_supports = set()
        for expression, polynomial, _detail in self._support_scan_atoms(
            invariant
        ):
            if self._is_degenerate_atom(polynomial, init_zero):
                continue
            key = str(expression)
            if key in seen_supports:
                continue
            seen_supports.add(key)
            scanned.append(
                (expression, _poly_degree(polynomial), 1, "scan")
            )
        init_passing = invariant
        # Degenerate multiples (v * g with v(Init) == 0) carry no new
        # constraint; emit only primitive atoms and use them as closure
        # seeds too.
        primitive = [
            p for p in init_passing
            if not self._is_degenerate_atom(p, init_zero)
        ]
        atom_pool = primitive if primitive else init_passing
        atom_pool.sort(
            key=lambda p: (_poly_degree(p), _poly_term_count(p))
        )
        emitted = []
        seen = set()
        interfaces = {}

        def emit(formula, degree, clauses, detail, interface="atom"):
            key = str(formula)
            if key in seen:
                origin = (interface, detail)
                if origin not in interfaces[key]:
                    interfaces[key].append(origin)
                return
            seen.add(key)
            emitted.append((formula, degree, clauses, detail))
            interfaces[key] = [(interface, detail)]

        # Target residuals are tested for membership in the computed
        # invariant space. This recovers sparse high-degree relations
        # without enlarging the ambient basis or enumerating supports.
        if target is not None:
            echelon = _EchelonBasis()
            for polynomial in invariant:
                echelon.add(polynomial)
            goals = []
            def target_atoms(formula):
                if z3.is_and(formula):
                    return [atom for child in formula.children() for atom in target_atoms(child)]
                return [formula]

            for atom in target_atoms(target):
                if not z3.is_eq(atom):
                    continue
                try:
                    left, right = atom.children()
                    polynomial = _z3_to_poly(z3.simplify(left - right, som=True), self.variables)
                except KernelSynthesisError:
                    continue
                if not polynomial or _poly_degree(polynomial) > self.max_degree:
                    continue
                if not echelon.reduce(polynomial):
                    goals.append((atom, polynomial))
            if goals:
                formulas = [atom for atom, _ in goals]
                boundaries = self._boundary_candidates()
                degree = max(_poly_degree(poly) for _, poly in goals)
                emit(z3.And(*formulas, *boundaries), degree,
                     len(formulas) + len(boundaries), "target",
                     "target_boundary" if boundaries else "target")
                emit(z3.And(*formulas), degree, len(formulas), "target", "target")

        # (a0) support-scan atoms first — the sparsest generators
        #      (e.g. plain entry-value conservations) that the basis
        #      itself need not contain.
        for expression, degree, _cl, detail in scanned:
            emit(expression, degree, 1, detail)
        # (a) individual equality atoms — possibly only jointly
        #     inductive; exactly the STEP-partial shape the clause bank
        #     is designed to retain.
        for polynomial in atom_pool[:max_atoms]:
            if _poly_degree(polynomial) == 0:
                continue
            scaled = _integer_scale(polynomial)
            emit(
                _poly_to_z3(scaled, self.symbol_vector) == 0,
                _poly_degree(polynomial),
                1,
                "atom",
            )
        # (b) conjunctions of greedily closed minimal invariant
        #     subspaces seeded at the sparsest initial-satisfied atoms.
        for seed in atom_pool[:max_seeds]:
            if _poly_degree(seed) == 0:
                continue
            closure = self._minimal_invariant_closure(
                seed, init_passing, max_conjunction_terms
            )
            if not closure:
                continue
            closure = [p for p in closure if _poly_degree(p) > 0]
            if not closure:
                continue
            clauses = [
                _poly_to_z3(_integer_scale(p), self.symbol_vector) == 0
                for p in closure
            ]
            formula = (
                z3.And(*clauses) if len(clauses) > 1 else clauses[0]
            )
            emit(
                formula,
                max(_poly_degree(p) for p in closure),
                len(closure),
                "closure",
                "sparse_group",
            )
            if len(emitted) >= max_atoms + max_conjunctions:
                break
        # (c) guard-overshoot boundary clauses (transition-driven
        #     bounds; the equality machinery cannot express them).
        for formula in self._boundary_candidates():
            emit(formula, self._z3_degree_of(formula), 1, "boundary")

        def enabled(interface):
            if interface in ("target", "target_boundary") and not target_enabled:
                return False
            if interface == "target_boundary" and not boundary_partners_enabled:
                return False
            if interface == "sparse_group" and not sparse_groups_enabled:
                return False
            return True

        selected = []
        for candidate in emitted:
            origins = interfaces[str(candidate[0])]
            active = [(interface, detail) for interface, detail in origins if enabled(interface)]
            if active:
                # Identical formulas can originate from several interfaces.
                # Keep a formula exposed by an enabled origin, and use its
                # source tag so a disabled target cannot retain target-only
                # protection through a duplicated sparse-group formula.
                selected.append((*candidate[:3], active[0][1]))
        # The plan fingerprint lets a study check that disabled interfaces
        # did not alter the common algebra, quotas or candidate ordering.
        # It is recorded before the filtering decision in every arm.
        space = sorted(json.dumps(sorted(
            [(list(key), [value.numerator, value.denominator])
             for key, value in polynomial.items()]
        )) for polynomial in invariant)
        plan = [(item[0].sexpr(), *item[1:],
                 interfaces[str(item[0])]) for item in emitted]
        input_state = dict(
            variables=self.variables, max_degree=self.max_degree,
            branches=[(guard.sexpr() if guard is not None else None,
                       [(left.sexpr(), right.sexpr()) for left, right in branch])
                      for guard, branch in zip(self.branch_guards, self.branch_maps)],
            initial_substitutions=[(left.sexpr(), right.sexpr())
                                   for left, right in self.initial_substitutions],
            assumption=self.assumption.sexpr() if self.assumption is not None else None,
            target=target.sexpr() if target is not None else None,
            limits=[max_atoms, max_conjunctions, max_conjunction_terms, max_seeds],
        )
        self.interface_audit = dict(
            input_state_sha256=hashlib.sha256(json.dumps(input_state).encode()).hexdigest(),
            invariant_space_sha256=hashlib.sha256(json.dumps(space).encode()).hexdigest(),
            common_plan_sha256=hashlib.sha256(json.dumps(plan).encode()).hexdigest(),
            common_plan_candidates=len(emitted),
            retained_candidates=len(selected),
            common_plan_interfaces={name: sum(any(origin[0] == name for origin in item[-1])
                                              for item in plan)
                                    for name in ("atom", "target", "target_boundary", "sparse_group")},
            enabled=dict(target=bool(target_enabled), sparse_groups=bool(sparse_groups_enabled),
                         boundary_partners=bool(boundary_partners_enabled)),
        )
        return selected

    def _z3_degree_of(self, formula):
        try:
            return max(
                (
                    sum(key)
                    for poly in (
                        _z3_to_poly(child, self.variables)
                        for child in _self_and_children(formula)
                    )
                    for key in poly
                ),
                default=1,
            )
        except KernelSynthesisError:
            return 1
