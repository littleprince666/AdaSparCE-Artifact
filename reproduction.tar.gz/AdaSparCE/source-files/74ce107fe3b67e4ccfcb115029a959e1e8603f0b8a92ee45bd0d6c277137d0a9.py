"""Cold online worker. Offline doctor blocks socket connections explicitly."""
import json
from pathlib import Path
import sys
import time


def main():
    request = json.load(sys.stdin)
    started = time.monotonic()
    if request.get('action') == 'offline-doctor':
        import socket
        def blocked(*args, **kwargs):
            raise RuntimeError('offline doctor forbids network connections')
        socket.socket.connect = blocked
        socket.socket.connect_ex = blocked
        socket.create_connection = blocked
    from .online_transport import OnlineBudgetExhausted, OnlineTaskDeadline
    try:
        from .online_clause2inv import run
        result = run(request)
    except OnlineBudgetExhausted:
        result = dict(status='budget-stop', reason='authorized study request/spending ceiling or provider usage assumption violated')
    except OnlineTaskDeadline:
        result = dict(status='timeout', reason='cold task deadline reached before another API request')
    except Exception as error:
        result = dict(status='error', reason=type(error).__name__)
    result['worker_seconds'] = time.monotonic()-started
    path = Path(request['result_file'])
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
    temporary.replace(path)


if __name__ == '__main__':
    main()
