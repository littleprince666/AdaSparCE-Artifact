"""Exact, explainable templates recovered from LIPuS verification conditions.

The C front end is useful for native benchmarks, but converted SyGuS tasks use
``normalized.c`` only as a feature carrier.  This module therefore reads the
actual ``pre-f``/``trans-f``/``post-f`` definitions and recovers:

* exit-property templates, including exact counter-boundary lifting;
* finite-difference closures of polynomial equalities; and
* sparse polynomial conservation laws satisfying the loop precondition.

All formulas produced here are merely candidates.  The independent LIPuS SMT
checker remains the sole authority for INIT/STEP/EXIT correctness."""

from functools import reduce
from itertools import product
from pathlib import Path
import hashlib
import re
import z3
from SparCE.symbolic.variables import checker_invariant_variables
from SparCE.generation.vc_polynomial import SPLIT
from SparCE.generation.vc_polynomial import VCAnalysisError
from SparCE.generation.vc_polynomial import _flatten_and
from SparCE.generation.vc_polynomial import _symbols
from SparCE.generation.vc_polynomial import _poly_add
from SparCE.generation.vc_polynomial import _poly_scale
from SparCE.generation.vc_polynomial import _poly_mul
from SparCE.generation.vc_polynomial import _poly_power
from SparCE.generation.vc_polynomial import _poly_degree
from SparCE.generation.vc_polynomial import _poly_substitute
from SparCE.generation.vc_recurrence import VCRecurrence
from SparCE.generation.vc_conservation import VCConservation
from SparCE.generation.vc_polynomial import _flatten_or as _flatten_or
from SparCE.generation.vc_polynomial import _lcm as _lcm
from SparCE.generation.vc_polynomial import _rref as _rref
from SparCE.generation.vc_polynomial import _nullspace as _nullspace
from SparCE.generation.vc_polynomial import _integer_vector as _integer_vector
from SparCE.generation.vc_polynomial import _poly_exactly_divides as _poly_exactly_divides
from SparCE.generation.vc_polynomial import _reduce_divisible_polynomials as _reduce_divisible_polynomials
from SparCE.generation.vc_polynomial import _monomial_exponents as _monomial_exponents

class VCAnalyzer(VCRecurrence, VCConservation):
    """Read exact VC definitions and expose symbolic candidate generators."""

    def __init__(self, smt_path):
        self.smt_path = str(smt_path)
        self.variables = tuple(checker_invariant_variables(smt_path))
        self.symbols = {name: z3.Int(name) for name in self.variables}
        self.primed = {
            name: z3.Int(name + "!") for name in self.variables
        }
        sections = Path(smt_path).read_text(encoding="utf-8").split(SPLIT)
        if len(sections) != 5:
            raise VCAnalysisError("expected-five-lipus-vc-sections")
        self._definitions = sections[0] + "true" + sections[1]
        self.pre_parameters = self._function_parameters("pre-f")
        self.transition_parameters = self._function_parameters("trans-f")
        self.post_parameters = self._function_parameters("post-f")
        self.precondition = self._parse_call(
            "(pre-f {})".format(" ".join(self.pre_parameters))
        )
        self.transition = self._parse_call(
            "(trans-f {})".format(" ".join(self.transition_parameters))
        )
        self.postcondition = self._parse_call(
            "(post-f {})".format(" ".join(self.post_parameters))
        )
        self.updates, self.guard_terms = self._deterministic_updates()

    @classmethod
    def from_program_model(
        cls,
        variables,
        updates,
        precondition,
        postcondition,
        guard,
        source_name="<program-model>",
    ):
        """Build the same exact analyzer from the normalized C front end.

        Native LIPuS VCs can contain SSA auxiliaries and a stuttering branch,
        while ``_ProgramAnalyzer`` already resolved the corresponding ordered
        C assignments.  This constructor shares the algebraic algorithms
        without reparsing or weakening the final Checker proof obligation.
        """
        analyzer = cls.__new__(cls)
        analyzer.smt_path = str(source_name)
        analyzer.variables = tuple(variables)
        analyzer.symbols = {
            name: z3.Int(name) for name in analyzer.variables
        }
        analyzer.primed = {
            name: z3.Int(name + "!") for name in analyzer.variables
        }
        analyzer.pre_parameters = analyzer.variables
        analyzer.transition_parameters = analyzer.variables
        analyzer.post_parameters = analyzer.variables
        analyzer.precondition = z3.simplify(precondition)
        analyzer.postcondition = z3.simplify(postcondition)
        analyzer.guard_terms = [z3.simplify(guard)] if guard is not None else []
        analyzer.updates = {
            name: z3.simplify(
                updates.get(name, analyzer.symbols[name])
            )
            for name in analyzer.variables
        }
        return analyzer

    def _function_parameters(self, function_name):
        match = re.search(
            r"\(\s*define-fun\s+{}\s*\((.*?)\)\s*Bool".format(
                re.escape(function_name)
            ),
            self._definitions,
            re.DOTALL,
        )
        if match is None:
            raise VCAnalysisError(
                "missing-function-definition:{}".format(function_name)
            )
        parameters = tuple(
            name
            for name, sort in re.findall(
                r"\(\s*([^\s()]+)\s+(Int|Real)\s*\)",
                match.group(1),
            )
        )
        if not parameters:
            raise VCAnalysisError(
                "empty-function-signature:{}".format(function_name)
            )
        return parameters

    def _parse_call(self, call):
        parsed = z3.parse_smt2_string(
            self._definitions + "\n(assert {})\n".format(call)
        )
        if len(parsed) != 1:
            raise VCAnalysisError("could-not-isolate-vc-definition")
        return parsed[0]

    @staticmethod
    def _is_named_const(expression, names):
        return (
            z3.is_const(expression)
            and expression.num_args() == 0
            and str(expression) in names
        )

    def _deterministic_updates(self):
        update_terms = {}
        guards = []
        prime_names = {name + "!" for name in self.variables}
        for term in _flatten_and(self.transition):
            if not z3.is_eq(term):
                guards.append(term)
                continue
            left, right = term.children()
            if self._is_named_const(left, prime_names):
                update_terms[str(left)[:-1]] = right
            elif self._is_named_const(right, prime_names):
                update_terms[str(right)[:-1]] = left
            else:
                guards.append(term)
        if set(update_terms) != set(self.variables):
            return {}, guards

        # Sequential C assignments translated from SyGuS can legitimately
        # mention another next-state symbol (for example x' = x + y').
        # Resolve that acyclic dependency exactly.
        resolved = {}
        pending = dict(update_terms)
        while pending:
            progress = False
            for name, expression in list(pending.items()):
                dependencies = {
                    symbol[:-1]
                    for symbol in _symbols(expression)
                    if symbol.endswith("!")
                }
                if not dependencies.issubset(resolved):
                    continue
                if dependencies:
                    expression = z3.substitute(
                        expression,
                        *[
                            (self.primed[dependency], resolved[dependency])
                            for dependency in sorted(dependencies)
                        ]
                    )
                if any(
                    symbol.endswith("!")
                    for symbol in _symbols(expression)
                ):
                    continue
                resolved[name] = z3.simplify(expression)
                del pending[name]
                progress = True
            if not progress:
                return {}, guards
        return resolved, guards

    def _expression_poly(self, expression):
        variable_index = {
            name: index for index, name in enumerate(self.variables)
        }
        variable_count = len(self.variables)
        zero = (0,) * variable_count

        def convert(node):
            if z3.is_int_value(node):
                value = node.as_long()
                return {} if value == 0 else {zero: value}
            if z3.is_const(node) and node.num_args() == 0:
                name = str(node)
                if name not in variable_index:
                    raise VCAnalysisError(
                        "non-state-polynomial-symbol:{}".format(name)
                    )
                exponent = [0] * variable_count
                exponent[variable_index[name]] = 1
                return {tuple(exponent): 1}
            kind = node.decl().kind()
            if z3.is_add(node):
                result = {}
                for child in node.children():
                    result = _poly_add(result, convert(child))
                return result
            if z3.is_mul(node):
                result = {zero: 1}
                for child in node.children():
                    result = _poly_mul(result, convert(child))
                return result
            if kind == z3.Z3_OP_SUB:
                children = node.children()
                result = convert(children[0])
                for child in children[1:]:
                    result = _poly_add(result, convert(child), scale=-1)
                return result
            if kind == z3.Z3_OP_UMINUS:
                return _poly_scale(convert(node.children()[0]), -1)
            if kind == z3.Z3_OP_POWER:
                base, exponent = node.children()
                if not z3.is_int_value(exponent) or exponent.as_long() < 0:
                    raise VCAnalysisError("non-natural-polynomial-power")
                return _poly_power(
                    convert(base), exponent.as_long(), variable_count
                )
            raise VCAnalysisError(
                "non-polynomial-operation:{}".format(node.decl())
            )

        return convert(z3.simplify(expression, som=True))

    def _poly_expression(self, polynomial):
        terms = []
        for exponent in sorted(
            polynomial,
            key=lambda item: (sum(item), item),
        ):
            coefficient = polynomial[exponent]
            factors = []
            if coefficient != 1 or not any(exponent):
                factors.append(z3.IntVal(coefficient))
            for index, power in enumerate(exponent):
                factors.extend([self.symbols[self.variables[index]]] * power)
            terms.append(
                reduce(lambda left, right: left * right, factors)
            )
        return z3.simplify(z3.Sum(*terms), som=True) if terms else z3.IntVal(0)

    def _update_polynomials(self):
        if not self.updates:
            raise VCAnalysisError("transition-is-not-deterministic-polynomial")
        return [
            self._expression_poly(self.updates[name])
            for name in self.variables
        ]

    def _conditional_update_polynomials(self, maximum_conditions=3):
        """Enumerate a bounded exact polynomial expansion of ITE updates.

        A normalized deterministic C loop often represents a two-way branch
        as ``If(condition, then_value, else_value)`` in every next-state
        assignment.  The returned substitutions are the branch updates; an
        identity established for each of them is inductive for the original
        ITE transition.  This deliberately does not try to infer arbitrary
        path conditions or split an unbounded number of guards.
        """
        if not self.updates:
            return []
        conditions = []
        seen = set()

        def collect(expression):
            if z3.is_app_of(expression, z3.Z3_OP_ITE):
                condition = expression.children()[0]
                key = str(condition)
                if key not in seen:
                    seen.add(key)
                    conditions.append(condition)
            for child in expression.children():
                collect(child)

        for update in self.updates.values():
            collect(update)
        if not conditions or len(conditions) > maximum_conditions:
            return []

        def contains_ite(expression):
            return z3.is_app_of(expression, z3.Z3_OP_ITE) or any(
                contains_ite(child) for child in expression.children()
            )

        branches = []
        branch_keys = set()
        for values in product((False, True), repeat=len(conditions)):
            replacements = [
                (condition, z3.BoolVal(value))
                for condition, value in zip(conditions, values)
            ]
            expressions = [
                z3.simplify(
                    z3.substitute(self.updates[name], *replacements),
                    som=True,
                )
                for name in self.variables
            ]
            if any(contains_ite(expression) for expression in expressions):
                continue
            try:
                branch = tuple(
                    self._expression_poly(expression)
                    for expression in expressions
                )
            except VCAnalysisError:
                continue
            key = tuple(
                tuple(sorted(polynomial.items())) for polynomial in branch
            )
            if key not in branch_keys:
                branch_keys.add(key)
                branches.append(branch)
        return branches

    def has_conditional_updates(self):
        """Cheap guard for the branchwise nullspace frontend."""
        def contains_ite(expression):
            return z3.is_app_of(expression, z3.Z3_OP_ITE) or any(
                contains_ite(child) for child in expression.children()
            )
        return any(contains_ite(update) for update in self.updates.values())

    def _formula_degree(self, expression):
        if z3.is_true(expression) or z3.is_false(expression):
            return 0
        if (
            z3.is_and(expression)
            or z3.is_or(expression)
            or z3.is_not(expression)
            or z3.is_implies(expression)
        ):
            return max(
                (
                    self._formula_degree(child)
                    for child in expression.children()
                ),
                default=0,
            )
        if (
            z3.is_eq(expression)
            or z3.is_lt(expression)
            or z3.is_le(expression)
            or z3.is_gt(expression)
            or z3.is_ge(expression)
            or z3.is_distinct(expression)
        ):
            return max(
                (
                    _poly_degree(self._expression_poly(child))
                    for child in expression.children()
                ),
                default=0,
            )
        raise VCAnalysisError(
            "unsupported-formula-operation:{}".format(expression.decl())
        )

    def is_affine_problem(self):
        """Whether the exact VC lies in the deterministic affine fragment."""
        if not self.updates:
            return False
        try:
            update_degree = max(
                (
                    _poly_degree(self._expression_poly(update))
                    for update in self.updates.values()
                ),
                default=0,
            )
            formula_degree = max(
                self._formula_degree(self.precondition),
                self._formula_degree(self.postcondition),
                *[
                    self._formula_degree(guard)
                    for guard in self.guard_terms
                ]
            )
        except VCAnalysisError:
            return False
        return max(update_degree, formula_degree) <= 1

    @staticmethod
    def _syntactic_arithmetic_degree(expression):
        if z3.is_int_value(expression) or z3.is_rational_value(expression):
            return 0
        if z3.is_const(expression) and expression.num_args() == 0:
            return 1
        kind = expression.decl().kind()
        if z3.is_add(expression) or kind in (
            z3.Z3_OP_SUB,
            z3.Z3_OP_UMINUS,
        ):
            return max(
                (
                    VCAnalyzer._syntactic_arithmetic_degree(child)
                    for child in expression.children()
                ),
                default=0,
            )
        if z3.is_mul(expression):
            return sum(
                VCAnalyzer._syntactic_arithmetic_degree(child)
                for child in expression.children()
            )
        if kind == z3.Z3_OP_POWER:
            base, exponent = expression.children()
            if z3.is_int_value(exponent) and exponent.as_long() >= 0:
                return (
                    VCAnalyzer._syntactic_arithmetic_degree(base)
                    * exponent.as_long()
                )
        raise VCAnalysisError(
            "non-polynomial-arithmetic:{}".format(expression.decl())
        )

    @staticmethod
    def _syntactic_formula_degree(expression):
        if z3.is_true(expression) or z3.is_false(expression):
            return 0
        if (
            z3.is_and(expression)
            or z3.is_or(expression)
            or z3.is_not(expression)
            or z3.is_implies(expression)
        ):
            return max(
                (
                    VCAnalyzer._syntactic_formula_degree(child)
                    for child in expression.children()
                ),
                default=0,
            )
        if (
            z3.is_eq(expression)
            or z3.is_lt(expression)
            or z3.is_le(expression)
            or z3.is_gt(expression)
            or z3.is_ge(expression)
            or z3.is_distinct(expression)
        ):
            return max(
                (
                    VCAnalyzer._syntactic_arithmetic_degree(child)
                    for child in expression.children()
                ),
                default=0,
            )
        raise VCAnalysisError(
            "unsupported-boolean-operation:{}".format(expression.decl())
        )

    def is_linear_chc_problem(self):
        """Whether the complete VC is in quantifier-free linear arithmetic."""
        try:
            return max(
                self._syntactic_formula_degree(self.precondition),
                self._syntactic_formula_degree(self.transition),
                self._syntactic_formula_degree(self.postcondition),
            ) <= 1
        except VCAnalysisError:
            return False

    def linear_chc_candidate(self, timeout_milliseconds=1000):
        """Ask Spacer for one linear inductive cover, then return it as a candidate.

        Spacer is used only as a candidate generator.  The returned cover must
        still pass the ordinary LIPuS INIT/STEP/EXIT checker.
        """
        if not self.is_linear_chc_problem():
            return None
        suffix = hashlib.sha256(
            self.smt_path.encode("utf-8")
        ).hexdigest()[:12]
        sorts = [z3.IntSort() for _ in self.variables]
        invariant = z3.Function(
            "adasparce_inv_" + suffix,
            *(sorts + [z3.BoolSort()])
        )
        bad = z3.Function(
            "adasparce_bad_" + suffix, z3.BoolSort()
        )
        fixedpoint = z3.Fixedpoint()
        fixedpoint.set(
            engine="spacer",
            timeout=max(1, int(timeout_milliseconds)),
        )
        fixedpoint.register_relation(invariant, bad)

        constants = {}

        def collect(expression):
            if (
                z3.is_const(expression)
                and expression.num_args() == 0
                and not z3.is_int_value(expression)
                and not z3.is_rational_value(expression)
            ):
                constants[str(expression)] = expression
            for child in expression.children():
                collect(child)

        for expression in (
            self.precondition,
            self.transition,
            self.postcondition,
        ):
            collect(expression)
        fixedpoint.declare_var(
            *[constants[name] for name in sorted(constants)]
        )
        current = [self.symbols[name] for name in self.variables]
        primed = [self.primed[name] for name in self.variables]
        fixedpoint.rule(invariant(*current), self.precondition)
        fixedpoint.rule(
            invariant(*primed),
            z3.And(invariant(*current), self.transition),
        )
        fixedpoint.rule(
            bad(),
            z3.And(invariant(*current), z3.Not(self.postcondition)),
        )
        if fixedpoint.query(bad()) != z3.unsat:
            return None
        cover = fixedpoint.get_cover_delta(-1, invariant)
        candidate = z3.simplify(
            z3.substitute_vars(cover, *current)
        )
        if (
            z3.is_true(candidate)
            or z3.is_false(candidate)
            or not _symbols(candidate).issubset(set(self.variables))
        ):
            return None
        return candidate

    def _delta(self, polynomial, substitutions=None):
        substitutions = substitutions or self._update_polynomials()
        return _poly_add(
            _poly_substitute(
                polynomial, substitutions, len(self.variables)
            ),
            polynomial,
            scale=-1,
        )

    def _pre_substitutions(self):
        variable_count = len(self.variables)
        identity = []
        for index in range(variable_count):
            exponent = [0] * variable_count
            exponent[index] = 1
            identity.append({tuple(exponent): 1})
        assignments = {}
        variable_names = set(self.variables)
        for term in _flatten_and(self.precondition):
            if not z3.is_eq(term):
                continue
            left, right = term.children()
            if self._is_named_const(left, variable_names):
                name, value = str(left), right
            elif self._is_named_const(right, variable_names):
                name, value = str(right), left
            else:
                continue
            if name in _symbols(value):
                continue
            try:
                assignments[name] = self._expression_poly(value)
            except VCAnalysisError:
                continue

        substitutions = list(identity)
        for name, polynomial in assignments.items():
            substitutions[self.variables.index(name)] = polynomial
        # Close acyclic chains such as x=y, y=0.
        for _ in range(variable_count):
            changed = False
            next_substitutions = []
            for polynomial in substitutions:
                replaced = _poly_substitute(
                    polynomial, substitutions, variable_count
                )
                next_substitutions.append(replaced)
                changed = changed or replaced != polynomial
            substitutions = next_substitutions
            if not changed:
                break
        return substitutions

    def _constant_initial_value(self, variable_name):
        variable = self.symbols[variable_name]
        for term in _flatten_and(self.precondition):
            if not z3.is_eq(term):
                continue
            left, right = term.children()
            if z3.eq(left, variable) and z3.is_int_value(right):
                return right
            if z3.eq(right, variable) and z3.is_int_value(left):
                return left
        return None

    def _precondition_implies(self, expression, timeout_ms=100):
        """Return true only when Z3 proves the entry implication.

        This check controls whether a counter boundary needs an initial-state
        disjunct.  ``unknown`` is deliberately treated as non-implication, so
        it can only make the generated invariant weaker, never unsoundly
        strengthen it.
        """
        query = z3.And(self.precondition, z3.Not(expression))
        try:
            simplified = z3.Then(
                z3.With(
                    z3.Tactic("simplify"),
                    som=True,
                    sort_sums=True,
                ),
                z3.Tactic("solve-eqs"),
                z3.With(
                    z3.Tactic("simplify"),
                    som=True,
                    sort_sums=True,
                ),
            )(query)
            if not simplified or all(
                z3.is_false(goal.as_expr()) for goal in simplified
            ):
                return True
        except z3.Z3Exception:
            pass
        solver = z3.Solver()
        solver.set("timeout", int(timeout_ms))
        solver.add(query)
        return solver.check() == z3.unsat

    def _precondition_state_rewrites(self):
        """Return acyclic state-variable rewrites exposed by the precondition."""
        state_names = set(self.variables)
        rewrites = {}
        for term in _flatten_and(self.precondition):
            if not z3.is_eq(term):
                continue
            left, right = term.children()
            if self._is_named_const(left, state_names):
                if str(left) not in _symbols(right):
                    rewrites[str(left)] = right
            elif self._is_named_const(right, state_names):
                if str(right) not in _symbols(left):
                    rewrites[str(right)] = left
        for _ in range(len(rewrites)):
            changed = False
            for name, expression in list(rewrites.items()):
                replacement = z3.simplify(z3.substitute(
                    expression,
                    *[
                        (self.symbols[other], value)
                        for other, value in rewrites.items()
                        if other != name
                    ],
                ), som=True)
                changed = changed or not z3.eq(replacement, expression)
                rewrites[name] = replacement
            if not changed:
                break
        return rewrites

    def _polynomial_is_zero_at_entry(self, polynomial, rewrites=None):
        rewrites = (
            self._precondition_state_rewrites()
            if rewrites is None else rewrites
        )
        if not rewrites:
            return False
        expression = z3.substitute(
            self._poly_expression(polynomial),
            *[
                (self.symbols[name], value)
                for name, value in rewrites.items()
            ],
        )
        expression = z3.simplify(expression, som=True)
        return z3.is_int_value(expression) and expression.as_long() == 0

    @staticmethod
    def _residual(atom):
        if not z3.is_eq(atom):
            return None
        left, right = atom.children()
        return z3.simplify(left - right, som=True)

    def _exit_properties(self):
        post = self.postcondition
        if z3.is_or(post):
            return list(post.children())
        if z3.is_implies(post):
            return [post.children()[1]]
        return [post]

    @staticmethod
    def _equality_atoms(expression):
        return [
            atom
            for atom in _flatten_and(expression)
            if z3.is_eq(atom)
        ]

    def candidates(self, max_degree=3, max_clauses=3):
        linear_cover = self.linear_chc_candidate()
        direct = self.finite_difference_candidates(
            max_degree=max_degree, max_clauses=max_clauses
        )
        conserved = self.conserved_candidates(
            # Degree-four nullspaces grow much faster than the targeted
            # finite-difference closure.  Conservation search is capped at
            # cubic terms; quartic exit recurrences are still handled exactly
            # by ``direct`` above.
            max_degree=min(max_degree, 3),
            max_clauses=max_clauses,
        )
        seen = set()
        result = []
        generated = []
        if linear_cover is not None:
            cover_clauses = (
                len(_flatten_and(linear_cover))
                if z3.is_and(linear_cover)
                else 1
            )
            generated.append(
                (
                    linear_cover,
                    "vc-linear-spacer-cover",
                    1,
                    cover_clauses,
                    (str(linear_cover),),
                )
            )
        generated.extend(direct)
        generated.extend(conserved)
        for candidate in generated:
            key = str(candidate[0])
            if key not in seen:
                result.append(candidate)
                seen.add(key)
        return result
