"""Semantic bounds, counter relations, weakening and update closure."""

from itertools import combinations
import z3
from pycparser import c_ast
from SparCE.symbolic.candidate import CandidateBranch


class SemanticGeneration:
    """Semantic bounds, counter relations, weakening and update closure."""

    @staticmethod
    def _variables(c_path, smt_path):
        from SparCE.symbolic.variables import candidate_variables

        return candidate_variables(c_path, smt_path)

    @staticmethod
    def _residual(postcondition):
        if (
            z3.is_eq(postcondition)
            or z3.is_ge(postcondition)
            or z3.is_le(postcondition)
            or z3.is_gt(postcondition)
            or z3.is_lt(postcondition)
        ):
            left, right = postcondition.children()
            return z3.simplify(left - right)
        return None

    @staticmethod
    def _total_degree(expression):
        from SparCE.ada_engine import AdaSparCEEngine

        if z3.is_int_value(expression) or (
            z3.is_const(expression) and expression.num_args() == 0
        ):
            return 0 if z3.is_int_value(expression) else 1
        if z3.is_add(expression):
            return max(
                (AdaSparCEEngine._total_degree(child) for child in expression.children()),
                default=0,
            )
        if z3.is_mul(expression):
            return sum(
                AdaSparCEEngine._total_degree(child)
                for child in expression.children()
            )
        if expression.decl().kind() == z3.Z3_OP_POWER:
            base, exponent = expression.children()
            if z3.is_int_value(exponent):
                return AdaSparCEEngine._total_degree(base) * exponent.as_long()
        return max(
            (AdaSparCEEngine._total_degree(child) for child in expression.children()),
            default=0,
        )

    @staticmethod
    def _symbols_in(expression):
        names = set()

        def visit(node):
            if z3.is_const(node) and node.num_args() == 0 and not z3.is_int_value(node):
                names.add(str(node))
            for child in node.children():
                visit(child)

        visit(expression)
        return names

    def _affine_relations(self, analyzer):
        updates = analyzer.constant_additive_updates()
        relations = []
        for left, right in combinations(sorted(updates), 2):
            left_initial = analyzer.constant_initial(left)
            right_initial = analyzer.constant_initial(right)
            if left_initial is None or right_initial is None:
                continue
            left_symbol = analyzer.translator.symbols[left]
            right_symbol = analyzer.translator.symbols[right]
            relation = (
                updates[right] * (left_symbol - left_initial)
                == updates[left] * (right_symbol - right_initial)
            )
            relations.append(z3.simplify(relation))
        return relations

    @staticmethod
    def _known_sign(expression, nonnegative_names):
        """Return 1 for known nonnegative, -1 for nonpositive, else 0.

        This deliberately recognizes only a small exact fragment.  Unknown
        signs are never guessed; every resulting candidate is still checked
        independently by the SMT verifier.
        """
        from SparCE.ada_engine import AdaSparCEEngine

        expression = z3.simplify(expression)
        if z3.is_int_value(expression):
            value = expression.as_long()
            return 1 if value >= 0 else -1
        if (
            z3.is_const(expression)
            and expression.num_args() == 0
            and str(expression) in nonnegative_names
        ):
            return 1
        if z3.is_mul(expression):
            constant = 1
            symbolic = []
            for child in expression.children():
                if z3.is_int_value(child):
                    constant *= child.as_long()
                else:
                    symbolic.append(child)
            if len(symbolic) == 1:
                child_sign = AdaSparCEEngine._known_sign(
                    symbolic[0], nonnegative_names
                )
                if child_sign:
                    return child_sign if constant >= 0 else -child_sign
        if z3.is_add(expression):
            signs = [
                AdaSparCEEngine._known_sign(
                    child, nonnegative_names
                )
                for child in expression.children()
            ]
            if signs and all(sign == 1 for sign in signs):
                return 1
            if signs and all(sign == -1 for sign in signs):
                return -1
        return 0

    def _constant_entry_branches(self, analyzer):
        """Try ``post`` strengthened by constant loop-entry bounds.

        Unlike the monotone mechanism, no sign reasoning is attempted here:
        every mutated variable with a known constant initial value generates
        ``var >= c`` / ``var <= c`` candidates, and the exact SMT checker
        decides inductivity.  This catches loops whose entry values bound the
        whole iteration (e.g. ``x`` and ``y`` only grow from ``1``).
        """
        post = analyzer.postcondition
        if post is None or self.config.max_clauses < 2:
            return []
        bounded = []
        for name in sorted(analyzer.mutated):
            initial = analyzer.constant_initial(name)
            if initial is None:
                continue
            symbol = analyzer.translator.symbols.get(name)
            if symbol is None:
                continue
            bounded.append(
                (name, symbol >= z3.IntVal(initial), symbol <= z3.IntVal(initial))
            )
        if not bounded:
            return []
        branches = []
        # Single-entry bounds first (cheap, high yield), then pairs.
        max_extra = min(2, self.config.max_clauses - 1, len(bounded))
        for extra_count in range(max_extra, 0, -1):
            for selected in combinations(bounded, extra_count):
                for orientation in range(2):
                    clauses = [post]
                    clauses.extend(
                        bound[1 + orientation] for bound in selected
                    )
                    formula = z3.And(*clauses)
                    branches.append(
                        CandidateBranch(
                            formula,
                            140.0 + extra_count - 5.0 * orientation,
                            "typed-constant-entry-bounds",
                            self._total_degree(formula),
                            len(clauses),
                            tuple(name for name, _, _ in selected),
                        )
                    )
        return branches

    def _monotone_initial_branches(self, analyzer):
        """Strengthen the postcondition with proven monotone entry bounds."""
        post = analyzer.postcondition
        if post is None or self.config.max_clauses < 2:
            return []
        nonnegative = analyzer.explicit_nonnegative()
        stable_bounds = []
        for name in sorted(analyzer.mutated):
            initial = analyzer.constant_initial(name)
            update = analyzer.updates.get(name)
            if initial is None or update is None:
                continue
            symbol = analyzer.translator.symbols[name]
            sign = self._known_sign(
                z3.simplify(update - symbol), nonnegative
            )
            if sign > 0:
                stable_bounds.append(
                    (name, symbol >= z3.IntVal(initial))
                )
            elif sign < 0:
                stable_bounds.append(
                    (name, symbol <= z3.IntVal(initial))
                )
        branches = []
        maximum_extra = min(
            self.config.max_clauses - 1, len(stable_bounds)
        )
        for extra_count in range(maximum_extra, 0, -1):
            for selected in combinations(stable_bounds, extra_count):
                clauses = [post]
                clauses.extend(bound for _, bound in selected)
                formula = z3.And(*clauses)
                branches.append(
                    CandidateBranch(
                        formula,
                        150.0 + extra_count,
                        "typed-monotone-entry-bounds",
                        self._total_degree(formula),
                        len(clauses),
                        tuple(name for name, _ in selected),
                    )
                )
        return branches

    def _precondition_frame_branches(self, analyzer):
        """Try postconditions strengthened by explicit loop-entry assumptions."""
        if not analyzer.assumptions or self.config.max_clauses < 2:
            return []
        branches = []
        maximum_extra = min(
            self.config.max_clauses - 1,
            len(analyzer.assumptions),
        )
        for extra_count in range(maximum_extra, 0, -1):
            for selected in combinations(
                analyzer.assumptions, extra_count
            ):
                formula = z3.And(analyzer.postcondition, *selected)
                branches.append(
                    CandidateBranch(
                        formula,
                        155.0 + extra_count,
                        "typed-precondition-frame",
                        self._total_degree(formula),
                        1 + extra_count,
                        tuple(str(item) for item in selected),
                    )
                )
        return branches

    def _affine_exit_branches(self, analyzer):
        """Combine synchronized counters with a one-sided exit boundary."""
        post = analyzer.postcondition
        if (
            post is None
            or not z3.is_eq(post)
            or self.config.max_clauses < 2
        ):
            return []
        left, right = post.children()
        target_name = None
        target_value = None
        if (
            z3.is_const(left)
            and left.num_args() == 0
            and z3.is_int_value(right)
        ):
            target_name = str(left)
            target_value = right.as_long()
        elif (
            z3.is_const(right)
            and right.num_args() == 0
            and z3.is_int_value(left)
        ):
            target_name = str(right)
            target_value = left.as_long()
        if target_name not in analyzer.updates:
            return []
        target = analyzer.translator.symbols[target_name]
        delta = z3.simplify(analyzer.updates[target_name] - target)
        if not z3.is_int_value(delta) or delta.as_long() == 0:
            return []
        boundary = (
            target <= target_value
            if delta.as_long() > 0
            else target >= target_value
        )
        branches = []
        for relation in self._affine_relations(analyzer):
            formula = z3.And(relation, boundary)
            branches.append(
                CandidateBranch(
                    formula,
                    154.0,
                    "typed-affine-exit-boundary",
                    self._total_degree(formula),
                    2,
                    (str(relation), str(boundary)),
                )
            )
        return branches

    def _counter_branches(self, analyzer):
        guard = analyzer.guard_ast
        post = analyzer.postcondition
        if not isinstance(guard, c_ast.BinaryOp):
            return []
        if not isinstance(guard.left, c_ast.ID) or not isinstance(guard.right, c_ast.ID):
            return []
        counter, bound = guard.left.name, guard.right.name
        if counter not in analyzer.variables or bound not in analyzer.variables:
            return []
        counter_symbol = analyzer.translator.symbols[counter]
        bound_symbol = analyzer.translator.symbols[bound]
        if bound not in self._symbols_in(post):
            return []
        lifted = z3.simplify(z3.substitute(post, (bound_symbol, counter_symbol)))
        base_clauses = [lifted]
        if guard.op == "<":
            base_clauses.append(counter_symbol <= bound_symbol)
        branches = [
            CandidateBranch(
                z3.And(*base_clauses),
                120.0,
                "typed-counter-lift",
                self._total_degree(z3.And(*base_clauses)),
                len(base_clauses),
            )
        ]
        if z3.is_lt(lifted) or z3.is_le(lifted) or z3.is_gt(lifted) or z3.is_ge(lifted):
            left, right = lifted.children()
            equality_clauses = [left == right]
            if guard.op == "<":
                equality_clauses.append(counter_symbol <= bound_symbol)
            branches.append(
                CandidateBranch(
                    z3.And(*equality_clauses),
                    118.0,
                    "typed-counter-boundary",
                    self._total_degree(z3.And(*equality_clauses)),
                    len(equality_clauses),
                )
            )
        affine = self._affine_relations(analyzer)
        expanded = list(branches)
        for branch in branches:
            for relation in affine:
                if branch.clauses < self.config.max_clauses:
                    expanded.append(
                        CandidateBranch(
                            z3.And(branch.formula, relation),
                            branch.score + 10.0,
                            branch.mechanism + "+sync",
                            branch.degree,
                            branch.clauses + 1,
                        )
                    )
        return expanded

    def _remaining_work_branches(self, analyzer, pool):
        residual = self._residual(analyzer.postcondition)
        if residual is None:
            return []
        post_mutated = self._symbols_in(analyzer.postcondition).intersection(
            analyzer.mutated
        )
        remaining_names = analyzer.mutated.difference(post_mutated)
        index_names = analyzer.variables
        branches = []
        for monomial in pool.ranked():
            if monomial.degree < 2 or monomial.degree > self.config.max_degree:
                continue
            used_names = {index_names[index] for index in monomial.variables_used}
            if not used_names or not used_names.issubset(remaining_names):
                continue
            distinct_bonus = 8.0 * len(used_names)
            expression = monomial.to_z3(
                [analyzer.translator.symbols[name] for name in analyzer.variables]
            )
            base_score = 90.0 + pool.score(monomial) + distinct_bonus
            for sign in (1, -1):
                branches.append(
                    CandidateBranch(
                        # Put the newly selected separating feature first.
                        # Equivalent NIA polynomials can differ drastically
                        # in Z3 runtime depending on AST term order.
                        z3.simplify(sign * expression + residual) == 0,
                        base_score,
                        "typed-remaining-work",
                        monomial.degree,
                        1,
                        (monomial.pretty_print(analyzer.variables),),
                    )
                )
        return sorted(branches, key=lambda branch: -branch.score)

    def _post_weakening_branches(self, analyzer):
        """Weaken an equality postcondition into one-sided inequalities.

        INIT failures mean the candidate is too strong at loop entry.  If the
        postcondition is an equality ``f == g`` (or a conjunction containing
        equalities), relaxing each equality to ``f <= g`` or ``f >= g`` admits
        more entry states while still bounding the exit property.

        This generator produces both orientations because the Checker alone
        decides which side is inductive.
        """
        post = analyzer.postcondition
        if post is None:
            return []
        equalities = self._collect_equalities(post)
        if not equalities:
            return []
        branches = []
        for eq in equalities:
            left, right = eq.children()
            residual = z3.simplify(left - right)
            degree = self._total_degree(residual)
            if degree < 2:
                continue
            branches.append(
                CandidateBranch(
                    z3.simplify(residual <= 0),
                    115.0,
                    "typed-post-weakening-le",
                    degree,
                    1,
                    ("<=0",),
                )
            )
            branches.append(
                CandidateBranch(
                    z3.simplify(residual >= 0),
                    115.0,
                    "typed-post-weakening-ge",
                    degree,
                    1,
                    (">=0",),
                )
            )
            if self.config.max_clauses >= 2:
                for name in sorted(analyzer.mutated):
                    initial = analyzer.constant_initial(name)
                    if initial is None:
                        continue
                    symbol = analyzer.translator.symbols[name]
                    for relation, label in ((z3.simplify(residual <= 0), "le"),
                                            (z3.simplify(residual >= 0), "ge")):
                        branches.append(
                            CandidateBranch(
                                z3.And(relation, symbol >= z3.IntVal(initial)),
                                120.0,
                                "typed-post-weakening-" + label + "+entry",
                                degree,
                                2,
                                (label, name),
                            )
                        )
        return branches

    @staticmethod
    def _collect_equalities(expression):
        """Flatten a conjunction and return all equality sub-formulas."""
        from SparCE.ada_engine import AdaSparCEEngine

        result = []
        if z3.is_and(expression):
            for child in expression.children():
                result.extend(AdaSparCEEngine._collect_equalities(child))
            return result
        if z3.is_eq(expression):
            result.append(expression)
        return result

    def _term_dropping_branches(self, analyzer):
        """Drop the highest-degree term from a polynomial postcondition.

        If the postcondition is ``c0 + c1*x + c2*x*y == 0`` and INIT fails,
        the cross term ``c2*x*y`` may be the culprit (too strong at entry).
        Dropping it yields ``c0 + c1*x == 0``, which is weaker and may be
        inductive.  The Checker still validates the result.

        Handles both single equality and conjunction postconditions.
        Only applies when the residual decomposes into a sum of monomial
        terms with at least one nonlinear term.
        """
        post = analyzer.postcondition
        if post is None:
            return []
        equalities = self._collect_equalities(post)
        if not equalities:
            return []
        branches = []
        for eq in equalities:
            left, right = eq.children()
            residual = z3.simplify(left - right)
            simplified = z3.simplify(residual, som=True)
            if not z3.is_add(simplified):
                continue
            children = list(simplified.children())
            if len(children) < 2:
                continue
            degrees = [self._total_degree(child) for child in children]
            max_degree = max(degrees)
            if max_degree < 2:
                continue
            for index, child in enumerate(children):
                if self._total_degree(child) < max_degree:
                    continue
                kept = [c for i, c in enumerate(children) if i != index]
                if not kept:
                    continue
                dropped = z3.simplify(z3.Sum(kept))
                branches.append(
                    CandidateBranch(
                        z3.simplify(dropped == 0),
                        110.0,
                        "typed-term-dropping",
                        self._total_degree(dropped),
                        1,
                        (str(child),),
                    )
                )
                if self.config.max_clauses >= 2:
                    for name in sorted(analyzer.mutated):
                        initial = analyzer.constant_initial(name)
                        if initial is None:
                            continue
                        symbol = analyzer.translator.symbols[name]
                        branches.append(
                            CandidateBranch(
                                z3.And(
                                    z3.simplify(dropped == 0),
                                    symbol >= z3.IntVal(initial),
                                ),
                                112.0,
                                "typed-term-dropping+entry",
                                self._total_degree(dropped),
                                2,
                                (str(child), name),
                            )
                        )
                break
        return branches

    def _guard_split_branches(self, analyzer):
        """Split the postcondition into guard-conditional clauses.

        When the postcondition fails INIT, it is often because the
        postcondition only holds at *exit*, not at *entry*.  The standard
        fix is to conjoin the postcondition with a guard-relaxed invariant:

            I = And(Implies(guard, loop_inv), Implies(Not(guard), post))

        where ``loop_inv`` is a simpler relation that holds throughout the
        loop.  This generator tries several candidates for ``loop_inv``:

          - the postcondition itself (weakened to an inequality),
          - counter × addend relations extracted from the updates,
          - affine relations between mutated variables.
        """
        post = analyzer.postcondition
        if post is None or self.config.max_clauses < 2:
            return []
        guard = getattr(analyzer, "guard_z3", None)
        if guard is None:
            try:
                guard = analyzer.translator.expression(analyzer.guard_ast)
            except (ValueError, AttributeError):
                return []
        branches = []

        # Strategy 1: counter × addend invariant
        # If a variable `counter` is incremented by `addend` each iteration,
        # and `sum` accumulates `addend`, then sum == counter * addend.
        # Detect counter from updates AND from the guard (a variable compared
        # in the guard that may be updated elsewhere in the SMT transition).
        updates = analyzer.constant_additive_updates()
        # Also check guard for counter variables not in constant_additive_updates
        # (the transition may update them in a way the C parser misses).
        guard_vars = self._symbols_in(guard)
        counter_candidates = set(updates.keys())
        for name in guard_vars:
            if name in analyzer.variables and name in analyzer.mutated:
                counter_candidates.add(name)
        for name in sorted(counter_candidates):
            if name not in analyzer.translator.symbols:
                continue
            sym = analyzer.translator.symbols[name]
            delta = updates.get(name)
            # Look for another variable that accumulates delta
            for accum_name in sorted(analyzer.mutated):
                if accum_name == name or accum_name not in analyzer.updates:
                    continue
                accum_sym = analyzer.translator.symbols[accum_name]
                accum_update = analyzer.updates[accum_name]
                accum_diff = z3.simplify(accum_update - accum_sym)
                # Case 1: both counter and accumulator have constant deltas
                if z3.is_int_value(accum_diff) and accum_diff.as_long() != 0:
                    accum_delta = accum_diff.as_long()
                    effective_delta = (
                        delta if delta is not None and delta != 0
                        else 1
                    )
                    if accum_delta == effective_delta:
                        accum_init = analyzer.constant_initial(accum_name)
                        counter_init = analyzer.constant_initial(name)
                        if (
                            accum_init is not None
                            and counter_init is not None
                            and accum_init == 0
                            and counter_init == 0
                        ):
                            inv = (
                                accum_sym == sym * z3.IntVal(effective_delta)
                            )
                            formula = z3.And(
                                z3.Implies(guard, inv),
                                z3.Implies(z3.Not(guard), post),
                            )
                            branches.append(
                                CandidateBranch(
                                    z3.simplify(formula),
                                    160.0,
                                    "typed-guard-split-counter",
                                    max(self._total_degree(inv),
                                        self._total_degree(post)),
                                    2,
                                    (accum_name, name),
                                )
                            )
                            branches.append(
                                CandidateBranch(
                                    z3.simplify(inv),
                                    155.0,
                                    "typed-counter-accumulator",
                                    self._total_degree(inv),
                                    1,
                                    (accum_name, name),
                                )
                            )
                # Case 2: accumulator adds a VARIABLE each iteration
                # (e.g. sn += a, i += 1 → sn == i * a)
                # The accum_diff is a symbolic expression (like `a`).
                # If counter increments by 1 and accumulator increments by
                # the same symbolic value each step, then
                # accum == counter * accum_diff (if both start at 0).
                elif not z3.is_int_value(accum_diff) and delta == 1:
                    accum_init = analyzer.constant_initial(accum_name)
                    counter_init = analyzer.constant_initial(name)
                    if (
                        accum_init is not None
                        and counter_init is not None
                        and accum_init == 0
                        and counter_init == 0
                    ):
                        # sn == i * a  (where a is the symbolic increment)
                        inv = (accum_sym == sym * accum_diff)
                        formula = z3.And(
                            z3.Implies(guard, inv),
                            z3.Implies(z3.Not(guard), post),
                        )
                        branches.append(
                            CandidateBranch(
                                z3.simplify(formula),
                                165.0,
                                "typed-guard-split-counter-var",
                                max(self._total_degree(inv),
                                    self._total_degree(post)),
                                2,
                                (accum_name, name),
                            )
                        )
                        # Also try the bare invariant
                        branches.append(
                            CandidateBranch(
                                z3.simplify(inv),
                                158.0,
                                "typed-counter-accumulator-var",
                                self._total_degree(inv),
                                1,
                                (accum_name, name),
                            )
                        )

        # Strategy 2: post weakened to inequality as loop_inv
        equalities = self._collect_equalities(post)
        for eq in equalities:
            left, right = eq.children()
            residual = z3.simplify(left - right)
            if self._total_degree(residual) < 2:
                continue
            for relation, label in (
                (residual <= z3.IntVal(0), "le"),
                (residual >= z3.IntVal(0), "ge"),
            ):
                formula = z3.And(
                    z3.Implies(guard, z3.simplify(relation)),
                    z3.Implies(z3.Not(guard), post),
                )
                branches.append(
                    CandidateBranch(
                        z3.simplify(formula),
                        145.0,
                        "typed-guard-split-weaken-" + label,
                        self._total_degree(residual),
                        2,
                        (label,),
                    )
                )

        # Strategy 3: disjunctive post when post is itself Or(...)
        if z3.is_or(post):
            for child in post.children():
                branches.append(
                    CandidateBranch(
                        z3.simplify(child),
                        135.0,
                        "typed-disjunctive-post-branch",
                        self._total_degree(child),
                        1,
                        (str(child)[:40],),
                    )
                )
                # Also try child conjoined with guard
                if self.config.max_clauses >= 2:
                    branches.append(
                        CandidateBranch(
                            z3.And(child, z3.Not(guard)),
                            150.0,
                            "typed-disjunctive-post-exit",
                            self._total_degree(child),
                            2,
                            (str(child)[:40],),
                        )
                    )

        return branches

    def _nonnegative_branches(self, analyzer):
        post = analyzer.postcondition
        names = sorted(
            analyzer.explicit_nonnegative().intersection(analyzer.mutated)
        )
        priorities = {}
        for name in names:
            symbol = analyzer.translator.symbols[name]
            update = analyzer.updates.get(name)
            priority = 0.0
            if update is not None:
                difference = z3.simplify(update - symbol)
                if z3.is_mul(difference):
                    children = difference.children()
                    if len(children) == 2 and str(children[0]) == str(children[1]):
                        priority = 20.0
                    else:
                        priority = 8.0
                elif z3.is_int_value(difference) and difference.as_long() >= 0:
                    priority = 5.0
            priorities[name] = priority
        branches = []
        maximum_extra = min(self.config.max_clauses - 1, len(names))
        for extra_count in range(1, maximum_extra + 1):
            for selected in combinations(names, extra_count):
                clauses = [post]
                clauses.extend(
                    analyzer.translator.symbols[name] >= 0 for name in selected
                )
                branches.append(
                    CandidateBranch(
                        z3.And(*clauses),
                        100.0
                        + 5.0 * extra_count
                        + sum(priorities[name] for name in selected),
                        "typed-sign-clauses",
                        self._total_degree(z3.And(*clauses)),
                        len(clauses),
                        tuple(selected),
                    )
                )
        return branches

    def _update_closure_branches(self, analyzer):
        """Lift a post residual with its exact one-step polynomial difference."""
        if not self.config.update_closure:
            return []
        guard = getattr(analyzer, "guard_z3", None)
        if guard is None:
            try:
                analyzer.translator.expression(analyzer.guard_ast)
            except (ValueError, AttributeError):
                return []
        residual = self._residual(analyzer.postcondition)
        if residual is None or not analyzer.updates:
            return []
        substitutions = [
            (analyzer.translator.symbols[name], update)
            for name, update in analyzer.updates.items()
        ]
        after = z3.simplify(z3.substitute(residual, *substitutions), som=True)
        difference = z3.simplify(after - residual, som=True)
        if z3.is_int_value(difference):
            return []
        degree = max(self._total_degree(residual), self._total_degree(difference))
        if degree > self.config.max_degree or self.config.max_clauses < 2:
            return []
        common = dict(
            score=125.0,
            mechanism="typed-update-closure",
            degree=degree,
            clauses=2,
            monomials=(str(difference),),
        )
        return [
            CandidateBranch(
                z3.And(analyzer.postcondition, difference == 0),
                **common
            ),
            CandidateBranch(
                z3.And(residual == 0, difference == 0),
                **common
            ),
        ]

    def _is_linear_program(self, analyzer):
        """Return True if all updates and the postcondition are linear."""
        if getattr(
            self.config, "linear_fast_path_guard", False
        ):
            # A linear loop body with a nonlinear pre-loop
            # initialization (e.g. an entry product assignment) still
            # needs a degree-2 invariant; the linear fast path would
            # only burn its budget on hopeless linear combinations.
            for value in analyzer.initial_values.values():
                if self._z3_degree(value) > 1:
                    return False
        for name, rhs in analyzer.updates.items():
            symbol = analyzer.translator.symbols[name]
            diff = z3.simplify(rhs - symbol)
            if self._z3_degree(diff) > 1:
                return False
        if self._z3_degree(analyzer.postcondition) > 1:
            return False
        return True

    @staticmethod
    def _z3_degree(expression):
        # Shared implementation: identical semantics to the checker-side
        # degree function (SMT_verifier.expr_degree); delegation keeps a
        # single source of truth without changing behavior.
        from SMT_Solver.SMT_verifier import expr_degree

        return expr_degree(expression)
