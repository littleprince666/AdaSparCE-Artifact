"""Candidate checks, counterexample replay and original-VC portfolios."""

from dataclasses import replace
import time
import z3
from SMT_Solver.SMT_verifier import CheckFailureType
from SMT_Solver.SMT_verifier import CheckResult
from SMT_Solver.SMT_verifier import SMT_verifier
from SparCE.feedback.ce_prefilter import ce_proves_failure
from SparCE.logging_utils import stable_hash
from SparCE.ranking.ranker_trace import candidate_formula_hash
from SparCE.symbolic.candidate import CandidateBranch


class CandidateChecking:
    """Candidate checks, counterexample replay and original-VC portfolios."""

    MULTI_SEED_PORTFOLIO = (0, 1, 2, 3)

    def _remaining_check_ms(self, requested):
        deadline = getattr(self, "_task_wall_deadline", None)
        if deadline is None:
            return max(0, int(requested))
        return max(0, min(int(requested), int(1000 * (deadline - time.perf_counter()))))


    def _bounded_solver_check(self, solver, timeout_ms):
        remaining = self._remaining_check_ms(timeout_ms)
        if remaining < 1:
            return z3.unknown
        solver.set("timeout", remaining)
        status, _ = SMT_verifier._check_with_watchdog(solver, remaining / 1000.0)
        return status


    def _checker_budget_exhausted(self, checked):
        limit = int(getattr(self.config, "max_checker_calls", 0))
        return bool(limit and checked >= limit)

    def _reset_prefilter_task(self):
        self._prefilter_counterexamples = []
        self._prefilter_signatures = set()
        self._prefilter_rejections = 0
        self._prefilter_materials = []

    def _record_prefilter_counterexample(self, result):
        """Remember a typed counterexample for sound replay filtering."""
        if not getattr(self.config, "counterexample_prefilter", False):
            return
        if result is None or result.counterexample is None:
            return
        if self._failure_name(result.failure_type) not in (
            "INIT", "STEP", "EXIT"
        ):
            return
        signature = stable_hash(result.counterexample)
        if signature in self._prefilter_signatures:
            return
        limit = int(getattr(
            self.config, "counterexample_prefilter_max_records", 64
        ))
        self._prefilter_counterexamples.append(
            (result.failure_type, result.counterexample)
        )
        self._prefilter_signatures.add(signature)
        while len(self._prefilter_counterexamples) > limit:
            dropped_failure, dropped = (
                self._prefilter_counterexamples.pop(0)
            )
            self._prefilter_signatures.discard(stable_hash(dropped))

    def _prefilter_rejects(self, branch):
        """Return the witnessing failure type when replay refutes the
        candidate, otherwise None.  Never uses the solver."""
        if not getattr(self.config, "counterexample_prefilter", False):
            return None
        if not self._prefilter_counterexamples:
            return None
        # Branches checked through the specialized contextual/normalized
        # frontends use their own query encodings; keep them untouched.
        if "sparse-recurrence-closure" in branch.mechanism:
            return None
        if branch.mechanism == "typed-update-closure":
            return None
        for failure_type, counterexample in self._prefilter_counterexamples:
            if ce_proves_failure(
                branch.formula, failure_type, counterexample
            ):
                return failure_type
        return None

    def _contextual_original_vc_check(self, smt_path, candidate):
        """Prove a candidate against the original VC after exact splitting.

        Older LIPuS VCs encode one loop step as a disjunction of a stuttering
        branch and the real update, with several SSA auxiliaries.  Sending the
        combined nonlinear disjunction directly to QF_NIA often times out even
        when each branch reduces to a polynomial identity.  Splitting that
        top-level transition disjunction is logically exact: the STEP VC is
        UNSAT iff every branch-specific STEP VC is UNSAT.

        All transformations below are Z3 equisatisfiability-preserving
        tactics.  Only an UNSAT result for every original INIT/STEP/EXIT
        obligation is accepted as success; SAT and UNKNOWN remain failures.
        """
        try:
            from SparCE.verification.proof_obligations import (
                original_queries,
                split_query,
            )

            queries = original_queries(smt_path, candidate)
        except (ValueError, z3.Z3Exception) as error:
            return (
                z3.unknown,
                CheckFailureType.UNKNOWN,
                0.0,
                "original-vc-parse:{}".format(error),
                (),
            )
        obligations = tuple(
            (
                (
                    failure,
                    (
                        split_query(query)
                        if failure == CheckFailureType.STEP
                        else (query,)
                    ),
                )
                for failure, query in zip(
                    (
                        CheckFailureType.INIT,
                        CheckFailureType.STEP,
                        CheckFailureType.EXIT,
                    ),
                    queries,
                )
            )
        )
        timeout_ms = max(1, int(self.config.checker_timeout_seconds * 1000))
        wall_deadline = getattr(self, "_task_wall_deadline", None)
        if wall_deadline is not None:
            remaining_ms = int((wall_deadline - time.perf_counter()) * 1000)
            if remaining_ms < 50:
                return (
                    z3.unknown,
                    CheckFailureType.TIMEOUT,
                    0.0,
                    "wall-budget-exhausted",
                    (),
                )
            timeout_ms = max(25, min(timeout_ms, remaining_ms))
        contextual_timeout_ms = max(25, min(250, timeout_ms // 4))
        contextual_tactic = z3.Then(
            z3.With(z3.Tactic("simplify"), som=True, sort_sums=True),
            z3.Tactic("solve-eqs"),
            z3.TryFor(z3.Tactic("ctx-solver-simplify"), contextual_timeout_ms),
            z3.With(z3.Tactic("simplify"), som=True, sort_sums=True),
        )
        started = time.perf_counter()
        vc_results = []
        solvers_used = []
        for failure_type, branch_queries in obligations:
            if len(branch_queries) != 1:
                continue
            direct = z3.Solver()
            direct.set("timeout", int(timeout_ms))
            direct.set("random_seed", 0)
            direct.add(branch_queries[0])
            direct_status = self._bounded_solver_check(direct, timeout_ms)
            if direct_status == z3.sat:
                return (
                    direct_status,
                    failure_type,
                    time.perf_counter() - started,
                    "z3-original-direct",
                    (
                        {
                            "vc": failure_type.value,
                            "status": "sat",
                            "failure_type": failure_type.value,
                            "solver_name": "z3-original-direct",
                            "trace_source": "adasparce-original-vc",
                        },
                    ),
                )
        for failure_type, branch_queries in obligations:
            for branch_index, query in enumerate(branch_queries):
                query_started = time.perf_counter()
                direct = z3.Solver()
                direct.set("timeout", int(timeout_ms))
                direct.set("random_seed", 0)
                direct.add(query)
                direct_status = self._bounded_solver_check(direct, timeout_ms)
                if direct_status == z3.sat:
                    vc_results.append(
                        {
                            "vc": (
                                failure_type.value
                                if len(branch_queries) == 1
                                else "{}[{}]".format(failure_type.value, branch_index)
                            ),
                            "status": "sat",
                            "failure_type": failure_type.value,
                            "solver_time_seconds": time.perf_counter() - query_started,
                            "normalization_time_seconds": 0.0,
                            "query_size": len(str(query)),
                            "solver_name": "z3-original-direct",
                            "solver_attempts": [
                                {"solver": "z3-original-direct", "status": "sat"}
                            ],
                            "portfolio_used": False,
                            "tactic_used": False,
                            "polynomial_normalization_used": False,
                            "watchdog_interrupted": False,
                            "raw_solver_status": "sat",
                            "trace_source": "adasparce-original-vc",
                        }
                    )
                    return (
                        direct_status,
                        failure_type,
                        time.perf_counter() - started,
                        "z3-original-direct",
                        tuple(vc_results),
                    )
                direct_unknown = direct_status == z3.unknown
                remaining_ms = self._remaining_check_ms(timeout_ms)
                if remaining_ms < 1:
                    return (
                        z3.unknown,
                        CheckFailureType.TIMEOUT,
                        time.perf_counter() - started,
                        "wall-budget-exhausted",
                        tuple(vc_results),
                    )
                try:
                    transformed = z3.TryFor(contextual_tactic, remaining_ms)(query)
                    subgoals = [
                        z3.simplify(goal.as_expr(), som=True) for goal in transformed
                    ]
                except z3.Z3Exception:
                    subgoals = [z3.simplify(query, som=True)]
                attempts = [
                    {"solver": "z3-original-direct", "status": str(direct_status)}
                ]
                if subgoals and all((z3.is_false(subgoal) for subgoal in subgoals)):
                    status = z3.unsat
                    attempts.append(
                        {"solver": "ctx-solver-simplify", "status": "unsat"}
                    )
                else:
                    subgoal_statuses = []
                    for subgoal in subgoals:
                        if z3.is_false(subgoal):
                            subgoal_statuses.append(z3.unsat)
                            continue
                        status = self._portfolio_check(subgoal, "qfnia", timeout_ms)
                        attempts.append({"solver": "QF_NIA", "status": str(status)})
                        if status == z3.unknown:
                            status = self._portfolio_check(subgoal, "nlsat", timeout_ms)
                            attempts.append(
                                {"solver": "nlsat-tactic", "status": str(status)}
                            )
                        subgoal_statuses.append(status)
                    if any((status == z3.sat for status in subgoal_statuses)):
                        status = z3.sat
                    elif subgoal_statuses and all(
                        (status == z3.unsat for status in subgoal_statuses)
                    ):
                        status = z3.unsat
                    else:
                        status = z3.unknown
                solver_label = (
                    attempts[-1]["solver"] if attempts else "ctx-solver-simplify"
                )
                solvers_used.append(solver_label)
                vc_results.append(
                    {
                        "vc": (
                            failure_type.value
                            if len(branch_queries) == 1
                            else "{}[{}]".format(failure_type.value, branch_index)
                        ),
                        "status": str(status),
                        "failure_type": (
                            None
                            if status == z3.unsat
                            else (
                                failure_type.value
                                if status == z3.sat
                                else CheckFailureType.UNKNOWN.value
                            )
                        ),
                        "solver_time_seconds": time.perf_counter() - query_started,
                        "normalization_time_seconds": 0.0,
                        "query_size": len(str(query)),
                        "solver_name": solver_label,
                        "solver_attempts": attempts,
                        "portfolio_used": any(
                            (
                                attempt["solver"] != "ctx-solver-simplify"
                                for attempt in attempts
                            )
                        ),
                        "tactic_used": True,
                        "polynomial_normalization_used": True,
                        "watchdog_interrupted": False,
                        "raw_solver_status": str(status),
                        "trace_source": "adasparce-original-vc",
                    }
                )
                if status == z3.sat:
                    return (
                        status,
                        failure_type,
                        time.perf_counter() - started,
                        ",".join(solvers_used),
                        tuple(vc_results),
                    )
                if status == z3.unknown:
                    return (
                        status,
                        CheckFailureType.UNKNOWN,
                        time.perf_counter() - started,
                        ",".join(solvers_used),
                        tuple(vc_results),
                    )
        return (
            z3.unsat,
            CheckFailureType.SUCCESS,
            time.perf_counter() - started,
            ",".join(solvers_used),
            tuple(vc_results),
        )


    def _normalized_smt_check(self, smt_path, candidate):
        """Normalize only the original SMT obligations using trusted tactics.

        Historical code rebuilt P/T/Q from the C feature analyzer and could
        accept invariants invalid for the supplied VC (e.g. real '/' versus
        integer 'div'). C models are no longer proof authorities.
        """
        return self._contextual_original_vc_check(smt_path, candidate)

    def _portfolio_check(self, normalized, kind, timeout_ms):
        """Run a single solver/tactic and return z3.sat/z3.unsat/z3.unknown.

        When the primary seed (0) returns ``unknown``, retry with up to
        three additional seeds.  Z3's QF_NIA heuristics are seed-sensitive;
        a different seed can decide the same query.  Each retry gets the
        shared per-query budget, capped again by the task deadline. A new
        seed never renews an exhausted wall-clock budget.
        """
        from SparCE.ada_engine import AdaSparCEEngine

        deadline = time.perf_counter() + timeout_ms / 1000.0
        per_seed_ms = max(1, timeout_ms // len(AdaSparCEEngine.MULTI_SEED_PORTFOLIO))
        for seed_index, seed in enumerate(AdaSparCEEngine.MULTI_SEED_PORTFOLIO):
            remaining_ms = self._remaining_check_ms(
                min(per_seed_ms, int(1000 * (deadline - time.perf_counter())))
            )
            if remaining_ms < 1:
                return z3.unknown
            try:
                if kind == "qflia":
                    solver = z3.SolverFor("QF_LIA")
                    solver.set("timeout", per_seed_ms)
                    solver.set("random_seed", seed)
                    solver.add(normalized)
                    status = self._bounded_solver_check(solver, remaining_ms)
                elif kind == "qfnia":
                    solver = z3.SolverFor("QF_NIA")
                    solver.set("timeout", per_seed_ms)
                    solver.set("random_seed", seed)
                    solver.add(normalized)
                    status = self._bounded_solver_check(solver, remaining_ms)
                elif kind == "nlsat":
                    tactic = z3.Then(
                        z3.Tactic("simplify"),
                        z3.Tactic("propagate-values"),
                        z3.Tactic("nlsat"),
                    )
                    tac_solver = tactic.solver()
                    tac_solver.set("timeout", per_seed_ms)
                    tac_solver.add(normalized)
                    status = self._bounded_solver_check(tac_solver, remaining_ms)
                else:
                    return z3.unknown
                if status != z3.unknown:
                    return status
            except z3.Z3Exception:
                return z3.unknown
        return z3.unknown


    def _run_conjunction_trials(
        self,
        tracker,
        conjunctions,
        verifier,
        smt_path,
        program_id,
        started,
        checked,
        degree,
        clauses,
        analyzer=None,
        fixed_checker_timeout=None,
        on_result=None,
    ):
        """Verify tracker-proposed conjunctions on the frozen checker.

        Conjunction candidates are few and deliberately composed, but
        their nonlinear STEP queries can be far more expensive than the
        base checker timeout (e.g. coupled egcd equalities need ~90 s in
        z3).  Each trial therefore escalates the per-check timeout in
        proportion to the remaining task budget instead of failing at the
        static 4 s budget.  This is a budget-allocation policy: the same
        frozen three-VC checker still decides soundness.

        Returns ``(success_branch, checked_delta)``; ``success_branch`` is
        a synthetic CandidateBranch when a conjunction passes all three
        VCs, otherwise ``None``.
        """
        checked_delta = 0
        if not conjunctions:
            return None, checked_delta
        checker_timeout = self.config.checker_timeout_seconds
        for conjunction in conjunctions:
            remaining = (
                self.config.timeout_seconds
                - (time.perf_counter() - started)
            )
            if remaining <= 0 or self._checker_budget_exhausted(
                checked + checked_delta
            ):
                break
            escalated_timeout = max(
                checker_timeout,
                min(150.0, remaining / 3.0),
            )
            if fixed_checker_timeout is not None:
                # Scheduler-owned timeout tier for this conjunction round.
                escalated_timeout = max(0.5, float(fixed_checker_timeout))
            branch = CandidateBranch(
                conjunction,
                90.0,
                "partial-lemma-conjunction",
                degree,
                clauses,
            )
            result = self._check_branch(
                verifier,
                branch,
                smt_path,
                program_id,
                checked + checked_delta + 1,
                analyzer,
                None,
                checker_timeout=escalated_timeout,
            )
            if result is None:
                continue
            checked_delta += 1
            if on_result is not None:
                on_result(result)
            self.logger.write(
                {
                    "event": "lemma_conjunction_trial",
                    "program_id": program_id,
                    "template_mode": "adasparce",
                    "candidate": str(conjunction),
                    "failure_type": result.failure_type.value,
                    "trials_used": tracker.trials,
                }
            )
            if result.failure_type == CheckFailureType.SUCCESS:
                return branch, checked_delta
            if result.failure_type == CheckFailureType.EXIT:
                # The conjunction itself is an inductive lemma; feed it
                # back so further conjunctions can build on it.
                for further in tracker.note(
                    conjunction, 90.0, CheckFailureType.EXIT
                ):
                    remaining = (
                        self.config.timeout_seconds
                        - (time.perf_counter() - started)
                    )
                    if remaining <= 0 or self._checker_budget_exhausted(
                        checked + checked_delta
                    ):
                        break
                    branch2 = CandidateBranch(
                        further,
                        90.0,
                        "partial-lemma-conjunction",
                        degree,
                        clauses,
                    )
                    further_timeout = (
                        escalated_timeout
                        if fixed_checker_timeout is not None
                        else max(escalated_timeout, remaining / 3.0)
                    )
                    result2 = self._check_branch(
                        verifier,
                        branch2,
                        smt_path,
                        program_id,
                        checked + checked_delta + 1,
                        analyzer,
                        None,
                        checker_timeout=further_timeout,
                    )
                    if result2 is None:
                        continue
                    checked_delta += 1
                    if on_result is not None:
                        on_result(result2)
                    self.logger.write(
                        {
                            "event": "lemma_conjunction_trial",
                            "program_id": program_id,
                            "template_mode": "adasparce",
                            "candidate": str(further),
                            "failure_type": (
                                result2.failure_type.value
                            ),
                            "trials_used": tracker.trials,
                        }
                    )
                    if result2.failure_type == CheckFailureType.SUCCESS:
                        return branch2, checked_delta
        return None, checked_delta

    def _check_branch(
        self,
        verifier,
        branch,
        smt_path,
        program_id,
        rank,
        analyzer=None,
        trace_context=None,
        suppress_timeout_escalation=False,
        checker_timeout=None,
    ):
        # Scheduler-owned timeout tier: the per-call override replaces
        # the task-level checker budget for this call as the *base*
        # timeout.  It is threaded as a parameter (no global mutation).
        # The legacy escalation retry stays active (bounded by
        # timeout_escalation_limit/cap): nonlinear egcd-class candidates
        # routinely need a ~150 s retry after a tier timeout, and
        # suppressing it regressed nl3/nl6 (OFF solved them via
        # escalation at 75 s/104 s; the tiered run starved the retry).
        old_deadline = getattr(self, "_task_wall_deadline", None)
        old_verifier_deadline = verifier.wall_deadline
        coverage = self.config.coverage_optimizations
        if coverage:
            # One budget covers all obligations, internal portfolios and
            # retries. Scheduler retries can explicitly choose a longer tier.
            limit = float(checker_timeout or self.config.checker_timeout_seconds)
            deadline = time.perf_counter() + max(0.5, limit)
            self._task_wall_deadline = min(deadline, old_deadline) if old_deadline else deadline
            verifier.wall_deadline = self._task_wall_deadline
        try:
            return self._check_branch_impl(
                verifier, branch, smt_path, program_id, rank,
                analyzer, trace_context, suppress_timeout_escalation or coverage,
                checker_timeout=(max(0.5, float(checker_timeout))
                                 if checker_timeout is not None else None),
            )
        finally:
            self._task_wall_deadline = old_deadline
            verifier.wall_deadline = old_verifier_deadline

    def _check_branch_impl(
        self,
        verifier,
        branch,
        smt_path,
        program_id,
        rank,
        analyzer=None,
        trace_context=None,
        suppress_timeout_escalation=False,
        checker_timeout=None,
    ):
        self._task_started = getattr(self, "_task_started", None)
        if self._task_started is None:
            self._task_started = time.perf_counter()
        self._timeout_escalations = getattr(
            self, "_timeout_escalations", 0
        )
        key = str(z3.simplify(branch.formula))
        if key in self.candidate_cache:
            if trace_context is not None:
                self._trace_candidate_outcome(
                    branch,
                    None,
                    trace_context,
                    skip_reason="candidate-cache",
                )
            return None
        self.candidate_cache.add(key)
        if self._pruner is not None:
            if not self._pruner.should_check_formula(branch.formula):
                if trace_context is not None:
                    self._trace_candidate_outcome(
                        branch,
                        None,
                        trace_context,
                        skip_reason="pruner",
                    )
                return None
        prefilter_failure = self._prefilter_rejects(branch)
        if prefilter_failure is not None:
            self._prefilter_rejections += 1
            if self.config.coverage_optimizations:
                self._prefilter_materials.append(branch)
                del self._prefilter_materials[:-64]
            self.logger.write(
                {
                    "event": "ada_prefilter_reject",
                    "program_id": program_id,
                    "template_mode": "adasparce",
                    "mechanism": branch.mechanism,
                    "degree": branch.degree,
                    "clauses": branch.clauses,
                    "candidate": str(branch.formula),
                    "candidate_hash": candidate_formula_hash(
                        branch.formula
                    ),
                    "witness_failure_type": prefilter_failure.value,
                    "prefilter_records": len(
                        self._prefilter_counterexamples
                    ),
                }
            )
            if trace_context is not None:
                self._trace_candidate_outcome(
                    branch,
                    None,
                    trace_context,
                    skip_reason="ce-prefilter",
                )
            return None
        result = None
        if "sparse-recurrence-closure" in branch.mechanism:
            (
                contextual_status,
                contextual_failure,
                contextual_time,
                contextual_solver,
                contextual_vc_results,
            ) = self._contextual_original_vc_check(
                smt_path, branch.formula
            )
            if contextual_status != z3.unknown:
                result = CheckResult(
                    status=(
                        "success"
                        if contextual_status == z3.unsat
                        else "counterexample"
                    ),
                    failure_type=contextual_failure,
                    counterexample=None,
                    solver_time=contextual_time,
                    solver_name=(
                        "z3-original-vc-contextual-"
                        + contextual_solver
                    ),
                    query_size=len(str(branch.formula)),
                    candidate_hash=candidate_formula_hash(
                        branch.formula
                    ),
                    raw_solver_status=str(contextual_status),
                    vc_results=contextual_vc_results,
                )
        if analyzer is not None and branch.mechanism == "typed-update-closure":
            (
                normalized_status,
                normalized_failure,
                normalized_time,
                normalized_solver,
                normalized_vc_results,
            ) = self._normalized_smt_check(smt_path, branch.formula)
            if result is None and normalized_status != z3.unknown:
                result = CheckResult(
                    status=(
                        "success"
                        if normalized_status == z3.unsat
                        else "counterexample"
                    ),
                    failure_type=normalized_failure,
                    counterexample=None,
                    solver_time=normalized_time,
                    solver_name="z3-normalized-" + normalized_solver,
                    query_size=len(str(branch.formula)),
                    candidate_hash=candidate_formula_hash(branch.formula),
                    raw_solver_status=str(normalized_status),
                    vc_results=normalized_vc_results,
                )
        if result is None:
            result = verifier.check(
                branch.formula,
                smt_path,
                normalize_polynomials=(
                    branch.mechanism.startswith("vc-")
                    or branch.mechanism == "postcondition-seed"
                ),
                timeout_seconds=checker_timeout,
            )
            if (
                result.failure_type == CheckFailureType.TIMEOUT
                and not suppress_timeout_escalation
                and self._timeout_escalations
                < self.config.timeout_escalation_limit
            ):
                remaining = (
                    self.config.timeout_seconds
                    - (time.perf_counter() - self._task_started)
                )
                escalated_timeout = max(
                    self.config.checker_timeout_seconds,
                    min(self.config.timeout_escalation_cap, remaining / 3.0),
                )
                if escalated_timeout > self.config.checker_timeout_seconds:
                    self._timeout_escalations += 1
                    escalated_result = verifier.check(
                        branch.formula,
                        smt_path,
                        normalize_polynomials=(
                            branch.mechanism.startswith("vc-")
                            or branch.mechanism == "postcondition-seed"
                        ),
                        timeout_seconds=escalated_timeout,
                    )
                    self.logger.write(
                        {
                            "event": "checker_timeout_escalation",
                            "program_id": program_id,
                            "template_mode": "adasparce",
                            "mechanism": branch.mechanism,
                            "escalated_timeout_seconds": escalated_timeout,
                            "base_failure_type": "TIMEOUT",
                            "escalated_failure_type": (
                                escalated_result.failure_type.value
                            ),
                            "escalations_used": self._timeout_escalations,
                        }
                    )
                    if (
                        escalated_result.failure_type
                        != CheckFailureType.TIMEOUT
                    ):
                        result = escalated_result
        if (
            analyzer is not None
            and result.failure_type
            in (CheckFailureType.TIMEOUT, CheckFailureType.UNKNOWN)
        ):
            (
                normalized_status,
                _,
                normalized_time,
                normalized_solver,
                normalized_vc_results,
            ) = self._normalized_smt_check(smt_path, branch.formula)
            if normalized_status == z3.unsat:
                result = replace(
                    result,
                    status="success",
                    failure_type=CheckFailureType.SUCCESS,
                    solver_time=result.solver_time + normalized_time,
                    solver_name=(
                        result.solver_name
                        + "+normalized-"
                        + normalized_solver
                    ),
                    raw_solver_status="unsat,unsat,unsat",
                    vc_results=(
                        tuple(result.vc_results)
                        + tuple(normalized_vc_results)
                    ),
                )
            else:
                result = replace(
                    result,
                    solver_time=result.solver_time + normalized_time,
                    solver_name=(
                        result.solver_name
                        + "+normalized-"
                        + normalized_solver
                    ),
                    raw_solver_status=(
                        result.raw_solver_status
                        + "|normalized-retry:"
                        + str(normalized_status)
                    ),
                    vc_results=(
                        tuple(result.vc_results)
                        + tuple(normalized_vc_results)
                    ),
                )
        self._record_prefilter_counterexample(result)
        if trace_context is not None:
            self._trace_candidate_outcome(branch, result, trace_context)
        self._record_neural_ranker_outcome(branch, result)
        self.logger.write(
            {
                "event": "ada_candidate",
                "program_id": program_id,
                "template_mode": "adasparce",
                "mechanism": branch.mechanism,
                "beam_rank": rank,
                "score": branch.score,
                "graph_structural_bonus": self._graph_bonus(branch),
                "degree": branch.degree,
                "clauses": branch.clauses,
                "monomials": list(branch.monomials),
                "candidate": str(branch.formula),
                "candidate_hash": result.candidate_hash,
                "checker_result": result.status,
                "failure_type": result.failure_type.value,
                "checker_time_ms": result.solver_time * 1000,
                "solver_name": result.solver_name,
                "query_size": result.query_size,
                "raw_solver_status": result.raw_solver_status,
                "vc_results": list(result.vc_results),
                "ranker_trace_run_id": (
                    trace_context.get("run_id") if trace_context else None
                ),
                "search_state_id": (
                    trace_context.get("search_state_id")
                    if trace_context
                    else None
                ),
                "candidate_group_id": (
                    trace_context.get("candidate_group_id")
                    if trace_context
                    else None
                ),
            }
        )
        return result
