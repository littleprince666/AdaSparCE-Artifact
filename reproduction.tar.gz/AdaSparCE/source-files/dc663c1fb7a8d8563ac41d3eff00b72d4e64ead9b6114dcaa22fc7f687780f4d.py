"""C frontend: pycparser AST extraction and C-expression -> Z3 translation.

``ProgramAnalyzer`` recovers the loop guard, deterministic updates,
initial values and the assert postcondition from the normalized C
source.  When the C parser cannot see the loop (``unknown()`` guards in
SyGuS / code2inv format), ``fill_from_smt`` recovers guard and updates
from the SMT ``trans-f`` definition instead.
"""

import re
from pathlib import Path

import z3
from pycparser import c_ast


class CToZ3Converter:
    def __init__(self, variables):
        self.variables = variables
        self.symbols = {name: z3.Int(name) for name in variables}

    @staticmethod
    def boolean(value):
        """C scalar truth, without adding an equality or choosing a value."""
        return value if z3.is_bool(value) else value != 0

    def expression(self, node):
        if isinstance(node, c_ast.ID):
            if node.name in ("true", "false"):
                return z3.BoolVal(node.name == "true")
            if node.name in self.symbols:
                return self.symbols[node.name]
            return z3.Int(node.name)
        if isinstance(node, c_ast.Constant):
            return z3.IntVal(int(node.value, 0))
        if isinstance(node, c_ast.Cast):
            return self.expression(node.expr)
        if isinstance(node, c_ast.UnaryOp):
            value = self.expression(node.expr)
            if node.op == "-":
                return -value
            if node.op == "+":
                return value
            if node.op == "!":
                return z3.Not(self.boolean(value))
        if isinstance(node, c_ast.BinaryOp):
            left, right = self.expression(node.left), self.expression(node.right)
            operations = {
                "+": lambda: left + right,
                "-": lambda: left - right,
                "*": lambda: left * right,
                "/": lambda: left / right,
                "%": lambda: left % right,
                "==": lambda: left == right,
                "!=": lambda: left != right,
                "<": lambda: left < right,
                "<=": lambda: left <= right,
                ">": lambda: left > right,
                ">=": lambda: left >= right,
                "&&": lambda: z3.And(self.boolean(left), self.boolean(right)),
                "||": lambda: z3.Or(self.boolean(left), self.boolean(right)),
            }
            if node.op in operations:
                return operations[node.op]()
        if isinstance(node, c_ast.ExprList) and len(node.exprs) == 1:
            return self.expression(node.exprs[0])
        if isinstance(node, c_ast.Assignment) and node.op == "=":
            # Several original LIPuS benchmarks write assume(c = 0) while
            # their generated SMT VC (and intended specification) uses
            # equality.  Match that established benchmark semantics.
            return self.expression(node.lvalue) == self.expression(node.rvalue)
        if isinstance(node, c_ast.TernaryOp):
            cond = self.expression(node.cond)
            iftrue = self.expression(node.iftrue) if node.iftrue else z3.BoolVal(True)
            iffalse = self.expression(node.iffalse) if node.iffalse else z3.BoolVal(True)
            return z3.If(self.boolean(cond), iftrue, iffalse)
        raise ValueError("unsupported C expression {}".format(type(node).__name__))


class ProgramAnalyzer(c_ast.NodeVisitor):
    def __init__(self, variables, collect_branch_transitions=False):
        self.variables = tuple(variables)
        self.translator = CToZ3Converter(self.variables)
        self.postcondition = None
        self.guard_ast = None
        self.assumptions = []
        self.initial_values = {}
        self.updates = {}
        self.mutated = set()
        self._loop_depth = 0
        self.smt_fallback_used = False
        self.guard_z3 = None
        # Branch-aware transition model (opt-in).  Each entry is
        # (path_guard_z3_or_None, {var: rhs_z3}) for one straight-line
        # path through the loop body, with per-path sequential
        # composition.  Unlike the legacy merged ``updates`` (which
        # concatenates if/else assignments unconditionally and is
        # therefore wrong for conditional updates), this model keeps
        # the branches separate so algebraic generators can require
        # preservation under *every* path.
        self.collect_branch_transitions = bool(collect_branch_transitions)
        self.branch_transitions = []
        # A nondeterministic input is not a deterministic initialization or
        # recurrence.  Track its carrier-local aliases too: the Checker state
        # interface can omit next-state/input temporaries declared in the C.
        self.nondeterministic_names = set()

    def _nondeterministic_expression(self, node):
        """Recognize only explicit zero-argument nondeterministic inputs.

        Unsupported ordinary function calls still reach the converter and
        fail explicitly.  No fresh input is silently replaced by zero, a
        shared function symbol, or an equality to the previous state.
        """
        if isinstance(node, c_ast.FuncCall):
            return (isinstance(node.name, c_ast.ID)
                    and node.name.name in {"unknown", "nondet_int", "__VERIFIER_nondet_int"}
                    and (node.args is None or not node.args.exprs))
        if isinstance(node, c_ast.ID):
            return node.name in self.nondeterministic_names
        return any(self._nondeterministic_expression(child)
                   for _, child in node.children())

    def visit_Decl(self, node):
        if node.init is not None and self._nondeterministic_expression(node.init):
            self.nondeterministic_names.add(node.name)
            self.initial_values.pop(node.name, None)
            self.generic_visit(node)
            return
        if (
            node.name in self.variables
            and node.init is not None
            and self._loop_depth == 0
        ):
            self.initial_values[node.name] = self.translator.expression(node.init)
        self.generic_visit(node)

    def visit_FuncCall(self, node):
        name = node.name.name if isinstance(node.name, c_ast.ID) else ""
        if (name in {"assume", "assert"} and node.args is not None
                and len(node.args.exprs) == 1):
            expression = self.translator.boolean(
                self.translator.expression(node.args.exprs[0]))
            if name == "assume" and self._loop_depth == 0:
                self.assumptions.append(expression)
                self._record_assumed_initial(node.args.exprs[0])
            elif name == "assert":
                self.postcondition = expression
        self.generic_visit(node)

    def _record_assumed_initial(self, node):
        if not isinstance(node, c_ast.BinaryOp) or node.op != "==":
            return
        if isinstance(node.left, c_ast.ID):
            self.initial_values[node.left.name] = self.translator.expression(node.right)
        elif isinstance(node.right, c_ast.ID):
            self.initial_values[node.right.name] = self.translator.expression(node.left)

    def visit_While(self, node):
        if self._loop_depth == 0:
            # An arbitrary *initial* value is still an ordinary current-state
            # variable in a deterministic loop update such as x := x + 1.
            # Input temporaries outside the invariant interface stay tainted.
            self.nondeterministic_names.difference_update(self.variables)
        if self.guard_ast is None:
            self.guard_ast = node.cond
        if (
            self.collect_branch_transitions
            and self._loop_depth == 0
            and not self.branch_transitions
        ):
            self._collect_branch_transitions(node)
        self._loop_depth += 1
        self.visit(node.stmt)
        self._loop_depth -= 1

    # ------------------------------------------------------------------
    # Branch-aware transition collection
    # ------------------------------------------------------------------

    def _compose_update(self, updates, name, rhs):
        """Sequentially compose one more assignment into a path."""
        if updates:
            rhs = z3.substitute(
                rhs,
                *[
                    (self.translator.symbols[variable], update)
                    for variable, update in updates.items()
                ],
            )
        updates = dict(updates)
        updates[name] = z3.simplify(rhs)
        return updates

    def _statement_updates(self, node, updates):
        """Apply one statement to a path's update map."""
        if isinstance(node, c_ast.Assignment):
            if not isinstance(node.lvalue, c_ast.ID):
                raise ValueError("branch-transition: compound assignment target")
            name = node.lvalue.name
            if name not in self.translator.symbols:
                return updates
            if node.op == "=":
                rhs = self.translator.expression(node.rvalue)
            elif node.op == "+=":
                rhs = (
                    self.translator.symbols[name]
                    + self.translator.expression(node.rvalue)
                )
            elif node.op == "-=":
                rhs = (
                    self.translator.symbols[name]
                    - self.translator.expression(node.rvalue)
                )
            elif node.op == "*=":
                rhs = (
                    self.translator.symbols[name]
                    * self.translator.expression(node.rvalue)
                )
            else:
                raise ValueError("branch-transition: unsupported assignment op")
            return self._compose_update(updates, name, rhs)
        if isinstance(node, c_ast.UnaryOp) and node.op in (
            "p++", "p--", "++", "--"
        ) and isinstance(node.expr, c_ast.ID):
            name = node.expr.name
            if name not in self.translator.symbols:
                return updates
            delta = z3.IntVal(1) if "++" in node.op else z3.IntVal(-1)
            return self._compose_update(
                updates, name, self.translator.symbols[name] + delta
            )
        if isinstance(node, c_ast.Compound):
            if node.block_items is None:
                return updates
            for item in node.block_items:
                updates = self._statement_updates(item, updates)
            return updates
        if isinstance(node, c_ast.EmptyStatement):
            return updates
        raise ValueError(
            "branch-transition: unsupported statement {}".format(
                type(node).__name__
            )
        )

    def _body_paths(self, node, guard):
        """Decompose a loop-body statement into (path_guard, updates)."""
        if isinstance(node, c_ast.If):
            condition = self.translator.expression(node.cond)
            paths = []
            iftrue = node.iftrue if node.iftrue else c_ast.EmptyStatement()
            paths.extend(
                self._body_paths(
                    iftrue,
                    z3.simplify(z3.And(guard, condition))
                    if guard is not None
                    else condition,
                )
            )
            iffalse = (
                node.iffalse
                if node.iffalse
                else c_ast.EmptyStatement()
            )
            paths.extend(
                self._body_paths(
                    iffalse,
                    z3.simplify(z3.And(guard, z3.Not(condition)))
                    if guard is not None
                    else z3.Not(condition),
                )
            )
            return paths
        if isinstance(node, c_ast.Compound):
            if node.block_items is None:
                return [(guard, {})]
            if len(node.block_items) == 1:
                return self._body_paths(node.block_items[0], guard)
            # Sequential composition of statements: expand every
            # statement into paths, then compose paths pairwise.  This
            # handles if/else chains and mixed statement sequences
            # without flattening branches into each other.
            paths = [(guard, {})]
            for item in node.block_items:
                expanded = self._body_paths(item, guard)
                merged = []
                for path_guard, path_updates in paths:
                    for item_guard, item_updates in expanded:
                        combined_guard = (
                            z3.simplify(z3.And(path_guard, item_guard))
                            if path_guard is not None
                            else item_guard
                        )
                        composed = dict(path_updates)
                        for name, rhs in item_updates.items():
                            composed = self._compose_update(
                                composed, name, rhs
                            )
                        merged.append((combined_guard, composed))
                paths = merged
            return paths
        return [(guard, self._statement_updates(node, {}))]

    def _collect_branch_transitions(self, node):
        """Collect per-path transitions for the outermost loop."""
        try:
            guard = self.translator.expression(node.cond)
        except ValueError:
            self.branch_transitions = []
            return
        try:
            paths = self._body_paths(node.stmt, guard)
        except (ValueError, z3.Z3Exception):
            self.branch_transitions = []
            return
        transitions = []
        for path_guard, path_updates in paths:
            if path_guard is not None and z3.is_false(
                z3.simplify(path_guard)
            ):
                continue
            transitions.append((path_guard, path_updates))
        if len(transitions) < 1:
            self.branch_transitions = []
            return
        # Every mutable variable must have a well-defined value on every
        # path (identity where unassigned) for the model to be usable.
        self.branch_transitions = transitions

    def visit_Assignment(self, node):
        if not isinstance(node.lvalue, c_ast.ID):
            return
        name = node.lvalue.name
        if self._nondeterministic_expression(node.rvalue):
            self.nondeterministic_names.add(name)
            if name in self.variables:
                if self._loop_depth:
                    self.updates.pop(name, None)
                    self.mutated.add(name)
                else:
                    self.initial_values.pop(name, None)
            return
        # Carrier-local next-state and rule input variables are features,
        # not additional invariant parameters or deterministic updates.
        if name not in self.variables:
            return
        if not self._loop_depth:
            if node.op == "=" and name in self.variables:
                value = self.translator.expression(node.rvalue)
                if self.initial_values:
                    value = z3.substitute(
                        value,
                        *[
                            (
                                self.translator.symbols[variable],
                                initial,
                            )
                            for variable, initial
                            in self.initial_values.items()
                        ]
                    )
                self.initial_values[name] = z3.simplify(value)
            return
        if node.op == "=":
            rhs = self.translator.expression(node.rvalue)
        elif node.op == "+=":
            rhs = (
                self.translator.symbols[name]
                + self.translator.expression(node.rvalue)
            )
        elif node.op == "-=":
            rhs = (
                self.translator.symbols[name]
                - self.translator.expression(node.rvalue)
            )
        elif node.op == "*=":
            rhs = (
                self.translator.symbols[name]
                * self.translator.expression(node.rvalue)
            )
        else:
            return
        if self.updates:
            rhs = z3.substitute(
                rhs,
                *[
                    (self.translator.symbols[variable], update)
                    for variable, update in self.updates.items()
                ]
            )
        self.updates[name] = rhs
        self.mutated.add(name)

    def visit_UnaryOp(self, node):
        """Handle ``i++``, ``i--``, ``++i``, ``--i`` inside loops."""
        if not self._loop_depth or not isinstance(node.expr, c_ast.ID):
            self.generic_visit(node)
            return
        name = node.expr.name
        if name not in self.variables:
            self.generic_visit(node)
            return
        if name in self.nondeterministic_names:
            self.updates.pop(name, None)
            self.mutated.add(name)
            return
        symbol = self.translator.symbols[name]
        if node.op in ("p++", "p--"):
            delta = z3.IntVal(1) if node.op == "p++" else z3.IntVal(-1)
            rhs = symbol + delta
        elif node.op in ("++", "--"):
            delta = z3.IntVal(1) if node.op == "++" else z3.IntVal(-1)
            rhs = symbol + delta
        else:
            self.generic_visit(node)
            return
        if self.updates:
            rhs = z3.substitute(
                rhs,
                *[
                    (self.translator.symbols[variable], update)
                    for variable, update in self.updates.items()
                ]
            )
        self.updates[name] = z3.simplify(rhs)
        self.mutated.add(name)

    def constant_additive_updates(self):
        result = {}
        for name, rhs in self.updates.items():
            symbol = self.translator.symbols[name]
            difference = z3.simplify(rhs - symbol)
            if z3.is_int_value(difference):
                result[name] = difference.as_long()
        return result

    def needs_smt_fallback(self):
        """True only when the C parser completely failed to extract updates.

        This triggers for ``unknown()`` guard tasks (SyGuS / code2inv format)
        where pycparser cannot see any assignment inside the loop body.
        It does NOT trigger when the C parser already extracted updates
        successfully, even if the guard is ``unknown()`` — in that case
        the guard is recovered separately by ``fill_from_smt`` without
        overwriting the existing updates.
        """
        return not self.updates

    def fill_from_smt(self, smt_path):
        """Populate guard/updates/mutated from the SMT trans-f.

        Used when the C source uses ``unknown()`` (SyGuS / code2inv format)
        and the pycparser cannot extract the loop guard or transition.
        """
        self.smt_fallback_used = True
        text = Path(smt_path).read_text(encoding="utf-8")
        text = text.replace(
            "SPLIT_HERE_asdfghjklzxcvbnmqwertyuiop", "true"
        )
        trans_match = re.search(
            r'\(define-fun\s+trans-f\s*\(\((.*?)\)\)\s*Bool',
            text,
        )
        if not trans_match:
            return False
        param_str = trans_match.group(1)
        all_params = re.findall(r'([\w!]+)\s+Int', param_str)
        base_vars = [v for v in all_params if not v.endswith("!")]
        primed = {v: v + "!" for v in base_vars}
        depth = 0
        start = trans_match.end()
        body_start = text.find("Bool", trans_match.start())
        if body_start == -1:
            return False
        body_start += 4
        rest = text[body_start:]
        paren_depth = 0
        body_chars = []
        for ch in rest:
            if ch == "(":
                paren_depth += 1
                body_chars.append(ch)
            elif ch == ")":
                paren_depth -= 1
                if paren_depth < 0:
                    break
                body_chars.append(ch)
            else:
                body_chars.append(ch)
        body = "".join(body_chars).strip()
        if not body:
            return False
        decls = " ".join(
            "(declare-const |{}| Int)".format(v) for v in all_params
        )
        safe_body = body
        for v in all_params:
            if "!" in v:
                safe_body = safe_body.replace(v, "|{}|".format(v))
        full_smt = "(set-logic ALL) {} (assert {}) (check-sat)".format(
            decls, safe_body
        )
        try:
            parsed = z3.parse_smt2_string(full_smt)
            expr = z3.simplify(parsed[0]) if parsed else z3.BoolVal(True)
        except z3.Z3Exception:
            return False
        branches = expr.children() if z3.is_or(expr) else [expr]
        guard_parts = []
        update_found = False
        for branch in branches:
            if not z3.is_and(branch):
                continue
            parts = branch.children()
            branch_guard = []
            branch_updates = {}
            for part in parts:
                part_str = str(part)
                has_primed = "!" in part_str
                if not has_primed and (
                    z3.is_lt(part) or z3.is_le(part)
                    or z3.is_gt(part) or z3.is_ge(part)
                    or z3.is_not(part)
                ):
                    clean = z3.simplify(part)
                    if not z3.is_true(clean) and not z3.is_false(clean):
                        branch_guard.append(part)
                elif has_primed and z3.is_eq(part):
                    left, right = part.children()
                    left_str = str(left)
                    right_str = str(right)
                    if left_str.endswith("!"):
                        var_name = left_str[:-1]
                        if var_name in self.translator.symbols:
                            branch_updates[var_name] = right
                    elif right_str.endswith("!"):
                        var_name = right_str[:-1]
                        if var_name in self.translator.symbols:
                            branch_updates[var_name] = left
            for var_name, rhs in branch_updates.items():
                if var_name in self.updates:
                    continue
                sym = self.translator.symbols[var_name]
                try:
                    diff = z3.simplify(rhs - sym)
                except z3.Z3Exception:
                    diff = z3.IntVal(999)
                if not z3.is_int_value(diff) or diff.as_long() != 0:
                    self.updates[var_name] = rhs
                    self.mutated.add(var_name)
                    update_found = True
            if branch_guard and branch_updates:
                guard_parts.extend(branch_guard)
        if guard_parts:
            self.guard_z3 = z3.Or(*guard_parts) if len(guard_parts) > 1 else guard_parts[0]
        else:
            self.guard_z3 = None
        if not self.mutated:
            for branch in branches:
                if not z3.is_and(branch):
                    continue
                for part in branch.children():
                    if z3.is_eq(part):
                        left, right = part.children()
                        left_str = str(left)
                        right_str = str(right)
                        if left_str.endswith("!"):
                            var_name = left_str[:-1]
                            if var_name in self.translator.symbols:
                                self.updates[var_name] = right
                                self.mutated.add(var_name)
                        elif right_str.endswith("!"):
                            var_name = right_str[:-1]
                            if var_name in self.translator.symbols:
                                self.updates[var_name] = left
                                self.mutated.add(var_name)
        return update_found or bool(guard_parts)


    def constant_initial(self, name):
        value = self.initial_values.get(name)
        value = z3.simplify(value) if value is not None else None
        return value.as_long() if value is not None and z3.is_int_value(value) else None

    def explicit_nonnegative(self):
        result = set()

        def visit(expression):
            if z3.is_and(expression):
                for child in expression.children():
                    visit(child)
                return
            if z3.is_ge(expression):
                left, right = expression.children()
                if z3.is_const(left) and z3.is_int_value(right) and right.as_long() == 0:
                    result.add(str(left))
            if z3.is_le(expression):
                left, right = expression.children()
                if z3.is_int_value(left) and left.as_long() == 0 and z3.is_const(right):
                    result.add(str(right))

        for assumption in self.assumptions:
            visit(assumption)
        for name, value in self.initial_values.items():
            if z3.is_int_value(z3.simplify(value)) and z3.simplify(value).as_long() == 0:
                result.add(name)
        return result
