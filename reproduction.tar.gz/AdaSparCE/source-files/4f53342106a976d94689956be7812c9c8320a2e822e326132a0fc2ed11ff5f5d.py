"""Feedback components for AdaSparCE."""
