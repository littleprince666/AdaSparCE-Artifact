"""JSONL experiment logging and summary statistics."""

import hashlib
import json
import statistics
import time
from pathlib import Path


def stable_hash(value):
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, default=str).encode("utf-8")
    ).hexdigest()


class JsonlLogger:
    def __init__(self, path=None):
        self.path = Path(path) if path else None
        if self.path:
            self.path.parent.mkdir(parents=True, exist_ok=True)

    def write(self, record):
        payload = dict(record)
        payload.setdefault("timestamp", time.time())
        if self.path:
            with self.path.open("a", encoding="utf-8") as output:
                output.write(json.dumps(payload, sort_keys=True) + "\n")


def load_records(paths):
    records = []
    for path in paths:
        with Path(path).open(encoding="utf-8") as source:
            for line in source:
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    return records


def summarize(records, timeout_seconds=600):
    terminal = [record for record in records if record.get("event") == "final"]
    solved = [record for record in terminal if record.get("status") == "solved"]
    times = [record.get("total_time_seconds", 0.0) for record in solved]
    par2_values = [
        record.get("total_time_seconds", 0.0)
        if record.get("status") == "solved"
        else 2 * timeout_seconds
        for record in terminal
    ]
    iterations = [
        record
        for record in records
        if record.get("event") == "iteration"
    ]
    template_queries = [
        record for record in iterations if "template_result" in record
    ]
    candidate_records = [
        record for record in iterations if record.get("candidate") is not None
    ]
    return {
        "programs": len(terminal),
        "solved": len(solved),
        "total_time": sum(record.get("total_time_seconds", 0.0) for record in terminal),
        "median_solved_time": statistics.median(times) if times else None,
        "par_2": sum(par2_values) / len(par2_values) if par2_values else None,
        "smt_queries": len(template_queries)
        + sum(
            record.get("checker_result")
            not in (None, "NONE", "skipped-duplicate")
            for record in iterations
        ),
        "template_sat": sum(r.get("template_result") == "sat" for r in template_queries),
        "template_unsat": sum(
            r.get("template_result") in ("bounded-unsat", "structural-unsat")
            for r in template_queries
        ),
        "template_timeout": sum(
            r.get("template_result") in ("timeout", "unknown") for r in template_queries
        ),
        "checker_sat": sum(r.get("checker_result") == "counterexample" for r in iterations),
        "checker_unsat": sum(r.get("checker_result") == "success" for r in iterations),
        "checker_timeout": sum(
            r.get("checker_result") in ("timeout", "unknown") for r in iterations
        ),
        "average_monomials": (
            sum(r.get("candidate_monomials", 0) for r in candidate_records)
            / len(candidate_records)
            if candidate_records
            else 0.0
        ),
        "max_degree": max((r.get("max_degree", 0) for r in iterations), default=0),
        "average_candidate_ast_size": (
            sum(r.get("candidate_ast_size", 0) for r in candidate_records)
            / len(candidate_records)
            if candidate_records
            else 0.0
        ),
    }
