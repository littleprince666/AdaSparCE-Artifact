"""Stable, identifier-free trace schema for neural candidate ranking.

This module contains no model code.  It serializes the search state and
candidate structure needed to build listwise training examples while keeping
task identifiers, paths, variable names, and variable positions out of the
ranker-facing records.
"""

import hashlib
import json
import math
from collections import Counter
from pathlib import Path

import z3


TRACE_SCHEMA_VERSION = "vc_deepsets_ranker_trace.v1"

OUTCOME_PROGRESS = {
    "INIT": 0.0,
    "STEP": 1.0 / 3.0,
    "EXIT": 2.0 / 3.0,
    "SUCCESS": 1.0,
}


def _sha256_bytes(value):
    return hashlib.sha256(value).hexdigest()


def stable_json_hash(value):
    payload = json.dumps(
        value, sort_keys=True, separators=(",", ":"), default=str
    ).encode("utf-8")
    return _sha256_bytes(payload)


def candidate_formula_hash(formula):
    """Match ``SMT_verifier.CheckResult.candidate_hash`` exactly."""
    return _sha256_bytes(str(formula).encode("utf-8"))


def program_content_hash(c_path, smt_path):
    """Hash program contents without using an identifier or filesystem path."""
    c_bytes = Path(c_path).read_bytes()
    smt_bytes = Path(smt_path).read_bytes()
    payload = (
        b"normalized.c\0"
        + len(c_bytes).to_bytes(8, "big")
        + c_bytes
        + b"task.c_smt\0"
        + len(smt_bytes).to_bytes(8, "big")
        + smt_bytes
    )
    return _sha256_bytes(payload)


def _symbols(expression):
    values = set()

    def visit(node):
        if z3.is_const(node) and node.num_args() == 0:
            if node.sort().kind() != z3.Z3_BOOL_SORT and not z3.is_int_value(node):
                values.add(str(node))
            return
        for child in node.children():
            visit(child)

    if expression is not None:
        visit(expression)
    return values


def semantic_roles(analyzer):
    """Return internal variable-role sets used only for aggregate features."""
    guard = getattr(analyzer, "guard_z3", None)
    if guard is None:
        try:
            guard = analyzer.translator.expression(analyzer.guard_ast)
        except (AttributeError, ValueError):
            guard = None
    guard_variables = _symbols(guard)
    mutated = set(getattr(analyzer, "mutated", ()))
    post_variables = _symbols(getattr(analyzer, "postcondition", None))
    monotone = set()
    accumulators = set()
    for name, update in getattr(analyzer, "updates", {}).items():
        symbol = getattr(analyzer, "translator", None)
        symbol = getattr(symbol, "symbols", {}).get(name)
        if symbol is None:
            continue
        difference = z3.simplify(update - symbol)
        if z3.is_int_value(difference) and difference.as_long() != 0:
            monotone.add(name)
        dependencies = _symbols(difference) - {name}
        if dependencies:
            accumulators.add(name)
    initialized_constant = set()
    for name in getattr(analyzer, "variables", ()):
        try:
            if analyzer.constant_initial(name) is not None:
                initialized_constant.add(name)
        except (AttributeError, KeyError, TypeError, z3.Z3Exception):
            pass
    counters = guard_variables.intersection(mutated)
    return {
        "guard": guard_variables,
        "mutated": mutated,
        "monotone": monotone,
        "postcondition": post_variables,
        "synchronization_counter": counters,
        "counter": counters,
        "accumulator": accumulators,
        "initialized_constant": initialized_constant,
    }


def _merge_exponents(parts):
    merged = Counter()
    for part in parts:
        if part is None:
            return None
        merged.update(part)
    return dict(merged)


def _monomial_exponents(expression):
    if z3.is_int_value(expression) or z3.is_rational_value(expression):
        return {}
    if (
        z3.is_const(expression)
        and expression.num_args() == 0
        and expression.sort().kind() != z3.Z3_BOOL_SORT
    ):
        return {str(expression): 1}
    if z3.is_mul(expression):
        return _merge_exponents(
            _monomial_exponents(child) for child in expression.children()
        )
    if z3.is_app_of(expression, z3.Z3_OP_POWER):
        base, exponent = expression.children()
        base_value = _monomial_exponents(base)
        if base_value is not None and z3.is_int_value(exponent):
            power = exponent.as_long()
            if power >= 0:
                return {
                    name: value * power for name, value in base_value.items()
                }
    return None


def _structural_monomial(exponents, roles, mechanism):
    values = tuple(exponents.values())
    degree = sum(values)
    names = set(exponents)
    record = {
        "degree": degree,
        "variables_used": len(names),
        "max_exponent": max(values, default=0),
        "is_constant": degree == 0,
        "is_linear": degree == 1,
        "is_square": degree == 2 and max(values, default=0) == 2,
        "is_high_power": max(values, default=0) >= 3,
        "is_cross_term": len(names) >= 2,
        "has_guard_role": bool(names.intersection(roles["guard"])),
        "has_mutated_role": bool(names.intersection(roles["mutated"])),
        "has_monotone_role": bool(names.intersection(roles["monotone"])),
        "has_postcondition_role": bool(
            names.intersection(roles["postcondition"])
        ),
        "has_synchronization_counter_role": bool(
            names.intersection(roles["synchronization_counter"])
        ),
        "has_counter_role": bool(names.intersection(roles["counter"])),
        "has_accumulator_role": bool(
            names.intersection(roles["accumulator"])
        ),
        "has_initialized_constant_role": bool(
            names.intersection(roles["initialized_constant"])
        ),
        "from_update_closure": "update-closure" in mechanism,
        "from_counterexample_repair": mechanism.startswith("ce-"),
        "from_postcondition_seed": mechanism == "postcondition-seed",
    }
    return record


def structural_monomials(formula, analyzer, mechanism):
    """Extract an order-independent list without names or variable indices."""
    roles = semantic_roles(analyzer)
    found = []

    def visit(node):
        if z3.is_and(node) or z3.is_or(node) or z3.is_not(node) or z3.is_implies(node):
            for child in node.children():
                visit(child)
            return
        if z3.is_eq(node) or z3.is_le(node) or z3.is_lt(node) or z3.is_ge(node) or z3.is_gt(node):
            for child in node.children():
                visit(child)
            return
        if z3.is_add(node):
            for child in node.children():
                visit(child)
            return
        exponents = _monomial_exponents(node)
        if exponents is not None:
            found.append(_structural_monomial(exponents, roles, mechanism))
            return
        for child in node.children():
            visit(child)

    visit(formula)
    counts = Counter(
        json.dumps(item, sort_keys=True, separators=(",", ":"))
        for item in found
    )
    result = []
    for encoded, occurrence_count in sorted(counts.items()):
        item = json.loads(encoded)
        item["occurrence_count"] = occurrence_count
        result.append(item)
    return result


def z3_ast_size(expression):
    seen = set()

    def visit(node):
        identity = node.get_id()
        if identity in seen:
            return 0
        seen.add(identity)
        return 1 + sum(visit(child) for child in node.children())

    return visit(expression)


def relation_type(formula):
    if z3.is_and(formula):
        return "conjunction"
    if z3.is_or(formula):
        return "disjunction"
    if z3.is_implies(formula):
        return "implication"
    relations = (
        (z3.is_eq, "eq"),
        (z3.is_le, "le"),
        (z3.is_lt, "lt"),
        (z3.is_ge, "ge"),
        (z3.is_gt, "gt"),
    )
    for predicate, name in relations:
        if predicate(formula):
            return name
    return "other"


def _candidate_flags(mechanism):
    return {
        "specialized_frontend": mechanism.startswith("vc-"),
        "linear_fast_path": mechanism == "linear-fast-path",
        "spacer": "spacer" in mechanism,
        "fallback": "fallback" in mechanism,
        "counterexample_repair": mechanism.startswith("ce-"),
        "postcondition_seed": mechanism == "postcondition-seed",
    }


def candidate_record(
    branch,
    analyzer,
    ordinal,
    score_components=None,
    mechanism_history=None,
    historical_occurrences=0,
    coefficient_bound=None,
):
    score_components = dict(score_components or {})
    history = dict(mechanism_history or {})
    formula_hash = candidate_formula_hash(branch.formula)
    instance_id = stable_json_hash(
        {
            "candidate_hash": formula_hash,
            "mechanism": branch.mechanism,
            "ordinal": ordinal,
        }
    )
    monomials = structural_monomials(
        branch.formula, analyzer, branch.mechanism
    )
    flags = _candidate_flags(branch.mechanism)
    flags.update({
        "contains_guard": any(
            item["has_guard_role"] for item in monomials
        ),
        "contains_postcondition": any(
            item["has_postcondition_role"] for item in monomials
        ),
        "responds_to_current_counterexample": flags[
            "counterexample_repair"
        ],
        "repeated_candidate": int(historical_occurrences) > 0,
    })
    return {
        "candidate_instance_id": instance_id,
        "candidate_hash": formula_hash,
        "generation_ordinal": ordinal,
        "mechanism": branch.mechanism,
        "heuristic_score": float(branch.score),
        "score_components": score_components,
        "degree": int(branch.degree),
        "clauses": int(branch.clauses),
        "monomial_count": len(branch.monomials),
        "structural_monomials": monomials,
        "relation_type": relation_type(branch.formula),
        "coefficient_bound": coefficient_bound,
        "coefficient_bound_available": coefficient_bound is not None,
        "candidate_ast_size": z3_ast_size(branch.formula),
        "estimated_query_size": len(str(branch.formula)),
        "historical_candidate_occurrences": int(historical_occurrences),
        "mechanism_history": {
            "success": int(history.get("success", 0)),
            "failure": int(history.get("failure", 0)),
            "timeout": int(history.get("timeout", 0)),
        },
        "flags": flags,
    }


def make_state_id(program_hash, state):
    stable_state = dict(state)
    stable_state.pop("elapsed_time_ratio", None)
    return stable_json_hash(
        {"program_content_hash": program_hash, "state": stable_state}
    )


def make_group_id(run_id, program_hash, state_id, group_index, phase):
    return stable_json_hash(
        {
            "run_id": run_id,
            "program_content_hash": program_hash,
            "search_state_id": state_id,
            "group_index": group_index,
            "phase": phase,
        }
    )


def outcome_labels(failure_type, checker_time_seconds, current_failure_type):
    """Build labels without treating an undecided solver result as negative."""
    decided = failure_type in OUTCOME_PROGRESS
    progress = OUTCOME_PROGRESS.get(failure_type)
    current_progress = OUTCOME_PROGRESS.get(current_failure_type, 0.0)
    return {
        "success_label": (
            1.0 if failure_type == "SUCCESS" else 0.0
        ) if decided else None,
        "success_label_valid": decided,
        "progress_label": progress,
        "progress_label_valid": decided,
        "progress_gain_label": (
            progress - current_progress if decided else None
        ),
        "improves_current_failure_label": (
            float(progress > current_progress) if decided else None
        ),
        "cost_log1p_seconds_label": math.log1p(
            max(0.0, float(checker_time_seconds))
        ),
        "cost_label_valid": True,
    }
