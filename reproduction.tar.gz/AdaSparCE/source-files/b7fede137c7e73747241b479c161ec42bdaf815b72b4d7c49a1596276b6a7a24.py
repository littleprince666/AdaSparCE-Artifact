"""Partial-lemma retention and conjunction proposals.

The legacy clause-iterative search discards a clause that cannot pass all
three VCs on its own.  Two common failure shapes carry reusable
information:

* EXIT-only failure: the candidate passed INIT and STEP, so it is a
  verified inductive lemma that is merely too weak to prove the
  postcondition (e.g. a summation equality that still needs an exit
  fence).
* STEP failure after INIT: the clause may be *jointly* inductive with a
  partner clause (e.g. the coupled egcd equalities), even though neither
  is inductive alone.

The tracker keeps bounded pools of both shapes and proposes a small,
deterministic set of conjunctions to verify jointly.  Every proposed
conjunction is still judged by the frozen three-VC checker, so the
mechanism is soundness-preserving by construction.
"""

import z3

from SMT_Solver.SMT_verifier import CheckFailureType


class PartialLemmaTracker:
    def __init__(self, max_exit_lemmas=8, max_step_partials=12,
                 max_trials=48, max_partners=3):
        self.max_exit_lemmas = max_exit_lemmas
        self.max_step_partials = max_step_partials
        self.max_trials = max_trials
        self.max_partners = max_partners
        self.exit_lemmas = []
        self.step_partials = []
        self.tried_keys = set()
        self.trials = 0

    def _key(self, formula):
        return str(z3.simplify(formula))

    def _partners(self, pool):
        """Pair with every pool member, best-scored first.

        Score-based truncation can crowd out the complementary clause of
        a mutually-inductive pair (each member alone scores no better
        than wrong-but-simple clauses), so pairing covers the full pool
        and ordering only decides which conjunctions are checked first.
        """
        ranked = sorted(pool, key=lambda item: -item[1])
        return [formula for formula, _ in ranked]

    def _retain(self, pool, entry, capacity):
        pool.append(entry)
        if len(pool) > capacity:
            # Evict the lowest-score member so high-quality equations
            # survive busy phases instead of FIFO eviction.
            pool.sort(key=lambda item: item[1])
            pool.pop(0)

    def note(self, formula, score, failure_type):
        """Record a partial result; return conjunctions to verify."""
        if self.trials >= self.max_trials:
            return []
        proposals = []
        key = self._key(formula)
        if failure_type == CheckFailureType.EXIT:
            if key not in {self._key(f) for f, _ in self.exit_lemmas}:
                self._retain(
                    self.exit_lemmas, (formula, score), self.max_exit_lemmas
                )
                for partner in self._partners(self.exit_lemmas):
                    if self._key(partner) != key:
                        proposals.append(z3.And(formula, partner))
                if len(self.exit_lemmas) > 1:
                    proposals.append(
                        z3.And(*[f for f, _ in self.exit_lemmas])
                    )
        elif failure_type == CheckFailureType.STEP:
            if key not in {self._key(f) for f, _ in self.step_partials}:
                self._retain(
                    self.step_partials,
                    (formula, score),
                    self.max_step_partials,
                )
                for partner in self._partners(self.step_partials):
                    if self._key(partner) != key:
                        proposals.append(z3.And(formula, partner))
        deduped = []
        for conjunction in proposals:
            ckey = self._key(conjunction)
            if ckey in self.tried_keys or ckey == key:
                continue
            self.tried_keys.add(ckey)
            deduped.append(conjunction)
            self.trials += 1
            if self.trials >= self.max_trials:
                break
        return deduped
