"""Cost-aware strategy-level scheduler for AdaSparCE.

The scheduler groups proof mechanisms into stable *strategy categories*.
Mechanism names are normalized by longest-prefix rules with compound
suffix stripping (``typed-divmod-euclidean`` and ``typed-divmod-weak``
both resolve to ``divmod``; ``typed-post-weakening-le+entry`` resolves
to ``post-weakening``), never by exact string matching.

Each scheduling action selects

    (strategy category, per-round candidate quota, checker timeout tier)

instead of a single candidate.  Utility is cost-aware:

    ratio  : utility = p_success / (epsilon + expected_time)
    linear : utility = p_success - lambda * expected_time
                             - mu * p_timeout

Success probability, expected checker time and timeout probability are
modelled separately. TIMEOUT/UNKNOWN do not count as definitive proof
failures. Their consumed time DOES enter the mean observed checker cost;
that mean is not an estimate of uncensored time to solver completion.

One adaptive policy and three ranking controls:

* ``heuristic`` — a deterministic per-instance UCB-style scheduler backed by
  Beta-smoothed success-rate priors (empirical aggregates, or the
  training-free cold mode).  Fully reproducible.
* ``random`` — uniform strategy-order ablation control, deterministic
  under the configured seed.  Quota and timeout tier still come from
  the same cost-aware sub-procedures, so comparisons isolate exactly
  the ranking function.
* ``fixed`` — canonical category order, retaining common budget rules.
* ``cost-only`` — ranks using observed/prior cost without success utility.

A frozen three-head MLP policy existed experimentally but was removed:
it required pretraining on collected decision traces and only reached
parity with the training-free bandit (see
docs/策略级成本感知调度器_设计与开发实验_2026-09-07.md §4.5).

The scheduler never changes proof semantics: every returned invariant
is still judged by the frozen INIT/STEP/EXIT three-VC SMT checker, and
unchecked candidates remain in their pools except for explicitly configured
output-removal ablations. Ordinary scheduling changes order and budget.
"""

import hashlib
import math
from collections import defaultdict
from dataclasses import dataclass, field

from SparCE.scheduling.mechanism_prioritizer import (
    DEFAULT_RATE,
    EMPIRICAL_SUCCESS_RATES,
)
from SparCE.scheduling.mechanisms import REGISTRY as _MECHANISM_REGISTRY
from SparCE.scheduling.mechanisms import mechanism_prefix_rules
from SparCE.scheduling.strategy_catalog import (
    CATALOG, STRATEGY_CATEGORIES, STRATEGY_COST_CLASS, DEFAULT_QUOTAS,
    GRANULARITIES, category_group,
)


# ---------------------------------------------------------------------------
# Strategy categories and prefix normalization
# ---------------------------------------------------------------------------

STRATEGY_INDEX = {
    category: index for index, category in enumerate(STRATEGY_CATEGORIES)
}

# Compound suffixes appended by mechanism constructors (e.g.
# ``typed-post-weakening-le+entry``).  They never change the strategy
# family and are stripped before prefix matching.
_COMPOUND_SUFFIXES = ("+sync", "+entry")

# Longest-prefix rules, derived from the single mechanism registry in
# ``SparCE.scheduling.mechanisms`` (adding a mechanism there is the only
# registration step).  The ``vc-``/``program-`` catch-alls are excluded
# here on purpose: they are resolved by the twin-frontend recursion
# below.  Rules are sorted by descending prefix length at derivation
# time, so ``program-counter-lifted-sparse-recurrence-closure`` matches
# its own rule before the shorter ``program-`` recursion.
_PREFIX_RULES = mechanism_prefix_rules()

_SORTED_PREFIX_RULES = sorted(
    _PREFIX_RULES, key=lambda item: -len(item[0])
)


def normalize_strategy(mechanism):
    """Map a mechanism name to its stable strategy category.

    Supports suffixed variants (``typed-divmod-*``, ``typed-guard-split-*``,
    ``...+entry``) and the ``program-``/``vc-`` frontend twins.  Unknown
    mechanisms fall back to ``"other"`` (never to ``fallback``).
    """
    if not mechanism:
        return "other"
    name = str(mechanism).strip().lower()
    for suffix in _COMPOUND_SUFFIXES:
        if name.endswith(suffix):
            name = name[: -len(suffix)]
    for prefix, category in _SORTED_PREFIX_RULES:
        if name.startswith(prefix):
            return category
    if name.startswith("program-"):
        return normalize_strategy(name[len("program-"):])
    if name.startswith("vc-"):
        return "vc-frontend"
    return "other"


# ---------------------------------------------------------------------------
# Cost model priors
# ---------------------------------------------------------------------------

COST_CLASS_EXPECTED_TIME = {0: 1.5, 1: 4.0, 2: 12.0}
COST_CLASS_TIMEOUT_PRIOR = {0: 0.02, 1: 0.08, 2: 0.25}


def _validate_mechanism_registry():
    """Fail fast when the registry and the strategy tables drift apart.

    Previously the mechanism metadata lived in five independent places
    (generator scores, mechanisms.REGISTRY, empirical rates, prefix
    rules, preferred-failure feedback) and a missed registration
    silently degraded to ``"other"`` / default cost.  The registry is
    now the single source; this check runs at import so an inconsistent
    edit cannot reach an experiment.
    """
    categories = set(STRATEGY_CATEGORIES)
    for prefix, entry in _MECHANISM_REGISTRY.items():
        strategy = entry.get("strategy")
        if strategy not in categories:
            raise ValueError(
                "mechanism registry entry %r maps to unknown strategy %r"
                % (prefix, strategy)
            )
    missing_costs = categories - set(STRATEGY_COST_CLASS)
    if missing_costs:
        raise ValueError(
            "STRATEGY_COST_CLASS is missing entries for: %s"
            % ", ".join(sorted(missing_costs))
        )


_validate_mechanism_registry()

# Empirical expected checker time (seconds) and timeout rate per
# strategy, measured on the nonlinear dev_train split (74 tasks, 30 s
# budget, checker timeout 4 s, legacy order; traces under
# Result/StrategyScheduler/dev-train-off-30s).  Times are lower bounds
# where the 4 s budget censored slow calls; strategies without enough
# observations fall back to the cost-class defaults above.
STRATEGY_EXPECTED_TIME_PRIORS = {
    "postcondition-seed": 0.55,
    "ce-synthesis": 0.05,
    "vc-frontend": 0.70,
    "update-closure": 0.05,
    "post-weakening": 0.45,
    "precondition-entry-bound": 0.05,
    "remaining-work": 0.05,
    "guard-split": 0.10,
    "counter-lift": 0.05,
    "algebraic-recurrence": 0.10,
    "sign-clauses": 0.05,
    "divmod": 0.20,
}

STRATEGY_TIMEOUT_PRIORS = {
    "postcondition-seed": 0.05,
    "ce-synthesis": 0.02,
    "vc-frontend": 0.05,
    "update-closure": 0.02,
    "post-weakening": 0.05,
    "precondition-entry-bound": 0.02,
    "remaining-work": 0.02,
    "guard-split": 0.02,
    "counter-lift": 0.02,
    "algebraic-recurrence": 0.05,
    "sign-clauses": 0.02,
    "divmod": 0.05,
}

# Priors for categories that have no mechanism-level dev evidence.
_EXTRA_STRATEGY_PRIORS = {
    "fallback": 0.10,
    "partial-lemma-conjunction": 0.15,
    "clause-composer": 0.08,
    "ce-synthesis": 0.05,
    "guard-split": 0.10,
    "divmod": 0.05,
    "post-weakening": 0.05,
    "algebraic-recurrence": 0.10,
    "transition-kernel": 0.10,
    "branchwise-conservation": 0.08,
    "scaled-division": 0.05,
    "entry-potential-exit-post-closure": 0.08,
    "other": 0.05,
}


def _build_strategy_prior_rates():
    grouped = defaultdict(list)
    for mechanism, rate in EMPIRICAL_SUCCESS_RATES.items():
        grouped[normalize_strategy(mechanism)].append(float(rate))
    priors = {
        category: sum(rates) / len(rates)
        for category, rates in grouped.items()
    }
    priors.update(_EXTRA_STRATEGY_PRIORS)
    for category in STRATEGY_CATEGORIES:
        priors.setdefault(category, DEFAULT_RATE)
    return priors


STRATEGY_PRIOR_RATES = _build_strategy_prior_rates()

# Cold-start mode: zero corpus statistics.  Every strategy shares one
# uninformative success prior (the exact value barely matters for
# ranking because it is shared — the initial order is driven by cost),
# and expected time / timeout priors come from the hand-designed
# structural cost classes only.  No constant in this mode is estimated
# from any task corpus.
COLD_SUCCESS_PRIOR = 0.10

DEFAULT_TIMEOUT_TIERS = (4.0, 15.0, 60.0, 150.0)

# ---------------------------------------------------------------------------
# Scheduler configuration
# ---------------------------------------------------------------------------

@dataclass
class StrategySchedulerConfig:
    policy: str = "heuristic"            # heuristic | random | fixed | cost-only
    utility_form: str = "ratio"          # ratio | linear | success
    # empirical: corpus-derived aggregate priors (success rates from
    # historical dev traces, expected times from a dev_train run);
    # cold: zero corpus statistics — uniform success prior, structural
    # cost-class time/timeout defaults, nothing estimated from data.
    priors: str = "empirical"            # empirical | cold
    epsilon: float = 1.0
    lambda_cost: float = 0.005           # seconds^-1, linear form only
    mu: float = 0.1                      # linear form only
    exploration_scale: float = 0.05
    prior_strength: float = 5.0
    timeout_tiers: tuple = DEFAULT_TIMEOUT_TIERS
    quotas: dict = field(
        default_factory=lambda: dict(DEFAULT_QUOTAS)
    )
    min_typed_budget_ratio: float = 0.15
    min_fallback_budget_ratio: float = 0.20
    timeout_escalation_cap: float = 150.0
    max_decisions: int = 200
    seed: int = 0
    # Progress feedback: add a per-strategy best-progress bonus
    # (EXIT > STEP > INIT) to the utility so strategies that advance the
    # proof keep budget share; the exploration floor is unchanged.
    progress_feedback: bool = False
    progress_weight: float = 0.05
    granularity: str = "category21"
    online_updates: bool = True
    quota_mode: str = "legacy"  # legacy | auto | unit
    round_budget_ratio: float = 0.10
    disabled_categories: tuple = ()

    def validate(self):
        if self.policy not in ("heuristic", "random", "fixed", "cost-only"):
            raise ValueError(
                "invalid strategy_scheduler_policy"
            )
        if self.granularity not in GRANULARITIES:
            raise ValueError("invalid strategy granularity")
        if self.quota_mode not in ("legacy", "auto", "unit"):
            raise ValueError("invalid quota_mode")
        if not 0 < self.round_budget_ratio <= 1:
            raise ValueError("round_budget_ratio must be in (0, 1]")
        if set(self.disabled_categories) - set(STRATEGY_CATEGORIES):
            raise ValueError("unknown disabled categories")
        for value in (self.exploration_scale, self.progress_weight):
            if not math.isfinite(value) or value < 0:
                raise ValueError("feedback weights must be finite and nonnegative")
        if not math.isfinite(self.prior_strength) or self.prior_strength <= 0:
            raise ValueError("prior_strength must be finite and positive")
        if self.utility_form not in ("ratio", "linear", "success"):
            raise ValueError(
                "strategy_scheduler_utility must be 'ratio', 'linear' "
                "or 'success'"
            )
        if self.priors not in ("empirical", "cold"):
            raise ValueError(
                "strategy scheduler priors must be 'empirical' or 'cold'"
            )
        for name in ("min_typed_budget_ratio", "min_fallback_budget_ratio"):
            value = getattr(self, name)
            if not 0.0 <= value <= 1.0:
                raise ValueError(f"{name} must be within [0, 1]")
        if (
            self.min_typed_budget_ratio + self.min_fallback_budget_ratio
            > 1.0
        ):
            raise ValueError(
                "min_typed_budget_ratio + min_fallback_budget_ratio "
                "must not exceed 1"
            )
        tiers = tuple(float(t) for t in self.timeout_tiers)
        if not tiers or any(t <= 0 for t in tiers):
            raise ValueError("timeout_tiers must be positive")
        if list(tiers) != sorted(tiers):
            raise ValueError("timeout_tiers must be ascending")
        if self.epsilon <= 0:
            raise ValueError("strategy_scheduler_epsilon must be positive")


def compute_utility(p_success, expected_time, p_timeout, config):
    """Cost-aware utility; both heads must already be validated."""
    p_success = min(max(float(p_success), 0.0), 1.0)
    p_timeout = min(max(float(p_timeout), 0.0), 1.0)
    expected_time = min(max(float(expected_time), 0.0), 1e4)
    if config.utility_form == "ratio":
        return p_success / (config.epsilon + expected_time)
    if config.utility_form == "success":
        # Ablation control: ranking ignores cost entirely.
        return p_success
    return (
        p_success
        - config.lambda_cost * expected_time
        - config.mu * p_timeout
    )


def choose_checker_timeout(
    expected_time,
    timeout_ratio,
    tiers,
    remaining_seconds,
    escalation_cap,
):
    """Pick the smallest tier that comfortably covers the expected time.

    The tier is bumped once when the strategy has been timing out, and
    is always clamped by the remaining task budget and the configured
    escalation cap.
    """
    tiers = tuple(float(t) for t in tiers)
    required = max(0.1, float(expected_time)) * 1.5
    tier_index = len(tiers) - 1
    for index, tier in enumerate(tiers):
        if tier >= required:
            tier_index = index
            break
    if timeout_ratio > 1.0 / 3.0 and tier_index + 1 < len(tiers):
        tier_index += 1
    timeout = tiers[tier_index]
    timeout = min(timeout, float(escalation_cap))
    budget_cap = max(float(remaining_seconds) * 0.8, 0.5)
    timeout = min(timeout, budget_cap)
    return max(timeout, 0.5)


def choose_quota(strategy, config, pool_size, expected_time, remaining_seconds):
    """Quota for one round: configured default, pool size, affordability."""
    if config.quota_mode == "unit":
        return 1
    if config.quota_mode == "auto":
        # A shared fraction of remaining budget, with no per-category table.
        # Estimate actual observed cost, not uncensored completion time.
        allotment = max(0.0, remaining_seconds) * config.round_budget_ratio
        quota = max(1, int(allotment / (max(0.1, expected_time) + 0.5)))
        return min(quota, pool_size) if pool_size else quota
    default_quota = int(config.quotas.get(strategy, DEFAULT_QUOTAS.get(
        strategy, 2
    )))
    default_quota = max(1, default_quota)
    affordable = int(
        max(1.0, float(remaining_seconds))
        / (max(0.1, float(expected_time)) + 0.5)
    )
    quota = min(default_quota, max(1, affordable))
    if pool_size:
        quota = min(quota, int(pool_size))
    return max(1, quota)


# ---------------------------------------------------------------------------
# Runtime statistics and state
# ---------------------------------------------------------------------------

class StrategyRuntimeStats:
    """Per-strategy observations accumulated within one task run."""

    __slots__ = (
        "offered", "tried", "successes", "timeouts",
        "total_checker_time", "definitive", "best_progress",
    )

    # Progress score of a checker outcome: a strategy whose candidates
    # reach EXIT (inductive but too weak) carries more signal than one
    # stuck at INIT.
    PROGRESS_SCORES = {
        "SUCCESS": 1.0,
        "EXIT": 0.6,
        "STEP": 0.3,
        "INIT": 0.1,
        "TIMEOUT": 0.0,
        "UNKNOWN": 0.0,
    }

    def __init__(self):
        self.offered = 0          # candidates visible in the pool
        self.tried = 0            # candidates actually checked
        self.successes = 0
        self.timeouts = 0
        self.total_checker_time = 0.0
        self.definitive = 0       # non-timeout checker results
        self.best_progress = 0.0

    def observe(self, failure_type_value, checker_time):
        self.tried += 1
        if checker_time is not None and checker_time >= 0:
            self.total_checker_time += float(checker_time)
        if failure_type_value == "SUCCESS":
            self.successes += 1
            self.definitive += 1
        elif failure_type_value in ("TIMEOUT", "UNKNOWN"):
            # Censored observations: neither TIMEOUT nor UNKNOWN is
            # definitive evidence about success, so they enter neither
            # the success nor the failure count of the Beta posterior.
            self.timeouts += 1
        else:
            self.definitive += 1
        self.best_progress = max(
            self.best_progress,
            self.PROGRESS_SCORES.get(str(failure_type_value), 0.0),
        )

    def avg_checker_time(self):
        if self.tried == 0:
            return None
        return self.total_checker_time / self.tried

    def as_dict(self):
        return {
            "offered": self.offered,
            "tried": self.tried,
            "successes": self.successes,
            "timeouts": self.timeouts,
            "avg_checker_time": self.avg_checker_time(),
            "best_progress": self.best_progress,
        }


STATIC_STATE_FIELDS = (
    "num_variables",
    "num_updated_variables",
    "num_branches",
    "max_update_degree",
    "max_postcondition_degree",
    "has_division",
    "has_modulo",
    "has_nonlinear_multiplication",
    "has_ite",
    "has_accumulator",
    "has_counter",
    "has_monotone_variable",
    "has_coupled_variable",
    "is_linear",
)

DYNAMIC_STATE_FIELDS = (
    "current_degree",
    "current_clauses",
    "degree_cap",
    "clause_cap",
    "init_count",
    "step_count",
    "exit_count",
    "timeout_count",
    "last_failure_type",
    "elapsed_seconds",
    "total_seconds",
    "checked",
    "max_checker_calls",
    "partial_lemma_pool_size",
    "best_progress",
)

STATE_FIELDS = STATIC_STATE_FIELDS + DYNAMIC_STATE_FIELDS

_LAST_FAILURE_ONEHOT = ("INIT", "STEP", "EXIT", "TIMEOUT", "NONE")

_PER_STRATEGY_FEATURES = (
    "strategy_tried_log",
    "strategy_offered_log",
    "strategy_avg_checker_time_log",
    "strategy_timeouts_log",
    "strategy_successes_log",
    "pool_size_log",
)

STATIC_FEATURE_NAMES = (
    "num_variables_log",
    "num_updated_variables_log",
    "num_branches_log",
    "max_update_degree_scaled",
    "max_postcondition_degree_scaled",
    "has_division",
    "has_modulo",
    "has_nonlinear_multiplication",
    "has_ite",
    "has_accumulator",
    "has_counter",
    "has_monotone_variable",
    "has_coupled_variable",
    "is_linear",
)

DYNAMIC_FEATURE_NAMES = (
    "current_degree_scaled",
    "current_clauses_scaled",
    "init_count_log",
    "step_count_log",
    "exit_count_log",
    "timeout_count_log",
    "elapsed_ratio",
    "remaining_seconds_log",
    "checked_log",
    "remaining_checker_ratio",
    "partial_lemma_pool_size_log",
    "best_progress",
) + tuple(
    f"last_failure_{name.lower()}" for name in _LAST_FAILURE_ONEHOT
)

FEATURE_NAMES = (
    STATIC_FEATURE_NAMES
    + DYNAMIC_FEATURE_NAMES
    + _PER_STRATEGY_FEATURES
    + tuple(f"strategy_onehot_{c}" for c in STRATEGY_CATEGORIES)
)

FEATURE_COUNT = len(FEATURE_NAMES)


def _log1p(value, scale):
    try:
        return math.log1p(max(0.0, float(value))) / scale
    except (TypeError, ValueError, OverflowError):
        return 0.0


def _clip01(value):
    try:
        value = float(value)
    except (TypeError, ValueError):
        return 0.0
    if math.isnan(value) or math.isinf(value):
        return 0.0
    return min(max(value, 0.0), 1.0)


def encode_state_features(state, strategy, pool_size, stats):
    """Deterministic, numerically stable feature vector.

    The encoding must stay fixed: checkpoints and collected traces both
    depend on ``FEATURE_COUNT`` and the exact feature order.
    """
    degree_cap = max(1, int(state.get("degree_cap") or 1))
    clause_cap = max(1, int(state.get("clause_cap") or 1))
    total_seconds = max(1e-6, float(state.get("total_seconds") or 0.0))
    elapsed = max(0.0, float(state.get("elapsed_seconds") or 0.0))
    checked = max(0, int(state.get("checked") or 0))
    max_calls = state.get("max_checker_calls") or 0
    last_failure = str(state.get("last_failure_type") or "NONE").upper()

    features = [
        _log1p(state.get("num_variables"), 4.6),
        _log1p(state.get("num_updated_variables"), 4.6),
        _log1p(state.get("num_branches"), 4.6),
        min(float(state.get("max_update_degree") or 0), 8.0) / 8.0,
        min(float(state.get("max_postcondition_degree") or 0), 8.0) / 8.0,
        1.0 if state.get("has_division") else 0.0,
        1.0 if state.get("has_modulo") else 0.0,
        1.0 if state.get("has_nonlinear_multiplication") else 0.0,
        1.0 if state.get("has_ite") else 0.0,
        1.0 if state.get("has_accumulator") else 0.0,
        1.0 if state.get("has_counter") else 0.0,
        1.0 if state.get("has_monotone_variable") else 0.0,
        1.0 if state.get("has_coupled_variable") else 0.0,
        1.0 if state.get("is_linear") else 0.0,
        min(float(state.get("current_degree") or 0), degree_cap) / degree_cap,
        min(float(state.get("current_clauses") or 0), clause_cap) / clause_cap,
        _log1p(state.get("init_count"), 5.0),
        _log1p(state.get("step_count"), 5.0),
        _log1p(state.get("exit_count"), 5.0),
        _log1p(state.get("timeout_count"), 5.0),
        _clip01(elapsed / total_seconds),
        _log1p(max(0.0, total_seconds - elapsed), 6.0),
        _log1p(checked, 6.0),
        _clip01(1.0 - checked / float(max_calls)) if max_calls else 1.0,
        _log1p(state.get("partial_lemma_pool_size"), 4.0),
        _clip01(state.get("best_progress")),
    ]
    onehot = [0.0] * len(_LAST_FAILURE_ONEHOT)
    key = last_failure if last_failure in _LAST_FAILURE_ONEHOT else "NONE"
    onehot[_LAST_FAILURE_ONEHOT.index(key)] = 1.0
    features.extend(onehot)

    avg_time = stats.avg_checker_time()
    features.extend([
        _log1p(stats.tried, 4.0),
        _log1p(stats.offered, 6.0),
        _log1p(avg_time, 6.0) if avg_time is not None else 0.0,
        _log1p(stats.timeouts, 4.0),
        _log1p(stats.successes, 4.0),
        _log1p(pool_size, 6.0),
    ])

    strategy_onehot = [0.0] * len(STRATEGY_CATEGORIES)
    strategy_onehot[STRATEGY_INDEX.get(strategy, STRATEGY_INDEX["other"])] = 1.0
    features.extend(strategy_onehot)

    assert len(features) == FEATURE_COUNT
    for value in features:
        if math.isnan(value) or math.isinf(value):
            raise ValueError("non-finite scheduler state feature")
    return features


# ---------------------------------------------------------------------------
# Decisions
# ---------------------------------------------------------------------------

@dataclass
class SchedulingDecision:
    strategy: str
    quota: int
    checker_timeout: float
    policy: str                 # "heuristic" | "random"
    utility: float
    predictions: dict           # strategy -> prediction dict
    reason: str                 # "model" | "heuristic" | fallback reason
    state_features: dict = field(default_factory=dict)
    available_strategies: tuple = ()


# ---------------------------------------------------------------------------
# Policies
# ---------------------------------------------------------------------------

class HeuristicPolicy:
    """Per-instance failure/cost adaptation with a UCB-style exploration bonus.

    Success probability is the posterior mean of a Beta distribution
    whose prior concentrates on the empirical dev-trace rate of the
    strategy family; expected checker time starts from the cost-class
    default and is replaced by the observed per-task average once the
    strategy has been tried.  An explicit exploration term keeps rarely
    tried strategies some preference. Finite budgets and stopping on success
    do not guarantee coverage or stationary-bandit regret bounds.
    """

    def __init__(self, config):
        self.config = config

    def predict(self, strategy, stats):
        if self.config.priors == "cold":
            prior = COLD_SUCCESS_PRIOR
        else:
            prior = float(
                STRATEGY_PRIOR_RATES.get(strategy, DEFAULT_RATE)
            )
        strength = max(1.0, float(self.config.prior_strength))
        alpha = prior * strength
        beta = (1.0 - prior) * strength
        # Censored observations: TIMEOUTs carry no definitive evidence
        # about success, so they enter neither the success nor the
        # failure count of the Beta posterior.
        definitive = stats.definitive
        p_success = (alpha + stats.successes) / (
            alpha + beta + definitive
        )
        avg_time = stats.avg_checker_time()
        cost_class = STRATEGY_COST_CLASS.get(strategy, 1)
        if self.config.priors == "cold":
            expected_time = (
                avg_time if avg_time is not None and avg_time > 0
                else COST_CLASS_EXPECTED_TIME[cost_class]
            )
            timeout_prior = COST_CLASS_TIMEOUT_PRIOR[cost_class]
        else:
            expected_time = (
                avg_time if avg_time is not None and avg_time > 0
                else STRATEGY_EXPECTED_TIME_PRIORS.get(
                    strategy, COST_CLASS_EXPECTED_TIME[cost_class]
                )
            )
            timeout_prior = STRATEGY_TIMEOUT_PRIORS.get(
                strategy, COST_CLASS_TIMEOUT_PRIOR[cost_class]
            )
        p_timeout = (timeout_prior + stats.timeouts) / (
            1.0 + stats.tried
        )
        p_timeout = min(max(p_timeout, 0.0), 1.0)
        return {
            "p_success": p_success,
            "expected_time": expected_time,
            "p_timeout": p_timeout,
            "confidence": 1.0,
            "source": "heuristic",
        }


# ---------------------------------------------------------------------------
# Scheduler facade
# ---------------------------------------------------------------------------

class StrategyScheduler:
    """Orders (strategy, quota, timeout-tier) actions for one task run."""

    def __init__(self, config, logger=None):
        config.validate()
        self.config = config
        self.logger = logger
        self.stats = {
            category: StrategyRuntimeStats()
            for category in STRATEGY_CATEGORIES
        }
        self.decision_count = 0
        self.heuristic = HeuristicPolicy(config)
        self.member_rounds = defaultdict(int)

    def category(self, key):
        if key.startswith("mechanism::"):
            return normalize_strategy(key[len("mechanism::"):])
        return key if key in CATALOG else normalize_strategy(key)

    def key_for_mechanism(self, mechanism):
        if self.config.granularity == "mechanism":
            return "mechanism::" + str(mechanism)
        return normalize_strategy(mechanism)

    def group(self, key):
        if self.config.granularity == "mechanism":
            return key
        return category_group(self.category(key), self.config.granularity)

    def is_enabled(self, key):
        return self.category(key) not in self.config.disabled_categories

    def _group_stats(self, key):
        if not self.config.online_updates:
            return StrategyRuntimeStats()
        if self.config.granularity in ("category21", "mechanism"):
            return self.stats[key]
        result = StrategyRuntimeStats()
        for member, stats in self.stats.items():
            if self.group(member) != self.group(key):
                continue
            for field_name in StrategyRuntimeStats.__slots__:
                if field_name == "best_progress":
                    result.best_progress = max(result.best_progress, stats.best_progress)
                else:
                    setattr(result, field_name, getattr(result, field_name) + getattr(stats, field_name))
        return result

    # -- observation -----------------------------------------------------

    def reset(self):
        """Reset per-task state (stats, decision counters)."""
        self.stats = {
            category: StrategyRuntimeStats()
            for category in STRATEGY_CATEGORIES
        }
        self.decision_count = 0
        self.member_rounds.clear()

    def observe_candidate(self, strategy, failure_type_value, checker_time):
        stats = self.stats.setdefault(
            strategy if strategy in self.stats or strategy.startswith("mechanism::")
            else normalize_strategy(strategy),
            StrategyRuntimeStats(),
        )
        stats.observe(failure_type_value, checker_time)

    def observe_offer(self, strategy, offered):
        stats = self.stats.setdefault(
            strategy if strategy in self.stats or strategy.startswith("mechanism::")
            else normalize_strategy(strategy),
            StrategyRuntimeStats(),
        )
        stats.offered = max(stats.offered, int(offered))

    def total_tried(self):
        return sum(s.tried for s in self.stats.values())

    # -- decisions ---------------------------------------------------------

    def select(self, state, available, pool_sizes, remaining_seconds):
        """Choose (strategy, quota, checker timeout) for the next round.

        ``available`` must already respect the fallback budget window
        (the engine computes fallback availability); this method only
        ranks the given options.
        """
        self.decision_count += 1
        remaining_seconds = max(0.0, float(remaining_seconds))
        available = [s for s in available if self.is_enabled(s)]
        for strategy in available:
            self.stats.setdefault(strategy, StrategyRuntimeStats())
        effective_stats = {s: self._group_stats(s) for s in available}

        feature_rows = {}
        state_features = {}
        for strategy in available:
            pool_size = int(pool_sizes.get(strategy, 0))
            features = encode_state_features(
                state, self.category(strategy), pool_size, effective_stats[strategy]
            )
            feature_rows[strategy] = features
            state_features[strategy] = features

        predictions = {
            strategy: self.heuristic.predict(
                self.category(strategy), effective_stats[strategy]
            )
            for strategy in available
        }
        # Coarse partitions share both observations and an unweighted mean
        # category prior. Pool size must not multiply a group's chances.
        if self.config.granularity in ("coarse4", "middle8"):
            for strategy in available:
                members = [c for c in STRATEGY_CATEGORIES
                           if self.group(c) == self.group(strategy) and self.is_enabled(c)]
                rows = [self.heuristic.predict(c, effective_stats[strategy]) for c in members]
                predictions[strategy] = {
                    k: sum(r[k] for r in rows) / len(rows)
                    for k in ("p_success", "expected_time", "p_timeout", "confidence")
                }
                predictions[strategy]["source"] = "grouped-heuristic"
        policy_name = self.config.policy
        reason = policy_name
        if self.config.policy == "random":
            policy_name = "random"
            reason = "random-control"

        total_tried = self.total_tried() if self.config.online_updates else 0
        exploration = float(self.config.exploration_scale)
        best_strategy = None
        best_utility = None
        utilities = {}
        for strategy in available:
            prediction = predictions[strategy]
            utility = compute_utility(
                prediction["p_success"],
                prediction["expected_time"],
                prediction["p_timeout"],
                self.config,
            )
            if policy_name == "cost-only":
                utility = 1.0 / (self.config.epsilon + prediction["expected_time"])
            elif policy_name == "fixed":
                utility = -float(STRATEGY_INDEX[self.category(strategy)])
            if policy_name == "heuristic":
                stats = effective_stats[strategy]
                utility += exploration * math.sqrt(
                    math.log1p(total_tried) / (1.0 + stats.tried)
                )
                if self.config.progress_feedback and stats.tried:
                    # Proof-progress feedback: strategies whose checks
                    # advanced further through the VCs keep budget
                    # share even with a low success posterior.
                    utility += (
                        float(self.config.progress_weight)
                        * stats.best_progress
                    )
            utilities[strategy] = utility
            prediction = dict(prediction)
            prediction["utility"] = utility
            predictions[strategy] = prediction
            if (
                best_utility is None
                or utility > best_utility
                or (
                    utility == best_utility
                    and (STRATEGY_INDEX[self.category(strategy)], strategy)
                    < (STRATEGY_INDEX[self.category(best_strategy)], best_strategy)
                )
            ):
                best_strategy = strategy
                best_utility = utility

        if best_strategy is None:
            raise ValueError("no strategies available to the scheduler")

        if policy_name == "random":
            # Ablation control: uniform strategy order, deterministic
            # under the configured seed.  Quota and timeout tier still
            # come from the same cost-aware sub-procedures, so the
            # comparison isolates exactly the ranking function.
            digest = hashlib.sha256(
                f"{self.config.seed}:{self.decision_count}".encode("utf-8")
            ).hexdigest()
            representatives = list(dict.fromkeys(self.group(s) for s in available))
            group = representatives[int(digest[:16], 16) % len(representatives)]
            best_strategy = next(s for s in available if self.group(s) == group)
            best_utility = utilities[best_strategy]

        if self.config.granularity in ("coarse4", "middle8"):
            # One group wins; rotate its available members by rounds used.
            # This is part of the grouping intervention, not a learned model.
            members = [s for s in available if self.group(s) == self.group(best_strategy)]
            best_strategy = min(members, key=lambda s: (
                self.member_rounds[s], STRATEGY_INDEX[self.category(s)], s))
            best_utility = utilities[best_strategy]
        self.member_rounds[best_strategy] += 1
        for strategy in predictions:
            predictions[strategy]["group"] = self.group(strategy)
            predictions[strategy]["category"] = self.category(strategy)

        prediction = predictions[best_strategy]
        stats = effective_stats[best_strategy]
        timeout_ratio = (
            stats.timeouts / stats.tried if stats.tried else 0.0
        )
        checker_timeout = choose_checker_timeout(
            prediction["expected_time"],
            timeout_ratio,
            self.config.timeout_tiers,
            remaining_seconds,
            self.config.timeout_escalation_cap,
        )
        pool_size = int(pool_sizes.get(best_strategy, 0))
        quota = choose_quota(
            self.category(best_strategy),
            self.config,
            pool_size if best_strategy != "fallback" else 0,
            prediction["expected_time"],
            remaining_seconds,
        )

        return SchedulingDecision(
            strategy=best_strategy,
            quota=quota,
            checker_timeout=checker_timeout,
            policy=policy_name,
            utility=best_utility,
            predictions=predictions,
            reason=reason,
            state_features=state_features,
            available_strategies=tuple(available),
        )

    # -- budget windows ----------------------------------------------------

    def fallback_window_open(self, state, other_strategies_available):
        """Fallback may be selected only inside the reserved window.

        * the typed (non-fallback) phase keeps at least
          ``min_typed_budget_ratio`` of the total budget, and
        * the fallback phase keeps at least
          ``min_fallback_budget_ratio`` of the total budget.

        When nothing else is left to check, fallback is allowed outside
        the window so the remaining budget is not wasted.
        """
        total = max(1e-6, float(state.get("total_seconds") or 0.0))
        elapsed = max(0.0, float(state.get("elapsed_seconds") or 0.0))
        remaining = max(0.0, total - elapsed)
        if not other_strategies_available:
            return True
        if elapsed < self.config.min_typed_budget_ratio * total:
            return False
        if remaining < self.config.min_fallback_budget_ratio * total:
            return False
        return True

    def fallback_deadline_reached(self, state, fallback_selected_yet):
        """True when the fallback reservation must be honoured now."""
        if fallback_selected_yet:
            return False
        total = max(1e-6, float(state.get("total_seconds") or 0.0))
        remaining = max(0.0, total - max(0.0, float(
            state.get("elapsed_seconds") or 0.0
        )))
        return remaining <= self.config.min_fallback_budget_ratio * total

    # -- reporting -----------------------------------------------------------

    def stats_summary(self):
        return {
            category: stats.as_dict()
            for category, stats in self.stats.items()
            if stats.tried or stats.offered
        }

    def _log(self, record):
        if self.logger is not None:
            try:
                self.logger.write(record)
            except Exception:  # noqa: BLE001 - logging must never break search
                pass
