"""Lossless SMT-LIB transport and exact serialization for raw-VC checking."""
import json
import re

SPLIT = "SPLIT_HERE_asdfghjklzxcvbnmqwertyuiop"


class Unsupported(ValueError):
    pass


def sexps(text):
    """Parse parentheses, comments and quoted identifiers; never evaluate input."""
    tokens = re.findall(r';[^\n]*|\|(?:[^|]|\\\|)*\||"(?:[^"]|"")*"|[()]|[^\s();]+', text)
    roots, stack = [], []
    for token in tokens:
        if token.startswith(';'):
            continue
        if token == '(':
            node = []
            (stack[-1] if stack else roots).append(node)
            stack.append(node)
        elif token == ')':
            if not stack:
                raise Unsupported('unbalanced SMT-LIB parentheses')
            stack.pop()
        else:
            (stack[-1] if stack else roots).append(token)
    if stack:
        raise Unsupported('unbalanced SMT-LIB parentheses')
    return roots


def smt(node):
    return '(' + ' '.join(smt(value) for value in node) + ')' if isinstance(node, list) else node


def raw_problem(text):
    parts = text.split(SPLIT)
    if len(parts) != 5:
        raise Unsupported('raw VC must contain exactly the invariant placeholder and three VC sections')
    definitions = sexps(parts[0] + ' true ' + parts[1])
    invs = [node for node in definitions if isinstance(node, list) and node[:2] == ['define-fun', 'inv-f']]
    if len(invs) != 1 or len(invs[0]) != 5 or invs[0][3] != 'Bool':
        raise Unsupported('unsupported invariant interface')
    parameters = invs[0][2]
    if not parameters or any(len(pair) != 2 or pair[1] not in ('Int', 'Real') for pair in parameters):
        raise Unsupported('only nonempty scalar Int/Real invariant interfaces are supported')
    if len({pair[0] for pair in parameters}) != len(parameters):
        raise Unsupported('duplicate invariant argument')
    assertions = []
    for part in parts[2:]:
        nodes = sexps(part)
        if len(nodes) != 1 or not isinstance(nodes[0], list) or nodes[0][0] != 'assert' or len(nodes[0]) != 2:
            raise Unsupported('each original VC section must contain one assertion')
        assertions.append(nodes[0][1])
    return definitions, parameters, assertions


def arithmetic_profile(text):
    """Classify the actual typed raw formula, without checking satisfiability.

    Several upstream files have LIA headers containing products or Real `/`.
    Promoting their logic enables those existing terms; no formula, sort,
    integer division, or SSA variable is rewritten.
    """
    import z3
    definitions,parameters,assertions=raw_problem(text)
    source=[node[1] for node in definitions if node[0]=='set-logic']
    if len(source)!=1:raise Unsupported('expected one original logic declaration')
    original=source[0].removeprefix('QF_')
    if original not in ('LIA','NIA','LRA','NRA','ALL'):
        raise Unsupported('unsupported original arithmetic logic: '+source[0])
    sorts=set()
    for node in definitions:
        if node[0]=='declare-const':sorts.add(node[2])
        elif node[0]=='define-fun':sorts.update(pair[1] for pair in node[2])
    prefix='\n'.join(smt(node) for node in definitions if node[0]!='set-logic')
    parsed=z3.parse_smt2_string('(set-logic ALL)\n'+prefix+'\n'+'\n'.join(
        '(assert '+smt(assertion)+')' for assertion in assertions))
    nonlinear=original in ('NIA','NRA')
    real='Real' in sorts
    integer='Int' in sorts
    seen=set();pending=list(parsed)
    def numeral(node):
        if z3.is_int_value(node) or z3.is_rational_value(node) or z3.is_algebraic_value(node):return True
        if z3.is_const(node):return False
        if all(numeral(child) for child in node.children()):
            reduced=z3.simplify(node)
            return z3.is_int_value(reduced) or z3.is_rational_value(reduced) or z3.is_algebraic_value(reduced)
        return False
    while pending:
        node=pending.pop()
        if node.get_id() in seen:continue
        seen.add(node.get_id())
        real=real or node.sort().kind()==z3.Z3_REAL_SORT
        integer=integer or (node.sort().kind()==z3.Z3_INT_SORT and not numeral(node))
        if z3.is_app(node):
            kind=node.decl().kind()
            if kind==z3.Z3_OP_MUL and sum(not numeral(child) for child in node.children())>1:
                nonlinear=True
            elif kind in (z3.Z3_OP_DIV,z3.Z3_OP_IDIV,z3.Z3_OP_MOD,z3.Z3_OP_REM) and not numeral(node.arg(1)):
                nonlinear=True
            elif kind==z3.Z3_OP_POWER:
                nonlinear=True
        pending.extend(node.children())
    selected=('ALL' if original=='ALL' else ('NIRA' if nonlinear else 'LIRA') if integer and real else
        ('NRA' if nonlinear else 'LRA') if real else ('NIA' if nonlinear else 'LIA'))
    return dict(source_logic=source[0],selected_logic=selected,integer=integer,real=real,
        nonlinear=nonlinear,policy='Typed original formulas; logic promotion and explicit original-Z3 integer coercions; no projection or division reinterpretation')


def explicit_integer_coercions(definitions):
    """Expose the raw checker's implicit Real-to-Int casts for div/mod.

    Z3 accepts e.g. (mod (/ x 2) 2) by inserting to_int around the Real
    division. Strict SMT-LIB parsers require that cast explicitly. Only
    definitions containing an integer operator use typed AST serialization;
    inv-f remains uninterpreted, never replaced by a concrete invariant.
    No simplifier or satisfiability check is called.
    """
    import z3
    prefix=[]
    for node in definitions:
        if node[0]=='set-logic':continue
        if node[:2]==['define-fun','inv-f']:
            prefix.append(['declare-fun','inv-f',[pair[1] for pair in node[2]],'Bool'])
        else:prefix.append(node)
    context='(set-logic ALL)\n'+'\n'.join(smt(node) for node in prefix)
    output=[];normalized=[]
    def contains(node):
        if not isinstance(node,list):return False
        if node and isinstance(node[0],str) and node[0] in ('div','mod','rem'):return True
        return any(contains(child) for child in node)
    for node in definitions:
        if node[0]!='define-fun' or node[1]=='inv-f' or not contains(node[4]):
            output.append(node);continue
        if node[3]!='Bool':raise Unsupported('integer-coercion transport requires a Boolean helper body')
        parameters=node[2]
        wrapper=['forall',parameters,node[4]] if parameters else node[4]
        parsed=z3.parse_smt2_string(context+'\n(assert '+smt(wrapper)+')')[-1]
        if parameters:
            sorts={'Int':z3.IntSort,'Real':z3.RealSort,'Bool':z3.BoolSort}
            variables=[z3.Const(name,sorts[sort]()) for name,sort in parameters]
            body=z3.substitute_vars(parsed.body(),*reversed(variables))
        else:body=parsed
        serialized=sexps(body.sexpr())
        if len(serialized)!=1:raise Unsupported('typed helper serialization is not one expression')
        replacement=[*node[:4],serialized[0]]
        output.append(replacement)
        if replacement!=node:normalized.append(node[1])
    return output,normalized


def to_sygus(text, with_profile=False):
    """Encode exactly the same synthesis problem, including every SSA variable.

    Original checking asks whether each counterexample assertion is UNSAT.
    The SyGuS constraint is its negation, universally quantified over all
    original declared constants. No projection, C translation or templates.
    """
    definitions, parameters, assertions = raw_problem(text)
    logics = [node[1] for node in definitions if isinstance(node, list) and node[:1] == ['set-logic']]
    if len(logics) != 1:
        raise Unsupported('expected one original logic declaration')
    profile=arithmetic_profile(text)
    definitions,normalized=explicit_integer_coercions(definitions)
    profile['typed_integer_operator_definitions']=normalized
    logic=profile['selected_logic']
    output = [['set-logic', logic]]
    for node in definitions:
        if not isinstance(node, list) or not node:
            raise Unsupported('unexpected top-level SMT input')
        head = node[0]
        if head == 'set-logic':
            continue
        if head == 'declare-const' and len(node) == 3 and node[2] in ('Int', 'Real', 'Bool'):
            output.append(['declare-var', node[1], node[2]])
        elif head == 'define-fun' and node[1] == 'inv-f':
            output.append(['synth-inv', 'inv-f', parameters])
        elif head == 'define-fun':
            output.append(node)
        else:
            raise Unsupported('unsupported original SMT command: ' + head)
    output.extend([['constraint', ['not', assertion]] for assertion in assertions])
    output.append(['check-synth'])
    converted='\n'.join(smt(node) for node in output)+'\n'
    return (converted,parameters,profile) if with_profile else (converted,parameters)


def solution_body(output, parameters):
    matches = []

    def visit(node):
        if isinstance(node, list):
            if node[:2] == ['define-fun', 'inv-f']:
                matches.append(node)
            else:
                for child in node:
                    visit(child)

    for root in sexps(output):
        visit(root)
    if len(matches) != 1:
        return None
    node = matches[0]
    if len(node) != 5 or node[2] != parameters or node[3] != 'Bool':
        raise Unsupported('synthesis solution changed the invariant interface')
    return smt(node[4])


def printed_invariant(body, parameters):
    """Translate SMT output to the existing full_recovery checker vocabulary.

    Z3 is used only as an exact parser here. Rational literals are serialized
    with ToReal, avoiding floats and ambiguous constant integer division.
    """
    import keyword
    import z3
    names = {name for name, _ in parameters}
    if any(not name.isidentifier() or keyword.iskeyword(name) for name in names):
        raise Unsupported('existing Python invariant checker cannot represent this symbol name')
    declarations = '\n'.join(f'(declare-const {name} {sort})' for name, sort in parameters)
    expressions = z3.parse_smt2_string(declarations + '\n(assert ' + body + ')')
    if len(expressions) != 1:
        raise Unsupported('solution is not one Boolean formula')
    calls = {z3.Z3_OP_AND: 'And', z3.Z3_OP_OR: 'Or', z3.Z3_OP_NOT: 'Not',
             z3.Z3_OP_IMPLIES: 'Implies', z3.Z3_OP_ITE: 'If', z3.Z3_OP_XOR: 'Xor',
             z3.Z3_OP_DISTINCT: 'Distinct', z3.Z3_OP_TO_REAL: 'ToReal', z3.Z3_OP_TO_INT: 'ToInt'}
    infix = {z3.Z3_OP_ADD: '+', z3.Z3_OP_SUB: '-', z3.Z3_OP_MUL: '*', z3.Z3_OP_DIV: '/',
             z3.Z3_OP_IDIV: '/', z3.Z3_OP_MOD: '%', z3.Z3_OP_POWER: '**', z3.Z3_OP_EQ: '==',
             z3.Z3_OP_LE: '<=', z3.Z3_OP_GE: '>=', z3.Z3_OP_LT: '<', z3.Z3_OP_GT: '>'}

    def emit(expr):
        if z3.is_true(expr):
            return 'True'
        if z3.is_false(expr):
            return 'False'
        if z3.is_int_value(expr):
            return str(expr.as_long())
        if z3.is_rational_value(expr):
            return f'(ToReal({expr.numerator_as_long()}) / ToReal({expr.denominator_as_long()}))'
        if z3.is_const(expr) and expr.decl().kind() == z3.Z3_OP_UNINTERPRETED and str(expr) in names:
            return str(expr)
        if not z3.is_app(expr):
            raise Unsupported('quantified or non-application invariant output')
        kind, arguments = expr.decl().kind(), [emit(child) for child in expr.children()]
        if kind == z3.Z3_OP_POWER:
            exponent = z3.simplify(expr.arg(1))
            integer = exponent.as_long() if z3.is_int_value(exponent) else (
                exponent.numerator_as_long() if z3.is_rational_value(exponent)
                and exponent.denominator_as_long() == 1 else None)
            if integer is not None and 0 <= integer <= 100:
                return '(' + arguments[0] + ' ** ' + str(integer) + ')'
            raise Unsupported('power exponent is outside the independent checker domain 0--100')
        if kind in calls:
            return calls[kind] + '(' + ', '.join(arguments) + ')'
        if kind == z3.Z3_OP_UMINUS:
            return '(-' + arguments[0] + ')'
        if kind in infix and len(arguments) >= 2:
            # Z3 IDIV on two integer numerals must not become an ambiguous
            # rational in the downstream printed-expression parser.
            if kind == z3.Z3_OP_IDIV and all(z3.is_int_value(child) for child in expr.children()):
                return emit(z3.simplify(expr))
            return '(' + (' ' + infix[kind] + ' ').join(arguments) + ')'
        raise Unsupported('unsupported invariant operator: ' + str(expr.decl()))

    return emit(expressions[0])


def from_infix(text):
    """Transport the author's Boolean infix result to the checker grammar."""
    import ast
    tree = ast.parse(re.sub(r'!(?!=)', ' not ', text.replace('&&', ' and ').replace('||', ' or ')).strip(), mode='eval')

    class BooleanCalls(ast.NodeTransformer):
        def visit_BoolOp(self, node):
            return ast.copy_location(ast.Call(func=ast.Name(id='And' if isinstance(node.op, ast.And) else 'Or', ctx=ast.Load()),
                                             args=[self.visit(value) for value in node.values], keywords=[]), node)

        def visit_UnaryOp(self, node):
            if isinstance(node.op, ast.Not):
                return ast.copy_location(ast.Call(func=ast.Name(id='Not', ctx=ast.Load()), args=[self.visit(node.operand)], keywords=[]), node)
            return self.generic_visit(node)

    return ast.unparse(ast.fix_missing_locations(BooleanCalls().visit(tree)))
