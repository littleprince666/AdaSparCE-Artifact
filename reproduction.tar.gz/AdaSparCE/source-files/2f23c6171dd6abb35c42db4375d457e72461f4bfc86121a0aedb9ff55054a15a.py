"""Resolve candidate variables from the Checker invariant interface."""

import re
from pathlib import Path

from Utilities.Cparser import get_varnames_from_source_code


def _is_auxiliary_variable(name):
    """Return True for SSA intermediates, control-flow, and primed variables.

    Filters out the code2inv/SyGuS SSA naming conventions:
      - Primed: ``x!``
      - Control-flow: ``conf_0``, ``conf_1``, ...
      - SSA numbered: ``x_0``, ``x_1``, ``x_2``, ...
      - SSA nested: ``x_0_1``, ``conf_1_2``, ...
    """
    if name.endswith("!"):
        return True
    if name.startswith("conf"):
        return True
    if re.match(r"^\w+_\d+$", name):
        return True
    if re.match(r"^\w+_0_\d+$", name):
        return True
    return False


def base_variables(variables):
    """Filter to 'base' program variables, removing SSA intermediates."""
    filtered = tuple(v for v in variables if not _is_auxiliary_variable(v))
    return filtered if filtered else variables


def checker_invariant_variables(smt_path):
    text = Path(smt_path).read_text(encoding="utf-8")
    match = re.search(
        r"\(\s*define-fun\s+inv-f\s*\((.*?)\)\s*Bool",
        text,
        re.DOTALL,
    )
    if match is None:
        raise ValueError(
            "Checker VC has no inv-f declaration: {}".format(smt_path)
        )
    variables = tuple(
        name
        for name, sort in re.findall(
            r"\(\s*([^\s()]+)\s+(Int|Real)\s*\)",
            match.group(1),
        )
    )
    if not variables:
        raise ValueError(
            "Checker inv-f has no state variables: {}".format(smt_path)
        )
    return variables


def candidate_variables(c_path, smt_path):
    parsed = get_varnames_from_source_code(c_path)
    if isinstance(parsed, str):
        raise ValueError(
            "could not parse program variables: {}".format(parsed)
        )
    source_variables = {
        name for name in parsed if name not in ("assume", "assert")
    }
    checker_variables = checker_invariant_variables(smt_path)
    variables = tuple(
        name for name in checker_variables if name in source_variables
    )
    if not variables:
        raise ValueError(
            "C source and Checker inv-f share no candidate variables: "
            "{} / {}".format(c_path, smt_path)
        )
    return variables
