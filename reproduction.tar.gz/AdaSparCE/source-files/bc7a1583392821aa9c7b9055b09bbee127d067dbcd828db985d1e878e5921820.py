"""Candidate pruning mechanisms for reducing wasted Z3 calls.

Three pruning strategies:

1. **Structure-equivalence pruning**: If a candidate with coefficient
   ratio (1:-1) fails, skip candidates with proportional ratios
   (2:-2, 4:-4) since GCD canonicalization already handles exact
   multiples, but cross-clause proportionality is not checked.

2. **Trivial candidate filtering**: Skip candidates that are trivially
   true (e.g., x² ≥ 0) or trivially false (e.g., x = 0 when INIT
   allows x ≠ 0).

3. **Counterexample memory**: Cache counterexamples and use them to
   quickly reject candidates that would be refuted by the same
   counterexample, without calling Z3.
"""

from math import gcd
from functools import reduce


class CandidatePruner:
    """Prune candidates before Z3 verification."""

    def __init__(self):
        self._structure_signatures = set()
        self._coefficient_ratios = {}
        self._counterexamples = []
        self._stats = {
            "trivial_filtered": 0,
            "structure_filtered": 0,
            "ce_filtered": 0,
            "passed": 0,
        }

    @property
    def stats(self):
        return dict(self._stats)

    def _coefficient_ratio_key(self, coefficient_vectors):
        """Compute a normalized ratio key for coefficient vectors.

        Two candidates with the same monomial structure and
        proportional coefficients are equivalent (up to scaling).
        The GCD canonicalization in PolynomialCandidate handles
        per-clause scaling, but cross-clause proportionality
        is not checked.  This function extracts the cross-clause
        ratio pattern.
        """
        all_coeffs = []
        for vector in coefficient_vectors:
            for coeff in vector:
                if coeff:
                    all_coeffs.append(abs(coeff))
        if not all_coeffs:
            return ()
        base_gcd = reduce(gcd, all_coeffs)
        if base_gcd == 0:
            return ()
        normalized = tuple(
            coeff // base_gcd if base_gcd else coeff
            for vector in coefficient_vectors
            for coeff in vector
        )
        return normalized

    def _structure_key(self, candidate):
        """Extract a structure signature ignoring coefficients.

        Two candidates with the same monomials, relations, and
        coefficient sign pattern (but different magnitudes) are
        likely to behave similarly under Z3.
        """
        parts = []
        for clause, vector in zip(
            candidate.clauses, candidate.coefficient_vectors
        ):
            signs = tuple(
                1 if coeff > 0 else (-1 if coeff < 0 else 0)
                for coeff in vector
            )
            monomial_keys = tuple(
                monomial.canonical_key
                for monomial, coeff in zip(clause.support, vector)
                if coeff
            )
            parts.append((clause.relation, monomial_keys, signs))
        return tuple(parts)

    def _is_trivially_true(self, candidate):
        """Check if candidate is trivially true (no information).

        Examples:
          x² ≥ 0  (always true for integers)
          x ≥ 0   when x is initialized to 0 and only increases
        """
        text = candidate.pretty_print()
        # Single clause with single monomial >= 0
        if " and " not in text:
            for clause, vector in zip(
                candidate.clauses, candidate.coefficient_vectors
            ):
                nonzero = [c for c in vector if c]
                if len(nonzero) == 1 and clause.relation in (">=", "<="):
                    coeff = nonzero[0]
                    monomial = next(
                        m for m, c in zip(clause.support, vector) if c
                    )
                    if monomial.degree >= 2 and coeff > 0:
                        return True
                    if clause.relation == "<=" and monomial.degree >= 2 and coeff > 0:
                        return True
        return False

    def _is_trivially_false(self, candidate, init_info=None):
        """Check if candidate is trivially false.

        Examples:
          x = 0  (when x is not always 0)
          1 = 0
          0 >= 1
        """
        for clause, vector in zip(
            candidate.clauses, candidate.coefficient_vectors
        ):
            nonzero = [c for c in vector if c]
            if not nonzero and clause.relation == "=":
                return True
            if len(nonzero) == 1:
                monomial = next(
                    m for m, c in zip(clause.support, vector) if c
                )
                if (
                    clause.relation == "="
                    and monomial.degree == 1
                    and len(monomial.variables_used) == 1
                ):
                    return True
        return False

    def _counterexample_rejects(self, candidate):
        """Check if any cached counterexample refutes this candidate.

        Returns True if a known counterexample makes this candidate
        false, so we can skip the Z3 call.
        """
        if not self._counterexamples:
            return False
        try:
            z3_formula = candidate.to_z3()
        except Exception:
            return False
        for ce in self._counterexamples:
            try:
                if isinstance(ce, dict):
                    assignment = ce
                elif isinstance(ce, (tuple, list)) and len(ce) == 2:
                    before, after = ce
                    assignment = dict(before) if isinstance(before, dict) else {}
                    if isinstance(after, dict):
                        for k, v in after.items():
                            assignment[k + "!"] = v
                else:
                    continue
                import z3 as _z3
                substitution = []
                for var_name, value in assignment.items():
                    clean_name = var_name.rstrip("!").replace("!", "")
                    try:
                        z3_var = _z3.Int(clean_name)
                        if isinstance(value, int):
                            substitution.append((z3_var, _z3.IntVal(value)))
                        elif hasattr(value, "as_long"):
                            substitution.append(
                                (z3_var, _z3.IntVal(value.as_long()))
                            )
                    except Exception:
                        pass
                if not substitution:
                    continue
                substituted = _z3.substitute(z3_formula, *substitution)
                simplified = _z3.simplify(substituted)
                if _z3.is_false(simplified):
                    return True
            except Exception:
                continue
        return False

    def should_check(self, candidate, init_info=None):
        """Return True if the candidate should be sent to Z3.

        Returns False if the candidate is pruned (trivial, duplicate
        structure, or refuted by cached counterexample).
        """
        # 1. Trivial candidate filter
        if self._is_trivially_true(candidate):
            self._stats["trivial_filtered"] += 1
            return False
        if self._is_trivially_false(candidate, init_info):
            self._stats["trivial_filtered"] += 1
            return False

        # 2. Structure-equivalence filter (DISABLED — too aggressive
        # for nonlinear arithmetic where coefficient magnitudes matter)

        # 3. Counterexample memory filter
        if self._counterexample_rejects(candidate):
            self._stats["ce_filtered"] += 1
            return False

        self._stats["passed"] += 1
        return True

    def record_counterexample(self, counterexample):
        """Cache a counterexample for future pruning.

        Args:
            counterexample: Either a dict {var: value} or a
                (before_dict, after_dict) tuple from the checker.
        """
        if counterexample is not None:
            self._counterexamples.append(counterexample)
            if len(self._counterexamples) > 50:
                self._counterexamples = self._counterexamples[-50:]

    def should_check_formula(self, formula):
        """Formula-level pruning for ada_engine's _check_branch.

        Only uses trivial true/false checks via z3.simplify.
        CE memory and structure dedup are DISABLED because they
        incorrectly reject valid candidates in CEGIS (where
        counterexamples are per-query, not global).
        """
        # Trivially true/false checks on formula
        try:
            import z3 as _z3
            simplified = _z3.simplify(formula)
            if _z3.is_true(simplified):
                self._stats["trivial_filtered"] += 1
                return False
            if _z3.is_false(simplified):
                self._stats["trivial_filtered"] += 1
                return False
        except Exception:
            pass

        self._stats["passed"] += 1
        return True

    def reset(self):
        """Reset per-task state."""
        self._structure_signatures = set()
        self._coefficient_ratios = {}
        self._counterexamples = []
