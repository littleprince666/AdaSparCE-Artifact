class Config:

    PT_SOLVING_TIME = 10

    SMT_CHECK_TIME = 100

    PT_SOLVING_MAX_CE = 100

    Limited_time = 600


config = Config()
