"""Command-line entry point for Baseline and deterministic sparse mode."""

import argparse
import json

from SparCE.engine import SparseConfig, SparseHeuristicEngine


def _parse_strategy_quotas(raw):
    """Parse 'cat=quota,cat=quota' into a dict; empty means defaults."""
    quotas = {}
    if not raw:
        return quotas
    for item in raw.split(","):
        item = item.strip()
        if not item:
            continue
        if "=" not in item:
            raise ValueError(
                f"invalid strategy quota entry: {item!r} (expected 'cat=quota')"
            )
        name, value = item.split("=", 1)
        quotas[name.strip()] = int(value)
    return quotas


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--template-mode",
        choices=(
            "baseline",
            "sparse-heuristic",
            "adasparce",
        ),
        default="sparse-heuristic",
    )
    parser.add_argument("--program-id", required=True)
    parser.add_argument("--c", required=True)
    parser.add_argument("--cfg")
    parser.add_argument("--smt", required=True)
    parser.add_argument("--max-degree", type=int, default=2)
    parser.add_argument("--max-monomials", type=int, default=12)
    parser.add_argument("--max-clauses", type=int, default=1)
    parser.add_argument("--coefficient-bounds", default="1,2,4,8")
    parser.add_argument("--timeout", type=float, default=30)
    parser.add_argument("--enable-coverage-optimizations", action="store_true")
    parser.add_argument("--template-timeout", type=float, default=5)
    parser.add_argument("--checker-timeout", type=float, default=10)
    parser.add_argument("--log-jsonl")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--disable-template-cache", action="store_true")
    parser.add_argument("--disable-candidate-cache", action="store_true")
    parser.add_argument("--enable-pruning", action="store_true")
    parser.add_argument("--max-candidates-per-structure", type=int, default=12)
    parser.add_argument(
        "--max-checker-calls",
        type=int,
        default=0,
        help=(
            "global final-SMT-check budget per task; zero means unlimited"
        ),
    )
    parser.add_argument(
        "--method-name",
        choices=(
            "AdaSparCE-Heuristic",
            "AdaSparCE-Legacy-MLP",
            "AdaSparCE-DeepSets-Ranker",
            "AdaSparCE-Graph-Ranker",
            "AdaSparCE-Random-Ranker",
            "AdaSparCE-Strategy-Scheduler",
        ),
    )
    parser.add_argument("--beam-width", type=int, default=5)
    parser.add_argument("--disable-degree-iterative", action="store_true")
    parser.add_argument("--disable-clause-iterative", action="store_true")
    parser.add_argument("--disable-typed-counterexamples", action="store_true")
    parser.add_argument(
        "--disable-semantic-generators",
        action="store_true",
        help=(
            "G module off: disable every program-semantics-specialised "
            "candidate generator (typed mechanisms, exact VC frontends, "
            "transition kernel, linear fast path); keep only the direct "
            "postcondition seed and the generic sparse template search"
        ),
    )
    parser.add_argument(
        "--disable-monomial-feedback",
        action="store_true",
        help=(
            "E module off for the sparse template search: keep the "
            "initial syntactic monomial ranking fixed instead of "
            "boosting monomials by observed failure type (the basic "
            "CEGIS counterexample constraints are unaffected)"
        ),
    )
    parser.add_argument("--disable-beam-search", action="store_true")
    parser.add_argument("--disable-update-closure", action="store_true")
    parser.add_argument("--disable-precondition-frame", action="store_true")
    parser.add_argument(
        "--disable-monotone-entry-bounds", action="store_true"
    )
    parser.add_argument(
        "--disable-affine-exit-boundary", action="store_true"
    )
    parser.add_argument("--enable-smt-vc-frontend", action="store_true")
    parser.add_argument("--smt-vc-max-degree", type=int, default=4)
    parser.add_argument(
        "--enable-branchwise-conservation-frontend",
        action="store_true",
    )
    parser.add_argument(
        "--branchwise-conservation-max-degree", type=int, default=2
    )
    parser.add_argument(
        "--enable-scaled-division-frontend", action="store_true"
    )
    parser.add_argument(
        "--enable-entry-potential-frontend", action="store_true"
    )
    parser.add_argument(
        "--enable-exit-post-closure-frontend", action="store_true"
    )
    parser.add_argument(
        "--enable-algebraic-recurrence-frontend", action="store_true"
    )
    parser.add_argument(
        "--algebraic-recurrence-max-degree", type=int, default=6
    )
    parser.add_argument(
        "--algebraic-recurrence-minimum-degree",
        type=int,
        default=0,
        help=(
            "minimum degree for sparse-recurrence closures; 0 keeps the "
            "historical floor (smt_vc_max_degree + 1)"
        ),
    )
    parser.add_argument(
        "--enable-branch-transitions",
        action="store_true",
        help=(
            "collect per-path (guard, updates) branch transitions with "
            "correct if/else semantics (legacy merged updates untouched)"
        ),
    )
    parser.add_argument(
        "--enable-transition-kernel",
        action="store_true",
        help=(
            "transition-relation and initial-condition driven equality "
            "synthesis (invariant-subspace linear algebra over a "
            "degree-bounded monomial basis)"
        ),
    )
    parser.add_argument(
        "--transition-kernel-max-degree", type=int, default=3
    )
    parser.add_argument("--transition-kernel-max-atoms", type=int, default=8)
    parser.add_argument(
        "--transition-kernel-max-conjunctions", type=int, default=3
    )
    parser.add_argument(
        "--enable-unified-clause-bank",
        action="store_true",
        help=(
            "single shared partial-clause store (INIT/STEP/EXIT outcome, "
            "counterexample, source, cost) feeding both conjunction "
            "trials and the clause composer"
        ),
    )
    parser.add_argument(
        "--unified-clause-bank-max-trials", type=int, default=64
    )
    parser.add_argument("--disable-divmod-frontend", action="store_true")
    parser.add_argument("--disable-linear-fast-path", action="store_true")
    parser.add_argument(
        "--enable-linear-fast-path-guard",
        action="store_true",
        help=(
            "skip the linear fast path when a pre-loop initialization is "
            "nonlinear (the invariant then needs degree >= 2)"
        ),
    )
    parser.add_argument("--disable-fallback", action="store_true")
    parser.add_argument(
        "--fallback-mode",
        choices=("fixed", "stagnation"),
        default="fixed",
        help=(
            "fixed keeps the historical 30/70 typed/fallback time split; "
            "stagnation gives the typed phase the full budget and hands "
            "the remainder to fallback after repeated non-progress checks"
        ),
    )
    parser.add_argument(
        "--fallback-stagnation-patience",
        type=int,
        default=8,
        help="consecutive checks without a new counterexample before "
             "the stagnation fallback triggers",
    )
    parser.add_argument(
        "--fallback-stagnation-min-elapsed-ratio",
        type=float,
        default=0.2,
        help="minimum elapsed budget fraction before stagnation may exit",
    )
    parser.add_argument(
        "--enable-ce-prefilter",
        action="store_true",
        help=(
            "skip SMT checks for candidates already refuted by an "
            "observed counterexample (sound replay, no solver call)"
        ),
    )
    parser.add_argument(
        "--enable-clause-composer",
        action="store_true",
        help=(
            "enable non-LLM, typed-counterexample-guided candidate "
            "composition"
        ),
    )
    parser.add_argument("--clause-composer-bank-size", type=int, default=64)
    parser.add_argument(
        "--clause-composer-max-ast-size", type=int, default=180
    )
    parser.add_argument(
        "--clause-composer-max-proposals", type=int, default=32
    )
    parser.add_argument(
        "--clause-composer-per-failure", type=int, default=4
    )
    parser.add_argument(
        "--clause-composer-generation-budget-ratio",
        type=float,
        default=0.15,
    )
    parser.add_argument(
        "--disable-lemma-conjunction",
        action="store_true",
        help=(
            "disable partial-lemma conjunction trials (EXIT-only and "
            "STEP-failing clauses are retained and verified jointly)"
        ),
    )
    parser.add_argument(
        "--lemma-conjunction-max-trials",
        type=int,
        default=48,
        help="per-task budget of partial-lemma conjunction VC checks",
    )
    parser.add_argument(
        "--degree-escalation-cap",
        type=int,
        default=0,
        help=(
            "continue degree-iterative layers up to this cap after the "
            "configured max_degree layers are exhausted (0 disables)"
        ),
    )
    parser.add_argument(
        "--clause-escalation-cap",
        type=int,
        default=0,
        help=(
            "continue clause-iterative layers up to this cap after the "
            "configured max_clauses layers are exhausted (0 disables)"
        ),
    )
    parser.add_argument(
        "--timeout-escalation-limit",
        type=int,
        default=3,
        help=(
            "per-task retry limit for checker timeout escalation"
        ),
    )
    parser.add_argument(
        "--timeout-escalation-cap",
        type=float,
        default=150.0,
        help="maximum checker timeout used by escalation retries",
    )
    parser.add_argument(
        "--enable-strategy-scheduler",
        action="store_true",
        help=(
            "enable the cost-aware strategy-level scheduler: mechanism "
            "pools, clause composer, partial-lemma conjunctions and the "
            "fallback hand-over are ordered by "
            "(strategy, quota, checker timeout tier) actions"
        ),
    )
    parser.add_argument(
        "--strategy-scheduler-policy",
        choices=("heuristic", "random", "fixed", "cost-only"),
        default="heuristic",
        help=(
            "heuristic: per-instance cost/progress adaptation; fixed: "
            "catalog order; cost-only: observed checker cost; random: "
            "uniform action-group ordering under --seed"
        ),
    )
    parser.add_argument("--strategy-scheduler-granularity", default="category21",
                        choices=("coarse4", "middle8", "category21", "mechanism"))
    parser.add_argument("--strategy-scheduler-no-online-updates", action="store_true")
    parser.add_argument("--strategy-scheduler-quota-mode", default="legacy",
                        choices=("legacy", "auto", "unit"))
    parser.add_argument("--strategy-scheduler-round-budget-ratio", type=float, default=0.10)
    parser.add_argument("--strategy-scheduler-prior-strength", type=float, default=5.0)
    parser.add_argument("--strategy-scheduler-progress-weight", type=float, default=0.05)
    parser.add_argument("--strategy-scheduler-disabled-categories", default="",
                        help="comma-separated categories whose outputs are removed from pools and composition")
    parser.add_argument(
        "--strategy-scheduler-utility",
        choices=("ratio", "linear", "success"),
        default="ratio",
        help=(
            "ratio: p_success / (epsilon + expected_time); "
            "linear: p_success - lambda*expected_time - mu*p_timeout; "
            "success: p_success only (ablation control, cost ignored)"
        ),
    )
    parser.add_argument(
        "--strategy-scheduler-priors",
        choices=("empirical", "cold"),
        default="empirical",
        help=(
            "empirical: corpus-derived aggregate priors; cold: zero "
            "corpus statistics (uniform success prior, structural "
            "cost-class time defaults)"
        ),
    )
    parser.add_argument(
        "--strategy-scheduler-epsilon",
        type=float,
        default=1.0,
        help="epsilon in the ratio utility form",
    )
    parser.add_argument(
        "--strategy-scheduler-lambda",
        type=float,
        default=0.005,
        help="per-second cost weight in the linear utility form",
    )
    parser.add_argument(
        "--strategy-scheduler-mu",
        type=float,
        default=0.1,
        help="timeout-probability weight in the linear utility form",
    )
    parser.add_argument(
        "--strategy-scheduler-exploration-scale",
        type=float,
        default=0.05,
        help="UCB exploration scale of the heuristic bandit",
    )
    parser.add_argument(
        "--strategy-scheduler-min-typed-budget-ratio",
        type=float,
        default=0.15,
        help=(
            "minimum fraction of the task budget reserved for the "
            "typed (non-fallback) phase"
        ),
    )
    parser.add_argument(
        "--strategy-scheduler-min-fallback-budget-ratio",
        type=float,
        default=0.2,
        help=(
            "minimum fraction of the task budget reserved for the "
            "fallback engine"
        ),
    )
    parser.add_argument(
        "--strategy-scheduler-timeout-tiers",
        default="4,15,60,150",
        help="comma-separated ascending checker timeout tiers (seconds)",
    )
    parser.add_argument(
        "--strategy-scheduler-quotas",
        default="",
        help=(
            "comma-separated per-strategy candidate quotas, e.g. "
            "'divmod=3,counter-lift=4'; unlisted strategies use defaults"
        ),
    )
    parser.add_argument(
        "--strategy-scheduler-max-decisions",
        type=int,
        default=200,
        help="per-task cap on scheduling decisions",
    )
    parser.add_argument(
        "--strategy-scheduler-progress-feedback",
        action="store_true",
        help=(
            "add a per-strategy best-progress bonus (EXIT > STEP > INIT) "
            "to the scheduler utility; exploration floor unchanged"
        ),
    )
    parser.add_argument(
        "--enable-checker-timeout-retry",
        action="store_true",
        help=(
            "re-queue a timed-out candidate once with a higher checker "
            "timeout tier while the task budget allows; the timeout stays "
            "censored (UNKNOWN) for the strategy statistics"
        ),
    )
    parser.add_argument(
        "--checker-timeout-retry-limit",
        type=int,
        default=1,
        help="per-task cap on checker-timeout retries",
    )
    parser.add_argument(
        "--strategy-scheduler-complexity-degree-weight",
        type=float,
        default=2.0,
        help=(
            "degree weight of the combined-complexity best-first pool "
            "ordering"
        ),
    )
    parser.add_argument(
        "--strategy-scheduler-complexity-clause-weight",
        type=float,
        default=1.0,
        help=(
            "clause weight of the combined-complexity best-first pool "
            "ordering"
        ),
    )
    parser.add_argument(
        "--neural-scorer",
        action="store_true",
        help="enable neural adaptive scorer for AdaSparCE beam ranking",
    )
    parser.add_argument(
        "--neural-scorer-checkpoint",
        default="",
        help="path to a pretrained neural scorer checkpoint",
    )
    parser.add_argument(
        "--neural-scorer-device",
        default="auto",
        help=(
            "torch device for the legacy neural scorer: 'cpu', 'npu', "
            "'cuda', or 'auto (pick cuda>npu>cpu)'"
        ),
    )
    parser.add_argument(
        "--neural-scorer-save",
        default="",
        help="path to save the neural scorer after the run",
    )
    parser.add_argument(
        "--neural-scorer-alpha",
        type=float,
        default=0.5,
        help="blending weight: final = branch.score + bonus + alpha*neural*100",
    )
    parser.add_argument(
        "--neural-scorer-lr",
        type=float,
        default=1e-3,
        help="online learning rate for the neural scorer",
    )
    parser.add_argument(
        "--neural-scorer-warmup",
        type=int,
        default=5,
        help="number of online samples before neural scoring is fully active",
    )
    parser.add_argument(
        "--neural-scorer-no-online",
        action="store_true",
        help="disable online learning (inference only)",
    )
    neural_ranker_group = parser.add_mutually_exclusive_group()
    neural_ranker_group.add_argument(
        "--neural-ranker",
        action="store_true",
        help="enable the frozen VC-conditioned DeepSets ranker",
    )
    neural_ranker_group.add_argument(
        "--graph-ranker",
        action="store_true",
        help="enable the frozen relational program--VC graph ranker",
    )
    neural_ranker_group.add_argument(
        "--random-ranker",
        action="store_true",
        help="enable deterministic random candidate ranking control",
    )
    neural_ranker_group.add_argument(
        "--disable-neural-ranker",
        action="store_true",
        help="explicitly keep the DeepSets ranker disabled",
    )
    parser.add_argument(
        "--neural-ranker-checkpoint",
        default="",
        help="strict versioned DeepSets ranker checkpoint",
    )
    parser.add_argument("--neural-ranker-alpha", type=float, default=1.0)
    parser.add_argument("--neural-ranker-beta", type=float, default=1.0)
    parser.add_argument("--neural-ranker-gamma", type=float, default=0.2)
    parser.add_argument(
        "--neural-ranker-device",
        default="auto",
        help="ranker inference device: cpu, cuda[:id], npu[:id], or auto",
    )
    parser.add_argument(
        "--neural-ranker-topk-safe",
        type=int,
        default=5,
        help="force-retain this many highest legacy-heuristic candidates",
    )
    parser.add_argument(
        "--neural-ranker-safety-mode",
        choices=("topk", "mechanism"),
        default="topk",
        help=(
            "topk freezes the heuristic prefix of the ranker (legacy); "
            "mechanism keeps one heuristic representative per triggered "
            "mechanism and lets the ranker order everything else"
        ),
    )
    parser.add_argument(
        "--neural-ranker-exploration-ratio",
        type=float,
        default=0.1,
        help="deterministic exploration fraction retained beyond safe sets",
    )
    parser.add_argument(
        "--neural-ranker-nonlinear-only",
        action="store_true",
        help="keep structurally linear programs on the legacy heuristic path",
    )
    parser.add_argument(
        "--enable-graph-strategy",
        action="store_true",
        help=(
            "use the symbolic program--VC dependency graph as a bounded "
            "candidate scheduling prior (SMT proof remains unchanged)"
        ),
    )
    parser.add_argument(
        "--graph-strategy-weight",
        type=float,
        default=8.0,
        help="maximum graph-structural scheduling bonus",
    )
    parser.add_argument(
        "--disable-neural-ranker-online-updates",
        action="store_true",
        help="protocol assertion; the DeepSets ranker is always inference-only",
    )
    parser.add_argument(
        "--ranker-trace",
        action="store_true",
        help="emit identifier-free neural-ranker candidate-group traces",
    )
    parser.add_argument(
        "--ranker-trace-run-id",
        default="",
        help="stable collection run id stored in ranker trace records",
    )
    parser.add_argument(
        "--ranker-trace-program-hash",
        default="",
        help="expected C+SMT content hash; mismatch is fatal",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    if (
        args.neural_ranker or args.graph_ranker or args.random_ranker
    ) and args.neural_scorer:
        raise ValueError(
            "candidate rankers and --neural-scorer are mutually exclusive"
        )
    if args.template_mode == "baseline":
        if not args.cfg:
            raise ValueError("--cfg is required in baseline mode")
        from baseline.main import main as baseline_main
        solver_time, invariant = baseline_main(args.c, args.cfg, args.smt)
        print(json.dumps({"status": "solved" if invariant else "timeout", "solver_time": solver_time, "invariant": invariant}))
        return

    common = dict(
        max_degree=args.max_degree,
        max_monomials=args.max_monomials,
        max_clauses=args.max_clauses,
        coefficient_bounds=tuple(int(value) for value in args.coefficient_bounds.split(",")),
        timeout_seconds=args.timeout,
        template_timeout_seconds=args.template_timeout,
        checker_timeout_seconds=args.checker_timeout,
        enable_template_cache=not args.disable_template_cache,
        enable_candidate_cache=not args.disable_candidate_cache,
        enable_pruning=args.enable_pruning,
        max_candidates_per_structure=args.max_candidates_per_structure,
        max_checker_calls=args.max_checker_calls,
        seed=args.seed,
        monomial_feedback=not args.disable_monomial_feedback,
    )
    if args.template_mode == "adasparce":
        from SparCE.ada_engine import AdaSparCEConfig, AdaSparCEEngine

        ns_config = None
        if args.neural_scorer:
            from SparCE.ranking.neural_scorer import NeuralScorerConfig

            ns_config = NeuralScorerConfig(
                alpha=args.neural_scorer_alpha,
                learning_rate=args.neural_scorer_lr,
                alpha_warmup=args.neural_scorer_warmup,
                online=not args.neural_scorer_no_online,
                device=args.neural_scorer_device,
            )
        sparse_config = AdaSparCEConfig(
            **common,
            beam_width=args.beam_width,
            degree_iterative=not args.disable_degree_iterative,
            clause_iterative=not args.disable_clause_iterative,
            typed_counterexamples=not args.disable_typed_counterexamples,
            semantic_generators_enabled=(
                not args.disable_semantic_generators
            ),
            beam_search=not args.disable_beam_search,
            update_closure=not args.disable_update_closure,
            precondition_frame=not args.disable_precondition_frame,
            monotone_entry_bounds=(
                not args.disable_monotone_entry_bounds
            ),
            affine_exit_boundary=(
                not args.disable_affine_exit_boundary
            ),
            smt_vc_frontend=args.enable_smt_vc_frontend,
            smt_vc_max_degree=args.smt_vc_max_degree,
            branchwise_conservation_frontend=(
                args.enable_branchwise_conservation_frontend
            ),
            branchwise_conservation_max_degree=(
                args.branchwise_conservation_max_degree
            ),
            scaled_division_frontend=args.enable_scaled_division_frontend,
            entry_potential_frontend=args.enable_entry_potential_frontend,
            exit_post_closure_frontend=(
                args.enable_exit_post_closure_frontend
            ),
            algebraic_recurrence_frontend=(
                args.enable_algebraic_recurrence_frontend
            ),
            algebraic_recurrence_max_degree=(
                args.algebraic_recurrence_max_degree
            ),
            algebraic_recurrence_minimum_degree=(
                args.algebraic_recurrence_minimum_degree
            ),
            branch_transitions_enabled=args.enable_branch_transitions,
            transition_kernel_enabled=args.enable_transition_kernel,
            transition_kernel_max_degree=(
                args.transition_kernel_max_degree
            ),
            transition_kernel_max_atoms=(
                args.transition_kernel_max_atoms
            ),
            transition_kernel_max_conjunctions=(
                args.transition_kernel_max_conjunctions
            ),
            unified_clause_bank_enabled=(
                args.enable_unified_clause_bank
            ),
            unified_clause_bank_max_trials=(
                args.unified_clause_bank_max_trials
            ),
            divmod_frontend=not args.disable_divmod_frontend,
            linear_fast_path=not args.disable_linear_fast_path,
            linear_fast_path_guard=args.enable_linear_fast_path_guard,
            fallback_enabled=not args.disable_fallback,
            fallback_mode=args.fallback_mode,
            fallback_stagnation_patience=(
                args.fallback_stagnation_patience
            ),
            fallback_stagnation_min_elapsed_ratio=(
                args.fallback_stagnation_min_elapsed_ratio
            ),
            counterexample_prefilter=args.enable_ce_prefilter,
            neural_scorer_enabled=args.neural_scorer,
            neural_scorer_config=ns_config,
            neural_scorer_checkpoint=args.neural_scorer_checkpoint,
            neural_scorer_save_path=args.neural_scorer_save,
            neural_ranker_enabled=(
                args.neural_ranker and not args.disable_neural_ranker
            ),
            graph_ranker_enabled=(
                args.graph_ranker and not args.disable_neural_ranker
            ),
            random_ranker_enabled=(
                args.random_ranker and not args.disable_neural_ranker
            ),
            neural_ranker_checkpoint=args.neural_ranker_checkpoint,
            neural_ranker_alpha=args.neural_ranker_alpha,
            neural_ranker_beta=args.neural_ranker_beta,
            neural_ranker_gamma=args.neural_ranker_gamma,
            neural_ranker_device=args.neural_ranker_device,
            neural_ranker_topk_safe=args.neural_ranker_topk_safe,
            neural_ranker_safety_mode=args.neural_ranker_safety_mode,
            neural_ranker_exploration_ratio=(
                args.neural_ranker_exploration_ratio
            ),
            neural_ranker_nonlinear_only=(
                args.neural_ranker_nonlinear_only
            ),
            graph_strategy_enabled=args.enable_graph_strategy,
            graph_strategy_weight=args.graph_strategy_weight,
            neural_ranker_online_updates=False,
            ranker_trace_enabled=args.ranker_trace,
            ranker_trace_run_id=args.ranker_trace_run_id,
            ranker_trace_program_hash=args.ranker_trace_program_hash,
            clause_composer_enabled=args.enable_clause_composer,
            clause_composer_bank_size=args.clause_composer_bank_size,
            clause_composer_max_ast_size=(
                args.clause_composer_max_ast_size
            ),
            clause_composer_max_proposals=(
                args.clause_composer_max_proposals
            ),
            clause_composer_per_failure=(
                args.clause_composer_per_failure
            ),
            clause_composer_generation_budget_ratio=(
                args.clause_composer_generation_budget_ratio
            ),
            lemma_conjunction_enabled=(
                not args.disable_lemma_conjunction
            ),
            lemma_conjunction_max_trials=(
                args.lemma_conjunction_max_trials
            ),
            degree_escalation_cap=args.degree_escalation_cap,
            clause_escalation_cap=args.clause_escalation_cap,
            timeout_escalation_limit=args.timeout_escalation_limit,
            timeout_escalation_cap=args.timeout_escalation_cap,
            coverage_optimizations=args.enable_coverage_optimizations,
            strategy_scheduler_enabled=args.enable_strategy_scheduler,
            strategy_scheduler_granularity=args.strategy_scheduler_granularity,
            strategy_scheduler_online_updates=not args.strategy_scheduler_no_online_updates,
            strategy_scheduler_quota_mode=args.strategy_scheduler_quota_mode,
            strategy_scheduler_round_budget_ratio=args.strategy_scheduler_round_budget_ratio,
            strategy_scheduler_prior_strength=args.strategy_scheduler_prior_strength,
            strategy_scheduler_progress_weight=args.strategy_scheduler_progress_weight,
            strategy_scheduler_disabled_categories=tuple(
                s for s in args.strategy_scheduler_disabled_categories.split(",") if s),
            strategy_scheduler_policy=args.strategy_scheduler_policy,
            strategy_scheduler_utility=args.strategy_scheduler_utility,
            strategy_scheduler_priors=args.strategy_scheduler_priors,
            strategy_scheduler_epsilon=args.strategy_scheduler_epsilon,
            strategy_scheduler_lambda=args.strategy_scheduler_lambda,
            strategy_scheduler_mu=args.strategy_scheduler_mu,
            strategy_scheduler_exploration_scale=(
                args.strategy_scheduler_exploration_scale
            ),
            strategy_scheduler_min_typed_budget_ratio=(
                args.strategy_scheduler_min_typed_budget_ratio
            ),
            strategy_scheduler_min_fallback_budget_ratio=(
                args.strategy_scheduler_min_fallback_budget_ratio
            ),
            strategy_scheduler_timeout_tiers=tuple(
                float(tier)
                for tier in args.strategy_scheduler_timeout_tiers.split(",")
                if tier.strip()
            ),
            strategy_scheduler_quotas=_parse_strategy_quotas(
                args.strategy_scheduler_quotas
            ),
            strategy_scheduler_max_decisions=(
                args.strategy_scheduler_max_decisions
            ),
            strategy_scheduler_progress_feedback=(
                args.strategy_scheduler_progress_feedback
            ),
            checker_timeout_retry_enabled=(
                args.enable_checker_timeout_retry
            ),
            checker_timeout_retry_limit=(
                args.checker_timeout_retry_limit
            ),
            strategy_scheduler_complexity_degree_weight=(
                args.strategy_scheduler_complexity_degree_weight
            ),
            strategy_scheduler_complexity_clause_weight=(
                args.strategy_scheduler_complexity_clause_weight
            ),
        )
        engine = AdaSparCEEngine(sparse_config, args.log_jsonl)
    else:
        sparse_config = SparseConfig(**common)
        engine = SparseHeuristicEngine(sparse_config, args.log_jsonl)
    result = engine.run(
        args.program_id, args.c, args.smt
    )
    method_name = args.method_name
    if not method_name:
        if (
            args.template_mode == "adasparce"
            and args.enable_strategy_scheduler
        ):
            method_name = "AdaSparCE-Strategy-Scheduler"
        elif args.template_mode == "adasparce" and args.neural_ranker:
            method_name = "AdaSparCE-DeepSets-Ranker"
        elif args.template_mode == "adasparce" and args.graph_ranker:
            method_name = "AdaSparCE-Graph-Ranker"
        elif args.template_mode == "adasparce" and args.random_ranker:
            method_name = "AdaSparCE-Random-Ranker"
        elif args.template_mode == "adasparce" and args.neural_scorer:
            method_name = "AdaSparCE-Legacy-MLP"
    if not method_name:
        _MODE_TO_METHOD = {
            "baseline": "LIPuS-RL",
            "sparse-heuristic": "SparseHeuristic-Fixed",
            "adasparce": "AdaSparCE",
        }
        method_name = _MODE_TO_METHOD[args.template_mode]
    print(
        json.dumps(
            {
                "status": result.status,
                "invariant": str(result.invariant) if result.invariant is not None else None,
                "candidate": result.candidate.pretty_print() if result.candidate else None,
                "total_time": result.total_time,
                "iterations": result.iterations,
                "checker_calls": result.checker_calls,
                "reason": result.reason,
                "method": method_name,
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
