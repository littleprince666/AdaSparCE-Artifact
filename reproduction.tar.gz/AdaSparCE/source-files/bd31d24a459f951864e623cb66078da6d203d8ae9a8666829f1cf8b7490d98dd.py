"""Candidate deduplication, scoring and beam/reserve construction."""

from SMT_Solver.SMT_verifier import CheckFailureType
from SparCE.logging_utils import stable_hash
from SparCE.ranking.ranker_trace import candidate_formula_hash


class FrontierGeneration:
    """Candidate deduplication, scoring and beam/reserve construction."""

    def _frontiers(
        self,
        analyzer,
        pool,
        failure_type,
        apply_beam=True,
        ranker_failure_type=None,
        failure_counts=None,
        checked=0,
        elapsed_time_ratio=0.0,
    ):
        frontiers = []
        if not self.config.semantic_generators_enabled:
            # G module off: no semantic mechanism candidates at all.
            # The run keeps the direct postcondition seed and the
            # generic fallback template search.
            return frontiers
        frames = (
            self._precondition_frame_branches(analyzer)
            if self.config.precondition_frame
            else []
        )
        affine_exit = (
            self._affine_exit_branches(analyzer)
            if self.config.affine_exit_boundary
            else []
        )
        monotone = (
            self._monotone_initial_branches(analyzer)
            if self.config.monotone_entry_bounds
            else []
        )
        counter = self._counter_branches(analyzer)
        remaining = self._remaining_work_branches(analyzer, pool)
        signs = self._nonnegative_branches(analyzer)
        closure = self._update_closure_branches(analyzer)
        divmod = self._divmod_branches(analyzer)
        constant_entry = self._constant_entry_branches(analyzer)
        weakening = self._post_weakening_branches(analyzer)
        term_drop = self._term_dropping_branches(analyzer)
        guard_split = self._guard_split_branches(analyzer)
        if failure_type == CheckFailureType.INIT:
            frontiers.extend(
                (
                    guard_split,
                    weakening,
                    term_drop,
                    frames,
                    monotone,
                    affine_exit,
                    constant_entry,
                    divmod,
                    counter,
                    closure,
                    remaining,
                    signs,
                )
            )
        elif failure_type == CheckFailureType.STEP:
            frontiers.extend(
                (
                    guard_split,
                    frames,
                    affine_exit,
                    divmod,
                    monotone,
                    constant_entry,
                    closure,
                    remaining,
                    counter,
                    signs,
                )
            )
        elif failure_type == CheckFailureType.EXIT:
            frontiers.extend(
                (
                    frames,
                    affine_exit,
                    monotone,
                    divmod,
                    constant_entry,
                    counter,
                    closure,
                    signs,
                    remaining,
                )
            )
        else:
            frontiers.extend(
                (
                    guard_split,
                    weakening,
                    term_drop,
                    frames,
                    affine_exit,
                    divmod,
                    monotone,
                    constant_entry,
                    closure,
                    counter,
                    remaining,
                    signs,
                )
            )
        width = (
            self.config.beam_width
            if apply_beam and self.config.beam_search
            else None
        )
        ordered_frontiers = []
        for frontier_index, frontier in enumerate(
            frontier for frontier in frontiers if frontier
        ):
            legacy_order = sorted(
                frontier,
                key=lambda branch: (-branch.score, -self._graph_bonus(branch)),
            )
            if width is None or self.neural_ranker is None:
                ordered_frontiers.append(
                    legacy_order[:self.config.beam_width]
                    if width is not None else legacy_order
                )
                continue
            if str(getattr(
                self.config, "neural_ranker_safety_mode", "topk"
            )) == "mechanism":
                # Mechanism-representative protection: the active frontier
                # is the neural order over a set that guarantees the
                # heuristic-best candidate of every triggered mechanism.
                # Unlike the legacy top-K prefix this can admit candidates
                # from outside the legacy beam, which is exactly the point
                # of the mode; everything not selected stays in the
                # complete reserve built below with apply_beam=False.
                predictions, inference_time = self._neural_ranker_predictions(
                    "pre-beam",
                    legacy_order,
                    analyzer,
                    ranker_failure_type or failure_type,
                    failure_counts,
                    checked,
                    elapsed_time_ratio,
                )
                if predictions is None:
                    ordered_frontiers.append(
                        legacy_order[:self.config.beam_width]
                    )
                    continue
                try:
                    from SparCE.ranking.neural_ranker import safe_ranker_selection

                    selection_seed = int(stable_hash({
                        "seed": self.config.seed,
                        "frontier_index": frontier_index,
                        "candidate_hashes": [
                            candidate_formula_hash(candidate.formula)
                            for candidate in legacy_order
                        ],
                    })[:16], 16)
                    selection = safe_ranker_selection(
                        legacy_order,
                        predictions.ranking_scores,
                        beam_width=width,
                        topk_safe=0,
                        exploration_ratio=(
                            self.config.neural_ranker_exploration_ratio
                        ),
                        seed=selection_seed,
                    )
                except Exception as error:
                    self._ranker_runtime_fallback = str(error)
                    self.neural_ranker = None
                    self.logger.write({
                        "event": "neural_ranker_fallback",
                        "phase": "pre-beam-mechanism-safety",
                        "reason": str(error),
                        "candidate_count": len(legacy_order),
                        "fallback": "legacy-beam",
                    })
                    ordered_frontiers.append(
                        legacy_order[:self.config.beam_width]
                    )
                    continue
                active_candidates = list(selection.ordered_candidates)
                ordered_frontiers.append(active_candidates)
                self.logger.write({
                    "event": "neural_ranker_prebeam",
                    "frontier_index": frontier_index,
                    "safety_mode": "mechanism",
                    "generated_candidate_count": len(legacy_order),
                    "retained_candidate_count": len(active_candidates),
                    "beam_width": self.config.beam_width,
                    "heuristic_safe_count": len(
                        selection.heuristic_safe_indices
                    ),
                    "mechanism_safe_count": len(
                        selection.mechanism_safe_indices
                    ),
                    "exploration_count": len(selection.exploration_indices),
                    "reserve_candidate_count": (
                        len(legacy_order) - len(active_candidates)
                    ),
                    "inference_time_seconds": inference_time,
                })
                continue
            if self.config.neural_ranker_topk_safe >= width:
                # The safety prefix already fixes the entire active beam, so
                # scoring the complete pre-beam pool cannot change either its
                # membership or order.  Skip that no-op inference: on small
                # program budgets it otherwise steals seconds from SMT checks.
                active_candidates = legacy_order[:width]
                ordered_frontiers.append(active_candidates)
                self.logger.write({
                    "event": "neural_ranker_prebeam",
                    "frontier_index": frontier_index,
                    "generated_candidate_count": len(legacy_order),
                    "retained_candidate_count": len(active_candidates),
                    "beam_width": width,
                    "heuristic_safe_count": len(active_candidates),
                    "mechanism_safe_count": 0,
                    "exploration_count": 0,
                    "reserve_candidate_count": (
                        len(legacy_order) - len(active_candidates)
                    ),
                    "inference_time_seconds": 0.0,
                    "inference_skipped": "safe-prefix-covers-beam",
                })
                continue
            predictions, inference_time = self._neural_ranker_predictions(
                "pre-beam",
                legacy_order,
                analyzer,
                ranker_failure_type or failure_type,
                failure_counts,
                checked,
                elapsed_time_ratio,
            )
            if predictions is None:
                ordered_frontiers.append(
                    legacy_order[:self.config.beam_width]
                )
                continue
            try:
                from SparCE.ranking.neural_ranker import safe_ranker_selection

                selection_seed = int(stable_hash({
                    "seed": self.config.seed,
                    "frontier_index": frontier_index,
                    "candidate_hashes": [
                        candidate_formula_hash(candidate.formula)
                        for candidate in legacy_order
                    ],
                })[:16], 16)
                selection = safe_ranker_selection(
                    legacy_order,
                    predictions.ranking_scores,
                    beam_width=self.config.beam_width,
                    topk_safe=self.config.neural_ranker_topk_safe,
                    exploration_ratio=(
                        self.config.neural_ranker_exploration_ratio
                    ),
                    seed=selection_seed,
                )
            except Exception as error:
                self._ranker_runtime_fallback = str(error)
                self.neural_ranker = None
                self.logger.write({
                    "event": "neural_ranker_fallback",
                    "phase": "pre-beam-safety",
                    "reason": str(error),
                    "candidate_count": len(legacy_order),
                    "fallback": "legacy-beam",
                })
                ordered_frontiers.append(
                    legacy_order[:self.config.beam_width]
                )
                continue
            # Keep the legacy beam's candidate *set* as the active frontier.
            # Mechanism/exploration candidates outside that set remain in the
            # complete reserve built below by ``apply_beam=False``.  Expanding
            # the active set here changes the adaptive heuristic itself and
            # can regress tasks even when the legacy top-K order is preserved.
            legacy_active = set(range(min(width, len(legacy_order))))
            active_candidates = [
                legacy_order[index]
                for index in selection.selected_indices
                if index in legacy_active
            ]
            ordered_frontiers.append(active_candidates)
            self.logger.write({
                "event": "neural_ranker_prebeam",
                "frontier_index": frontier_index,
                "generated_candidate_count": len(legacy_order),
                "retained_candidate_count": len(active_candidates),
                "beam_width": self.config.beam_width,
                "heuristic_safe_count": len(
                    selection.heuristic_safe_indices
                ),
                "mechanism_safe_count": len(
                    selection.mechanism_safe_indices
                ),
                "exploration_count": len(selection.exploration_indices),
                "reserve_candidate_count": (
                    len(legacy_order) - len(active_candidates)
                ),
                "inference_time_seconds": inference_time,
            })
        return ordered_frontiers
