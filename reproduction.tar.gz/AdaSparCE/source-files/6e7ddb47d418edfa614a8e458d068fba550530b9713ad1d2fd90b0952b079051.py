"""Proof-guided composition of symbolic invariant candidates.

The composer is deliberately independent of :mod:`SparCE.ada_engine`: it
accepts formulas and lightweight metadata and returns formula proposals.  In
particular, it does not generate text with an LLM and it never treats a
counterexample repair as a proof.  Every proposal must still pass the normal
INIT, STEP, and EXIT verification conditions.
"""

from dataclasses import dataclass, replace

import z3


_PROGRESS = {
    "UNKNOWN": 0,
    "TIMEOUT": 0,
    "INIT": 0,
    "STEP": 1,
    "EXIT": 2,
    "SUCCESS": 3,
}


def _formula_key(formula):
    return str(z3.simplify(formula))


def _ast_size(expression):
    """Count distinct Z3 nodes without depending on ranker modules."""
    seen = set()

    def visit(node):
        identity = node.get_id()
        if identity in seen:
            return 0
        seen.add(identity)
        return 1 + sum(visit(child) for child in node.children())

    return visit(expression)


def _failure_name(failure_type):
    if failure_type is None:
        return "UNKNOWN"
    return getattr(failure_type, "value", str(failure_type)).upper()


def _assignment_value(value, sort):
    if isinstance(value, z3.ExprRef):
        return value
    if sort.kind() == z3.Z3_BOOL_SORT:
        return z3.BoolVal(bool(value))
    return z3.IntVal(int(value))


def evaluate_formula(formula, assignment):
    """Evaluate a Boolean formula on a (possibly partial) concrete state.

    ``None`` means that the counterexample did not assign enough symbols to
    establish a Boolean value.  This conservative result prevents speculative
    combinations from being labelled as counterexample repairs.
    """
    if not isinstance(assignment, dict):
        return None
    substitutions = []
    seen = set()

    def visit(node):
        identity = node.get_id()
        if identity in seen:
            return
        seen.add(identity)
        if (
            z3.is_const(node)
            and node.num_args() == 0
            and node.decl().kind() == z3.Z3_OP_UNINTERPRETED
            and str(node) in assignment
        ):
            try:
                substitutions.append(
                    (node, _assignment_value(assignment[str(node)], node.sort()))
                )
            except (TypeError, ValueError, z3.Z3Exception):
                pass
        for child in node.children():
            visit(child)

    visit(formula)
    reduced = z3.simplify(z3.substitute(formula, *substitutions))
    if z3.is_true(reduced):
        return True
    if z3.is_false(reduced):
        return False
    return None


def repairs_counterexample(formula, failure_type, counterexample):
    """Return whether ``formula`` blocks the supplied typed counterexample."""
    failure = _failure_name(failure_type)
    if failure == "INIT":
        return evaluate_formula(formula, counterexample) is True
    if failure == "EXIT":
        return evaluate_formula(formula, counterexample) is False
    if failure == "STEP":
        if not (
            isinstance(counterexample, tuple)
            and len(counterexample) == 2
        ):
            return False
        before, after = counterexample
        before_value = evaluate_formula(formula, before)
        after_value = evaluate_formula(formula, after)
        return before_value is False or after_value is True
    return False


@dataclass(frozen=True)
class ClauseEntry:
    formula: object
    key: str
    score: float
    mechanism: str
    degree: int
    clauses: int
    monomials: tuple = ()
    outcome: str = "UNKNOWN"


@dataclass(frozen=True)
class ClauseProposal:
    formula: object
    key: str
    score: float
    mechanism: str
    degree: int
    clauses: int
    monomials: tuple
    left_mechanism: str
    right_mechanism: str
    operator: str


class ProofGuidedClauseComposer:
    """Bounded clause bank with typed-counterexample-directed composition."""

    def __init__(
        self,
        *,
        max_bank_size=64,
        max_ast_size=180,
        max_clauses=3,
        max_total_proposals=32,
    ):
        if min(
            max_bank_size,
            max_ast_size,
            max_clauses,
            max_total_proposals,
        ) < 1:
            raise ValueError("clause-composer bounds must be positive")
        self.max_bank_size = int(max_bank_size)
        self.max_ast_size = int(max_ast_size)
        self.max_clauses = int(max_clauses)
        self.max_total_proposals = int(max_total_proposals)
        self._bank = {}
        self._emitted = set()

    @property
    def bank_size(self):
        return len(self._bank)

    @property
    def emitted_count(self):
        return len(self._emitted)

    @staticmethod
    def _entry_priority(entry):
        return (
            _PROGRESS.get(entry.outcome, 0),
            float(entry.score),
            -_ast_size(entry.formula),
            entry.key,
        )

    def _trim(self):
        if len(self._bank) <= self.max_bank_size:
            return
        kept = sorted(
            self._bank.values(),
            key=self._entry_priority,
            reverse=True,
        )[: self.max_bank_size]
        self._bank = {entry.key: entry for entry in kept}

    def _insert(self, entry):
        simplified = z3.simplify(entry.formula)
        if (
            simplified.sort().kind() != z3.Z3_BOOL_SORT
            or z3.is_true(simplified)
            or z3.is_false(simplified)
            or _ast_size(simplified) > self.max_ast_size
        ):
            return
        key = _formula_key(simplified)
        normalized = replace(entry, formula=simplified, key=key)
        previous = self._bank.get(key)
        if previous is None or self._entry_priority(normalized) > self._entry_priority(previous):
            self._bank[key] = normalized

    def ingest(
        self,
        formula,
        *,
        score,
        mechanism,
        degree,
        clauses,
        monomials=(),
        split_top_level=True,
    ):
        """Add a generated symbolic candidate and optional top-level parts."""
        entry = ClauseEntry(
            formula=formula,
            key="",
            score=float(score),
            mechanism=str(mechanism),
            degree=int(degree),
            clauses=max(1, int(clauses)),
            monomials=tuple(monomials),
        )
        self._insert(entry)
        simplified = z3.simplify(formula)
        if split_top_level and (z3.is_and(simplified) or z3.is_or(simplified)):
            for child in simplified.children():
                self._insert(replace(
                    entry,
                    formula=child,
                    key="",
                    score=float(score) - 1.0,
                    mechanism=str(mechanism) + ":component",
                    clauses=1,
                ))
        self._trim()

    def observe(self, formula, failure_type):
        """Record how far a checked whole candidate advanced through the VCs."""
        key = _formula_key(formula)
        entry = self._bank.get(key)
        if entry is None:
            return
        outcome = _failure_name(failure_type)
        if _PROGRESS.get(outcome, 0) >= _PROGRESS.get(entry.outcome, 0):
            self._bank[key] = replace(entry, outcome=outcome)

    @staticmethod
    def _operators(failure_type):
        failure = _failure_name(failure_type)
        if failure == "INIT":
            return ("or",)
        if failure == "EXIT":
            return ("and",)
        if failure == "STEP":
            return ("and", "or")
        return ()

    def propose(
        self,
        formula,
        *,
        score,
        mechanism,
        degree,
        clauses,
        monomials=(),
        failure_type,
        counterexample,
        max_results=4,
    ):
        """Compose candidates that concretely repair the current typed CE."""
        if max_results < 1 or len(self._emitted) >= self.max_total_proposals:
            return []
        base = z3.simplify(formula)
        base_key = _formula_key(base)
        candidates = []
        failure = _failure_name(failure_type)
        for partner in self._bank.values():
            if partner.key == base_key:
                continue
            combined_clauses = int(clauses) + partner.clauses
            if combined_clauses > self.max_clauses:
                continue
            if failure == "INIT":
                operators = (
                    ("or",)
                    if evaluate_formula(partner.formula, counterexample) is True
                    else ()
                )
            elif failure == "EXIT":
                operators = (
                    ("and",)
                    if evaluate_formula(partner.formula, counterexample) is False
                    else ()
                )
            elif failure == "STEP" and (
                isinstance(counterexample, tuple)
                and len(counterexample) == 2
            ):
                before, after = counterexample
                operators = []
                if evaluate_formula(partner.formula, before) is False:
                    operators.append("and")
                if evaluate_formula(partner.formula, after) is True:
                    operators.append("or")
                operators = tuple(operators)
            else:
                operators = ()
            for operator in operators:
                if operator == "and":
                    combined = z3.simplify(z3.And(base, partner.formula))
                else:
                    combined = z3.simplify(z3.Or(base, partner.formula))
                key = _formula_key(combined)
                if (
                    key == base_key
                    or key == partner.key
                    or key in self._emitted
                    or _ast_size(combined) > self.max_ast_size
                ):
                    continue
                progress = _PROGRESS.get(partner.outcome, 0)
                component_bonus = (
                    14.0
                    if (
                        partner.mechanism.endswith(":component")
                        and z3.is_eq(partner.formula)
                    )
                    else 0.0
                )
                combined_score = (
                    max(float(score), partner.score)
                    + 8.0
                    + 4.0 * progress
                    + component_bonus
                    + (12.0 if operator == "and" else 0.0)
                    - 16.0 * max(0, combined_clauses - 2)
                    - 1.5 * _ast_size(combined)
                )
                candidates.append(ClauseProposal(
                    formula=combined,
                    key=key,
                    score=combined_score,
                    mechanism="typed-clause-compose-" + operator,
                    degree=max(int(degree), partner.degree),
                    clauses=combined_clauses,
                    monomials=tuple(dict.fromkeys(
                        tuple(monomials) + partner.monomials
                    )),
                    left_mechanism=str(mechanism),
                    right_mechanism=partner.mechanism,
                    operator=operator,
                ))
        candidates.sort(
            key=lambda item: (
                -item.score,
                _ast_size(item.formula),
                item.key,
            )
        )
        capacity = self.max_total_proposals - len(self._emitted)
        selected = candidates[: min(int(max_results), capacity)]
        self._emitted.update(item.key for item in selected)
        return selected
