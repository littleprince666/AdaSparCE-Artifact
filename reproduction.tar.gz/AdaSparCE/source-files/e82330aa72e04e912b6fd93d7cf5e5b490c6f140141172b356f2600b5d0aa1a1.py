"""VC, recurrence, linear and transition-kernel candidate frontends."""

import time
import z3
from SMT_Solver.SMT_verifier import CheckFailureType
from SparCE.logging_utils import stable_hash
from SparCE.symbolic.candidate import CandidateBranch


class FrontendGeneration:
    """VC, recurrence, linear and transition-kernel candidate frontends."""

    @staticmethod
    def _feedback_linear(pool, failure_type, feedback):
        wanted = {
            CheckFailureType.INIT: {"pre"},
            CheckFailureType.STEP: {"update", "dependency"},
            CheckFailureType.EXIT: {"post"},
        }.get(failure_type, set())
        for monomial in pool.ranked():
            if pool.sources(monomial).intersection(wanted):
                feedback[monomial] = feedback.get(monomial, 0.0) + 2.0

    @staticmethod
    def _count_z3_nodes(expression, predicate):
        if expression is None:
            return 0
        stack = [expression]
        seen = 0
        while stack:
            node = stack.pop()
            if predicate(node):
                seen += 1
            for child in node.children():
                stack.append(child)
        return seen

    def _scheduler_static_features(self, analyzer):
        """Static program features for the strategy scheduler state.

        Deterministic, z3-structural, and independent of the search:
        variable/update/branch counts, expression degrees, operator
        flags (division, modulo, nonlinear multiplication, ite) and
        update-shape flags (accumulator, counter, monotone, coupled).
        """
        expressions = list(analyzer.updates.values())
        post = analyzer.postcondition

        def is_div(node):
            return z3.is_app(node) and node.decl().kind() in (
                z3.Z3_OP_IDIV, z3.Z3_OP_DIV,
            )

        def is_mod(node):
            return z3.is_app(node) and node.decl().kind() == z3.Z3_OP_MOD

        def is_mul(node):
            return z3.is_app(node) and node.decl().kind() == z3.Z3_OP_MUL

        def is_ite(node):
            return z3.is_app(node) and node.decl().kind() == z3.Z3_OP_ITE

        has_mul = any(
            self._count_z3_nodes(expr, is_mul) > 0
            for expr in expressions + [post]
        )
        max_update_degree = max(
            (self._total_degree(expr) for expr in expressions),
            default=0,
        )
        nonnegative = analyzer.explicit_nonnegative()

        has_accumulator = False
        has_monotone = False
        has_coupled = False
        for name, rhs in analyzer.updates.items():
            symbol = analyzer.translator.symbols[name]
            difference = z3.simplify(rhs - symbol)
            if z3.is_add(rhs):
                addends = rhs.children()
                if any(
                    child.eq(symbol) for child in addends
                ) and any(
                    not z3.is_int_value(child) and not child.eq(symbol)
                    for child in addends
                ):
                    has_accumulator = True
            if z3.is_int_value(difference):
                if difference.as_long() > 0:
                    has_monotone = True
            elif z3.is_const(difference) and z3.is_int(difference):
                if str(difference) in nonnegative:
                    has_monotone = True
            for other in analyzer.mutated:
                if other == name:
                    continue
                other_symbol = analyzer.translator.symbols.get(other)
                if other_symbol is None:
                    continue
                if self._count_z3_nodes(rhs, lambda node: node.eq(other_symbol)):
                    has_coupled = True
                    break

        return {
            "num_variables": len(analyzer.variables),
            "num_updated_variables": len(analyzer.updates),
            "num_branches": sum(
                self._count_z3_nodes(expr, is_ite)
                for expr in expressions + [post]
            ),
            "max_update_degree": max_update_degree,
            "max_postcondition_degree": self._total_degree(post),
            "has_division": any(
                self._count_z3_nodes(expr, is_div) > 0
                for expr in expressions + [post]
            ),
            "has_modulo": any(
                self._count_z3_nodes(expr, is_mod) > 0
                for expr in expressions + [post]
            ),
            "has_nonlinear_multiplication": (
                has_mul
                and (max_update_degree > 1
                     or self._total_degree(post) > 1)
            ),
            "has_ite": any(
                self._count_z3_nodes(expr, is_ite) > 0
                for expr in expressions + [post]
            ),
            "has_accumulator": has_accumulator,
            "has_counter": bool(analyzer.constant_additive_updates()),
            "has_monotone_variable": has_monotone,
            "has_coupled_variable": has_coupled,
            "is_linear": self._is_linear_program(analyzer),
        }

    def _linear_fast_path(self, analyzer, c_path, verifier, smt_path,
                          program_id, started, budget_seconds):
        """Pure-linear template sweep with extended coefficient bounds.

        For programs whose updates and postcondition are all linear, the
        general polynomial search wastes time on cross terms.  This method
        builds a dedicated linear monomial pool (degree ≤ 1) and tries a
        wide coefficient range (up to 1024) with a short deadline.
        """
        from SparCE.symbolic.monomials import MonomialPool as _MP
        from SparCE.symbolic.template_solver import IncrementalTemplateSolver as _ITS
        from SparCE.symbolic.templates import PolynomialClause, PolynomialTemplate
        from itertools import product as _product

        linear_pool = _MP.seed_from_program(
            c_path, analyzer.variables, max_degree=1
        )
        # Seed from the analyzer's postcondition symbols too.
        try:
            linear_pool.seed_from_postcondition(analyzer.postcondition)
        except Exception:
            pass
        ranked = linear_pool.ranked(max_items=self.config.max_monomials)
        if len(ranked) < 2:
            return None, 0
        counterexamples = {"p": [], "n": [], "i": []}
        ce_keys = {"p": set(), "n": set(), "i": set()}
        feedback = {}
        linear_bounds = (1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024)
        checked = 0
        linear_failure_type = (
            CheckFailureType.UNKNOWN
            if self._ranker_trace_enabled()
            else None
        )
        linear_failure_counts = (
            {failure: 0 for failure in CheckFailureType}
            if self._ranker_trace_enabled()
            else None
        )
        deadline = started + budget_seconds
        for clause_count in range(1, self.config.max_clauses + 1):
            if time.perf_counter() >= deadline:
                break
            for relations in _product(("=", ">=", "<="), repeat=clause_count):
                if time.perf_counter() >= deadline:
                    break
                seeded = min(len(ranked), max(2, len(analyzer.variables) + 2))
                for support_size in sorted(set((seeded, len(ranked)))):
                    if time.perf_counter() >= deadline:
                        break
                    support = linear_pool.ranked(
                        max_items=support_size, feedback=feedback
                    )
                    clauses = tuple(
                        PolynomialClause(tuple(support), rel)
                        for rel in relations
                    )
                    template = PolynomialTemplate(
                        analyzer.variables, clauses,
                        coefficient_prefix="lin_{}_{}".format(
                            clause_count, support_size
                        ),
                    )
                    solver_obj = _ITS(
                        template,
                        timeout_seconds=self.config.template_timeout_seconds,
                    )
                    solver_obj.add_all(counterexamples)
                    total_coeffs = sum(
                        len(c) for c in template.coefficients
                    )
                    min_nonzero = clause_count
                    for bound in linear_bounds:
                        if time.perf_counter() >= deadline:
                            break
                        for max_nz in range(min_nonzero, total_coeffs + 1):
                            if time.perf_counter() >= deadline:
                                break
                            attempts = 0
                            while (
                                attempts
                                < self.config.max_candidates_per_structure
                                and not self._checker_budget_exhausted(checked)
                            ):
                                if time.perf_counter() >= deadline:
                                    break
                                sres = solver_obj.solve(bound, max_nz)
                                if sres.status != "sat":
                                    break
                                candidate = sres.candidate
                                attempts += 1
                                solver_obj.block_coefficients(
                                    sres.coefficient_values
                                )
                                remaining = deadline - time.perf_counter()
                                if remaining <= 0:
                                    break
                                linear_check_timeout = min(
                                    self.config.checker_timeout_seconds,
                                    max(0.001, remaining / 6.0),
                                )
                                candidate_formula = candidate.to_z3()
                                trace_branch = None
                                trace_context = None
                                if self._ranker_trace_enabled():
                                    trace_branch = CandidateBranch(
                                        candidate_formula,
                                        200.0,
                                        "linear-fast-path",
                                        1,
                                        clause_count,
                                        tuple(
                                            monomial.pretty_print(
                                                analyzer.variables
                                            )
                                            for monomial in support
                                        ),
                                    )
                                    trace_context = (
                                        self._trace_candidate_group(
                                            "linear-fast-path",
                                            [trace_branch],
                                            trace_branch,
                                            analyzer,
                                            linear_failure_type,
                                            linear_failure_counts,
                                            checked,
                                            (
                                                time.perf_counter() - started
                                            ) / self.config.timeout_seconds,
                                            degree=1,
                                            clauses=clause_count,
                                            score_components={
                                                trace_branch: {
                                                    "heuristic": 200.0,
                                                    "mechanism_bonus": 0.0,
                                                    "legacy_neural_bonus": 0.0,
                                                    "selection_score": 200.0,
                                                }
                                            },
                                            coefficient_bounds={
                                                trace_branch: bound
                                            },
                                            selection_policy=(
                                                "generated-singleton"
                                            ),
                                        )
                                    )
                                cres = verifier.check(
                                    candidate_formula, smt_path,
                                    timeout_seconds=linear_check_timeout,
                                )
                                if trace_branch is not None:
                                    self._trace_candidate_outcome(
                                        trace_branch, cres, trace_context
                                    )
                                checked += 1
                                self.logger.write({
                                    "event": "ada_candidate",
                                    "program_id": program_id,
                                    "template_mode": "adasparce",
                                    "mechanism": "linear-fast-path",
                                    "beam_rank": attempts,
                                    "score": 200.0,
                                    "degree": 1,
                                    "clauses": clause_count,
                                    "monomials": [
                                        m.pretty_print(analyzer.variables)
                                        for m in support
                                    ],
                                    "candidate": candidate.pretty_print(),
                                    "candidate_hash": cres.candidate_hash,
                                    "checker_result": cres.status,
                                    "failure_type": cres.failure_type.value,
                                    "checker_time_ms": cres.solver_time * 1000,
                                    "solver_name": cres.solver_name,
                                    "query_size": cres.query_size,
                                    "raw_solver_status": (
                                        cres.raw_solver_status
                                    ),
                                    "vc_results": list(cres.vc_results),
                                    "ranker_trace_run_id": (
                                        trace_context.get("run_id")
                                        if trace_context
                                        else None
                                    ),
                                    "search_state_id": (
                                        trace_context.get("search_state_id")
                                        if trace_context
                                        else None
                                    ),
                                    "candidate_group_id": (
                                        trace_context.get(
                                            "candidate_group_id"
                                        )
                                        if trace_context
                                        else None
                                    ),
                                })
                                if trace_context is not None:
                                    linear_failure_type = cres.failure_type
                                    linear_failure_counts[
                                        cres.failure_type
                                    ] += 1
                                if cres.failure_type == CheckFailureType.SUCCESS:
                                    return candidate, checked
                                if cres.failure_type in (
                                    CheckFailureType.TIMEOUT,
                                    CheckFailureType.UNKNOWN,
                                ):
                                    break
                                kind = {
                                    CheckFailureType.INIT: "p",
                                    CheckFailureType.STEP: "i",
                                    CheckFailureType.EXIT: "n",
                                }.get(cres.failure_type, "p")
                                ce_k = stable_hash(cres.counterexample)
                                if ce_k not in ce_keys[kind]:
                                    ce_keys[kind].add(ce_k)
                                    counterexamples[kind].append(
                                        cres.counterexample
                                    )
                                    solver_obj.add_counterexample(
                                        kind, cres.counterexample
                                    )
                                if self.config.monomial_feedback:
                                    self._feedback_linear(
                                        linear_pool,
                                        cres.failure_type,
                                        feedback,
                                    )
        return None, checked

    def _algebraic_minimum_degree(self):
        floor = int(
            getattr(
                self.config, "algebraic_recurrence_minimum_degree", 0
            )
        )
        if floor > 0:
            return floor
        return self.config.smt_vc_max_degree + 1

    def _vc_branches(self, smt_path, analyzer=None, apply_limit=True):
        """Recover exact templates from the Checker VC when explicitly enabled."""
        if not self.config.smt_vc_frontend:
            return []
        if not self.config.semantic_generators_enabled:
            # G module off: the exact VC frontends are semantic
            # generators and stay disabled even if a family flag is on.
            return []
        try:
            from SparCE.generation.vc_analyzer import VCAnalyzer

            vc_analyzer = VCAnalyzer(smt_path)
            native_nonlinear_vc = (
                analyzer is not None
                and analyzer.updates
                and not getattr(analyzer, "smt_fallback_used", False)
                and not vc_analyzer.is_affine_problem()
                and not vc_analyzer.is_linear_chc_problem()
            )
            if (
                native_nonlinear_vc
                and not self.config.algebraic_recurrence_frontend
                and not self.config.branchwise_conservation_frontend
                and not self.config.scaled_division_frontend
                and not self.config.entry_potential_frontend
                and not self.config.exit_post_closure_frontend
            ):
                return []
            recovered = []
            if not native_nonlinear_vc:
                recovered.extend(vc_analyzer.candidates(
                    max_degree=self.config.smt_vc_max_degree,
                    max_clauses=self.config.max_clauses,
                ))
            if self.config.algebraic_recurrence_frontend:
                recovered.extend(
                    vc_analyzer.sparse_recurrence_candidates(
                        max_degree=(
                            self.config.algebraic_recurrence_max_degree
                        ),
                        max_clauses=self.config.max_clauses,
                        minimum_degree=(
                            self._algebraic_minimum_degree()
                        ),
                    )
                )
            if self.config.scaled_division_frontend:
                recovered.extend(vc_analyzer.scaled_division_candidates(
                    max_degree=self.config.smt_vc_max_degree,
                    max_clauses=self.config.max_clauses,
                ))
            if self.config.entry_potential_frontend:
                recovered.extend(
                    vc_analyzer.entry_potential_envelope_candidates()
                )
            if self.config.exit_post_closure_frontend:
                recovered.extend(
                    vc_analyzer.exit_post_closure_candidates()
                )
            if (
                analyzer is not None
                and analyzer.updates
                and (
                    self.config.algebraic_recurrence_frontend
                    or self.config.scaled_division_frontend
                )
            ):
                symbols = analyzer.translator.symbols
                initial = list(analyzer.assumptions)
                initial.extend(
                    symbols[name] == value
                    for name, value in analyzer.initial_values.items()
                    if name in symbols
                )
                guard = getattr(analyzer, "guard_z3", None)
                if guard is None:
                    try:
                        guard = analyzer.translator.expression(
                            analyzer.guard_ast
                        )
                    except (ValueError, AttributeError):
                        guard = None
                if guard is not None:
                    program_analyzer = VCAnalyzer.from_program_model(
                        variables=analyzer.variables,
                        updates=analyzer.updates,
                        precondition=z3.And(*initial),
                        postcondition=analyzer.postcondition,
                        guard=guard,
                        source_name=smt_path,
                    )
                    if self.config.algebraic_recurrence_frontend:
                        for candidate in (
                            program_analyzer.sparse_recurrence_candidates(
                                max_degree=(
                                    self.config.algebraic_recurrence_max_degree
                                ),
                                max_clauses=self.config.max_clauses,
                                minimum_degree=(
                                    self._algebraic_minimum_degree()
                                ),
                            )
                        ):
                            (
                                formula,
                                mechanism,
                                degree,
                                clauses,
                                details,
                            ) = candidate
                            recovered.append((
                                formula,
                                mechanism.replace("vc-", "program-", 1),
                                degree,
                                clauses,
                                details,
                            ))
                    if self.config.scaled_division_frontend:
                        for candidate in (
                            program_analyzer.scaled_division_candidates(
                                max_degree=self.config.smt_vc_max_degree,
                                max_clauses=self.config.max_clauses,
                            )
                        ):
                            (
                                formula,
                                mechanism,
                                degree,
                                clauses,
                                details,
                            ) = candidate
                            recovered.append((
                                formula,
                                mechanism.replace("vc-", "program-", 1),
                                degree,
                                clauses,
                                details,
                            ))
            if (
                self.config.branchwise_conservation_frontend
                and vc_analyzer.has_conditional_updates()
            ):
                recovered.extend(
                    vc_analyzer.branchwise_post_completion_candidates(
                        max_degree=(
                            self.config
                            .branchwise_conservation_max_degree
                        ),
                    )
                )
                recovered.extend(
                    vc_analyzer.branchwise_entry_offset_candidates(
                        max_degree=(
                            self.config
                            .branchwise_conservation_max_degree
                        ),
                    )
                )
        except (ValueError, z3.Z3Exception) as error:
            self.logger.write(
                {
                    "event": "vc_frontend",
                    "status": "unsupported",
                    "smt_path": str(smt_path),
                    "reason": str(error),
                }
            )
            return []
        branches = []
        for formula, mechanism, degree, clauses, details in recovered:
            score = (
                230.0
                if mechanism == "vc-linear-spacer-cover"
                else
                220.0
                if mechanism == "vc-finite-difference-closure"
                else 225.0
                if mechanism == "vc-sparse-recurrence-closure"
                else 225.0
                if mechanism == "vc-branchwise-post-completion"
                else 225.0
                if mechanism == "program-scaled-division-difference-closure"
                else 220.0
                if mechanism == (
                    "program-counter-lifted-scaled-division-closure"
                )
                else 225.0
                if mechanism == "vc-entry-potential-envelope"
                else 225.0
                if mechanism == "vc-exit-post-closure"
                else 220.0
                if mechanism == (
                    "vc-counter-lifted-sparse-recurrence-closure"
                )
                else 225.0
                if mechanism == "program-sparse-recurrence-closure"
                else 220.0
                if mechanism == (
                    "program-counter-lifted-sparse-recurrence-closure"
                )
                else 215.0
                if mechanism == "vc-counter-lifted-difference-closure"
                else 190.0
            )
            branches.append(
                CandidateBranch(
                    formula=formula,
                    score=score - 2.0 * max(0, clauses - 1),
                    mechanism=mechanism,
                    degree=degree,
                    clauses=clauses,
                    monomials=details,
                )
            )
        branches.sort(key=lambda branch: -branch.score)
        deduplicated = []
        seen_formulas = set()
        for branch in branches:
            key = str(z3.simplify(branch.formula))
            if key in seen_formulas:
                continue
            seen_formulas.add(key)
            deduplicated.append(branch)
        branches = deduplicated
        # Keep the deterministic prefix bounded.  The exact Checker still
        # evaluates every retained candidate independently.
        limit = max(self.config.beam_width * 2, self.config.beam_width)
        selected = branches[:limit] if apply_limit else branches
        self.logger.write(
            {
                "event": "vc_frontend",
                "status": "recovered",
                "smt_path": str(smt_path),
                "candidate_count": len(branches),
                "retained_count": len(selected),
                "prefix_limit_applied": bool(apply_limit),
                "mechanisms": [
                    branch.mechanism for branch in selected
                ],
            }
        )
        return selected

    def _transition_kernel_branches(self, analyzer):
        """Equality candidates from invariant-subspace linear algebra.

        Purely symbolic: the branch transition relations and the exact
        initial conditions drive a rational linear-algebra computation
        (no corpus statistics, no benchmark-specific constants).  Every
        emission is only a candidate — the frozen INIT/STEP/EXIT
        checker remains the sole judge.
        """
        if not self.config.transition_kernel_enabled:
            return []
        if not self.config.semantic_generators_enabled:
            return []
        if not getattr(analyzer, "branch_transitions", None):
            return []
        started = time.perf_counter()
        from SparCE.generation.transition_kernel import (
            KernelSynthesisError,
            TransitionKernelSynthesizer,
        )

        substitutions = []
        for name, value in analyzer.initial_values.items():
            if name in analyzer.translator.symbols:
                substitutions.append(
                    (
                        analyzer.translator.symbols[name],
                        z3.simplify(value),
                    )
                )
        try:
            synthesizer = TransitionKernelSynthesizer(
                analyzer.variables,
                analyzer.branch_transitions,
                substitutions,
                None,
                max_degree=self.config.transition_kernel_max_degree,
            )
            raw = synthesizer.candidates(
                max_atoms=self.config.transition_kernel_max_atoms,
                max_conjunctions=(
                    self.config.transition_kernel_max_conjunctions
                ),
                target=(analyzer.postcondition
                        if self.config.coverage_optimizations else None),
                target_enabled=self.config.transition_kernel_target_enabled,
                sparse_groups_enabled=(
                    self.config.transition_kernel_sparse_groups_enabled
                ),
                boundary_partners_enabled=(
                    self.config.transition_kernel_boundary_partners_enabled
                ),
            )
        except (KernelSynthesisError, z3.Z3Exception, ValueError) as error:
            self.logger.write({
                "event": "transition_kernel",
                "program_id": analyzer.translator and "",
                "status": "skipped",
                "reason": str(error)[:200],
            })
            return []
        branches = []
        for formula, degree, clauses, detail in raw:
            key = str(z3.simplify(formula))
            if key in self.candidate_cache:
                continue
            branches.append(CandidateBranch(
                formula=formula,
                score=200.0 - 2.0 * max(0, clauses - 1),
                mechanism="typed-transition-kernel",
                degree=degree,
                clauses=clauses,
                monomials=(detail,),
            ))
        self.logger.write({
            "event": "transition_kernel",
            "status": "recovered",
            "candidate_count": len(branches),
            "elapsed_seconds": time.perf_counter() - started,
            "branch_count": len(analyzer.branch_transitions),
            "interface_audit": getattr(synthesizer, "interface_audit", None),
        })
        return branches
