"""Incremental linear-arithmetic solving for sparse templates."""

import time

import z3


class TemplateSolveResult:
    def __init__(
        self,
        status,
        candidate=None,
        solver_time=0.0,
        reason=None,
        coefficient_values=None,
    ):
        self.status = status
        self.candidate = candidate
        self.solver_time = solver_time
        self.reason = reason
        self.coefficient_values = coefficient_values


class IncrementalTemplateSolver:
    def __init__(self, template, timeout_seconds=10):
        self.template = template
        self.timeout_seconds = timeout_seconds
        self._persistent_constraints = list(template.nontrivial_constraints())
        self.solver = self._new_solver()
        self._seen = {"p": set(), "n": set(), "i": set()}

    def _new_solver(self):
        solver = z3.SolverFor("QF_LIA")
        solver.set("timeout", int(self.timeout_seconds * 1000))
        solver.set("random_seed", 0)
        solver.add(*self._persistent_constraints)
        return solver

    def _rebuild(self):
        self.solver = self._new_solver()

    @staticmethod
    def _state_key(state):
        return tuple(sorted((str(key), str(value)) for key, value in state.items()))

    def add_counterexample(self, kind, assignment):
        if kind == "i":
            key = (
                self._state_key(assignment[0]),
                self._state_key(assignment[1]),
            )
            constraint = self.template.constrain_implication(
                assignment[0], assignment[1]
            )
        else:
            key = self._state_key(assignment)
            state_constraint = self.template.constrain_state(assignment)
            constraint = state_constraint if kind == "p" else z3.Not(state_constraint)
        if key in self._seen[kind]:
            return False
        self._seen[kind].add(key)
        self._persistent_constraints.append(constraint)
        self.solver.add(constraint)
        return True

    def add_all(self, counterexamples):
        for kind in ("p", "n", "i"):
            for assignment in counterexamples[kind]:
                self.add_counterexample(kind, assignment)

    def solve(
        self,
        coefficient_bound,
        maximum_nonzero=None,
        timeout_seconds=None,
    ):
        try:
            self.solver.push()
        except z3.Z3Exception:
            self._rebuild()
            self.solver.push()
        effective_timeout = (
            self.timeout_seconds
            if timeout_seconds is None
            else max(0.001, min(self.timeout_seconds, timeout_seconds))
        )
        self.solver.set("timeout", int(effective_timeout * 1000))
        self.solver.add(
            *self.template.coefficient_bound_constraints(coefficient_bound)
        )
        if maximum_nonzero is not None:
            self.solver.add(self.template.sparsity_constraint(maximum_nonzero))
        started = time.perf_counter()
        status = self.solver.check()
        elapsed = time.perf_counter() - started
        if status == z3.sat:
            model = self.solver.model()
            candidate = self.template.instantiate(model)
            values = tuple(
                tuple(
                    model.eval(coefficient, model_completion=True).as_long()
                    for coefficient in coefficients
                )
                for coefficients in self.template.coefficients
            )
            result = TemplateSolveResult(
                "sat", candidate, elapsed, coefficient_values=values
            )
        elif status == z3.unsat:
            result = TemplateSolveResult("bounded-unsat", solver_time=elapsed)
        else:
            result = TemplateSolveResult(
                "timeout" if self.solver.reason_unknown() == "timeout" else "unknown",
                solver_time=elapsed,
                reason=self.solver.reason_unknown(),
            )
        self.solver.pop()
        if status == z3.unknown:
            # A timed-out incremental solver can remain in a canceled state and
            # reject the next push. Rebuild it from persistent CE/block clauses.
            self._rebuild()
        return result

    def block_coefficients(self, coefficient_values):
        constraint = z3.Or(
            *[
                coefficient != value
                for coefficients, values in zip(
                    self.template.coefficients, coefficient_values
                )
                for coefficient, value in zip(coefficients, values)
            ]
        )
        self._persistent_constraints.append(constraint)
        self.solver.add(constraint)
