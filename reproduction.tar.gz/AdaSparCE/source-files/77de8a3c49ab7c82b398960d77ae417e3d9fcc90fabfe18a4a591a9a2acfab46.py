"""Degree/clause iterative typed search with beam expansion."""

import time
import z3
from SMT_Solver.SMT_verifier import CheckFailureType
from SparCE.scheduling.mechanism_prioritizer import combined_bonus
from SparCE.scheduling.mechanisms import mechanism_cost_class
from SparCE.search.state import FAILURE_TYPE_PREFERRED_MECHANISMS


class LayeredSearch:
    """Degree/clause iterative typed search with beam expansion."""

    def _run_typed_layer_phase(self, state):
        """Legacy degree-outer / clause-inner typed search loop."""
        for degree in state.degrees:
            for clauses in state.clause_levels:
                if time.perf_counter() - state.started >= state.typed_phase_budget:
                    break
                if state.stagnation_exit:
                    break
                eligible = [
                    branch
                    for branch in state.all_branches
                    if branch.degree <= degree and branch.clauses <= clauses
                ]
                self.logger.write(
                    {
                        "event": "ada_phase",
                        "program_id": state.program_id,
                        "degree": degree,
                        "clauses": clauses,
                        "eligible_branches": len(eligible),
                        "degree_iterative": self.config.degree_iterative,
                        "clause_iterative": self.config.clause_iterative,
                        "typed_counterexamples": self.config.typed_counterexamples,
                        "beam_search": self.config.beam_search,
                    }
                )
                remaining = list(eligible)
                rank = 0
                while remaining:
                    if (
                        time.perf_counter() - state.started
                        >= state.typed_phase_budget
                        or self._checker_budget_exhausted(state.checked)
                    ):
                        break
                    if (
                        not state.stagnation_exit
                        and state.stagnation_mode
                        and state.stagnation_counter >= int(
                            getattr(
                                self.config,
                                "fallback_stagnation_patience",
                                8,
                            )
                        )
                        and (
                            (time.perf_counter() - state.started)
                            / self.config.timeout_seconds
                        ) >= float(getattr(
                            self.config,
                            "fallback_stagnation_min_elapsed_ratio",
                            0.2,
                        ))
                    ):
                        state.stagnation_exit = True
                        self.logger.write(
                            {
                                "event": "ada_stagnation_exit",
                                "program_id": state.program_id,
                                "template_mode": "adasparce",
                                "stagnation_counter": state.stagnation_counter,
                                "distinct_counterexamples": len(
                                    state.stagnation_signatures
                                ),
                                "elapsed_time_seconds": (
                                    time.perf_counter() - state.started
                                ),
                                "checked_candidates": state.checked,
                            }
                        )
                        break

                    def mechanism_bonus(branch):
                        if not self.config.typed_counterexamples:
                            return 0.0
                        return combined_bonus(
                            branch.mechanism,
                            self._mechanism_prioritizer,
                        )

                    time_ratio = (
                        (time.perf_counter() - state.started)
                        / self.config.timeout_seconds
                    )
                    neural_bonuses = {}
                    if self.neural_scorer is not None:
                        neural_bonuses = self.neural_scorer.rank_candidates(
                            remaining,
                            state.analyzer,
                            state.failure_type.value if state.failure_type else "NONE",
                            {k.value: v for k, v in state.failure_counts.items()},
                            state.checked,
                            time_ratio,
                        )

                    def adaptive_score(branch):
                        return (
                            branch.score + mechanism_bonus(branch)
                            + neural_bonuses.get(branch, 0.0),
                            self._graph_bonus(branch),
                        )

                    mechanism_representative = None
                    if state.mechanism_safety_mode:
                        present_mechanisms = {
                            candidate.mechanism
                            for candidate in remaining
                        }
                        unrepresented = (
                            present_mechanisms - state.checked_mechanisms
                        )
                        if unrepresented:
                            representatives = [
                                candidate
                                for candidate in remaining
                                if candidate.mechanism in unrepresented
                            ]

                            def representative_key(candidate):
                                score, graph_bonus = adaptive_score(
                                    candidate
                                )
                                return (
                                    mechanism_cost_class(
                                        candidate.mechanism
                                    ),
                                    -score,
                                    -graph_bonus,
                                )

                            mechanism_representative = min(
                                representatives,
                                key=representative_key,
                            )
                    safe_prefix = (
                        self.neural_ranker is not None
                        and not state.mechanism_safety_mode
                        and rank
                        < self.config.neural_ranker_topk_safe
                    )
                    if mechanism_representative is not None:
                        # Mechanism-representative protection: before
                        # the ranker reorders anything, every triggered
                        # mechanism gets one heuristic-best candidate
                        # checked (cheapest cost class first).  The
                        # neural model then owns the ordering of all
                        # remaining candidates.
                        ranker_predictions = None
                        ranker_inference_time = 0.0
                        branch = mechanism_representative
                        self.logger.write({
                            "event": "neural_ranker_mechanism_rep",
                            "candidate_count": len(remaining),
                            "unrepresented_mechanism_count": len(
                                unrepresented
                            ),
                            "selected_mechanism": branch.mechanism,
                            "mechanism_cost_class": mechanism_cost_class(
                                branch.mechanism
                            ),
                            "online_update": False,
                        })
                    elif safe_prefix:
                        # Preserve the first K adaptive-heuristic checks,
                        # not only their pre-beam membership.  Otherwise
                        # a neural permutation can consume the typed-phase
                        # budget before a known legacy success is checked.
                        ranker_predictions = None
                        ranker_inference_time = 0.0
                        branch = max(remaining, key=adaptive_score)
                        self.logger.write({
                            "event": "neural_ranker_safe_prefix",
                            "candidate_count": len(remaining),
                            "prefix_position": rank + 1,
                            "prefix_size": (
                                self.config.neural_ranker_topk_safe
                            ),
                            "selected_mechanism": branch.mechanism,
                            "online_update": False,
                        })
                    else:
                        ranker_predictions, ranker_inference_time = (
                            self._neural_ranker_predictions(
                                "typed-selection",
                                remaining,
                                state.analyzer,
                                state.failure_type,
                                state.failure_counts,
                                state.checked,
                                time_ratio,
                                degree=degree,
                                clauses=clauses,
                            )
                        )

                    if ranker_predictions is not None:
                        selected_ordinal = max(
                            range(len(remaining)),
                            key=lambda ordinal: (
                                ranker_predictions.ranking_scores[ordinal]
                            ),
                        )
                        branch = remaining[selected_ordinal]
                        heuristic_order = sorted(
                            range(len(remaining)),
                            key=lambda ordinal: (
                                -remaining[ordinal].score,
                                ordinal,
                            ),
                        )
                        self.logger.write({
                            "event": "neural_ranker_selection",
                            "candidate_count": len(remaining),
                            "selected_ordinal": selected_ordinal,
                            "selected_heuristic_rank": (
                                heuristic_order.index(selected_ordinal) + 1
                            ),
                            "selected_mechanism": branch.mechanism,
                            "ranking_score": (
                                ranker_predictions.ranking_scores[
                                    selected_ordinal
                                ]
                            ),
                            "success_score": (
                                ranker_predictions.success_scores[
                                    selected_ordinal
                                ]
                            ),
                            "progress_score": (
                                ranker_predictions.progress_scores[
                                    selected_ordinal
                                ]
                            ),
                            "cost_score": (
                                ranker_predictions.cost_scores[
                                    selected_ordinal
                                ]
                            ),
                            "inference_time_seconds": (
                                ranker_inference_time
                            ),
                            "online_update": False,
                        })
                    elif mechanism_representative is None:
                        branch = max(remaining, key=adaptive_score)
                    trace_context = None
                    if self._ranker_trace_enabled():
                        trace_score_components = {}
                        for candidate_ordinal, candidate in enumerate(
                            remaining
                        ):
                            candidate_mechanism_bonus = mechanism_bonus(
                                candidate
                            )
                            candidate_neural_bonus = neural_bonuses.get(
                                candidate, 0.0
                            )
                            deep_ranker_score = (
                                ranker_predictions.ranking_scores[
                                    candidate_ordinal
                                ]
                                if ranker_predictions is not None
                                else None
                            )
                            trace_score_components[candidate] = {
                                "heuristic": float(candidate.score),
                                "mechanism_bonus": float(
                                    candidate_mechanism_bonus
                                ),
                                "graph_structural_bonus": float(
                                    self._graph_bonus(candidate)
                                ),
                                "legacy_neural_bonus": float(
                                    candidate_neural_bonus
                                ),
                                "deep_ranker_score": deep_ranker_score,
                                "selection_score": (
                                    float(deep_ranker_score)
                                    if deep_ranker_score is not None
                                    else float(
                                        candidate.score
                                        + candidate_mechanism_bonus
                                        + candidate_neural_bonus
                                    )
                                ),
                            }
                        trace_context = self._trace_candidate_group(
                            "typed-phase",
                            remaining,
                            branch,
                            state.analyzer,
                            state.failure_type,
                            state.failure_counts,
                            state.checked,
                            time_ratio,
                            degree=degree,
                            clauses=clauses,
                            score_components=trace_score_components,
                            selection_policy=(
                                "vc-deepsets-ranker"
                                if ranker_predictions is not None
                                else "mechanism-representative"
                                if mechanism_representative is not None
                                else "heuristic-safe-prefix"
                                if safe_prefix
                                else "legacy-neural-adaptive"
                                if self.neural_scorer is not None
                                else "adaptive-heuristic"
                            ),
                        )
                    remaining.remove(branch)
                    rank += 1
                    neural_pred = None
                    if self.neural_scorer is not None:
                        neural_pred = self.neural_scorer.score(
                            state.analyzer,
                            branch,
                            state.failure_type.value if state.failure_type else "NONE",
                            {k.value: v for k, v in state.failure_counts.items()},
                            state.checked,
                            time_ratio,
                        )
                    result = self._check_branch(
                        state.verifier,
                        branch,
                        state.smt_path,
                        state.program_id,
                        rank,
                        state.analyzer,
                        trace_context,
                    )
                    if result is None:
                        continue
                    state.checked += 1
                    state.checked_mechanisms.add(branch.mechanism)
                    self._note_stagnation_progress(state, result)
                    self._mechanism_prioritizer.update(
                        branch.mechanism,
                        result.failure_type.value,
                    )
                    if self.neural_scorer is not None:
                        ns_update = self.neural_scorer.update_from_check(
                            state.analyzer,
                            branch,
                            result.failure_type.value,
                            {k.value: v for k, v in state.failure_counts.items()},
                            state.checked,
                            time_ratio,
                        )
                        if ns_update:
                            self.logger.write({
                                "event": "neural_scorer_update",
                                "program_id": state.program_id,
                                "mechanism": branch.mechanism,
                                "prediction": neural_pred,
                                "target": ns_update["target"],
                                "loss": ns_update["loss"],
                                "online_samples": ns_update["samples"],
                            })
                    if result.failure_type == CheckFailureType.SUCCESS:
                        return self._success(
                            state.program_id, branch, state.started, state.checked
                        )
                    state.failure_type = result.failure_type
                    state.failure_counts[state.failure_type] += 1
                    trial_branch, trial_delta = self._run_lemma_trials_hook(state, 
                        result, branch
                    )
                    if trial_branch is not None:
                        state.checked += trial_delta
                        return self._success(
                            state.program_id, trial_branch, state.started, state.checked
                        )
                    state.checked += trial_delta
                    if result.counterexample is not None:
                        state.last_counterexample = result.counterexample
                        state.all_counterexamples.append(
                            result.counterexample
                        )
                    if self.config.clause_composer_enabled:
                        state.composition_observations.append((branch, result))
                    if (
                        self.config.typed_counterexamples
                        and state.failure_counts[state.failure_type] > 1
                    ):
                        preferred = FAILURE_TYPE_PREFERRED_MECHANISMS.get(
                            state.failure_type, ()
                        )
                        expandable = [
                            candidate
                            for candidate in state.reserve_branches
                            if candidate.degree <= degree
                            and candidate.clauses <= clauses
                            and (
                                not preferred
                                or candidate.mechanism in preferred
                            )
                        ]
                        expanded = None
                        if expandable:
                            expanded = max(
                                expandable,
                                key=lambda candidate: candidate.score,
                            )
                            state.reserve_branches.remove(expanded)
                            remaining.append(expanded)
                        ce_branches = []
                        if state.last_counterexample is not None:
                            try:
                                from SparCE.generation.ce_synthesis import CESynthesizer
                                synthesizer = CESynthesizer(
                                    state.analyzer.variables,
                                    state.analyzer.translator.symbols,
                                    analyzer=state.analyzer,
                                    max_degree=self.config.max_degree,
                                )
                                ce_branches = synthesizer.synthesize(
                                    state.last_counterexample,
                                    state.failure_type.value,
                                    postcondition=state.analyzer.postcondition,
                                    max_results=4,
                                    all_counterexamples=state.all_counterexamples,
                                )
                                ce_branches = [
                                    cb
                                    for cb in ce_branches
                                    if cb.degree <= degree
                                    and cb.clauses <= clauses
                                    and str(
                                        z3.simplify(cb.formula)
                                    ) not in state.active_keys
                                    and str(
                                        z3.simplify(cb.formula)
                                    ) not in {
                                        str(z3.simplify(r.formula))
                                        for r in remaining
                                    }
                                ]
                                for cb in ce_branches:
                                    state.active_keys.add(
                                        str(z3.simplify(cb.formula))
                                    )
                                    if self.config.clause_composer_enabled:
                                        state.composition_bank_branches.append(cb)
                                remaining.extend(ce_branches)
                            except Exception:
                                ce_branches = []
                        self.logger.write(
                            {
                                "event": "ada_repeated_failure",
                                "program_id": state.program_id,
                                "failure_type": state.failure_type.value,
                                "count": state.failure_counts[state.failure_type],
                                "action": (
                                    "expand-corresponding-feature-branch"
                                    if expanded is not None
                                    else (
                                        "ce-synthesized"
                                        if ce_branches
                                        else "no-matching-reserve-branch"
                                    )
                                ),
                                "expanded_mechanism": (
                                    expanded.mechanism
                                    if expanded is not None
                                    else None
                                ),
                                "expanded_monomials": (
                                    list(expanded.monomials)
                                    if expanded is not None
                                    else []
                                ),
                                "ce_synthesized_count": len(ce_branches),
                                "ce_mechanisms": [
                                    cb.mechanism for cb in ce_branches
                                ],
                                "degree": degree,
                                "clauses": clauses,
                            }
                        )
