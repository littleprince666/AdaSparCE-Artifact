"""Lossless SMT-LIB transport and exact serialization for raw-VC checking."""
import json
import re

SPLIT = "SPLIT_HERE_asdfghjklzxcvbnmqwertyuiop"


class Unsupported(ValueError):
    pass


def sexps(text):
    """Parse parentheses, comments and quoted identifiers; never evaluate input."""
    tokens = re.findall(r';[^\n]*|\|(?:[^|]|\\\|)*\||"(?:[^"]|"")*"|[()]|[^\s();]+', text)
    roots, stack = [], []
    for token in tokens:
        if token.startswith(';'):
            continue
        if token == '(':
            node = []
            (stack[-1] if stack else roots).append(node)
            stack.append(node)
        elif token == ')':
            if not stack:
                raise Unsupported('unbalanced SMT-LIB parentheses')
            stack.pop()
        else:
            (stack[-1] if stack else roots).append(token)
    if stack:
        raise Unsupported('unbalanced SMT-LIB parentheses')
    return roots


def smt(node):
    return '(' + ' '.join(smt(value) for value in node) + ')' if isinstance(node, list) else node


def raw_problem(text):
    parts = text.split(SPLIT)
    if len(parts) != 5:
        raise Unsupported('raw VC must contain exactly the invariant placeholder and three VC sections')
    definitions = sexps(parts[0] + ' true ' + parts[1])
    invs = [node for node in definitions if isinstance(node, list) and node[:2] == ['define-fun', 'inv-f']]
    if len(invs) != 1 or len(invs[0]) != 5 or invs[0][3] != 'Bool':
        raise Unsupported('unsupported invariant interface')
    parameters = invs[0][2]
    if not parameters or any(len(pair) != 2 or pair[1] not in ('Int', 'Real') for pair in parameters):
        raise Unsupported('only nonempty scalar Int/Real invariant interfaces are supported')
    if len({pair[0] for pair in parameters}) != len(parameters):
        raise Unsupported('duplicate invariant argument')
    assertions = []
    for part in parts[2:]:
        nodes = sexps(part)
        if len(nodes) != 1 or not isinstance(nodes[0], list) or nodes[0][0] != 'assert' or len(nodes[0]) != 2:
            raise Unsupported('each original VC section must contain one assertion')
        assertions.append(nodes[0][1])
    return definitions, parameters, assertions


def to_sygus(text):
    """Encode exactly the same synthesis problem, including every SSA variable.

    Original checking asks whether each counterexample assertion is UNSAT.
    The SyGuS constraint is its negation, universally quantified over all
    original declared constants. No projection, C translation or templates.
    """
    definitions, parameters, assertions = raw_problem(text)
    logics = [node[1] for node in definitions if isinstance(node, list) and node[:1] == ['set-logic']]
    if len(logics) != 1:
        raise Unsupported('expected one original logic declaration')
    # SyGuS uses universally quantified constraints, so its logic names do
    # not carry the source query's QF_ prefix. Keep the same arithmetic theory.
    logic = logics[0].removeprefix('QF_')
    if logic not in ('LIA', 'NIA', 'LRA', 'NRA', 'ALL'):
        raise Unsupported('unsupported original arithmetic logic: ' + logics[0])
    output = [['set-logic', logic]]
    for node in definitions:
        if not isinstance(node, list) or not node:
            raise Unsupported('unexpected top-level SMT input')
        head = node[0]
        if head == 'set-logic':
            continue
        if head == 'declare-const' and len(node) == 3 and node[2] in ('Int', 'Real', 'Bool'):
            output.append(['declare-var', node[1], node[2]])
        elif head == 'define-fun' and node[1] == 'inv-f':
            output.append(['synth-inv', 'inv-f', parameters])
        elif head == 'define-fun':
            output.append(node)
        else:
            raise Unsupported('unsupported original SMT command: ' + head)
    output.extend([['constraint', ['not', assertion]] for assertion in assertions])
    output.append(['check-synth'])
    return '\n'.join(smt(node) for node in output) + '\n', parameters


def solution_body(output, parameters):
    matches = []

    def visit(node):
        if isinstance(node, list):
            if node[:2] == ['define-fun', 'inv-f']:
                matches.append(node)
            else:
                for child in node:
                    visit(child)

    for root in sexps(output):
        visit(root)
    if len(matches) != 1:
        return None
    node = matches[0]
    if len(node) != 5 or node[2] != parameters or node[3] != 'Bool':
        raise Unsupported('synthesis solution changed the invariant interface')
    return smt(node[4])


def printed_invariant(body, parameters):
    """Translate SMT output to the existing full_recovery checker vocabulary.

    Z3 is used only as an exact parser here. Rational literals are serialized
    with ToReal, avoiding floats and ambiguous constant integer division.
    """
    import keyword
    import z3
    names = {name for name, _ in parameters}
    if any(not name.isidentifier() or keyword.iskeyword(name) for name in names):
        raise Unsupported('existing Python invariant checker cannot represent this symbol name')
    declarations = '\n'.join(f'(declare-const {name} {sort})' for name, sort in parameters)
    expressions = z3.parse_smt2_string(declarations + '\n(assert ' + body + ')')
    if len(expressions) != 1:
        raise Unsupported('solution is not one Boolean formula')
    calls = {z3.Z3_OP_AND: 'And', z3.Z3_OP_OR: 'Or', z3.Z3_OP_NOT: 'Not',
             z3.Z3_OP_IMPLIES: 'Implies', z3.Z3_OP_ITE: 'If', z3.Z3_OP_XOR: 'Xor',
             z3.Z3_OP_DISTINCT: 'Distinct', z3.Z3_OP_TO_REAL: 'ToReal', z3.Z3_OP_TO_INT: 'ToInt'}
    infix = {z3.Z3_OP_ADD: '+', z3.Z3_OP_SUB: '-', z3.Z3_OP_MUL: '*', z3.Z3_OP_DIV: '/',
             z3.Z3_OP_IDIV: '/', z3.Z3_OP_MOD: '%', z3.Z3_OP_POWER: '**', z3.Z3_OP_EQ: '==',
             z3.Z3_OP_LE: '<=', z3.Z3_OP_GE: '>=', z3.Z3_OP_LT: '<', z3.Z3_OP_GT: '>'}

    def emit(expr):
        if z3.is_true(expr):
            return 'True'
        if z3.is_false(expr):
            return 'False'
        if z3.is_int_value(expr):
            return str(expr.as_long())
        if z3.is_rational_value(expr):
            return f'(ToReal({expr.numerator_as_long()}) / ToReal({expr.denominator_as_long()}))'
        if z3.is_const(expr) and expr.decl().kind() == z3.Z3_OP_UNINTERPRETED and str(expr) in names:
            return str(expr)
        if not z3.is_app(expr):
            raise Unsupported('quantified or non-application invariant output')
        kind, arguments = expr.decl().kind(), [emit(child) for child in expr.children()]
        if kind in calls:
            return calls[kind] + '(' + ', '.join(arguments) + ')'
        if kind == z3.Z3_OP_UMINUS:
            return '(-' + arguments[0] + ')'
        if kind in infix and len(arguments) >= 2:
            # Z3 IDIV on two integer numerals must not become an ambiguous
            # rational in the downstream printed-expression parser.
            if kind == z3.Z3_OP_IDIV and all(z3.is_int_value(child) for child in expr.children()):
                return emit(z3.simplify(expr))
            return '(' + (' ' + infix[kind] + ' ').join(arguments) + ')'
        raise Unsupported('unsupported invariant operator: ' + str(expr.decl()))

    return emit(expressions[0])


def from_infix(text):
    """Transport the author's Boolean infix result to the checker grammar."""
    import ast
    tree = ast.parse(re.sub(r'!(?!=)', ' not ', text.replace('&&', ' and ').replace('||', ' or ')).strip(), mode='eval')

    class BooleanCalls(ast.NodeTransformer):
        def visit_BoolOp(self, node):
            return ast.copy_location(ast.Call(func=ast.Name(id='And' if isinstance(node.op, ast.And) else 'Or', ctx=ast.Load()),
                                             args=[self.visit(value) for value in node.values], keywords=[]), node)

        def visit_UnaryOp(self, node):
            if isinstance(node.op, ast.Not):
                return ast.copy_location(ast.Call(func=ast.Name(id='Not', ctx=ast.Load()), args=[self.visit(node.operand)], keywords=[]), node)
            return self.generic_visit(node)

    return ast.unparse(ast.fix_missing_locations(BooleanCalls().visit(tree)))
