"""Sparse polynomial template representation and canonical candidates."""

from dataclasses import dataclass
from functools import reduce
from math import gcd

import z3

from SparCE.symbolic.monomials import Monomial, _term_sort_key


RELATIONS = ("=", "<=", ">=")


@dataclass(frozen=True)
class PolynomialClause:
    support: tuple
    relation: str = "="

    def __post_init__(self):
        if self.relation not in RELATIONS:
            raise ValueError("unsupported relation {}".format(self.relation))
        if not self.support:
            raise ValueError("a clause needs at least one monomial")
        ordered = tuple(
            sorted(set(self.support), key=_term_sort_key)
        )
        object.__setattr__(self, "support", ordered)


class PolynomialTemplate:
    """A conjunction of polynomial clauses with independent coefficients."""

    def __init__(self, variables, clauses, coefficient_prefix="sp"):
        self.variables = tuple(variables)
        self.clauses = tuple(clauses)
        if not self.clauses:
            raise ValueError("a template needs at least one clause")
        self.coefficients = []
        for clause_index, clause in enumerate(self.clauses):
            self.coefficients.append(
                tuple(
                    z3.Int("{}_{}_{}".format(coefficient_prefix, clause_index, index))
                    for index in range(len(clause.support))
                )
            )
        self.coefficients = tuple(self.coefficients)

    @property
    def max_degree(self):
        return max(monomial.degree for clause in self.clauses for monomial in clause.support)

    @property
    def ast_size(self):
        return 1 + sum(2 + len(clause.support) * 2 for clause in self.clauses)

    @property
    def complexity_score(self):
        return self.ast_size + 2 * self.max_degree + len(self.clauses)

    @property
    def canonical_key(self):
        return (
            self.variables,
            tuple(
                (
                    clause.relation,
                    tuple(monomial.canonical_key for monomial in clause.support),
                )
                for clause in self.clauses
            ),
        )

    def _polynomial(self, clause_index, state):
        clause = self.clauses[clause_index]
        terms = []
        for coefficient, monomial in zip(
            self.coefficients[clause_index], clause.support
        ):
            value = monomial.evaluate(state, self.variables)
            terms.append(coefficient * value)
        return z3.Sum(terms)

    @staticmethod
    def _relate(polynomial, relation):
        if relation == "=":
            return polynomial == 0
        if relation == "<=":
            return polynomial <= 0
        return polynomial >= 0

    def constrain_state(self, state):
        return z3.And(
            *[
                self._relate(self._polynomial(i, state), clause.relation)
                for i, clause in enumerate(self.clauses)
            ]
        )

    def constrain_implication(self, before, after):
        return z3.Implies(
            self.constrain_state(before),
            self.constrain_state(after),
        )

    def nontrivial_constraints(self):
        constraints = []
        for clause, coefficients in zip(self.clauses, self.coefficients):
            nonconstant = [
                coefficient
                for coefficient, monomial in zip(coefficients, clause.support)
                if monomial.degree > 0
            ]
            constraints.append(z3.Or(*[coefficient != 0 for coefficient in nonconstant]))
        return constraints

    def coefficient_bound_constraints(self, bound):
        return [
            z3.And(coefficient >= -bound, coefficient <= bound)
            for coefficients in self.coefficients
            for coefficient in coefficients
        ]

    def sparsity_constraint(self, maximum_nonzero):
        terms = [
            (coefficient != 0, 1)
            for coefficients in self.coefficients
            for coefficient in coefficients
        ]
        return z3.PbLe(terms, maximum_nonzero)

    def instantiate(self, model):
        vectors = []
        for coefficients in self.coefficients:
            vectors.append(
                tuple(
                    model.eval(coefficient, model_completion=True).as_long()
                    for coefficient in coefficients
                )
            )
        return PolynomialCandidate(self.variables, self.clauses, vectors)


class PolynomialCandidate:
    def __init__(self, variables, clauses, coefficient_vectors):
        self.variables = tuple(variables)
        self.clauses = tuple(clauses)
        self.coefficient_vectors = self._canonicalize(coefficient_vectors)

    def _canonicalize(self, vectors):
        result = []
        for clause, raw_vector in zip(self.clauses, vectors):
            vector = [int(value) for value in raw_vector]
            common = reduce(gcd, (abs(value) for value in vector if value), 0)
            if common > 1:
                vector = [value // common for value in vector]
            if clause.relation == "=":
                first = next((value for value in vector if value), 0)
                if first < 0:
                    vector = [-value for value in vector]
            result.append(tuple(vector))
        return tuple(result)

    @property
    def canonical_key(self):
        return tuple(
            (
                clause.relation,
                tuple(
                    (monomial.canonical_key, coefficient)
                    for monomial, coefficient in zip(clause.support, vector)
                    if coefficient
                ),
            )
            for clause, vector in zip(self.clauses, self.coefficient_vectors)
        )

    @property
    def ast_size(self):
        return 1 + sum(
            2 + 2 * sum(1 for value in vector if value)
            for vector in self.coefficient_vectors
        )

    @property
    def max_degree(self):
        degrees = [
            monomial.degree
            for clause, vector in zip(self.clauses, self.coefficient_vectors)
            for monomial, coefficient in zip(clause.support, vector)
            if coefficient
        ]
        return max(degrees) if degrees else 0

    @property
    def number_of_monomials(self):
        return sum(sum(1 for value in vector if value) for vector in self.coefficient_vectors)

    def to_z3(self, primed=False):
        suffix = "!" if primed else ""
        symbols = [z3.Int(name + suffix) for name in self.variables]
        predicates = []
        for clause, vector in zip(self.clauses, self.coefficient_vectors):
            terms = [
                z3.IntVal(coefficient) * monomial.to_z3(symbols)
                for monomial, coefficient in zip(clause.support, vector)
                if coefficient
            ]
            polynomial = z3.Sum(terms) if terms else z3.IntVal(0)
            predicates.append(PolynomialTemplate._relate(polynomial, clause.relation))
        return z3.And(*predicates)

    def pretty_print(self):
        parts = []
        for clause, vector in zip(self.clauses, self.coefficient_vectors):
            terms = []
            for monomial, coefficient in zip(clause.support, vector):
                if not coefficient:
                    continue
                terms.append(
                    "{}*{}".format(coefficient, monomial.pretty_print(self.variables))
                )
            parts.append("{} {} 0".format(" + ".join(terms) or "0", clause.relation))
        return " and ".join(parts)
