import random

import z3
from SMT_Solver.Config import config
from Utilities.SMT_parser import getConstsFromZ3Exp
from Utilities.TimeController import time_limit_calling

z3.set_param('parallel.enable', True)


def Substitute(PT, assignment):
    assignedVars = assignment.keys()
    canI = PT
    for avar in assignedVars:
        theValue = z3.IntVal(str(assignment[avar]))
        avar = z3.Int(str(avar))
        canI = z3.substitute(canI, (avar, theValue))

    return canI



def solve(PT, CE):

    sol = z3.SolverFor("QF_NIA")
    sol.set(auto_config=False)
    # Z3 expects milliseconds; the experiment configuration is in seconds.
    sol.set("timeout", config.PT_SOLVING_TIME * 1000)


    # Substitute all program vars with CE table.
    Query = z3.And(True, True)
    P_sampled = CE['p'] if len(CE['p']) <= config.PT_SOLVING_MAX_CE else random.sample(CE['p'], config.PT_SOLVING_MAX_CE)
    N_sampled = CE['n'] if len(CE['n']) <= config.PT_SOLVING_MAX_CE else random.sample(CE['n'], config.PT_SOLVING_MAX_CE)
    I_sampled = CE['i'] if len(CE['i']) <= config.PT_SOLVING_MAX_CE else random.sample(CE['i'], config.PT_SOLVING_MAX_CE)

    for counterexample in P_sampled:
        pterm = Substitute(PT, counterexample)
        Query = z3.And(Query, pterm)
    for counterexample in N_sampled:
        pterm = Substitute(PT, counterexample)
        Query = z3.And(Query, z3.Not(pterm))
    for counterexample in I_sampled:
        pre = Substitute(PT, counterexample[0])
        post = Substitute(PT, counterexample[1])
        Query = z3.And(Query, z3.Implies(pre, post))

    # Try to find a solution.
    try:
        Query = z3.simplify(Query)
    except Exception as e:
        print(e)
    sol.reset()
    # set to QFNIA
    sol.add(Query)



    r = time_limit_calling(sol.check, (Query), config.PT_SOLVING_TIME)


    if r == z3.sat: # coool
        m = sol.model()
        assignment = {}
        for s in m:
            if 'const_' not in str(s):
                continue
            assignment[str(s)] = str(m[s])

        consts = getConstsFromZ3Exp(PT)
        for conster in consts:
            if str(conster) not in assignment: # that means the consts can be any value
                 assignment[conster] = z3.IntVal(random.randint(-10,10))

        return Substitute(PT, assignment)

    elif r == z3.unsat: # Not Cool
        return None
    else:
        raise TimeoutError("template solving is OOT:    " + str(PT))



