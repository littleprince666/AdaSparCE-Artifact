import pdb
import shlex
from dataclasses import dataclass, asdict
from functools import partial
from pathlib import Path

DBG = pdb.set_trace

TMPDIR = Path("/var/tmp/")
LOGGER_LEVEL = 3
DO_MP = True  # use multiprocessing
# DO_SIMPLIFY / DO_FILTER are always-on constants (their -no… flags were
# removed); flip them here if you ever need to debug what they drop.
DO_SIMPLIFY = True  # simplify results, e.g., removing weaker invariants
DO_FILTER = True  # remove ieqs and min/max terms that unlikely interesting
DO_SS = True  # use symbolic states to check results
DO_EQTS = True  # support equalities
DO_IEQS = True  # support (octagonal) inequalities
DO_CONGRUENCES = True  # support congruence relations
DO_ARRAYS = True  # support array relations
DO_MINMAXPLUS = True  # support minmax-plus inequalities
DO_RECURRENCE = True  # static (recurrence-based) equalities for solvable loops
# Multi-path (CRA-style) extension of the recurrence engine: handle branching
# loop bodies (egcd/fermat/prodbin) by pooling per-path closed-form candidates
# and keeping the subset that is jointly inductive over the real loop (houdini).
# Only fires on loops the single-path engine declines, so it is purely additive.
DO_RECURRENCE_MP = True
DO_KAPUR = False  # RC-Kapur bounded-degree ideal equalities (opt-in; -dokapur)
# SYMBA (Li et al., POPL'14): maximize all inequality/min-max terms at a
# location simultaneously with one shared SMT solver (each model improves every
# objective's bound at once) instead of one z3-Optimize solve per term. Same
# exact bounds, fewer solver calls. Opt-in (-dosymba); overlaps the default
# per-term optimizer, so off by default like -dokapur.
DO_SYMBA = False
# Houdini pass over the union of LLM-proposed candidates (llm mode only): prove
# the largest jointly/k-inductive subset unboundedly, catching mutually
# inductive sets the per-candidate bounded check misses. Additive to verify().
DO_LLM_HOUDINI = True
DO_SOLVER_STATS = False  # collect solver usage stats
WRITE_VTRACES = None  # write vtraces to csv
WRITE_SSTATES = None  # write symbolic states to a json file
READ_SSTATES = None  # read symbolic states from a json file
BENCHMARK_TIMEOUT = 15 * 60  # mins

N_RAND_INPS = 100  # number of random inputs, only used when DO_SS is False
INP_MAX_V = 300
SE_DEPTH_NOCHANGES_MAX = 3
SE_MAX_DEPTH = 8  # max symbolic-execution depth; override with --se_maxdepth
# Deterministic z3 work-unit budget, plus a safety timeout for native arithmetic.
# The work budget is independent of CPU contention; timeout fallbacks can
# affect optional results and are recorded separately in benchmark settings.
# Calibrated to ~3s of CPU work on a typical core (see create_solver).
SOLVER_RLIMIT = 15_000_000
SOLVER_TIMEOUT_MS = 5000  # fallback when native arithmetic exceeds the work budget
# Optional bound searches and redundancy removal must not consume the whole
# run budget after equality discovery. Unknown optimization results are
# omitted; unknown implications retain the original invariant.
OPT_SOLVER_RLIMIT = 500_000
OPT_SOLVER_TIMEOUT_MS = 1000  # safety fallback for expensive native NIA operations
SIMPLIFY_SOLVER_RLIMIT = 100_000
SIMPLIFY_SOLVER_TIMEOUT_MS = 1000
FEASIBILITY_SOLVER_RLIMIT = 100_000
FEASIBILITY_SOLVER_TIMEOUT_MS = 100


@dataclass(frozen=True)
class SolverPolicy:
    rlimit: int
    timeout_ms: int


def solver_policy(phase="checking"):
    """Resolve each phase's immutable policy at use time, not import time."""
    values = {
        "checking": (SOLVER_RLIMIT, SOLVER_TIMEOUT_MS),
        "optimization": (OPT_SOLVER_RLIMIT, OPT_SOLVER_TIMEOUT_MS),
        "simplification": (SIMPLIFY_SOLVER_RLIMIT, SIMPLIFY_SOLVER_TIMEOUT_MS),
        "feasibility": (FEASIBILITY_SOLVER_RLIMIT, FEASIBILITY_SOLVER_TIMEOUT_MS),
    }
    return SolverPolicy(*values[phase])


def effective_settings():
    """Serializable effective configuration for a result, including policies."""
    result = {name: value for name, value in globals().items()
              if name.isupper() and not name.startswith("_")
              and isinstance(value, (str, int, float, bool, type(None)))}
    result["solver_policies"] = {phase: asdict(solver_policy(phase)) for phase in
                                 ("checking", "optimization", "simplification", "feasibility")}
    return result
EQT_RATE = 1.5
# Groebner-basis reduction (Miscs.reduce_eqts) can hang on degree-2/many-var
# candidate eqts (e.g. egcd, 8 vars). Bound it; on timeout we fall back to the
# unreduced eqts, which is reduce_eqts's documented behavior anyway.
GROEBNER_TIMEOUT = 5  # secs
UGLY_FACTOR = 20  # remove equalities that have lots of terms and "large" coefficients
MAX_TERM = 200

TRACE_MULTIPLIER = 5
INP_RANGE_V = 4  # use more inp ranges when # of inputs is <= this
UTERMS = None  # terms that the user's interested in, e.g., "y^2 xy"
SOURCE_TEMPLATES = True  # automatic hints; explicit template controls opt out

# Iequalities
IUPPER = 50  # t <= iupper
IUPPER_MMP = 1  # for min/max ieqs
# Cap on the # of operands inside a min/max-plus term, i.e. max(y1,..,yk).
# Term generation is O(n*2^n) in the # of vars; without a cap, programs with
# many vars (e.g. egcd, 8 vars) explode into thousands of mostly-spurious terms
# and time out in generation + simplify. Large-subset mp terms are rarely true.
MP_MAX_SUBSET = 2
IDEG = 1  # deg (if 1 then linear)
ITERMS = 2  # octagonal
ICOEFS = 1  # from -ICOEFS to ICOEFS, e.g., -1,0,1
# min # of distinct term values required to trust a congruence mod n.
# guards against a large modulus inferred from too few values (gcd overfit):
# the chance of a spurious shared divisor is ~1/2^SE_MAX_D(nvals-1), so a flat
# minimum suffices (large moduli are self-protecting).
CONGRUENCE_MIN_NVALS = 5

# options for full specs analysis
CTR_VAR = "Ct"  # counter variable contains this string
POST_LOC = "post"  # vtraceX_post  indicates postconditions

# Program Paths
TRACE_DIR = "traces"
SYMEXE_DIR = "symexe"
TRACE_INDICATOR = "vtrace"
MAINQ_FUN = "mainQ"

class C:
    GCC_CMD = "gcc"

    # Symbolic inference uses mathematical integer arithmetic. Reject native
    # executions that overflow signed C integers instead of fitting wrapped
    # values that contradict that arithmetic.
    COMPILE = "{gcc} -ftrapv {filename} -o {tmpfile}"
    COMPILE = partial(COMPILE.format, gcc=GCC_CMD)

    C_RUN = "{exe}"
    C_RUN = partial(C_RUN.format)

    # max wall-clock seconds a single program run may take. Inputs that don't
    # terminate within this bound are killed and contribute no traces, so a
    # non-terminating program can't hang DIG.
    RUN_TIMEOUT = 2

    # function calls that are rejected by the static safety scan before a file
    # is compiled/run: file deletion/modification, process spawning, etc. The
    # input programs are pure numeric computations, so none of these are needed.
    FORBIDDEN_CALLS = (
        "system", "popen",
        "exec", "execl", "execlp", "execle", "execv", "execvp", "execvpe",
        "fork", "vfork", "clone",
        "remove", "unlink", "unlinkat", "rmdir", "rename", "renameat",
        "fopen", "freopen", "open", "openat", "creat",
        "truncate", "ftruncate",
        "socket", "connect", "kill",
    )


# Declarative tables driving setup(). Each entry maps an argparse attribute to
# the settings attribute it overrides and the CLI flag used to reconstruct it
# when re-invoking dig.py as a subprocess (benchmark mode).

# -types/-only allowlist: canonical name -> the DO_* setting it enables. When
# -types is given, every governed type is turned off and only the listed ones
# back on, replacing the seven -no<type> flags with one positive selector.
# (The -no<type> flags still work as hidden aliases for back-compat.)
_TYPE_ALIASES = {
    "eqt": "DO_EQTS", "eqts": "DO_EQTS", "eq": "DO_EQTS",
    "ieq": "DO_IEQS", "ieqs": "DO_IEQS", "oct": "DO_IEQS",
    "minmax": "DO_MINMAXPLUS", "mmp": "DO_MINMAXPLUS", "minmaxplus": "DO_MINMAXPLUS",
    "congruence": "DO_CONGRUENCES", "cong": "DO_CONGRUENCES", "congruences": "DO_CONGRUENCES",
    "array": "DO_ARRAYS", "arrays": "DO_ARRAYS",
    "recurrence": "DO_RECURRENCE", "rec": "DO_RECURRENCE",
}
# every type governed by -types (all turned off before the allowlist re-enables)
_TYPE_SETTINGS = (
    "DO_EQTS", "DO_IEQS", "DO_MINMAXPLUS",
    "DO_CONGRUENCES", "DO_ARRAYS", "DO_RECURRENCE",
)


def _parse_types(spec):
    """Comma/space-separated type spec -> set of DO_* setting names to enable.
    Raises ValueError on an unknown type name (with the valid names listed)."""
    names = [t.strip() for t in spec.replace(",", " ").split() if t.strip()]
    enabled = set()
    for n in names:
        setting = _TYPE_ALIASES.get(n.lower())
        if setting is None:
            valid = ", ".join(sorted({k for k in _TYPE_ALIASES}))
            raise ValueError(f"unknown type '{n}' in -types (valid: {valid})")
        enabled.add(setting)
    return enabled


# store_true flags: when present, force the named DO_* setting to a fixed value.
# The "no..." flags disable a feature (set False); -dosolverstats enables one.
_BOOL_FLAGS = (
    # (arg_attr, setting_attr, cli_flag, value_when_present)
    # invariant-type selection is via -types (see _TYPE_SETTINGS); the old
    # per-type -no<type> flags were removed. -norecurrence maps to a type too
    # (recurrence), so it lives in -types now, not here.
    ("noss", "DO_SS", "-noss", False),
    ("nomp", "DO_MP", "-nomp", False),
    ("norecurrencemp", "DO_RECURRENCE_MP", "-norecurrencemp", False),
    ("dokapur", "DO_KAPUR", "-dokapur", True),
    ("dosymba", "DO_SYMBA", "-dosymba", True),
    ("nollmhoudini", "DO_LLM_HOUDINI", "-nollmhoudini", False),
    ("dosolverstats", "DO_SOLVER_STATS", "-dosolverstats", True),
)

# String options: apply and serialize the value verbatim, including spaces.
_STR_FLAGS = (
    # (arg_attr, setting_attr, cli_flag)
    ("writevtraces", "WRITE_VTRACES", "-writevtraces"),
    ("writesstates", "WRITE_SSTATES", "-writesstates"),
    ("readsstates", "READ_SSTATES", "-readsstates"),
)

# Int options: applied when given and >= 1; reconstructed as "-flag <value>".
_INT_FLAGS = (
    # (arg_attr, setting_attr, cli_flag)
    ("inpMaxV", "INP_MAX_V", "-inpMaxV"),
    ("iupper", "IUPPER", "-iupper"),
    ("ideg", "IDEG", "-ideg"),
    ("iterms", "ITERMS", "-iterms"),
    ("icoefs", "ICOEFS", "-icoefs"),
    ("maxterm", "MAX_TERM", "-maxterm"),
    ("nrandinps", "N_RAND_INPS", "-nrandinps"),
)


def setup(settings, args):
    """
    Apply command-line ``args`` to the global ``settings`` module.

    Two modes:
    - ``settings`` truthy: mutate the settings module in place and return a
      configured logger.
    - ``settings`` falsy (None): collect the equivalent CLI flags and return
      them as a string, used to re-invoke dig.py as a benchmark subprocess.
    """
    import helpers.vcommon

    opts = []
    if settings:
        settings.SOURCE_TEMPLATES = not any(
            getattr(args, name, None) is not None for name in ("ideg", "iterms", "icoefs"))

    # -types/-only: apply before the -no<type> flags so an explicit -no<type>
    # (or a hidden alias) can still further disable a type the allowlist enabled.
    types_spec = getattr(args, "types", None)
    if types_spec:
        enabled = _parse_types(types_spec)   # raises ValueError on a bad name
        if settings:
            for set_attr in _TYPE_SETTINGS:
                setattr(settings, set_attr, set_attr in enabled)
        else:
            opts.extend(["-types", types_spec])

    for arg_attr, set_attr, flag, value in _BOOL_FLAGS:
        if getattr(args, arg_attr):
            if settings:
                setattr(settings, set_attr, value)
            else:
                opts.append(flag)

    for arg_attr, set_attr, flag in _STR_FLAGS:
        val = getattr(args, arg_attr)
        if val:
            if settings:
                setattr(settings, set_attr, val)
            else:
                opts.extend([flag, str(val)])

    for arg_attr, set_attr, flag in _INT_FLAGS:
        val = getattr(args, arg_attr)
        if val is not None:
            if val < 1:
                raise ValueError(f"{flag} must be positive")
            if settings:
                setattr(settings, set_attr, val)
            else:
                opts.extend([flag, str(val)])

    if args.uterms:
        if settings:
            settings.UTERMS = set(args.uterms.split(';'))
        else:
            opts.extend(["-uterms", args.uterms])

    if args.se_maxdepth is not None and args.se_maxdepth >= 1:
        if settings:
            settings.SE_MAX_DEPTH = args.se_maxdepth
        else:
            opts.extend(["-se_maxdepth", str(args.se_maxdepth)])

    if not settings and getattr(args, "maxdeg", None) is not None:
        opts.extend(["-maxdeg", str(args.maxdeg)])
    if not settings:
        for name in ("writeresults", "test_tracefile"):
            if value := getattr(args, name, None):
                opts.extend(["-" + name, str(value)])

    if args.tmpdir:
        if settings:
            settings.TMPDIR = Path(args.tmpdir)
            assert settings.TMPDIR.is_dir()
        else:
            opts.extend(["-tmpdir", str(args.tmpdir)])

    if settings:
        settings.LOGGER_LEVEL = helpers.vcommon.getLogLevel(args.log_level)
        mlog = helpers.vcommon.getLogger(__name__, settings.LOGGER_LEVEL)
        return mlog
    else:
        opts.extend(["-log_level", str(args.log_level)])
        return shlex.join(opts)
