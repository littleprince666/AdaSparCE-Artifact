"""Sound counterexample-replay pre-filter for candidate checking.

A counterexample returned by the shared SMT verifier is a satisfying
assignment of one negated verification condition.  Given the standard
code2inv/SyGuS encoding::

    INIT:  (not (=> (pre-f s)        (inv-f s)))
    STEP:  (not (=> (and (inv-f s) (trans-f s s')) (inv-f s')))
    EXIT:  (not (=> (inv-f s)        (post-f s)))

a model ``s`` (or pair ``(s, s')``) witnesses the failure of the checked
candidate ``I_old``.  The very same witness proves that another candidate
``J`` fails the same VC whenever:

* INIT:  ``J(s)`` is false  (``pre(s)`` still holds);
* STEP:  ``J(s)`` is true and ``J(s')`` is false (``trans(s, s')`` holds);
* EXIT:  ``J(s)`` is true  (``not post(s)`` still holds).

Evaluations that do not reduce to a Boolean value (partial assignment,
unknown symbols) are inconclusive and never reject a candidate, so this
pre-filter can only skip candidates that are guaranteed to fail the
authoritative SMT check.  Soundness of the overall system is unchanged:
candidates are only removed from the checker queue when a concrete
counter-state already refutes them.
"""

from SparCE.feedback.clause_composer import evaluate_formula


def _failure_name(failure_type):
    if failure_type is None:
        return "UNKNOWN"
    return getattr(failure_type, "value", str(failure_type)).upper()


def ce_proves_failure(formula, failure_type, counterexample):
    """Return True when ``counterexample`` proves ``formula`` fails a VC.

    ``failure_type`` is the CheckFailureType under which the
    counterexample was produced.  The result is conservative: partial
    evaluations never claim a proof of failure.
    """
    failure = _failure_name(failure_type)
    if failure == "INIT":
        if not isinstance(counterexample, dict):
            return False
        return evaluate_formula(formula, counterexample) is False
    if failure == "EXIT":
        if not isinstance(counterexample, dict):
            return False
        return evaluate_formula(formula, counterexample) is True
    if failure == "STEP":
        if not (
            isinstance(counterexample, tuple)
            and len(counterexample) == 2
            and isinstance(counterexample[0], dict)
            and isinstance(counterexample[1], dict)
        ):
            return False
        before, after = counterexample
        return (
            evaluate_formula(formula, before) is True
            and evaluate_formula(formula, after) is False
        )
    return False
