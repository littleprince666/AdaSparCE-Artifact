"""Matched AdaSparCE control under the same cold-process total deadline."""
import json
from pathlib import Path
import subprocess
import sys
import time


def run(request):
    author = Path(request['author_root'])
    sys.path.insert(0, str(author))
    from tools.run_experiment import command_for
    config = json.loads((author/'run-config.json').read_text())
    command = command_for(request['task'], Path(request['dataset']), config,
                          Path(request['workdir'])/'ada-engine-trace.jsonl', 'adasparce', seed=request['seed'])
    capture = Path(request['workdir'])/'ada-engine-output.txt'
    with capture.open('w') as stream:
        try:
            subprocess.run(command, cwd=author, stdout=stream, stderr=subprocess.STDOUT,
                           timeout=max(.001, request['deadline_monotonic']-time.monotonic()), check=False)
        except subprocess.TimeoutExpired:
            return dict(status='timeout', reason='shared cold-process total deadline')
    parsed = None
    for line in reversed(capture.read_text().splitlines()):
        try:
            value = json.loads(line)
            if isinstance(value, dict) and 'status' in value:
                parsed = value
                break
        except json.JSONDecodeError:
            pass
    if parsed is None:
        return dict(status='error', reason='Ada control produced no complete result')
    parsed['native_search_seconds'] = parsed.pop('total_time', None)
    return parsed
