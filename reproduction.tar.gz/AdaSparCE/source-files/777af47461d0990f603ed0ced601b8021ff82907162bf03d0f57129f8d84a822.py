"""Houdini-style joint induction on the unchanged, previously frozen Q0.

This is a finite-predicate control, not an implementation of ESC/Java. Models
are evaluated against each *original* instantiated obligation, so reordered
inv-f arguments and nonstandard next-state names cannot corrupt elimination.
No value completion from the Clause2Inv presentation transport is used.
"""
from pathlib import Path
import json
import time

import z3

from SMT_Solver.SMT_verifier import SMT_verifier
from SparCE.verification.proof_obligations import original_queries
from tools.experiments.shared_pool_core import (
    SharedChecker, ReplayStop, digest, parse_formula, symbols_from_vc,
    replay_pool as original_replay, wall_budget,
)

VARIANTS = ('ada_c', 'no_composition', 'joint_houdini')


class JointChecker(SharedChecker):
    """The same three-query budget; retain models for joint elimination."""

    def check(self, formula, source='joint-houdini'):
        self.ensure_budget()
        key = z3.simplify(formula).sexpr()
        if key in self.cache:
            self.emit('duplicate-candidate', formula_sha256=digest(key), source=source)
            return self.cache[key]
        self.checks += 1
        self.emit('candidate-start', attempt=self.checks, source=source,
                  formula_smtlib=formula.sexpr(), formula_sha256=digest(formula.sexpr()))
        started = time.perf_counter()
        stop = min(self.deadline, started + self.candidate_seconds)
        statuses, models, records = [], [], []
        for name, query in zip(('INIT', 'STEP', 'EXIT'), original_queries(self.vc_path, formula)):
            context = z3.Context()
            solver = z3.Solver(ctx=context)
            solver.add(query.translate(context))
            query_text = solver.to_smt2()
            checksum = digest(query_text)
            target = self.query_dir / (checksum + '.smt2')
            if not target.exists():
                target.write_text(query_text)
            remaining = stop - time.perf_counter()
            solver_started = time.perf_counter()
            model = None
            if remaining <= 0:
                status, reason = z3.unknown, 'candidate-budget-exhausted'
            else:
                solver.set(timeout=max(1, int(remaining * 1000)), random_seed=self.seed)
                status, _ = SMT_verifier._check_with_watchdog(solver, remaining)
                reason = solver.reason_unknown() if status == z3.unknown else None
                if status == z3.sat:
                    model = solver.model()
            elapsed = time.perf_counter() - solver_started
            self.solver_seconds += elapsed
            statuses.append(status)
            models.append(model)
            records.append(dict(vc=name, status=str(status), solver_time_seconds=elapsed,
                                query_sha256=checksum, reason_unknown=reason))
        if all(status == z3.unsat for status in statuses):
            self.success = formula
        result = dict(statuses=statuses, models=models, formula=formula)
        self.cache[key] = result
        self.last = result
        self.completed += 1
        self.emit('candidate-check', source=source, candidate_index=self.checks,
                  formula_smtlib=formula.sexpr(), formula_sha256=digest(formula.sexpr()),
                  checker_seconds=time.perf_counter() - started, vc_results=records)
        return result


def jointly_inductive_subset(formulas, checker):
    """Remove precisely the predicates falsified by INIT/STEP witnesses.

    The initial conjunction contains the entire pool. INIT pruning precedes
    STEP pruning. No predicate is removed on UNKNOWN or an EXIT witness.
    If the maximal jointly inductive subset cannot establish EXIT, weakening
    it cannot repair that implication, and the finite-predicate control stops.
    """
    active = list(formulas)
    leaf_queries = [original_queries(checker.vc_path, f) for f in active]
    while True:
        checker.ensure_budget()
        joint = z3.And(*active)
        result = checker.check(joint)
        if checker.success is not None:
            return 'all-original-vcs-unsat'
        index = next((i for i in (0, 1) if result['statuses'][i] == z3.sat), None)
        if index is None:
            return ('joint-inductive-subset-insufficient-for-exit'
                    if all(s == z3.unsat for s in result['statuses'][:2])
                    else 'joint-induction-unknown')
        model = result['models'][index]
        remove = []
        for i, queries in enumerate(leaf_queries):
            checker.ensure_budget()
            # In a joint STEP model every retained pre-predicate holds.
            # Evaluating its original leaf VC thus tests the corresponding
            # post-predicate at the exact original inv-f call arguments.
            value = model.eval(queries[index].translate(model.ctx), model_completion=True)
            if z3.is_true(value):
                remove.append(i)
            elif not z3.is_false(value):
                return 'nonconcrete-joint-model-evaluation'
        if not remove:
            raise ValueError('joint-witness-did-not-falsify-any-retained-predicate')
        checker.emit('joint-eliminate', vc=('INIT', 'STEP')[index], before=len(active),
                     removed=[dict(index=i, formula_sha256=digest(active[i].sexpr())) for i in remove])
        removed = set(remove)
        active = [f for i, f in enumerate(active) if i not in removed]
        leaf_queries = [q for i, q in enumerate(leaf_queries) if i not in removed]


def replay_pool(pool, variant, seed, trace, query_dir, budget=30,
                candidate_seconds=4, max_checks=256, **kwargs):
    if variant in ('ada_c', 'no_composition'):
        return original_replay(pool, variant, seed, trace, query_dir, budget,
                               candidate_seconds, max_checks, **kwargs)
    if variant != 'joint_houdini':
        raise ValueError('unknown-joint-pool-variant')
    started = time.perf_counter()
    generation = float(pool['generation_seconds'])
    trace = Path(trace)
    trace.parent.mkdir(parents=True, exist_ok=True)
    trace.write_text('')
    result = dict(status='failed', invariant=None, invariant_smtlib=None,
                  generation_seconds=generation, replay_seconds=0, total_time=generation,
                  checker_calls=0, attempted_checker_calls=0, solver_seconds=0,
                  pool_sha256=pool['candidate_content_sha256'], candidate_count=pool['candidate_count'],
                  reason=None)
    if pool['status'] != 'prepared' or generation >= budget:
        result['reason'] = 'shared-generation-failed-or-exhausted-budget'
        trace.write_text(json.dumps(dict(event='shared-generation-failed', **result)) + '\n')
        return result
    checker = None
    try:
        with wall_budget(budget - generation):
            symbols = symbols_from_vc(pool['vc_path'])
            formulas = [parse_formula(r['sexpr'], symbols) for r in pool['candidates']]
            checker = JointChecker(pool['vc_path'], trace, query_dir,
                                   started + budget - generation, seed, candidate_seconds, max_checks)
            checker.emit('replay-start', variant=variant, seed=seed,
                         pool_sha256=pool['candidate_content_sha256'], generation_seconds=generation,
                         budget_seconds=budget, candidate_seconds=candidate_seconds,
                         max_checks=max_checks, scheduler=False, fallback=False,
                         dynamic_ce_generation=False, scope='joint-finite-predicate-induction')
            result['reason'] = jointly_inductive_subset(formulas, checker)
    except ReplayStop as exc:
        result['reason'] = str(exc)
    except Exception as exc:
        result.update(status='error', reason=type(exc).__name__ + ':' + str(exc))
    result['replay_seconds'] = time.perf_counter() - started
    result['total_time'] = generation + result['replay_seconds']
    if checker is not None:
        result.update(checker_calls=checker.completed, attempted_checker_calls=checker.checks,
                      solver_seconds=checker.solver_seconds)
        if checker.success is not None:
            result.update(status='solved', invariant=str(checker.success),
                          invariant_smtlib=checker.success.sexpr(), reason='all-original-vcs-unsat')
        checker.emit('replay-end', **result)
    return result
