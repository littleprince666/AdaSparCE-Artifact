"""Public AdaSparCE engine: task orchestration and result construction."""

from SparCE.config import AdaSparCEConfig as AdaSparCEConfig
import time
from pycparser import parse_file
from SMT_Solver.Config import config as baseline_config
from SMT_Solver.SMT_verifier import SMT_verifier
from SparCE.engine import SparseConfig
from SparCE.engine import SparseHeuristicEngine
from SparCE.engine import SparseRunResult
from SparCE.scheduling.strategy_scheduler import StrategyScheduler
from SparCE.scheduling.strategy_scheduler import StrategySchedulerConfig
from SparCE.ranking.ranker_features import extract_program_context
from SparCE.symbolic.candidate import CandidateBranch
from SparCE.feedback.partial_lemma import PartialLemmaTracker as _PartialLemmaTracker
from SparCE.generation.program_analyzer import ProgramAnalyzer as _ProgramAnalyzer
from SparCE.search.state import _RunState, FAILURE_TYPE_PREFERRED_MECHANISMS
from SparCE.search.initialization import EngineInitialization
from SparCE.ranking.adapter import CandidateRanking
from SparCE.generation.semantic import SemanticGeneration
from SparCE.generation.frontiers import FrontierGeneration
from SparCE.generation.division import DivisionGeneration
from SparCE.generation.frontend import FrontendGeneration
from SparCE.generation.coverage import CoverageGeneration
from SparCE.search.checking import CandidateChecking
from SparCE.search.frontend import FrontendSearch
from SparCE.search.scheduled import ScheduledSearch
from SparCE.search.layered import LayeredSearch
from SparCE.search.composition import CompositionSearch

class AdaSparCEEngine(
    EngineInitialization,
    CandidateRanking,
    SemanticGeneration,
    FrontierGeneration,
    DivisionGeneration,
    FrontendGeneration,
    CoverageGeneration,
    CandidateChecking,
    FrontendSearch,
    ScheduledSearch,
    LayeredSearch,
    CompositionSearch,
):
    """Compose search components and execute one invariant-synthesis task."""

    def _scheduler_experiment_kwargs(self):
        return {
            name: getattr(self.config, "strategy_scheduler_" + name)
            for name in (
                "granularity", "online_updates", "quota_mode", "round_budget_ratio",
                "prior_strength", "progress_weight", "disabled_categories",
            )
        }

    def run(self, program_id, c_path, smt_path):
        # Include scheduler setup in the same task wall-clock budget.
        started = time.perf_counter()
        scheduler = None
        if getattr(self.config, "strategy_scheduler_enabled", False):
            scheduler = StrategyScheduler(
                StrategySchedulerConfig(
                    **self._scheduler_experiment_kwargs(),
                    policy=str(getattr(
                        self.config, "strategy_scheduler_policy", "heuristic"
                    )),
                    utility_form=str(getattr(
                        self.config, "strategy_scheduler_utility", "ratio"
                    )),
                    priors=str(getattr(
                        self.config, "strategy_scheduler_priors", "empirical"
                    )),
                    epsilon=float(getattr(
                        self.config, "strategy_scheduler_epsilon", 1.0
                    )),
                    lambda_cost=float(getattr(
                        self.config, "strategy_scheduler_lambda", 0.005
                    )),
                     mu=float(getattr(
                         self.config, "strategy_scheduler_mu", 0.1
                     )),
                     exploration_scale=float(getattr(
                         self.config,
                         "strategy_scheduler_exploration_scale",
                         0.05,
                    )),
                    timeout_tiers=tuple(getattr(
                        self.config,
                        "strategy_scheduler_timeout_tiers",
                        (4.0, 15.0, 60.0, 150.0),
                    )),
                    quotas=dict(getattr(
                        self.config, "strategy_scheduler_quotas", {}
                    )),
                    min_typed_budget_ratio=float(getattr(
                        self.config,
                        "strategy_scheduler_min_typed_budget_ratio",
                        0.15,
                    )),
                    min_fallback_budget_ratio=float(getattr(
                        self.config,
                        "strategy_scheduler_min_fallback_budget_ratio",
                        0.2,
                    )),
                    timeout_escalation_cap=float(getattr(
                        self.config, "timeout_escalation_cap", 150.0
                    )),
                    max_decisions=int(getattr(
                        self.config, "strategy_scheduler_max_decisions", 200
                    )),
                    progress_feedback=bool(getattr(
                        self.config,
                        "strategy_scheduler_progress_feedback",
                        False,
                    )),
                    seed=int(getattr(self.config, "seed", 0)),
                ),
                logger=self.logger,
            )
        # Per-task timeout-control state: the escalation budget must be
        # computed from the true task clock (set here), not from the
        # first checker call (the historical lazy initialisation let
        # setup time — VC frontend, seed check, pool building — leak
        # into the escalation budget and pushed tasks up to ~18 s past
        # the program deadline).  The escalation counter is likewise
        # per task, so a reused engine instance cannot inherit retries.
        self._task_started = started
        self._timeout_escalations = 0
        # Canonical task wall deadline, shared by the engine-side
        # portfolios (_contextual_original_vc_check /
        # _normalized_smt_check) for the same clamping the verifier
        # applies to its own solver calls.
        self._task_wall_deadline = started + self.config.timeout_seconds
        self._reset_neural_ranker_task()
        self._reset_ranker_trace(c_path, smt_path)
        self._reset_prefilter_task()
        if self._pruner is not None:
            self._pruner.reset()
        self._mechanism_prioritizer.reset()
        variables = self._variables(c_path, smt_path)
        from SparCE.symbolic.variables import base_variables
        search_variables = base_variables(variables)
        ast = parse_file(c_path, use_cpp=True)
        analyzer = _ProgramAnalyzer(
            search_variables,
            collect_branch_transitions=(
                self.config.branch_transitions_enabled
                or self.config.transition_kernel_enabled
            ),
        )
        analyzer.visit(ast)
        if analyzer.postcondition is None:
            raise ValueError("program has no assert postcondition")
        if analyzer.needs_smt_fallback():
            analyzer.fill_from_smt(smt_path)
        if (
            self.config.graph_strategy_enabled
            or self._ranker_trace_enabled()
            or self.config.graph_ranker_enabled
        ):
            try:
                from SparCE.ranking.program_graph import ProgramVCGraph

                self._program_vc_graph = ProgramVCGraph.from_analyzer(analyzer)
                self.logger.write({
                    "event": "program_vc_graph",
                    "enabled": bool(self.config.graph_strategy_enabled),
                    "trace_enabled": self._ranker_trace_enabled(),
                    "weight": self.config.graph_strategy_weight,
                    **self._program_vc_graph.summary(),
                })
            except Exception as error:
                # Scheduling must remain fail-open: an unavailable graph prior
                # cannot stop the independent symbolic/SMT search.
                self._program_vc_graph = None
                self.logger.write({
                    "event": "program_vc_graph",
                    "enabled": False,
                    "fallback": "adaptive-heuristic",
                    "reason": str(error),
                })
        if (
            self.neural_ranker is not None
            and self.config.neural_ranker_nonlinear_only
            and self._is_linear_program(analyzer)
        ):
            # The improved deterministic linear pipeline is already strong,
            # while dev_val found no linear solve gain from learned ordering.
            # Keep it byte-for-byte on the heuristic path and reserve the
            # ranker for the nonlinear search space it is meant to prioritize.
            self.neural_ranker = None
            self._ranker_task_gate = "linear-program-heuristic"
            self.logger.write({
                "event": "neural_ranker_task_gate",
                "reason": self._ranker_task_gate,
                "ranker_kind": self._ranker_kind,
                "online_updates": False,
            })
        if self._ranker_trace_enabled() or self.neural_ranker is not None:
            try:
                program_context = extract_program_context(
                    analyzer, smt_path=smt_path
                )
                if self._ranker_trace_enabled():
                    self._trace_program_context = program_context
                if self.neural_ranker is not None:
                    self._ranker_program_context = program_context
            except Exception as error:
                if self.neural_ranker is not None:
                    self._ranker_runtime_fallback = str(error)
                    self.neural_ranker = None
                    self.logger.write({
                        "event": "neural_ranker_fallback",
                        "phase": "program-context",
                        "reason": str(error),
                        "fallback": "adaptive-heuristic",
                    })
                if self._ranker_trace_enabled():
                    self._trace_program_context = extract_program_context(
                        analyzer
                    )
        if scheduler is not None:
            # Per-task reset: fresh online statistics, no pretrained model.
            scheduler.reset()
            self.logger.write({
                "event": "strategy_scheduler_enabled",
                "program_id": program_id,
                "policy": str(getattr(
                    self.config, "strategy_scheduler_policy", "heuristic"
                )),
                "utility_form": str(getattr(
                    self.config, "strategy_scheduler_utility", "ratio"
                )),
                "timeout_tiers": list(getattr(
                    self.config,
                    "strategy_scheduler_timeout_tiers",
                    (4.0, 15.0, 60.0, 150.0),
                )),
                "min_typed_budget_ratio": float(getattr(
                    self.config,
                    "strategy_scheduler_min_typed_budget_ratio",
                    0.15,
                )),
                "min_fallback_budget_ratio": float(getattr(
                    self.config,
                    "strategy_scheduler_min_fallback_budget_ratio",
                    0.2,
                )),
            })
        verifier = SMT_verifier()
        # Hard wall-clock deadline for every checker call in this task:
        # each solver/tactic call inside verifier.check() is clamped to
        # the remaining budget, so a single candidate (3 VCs x portfolio
        # retries, possibly with an escalated or scheduler-tiered
        # timeout) cannot finish past the program budget.
        verifier.wall_deadline = started + self.config.timeout_seconds
        previous_timeout = baseline_config.SMT_CHECK_TIME
        baseline_config.SMT_CHECK_TIME = self.config.checker_timeout_seconds
        state = _RunState(
            program_id=program_id,
            c_path=c_path,
            smt_path=smt_path,
            started=started,
            analyzer=analyzer,
            verifier=verifier,
            scheduler=scheduler,
            search_variables=search_variables,
            base=CandidateBranch(
                analyzer.postcondition,
                130.0,
                "postcondition-seed",
                self._total_degree(analyzer.postcondition),
                1,
            ),
        )
        state.stagnation_mode = (
            self.config.fallback_enabled
            and str(getattr(self.config, "fallback_mode", "fixed"))
            == "stagnation"
        )
        state.lemma_tracker = (
            _PartialLemmaTracker(
                max_trials=self.config.lemma_conjunction_max_trials,
            )
            if self.config.lemma_conjunction_enabled
            else None
        )
        if (
            self.config.unified_clause_bank_enabled
            and self.config.lemma_conjunction_enabled
        ):
            # The unified bank replaces the legacy tracker object: every
            # existing note()/trials call site keeps working, while the
            # richer proposals (STEP x EXIT pairing, bounded full-set
            # step conjunctions) and the composer seeding become active.
            from SparCE.feedback.clause_bank import UnifiedClauseBank

            state.clause_bank = UnifiedClauseBank(
                max_trials=max(
                    self.config.unified_clause_bank_max_trials,
                    self.config.lemma_conjunction_max_trials,
                ),
            )
            state.lemma_tracker = state.clause_bank
        try:
            if (
                self.config.linear_fast_path
                and self.config.semantic_generators_enabled
                and self._is_linear_program(state.analyzer)
            ):
                linear_budget = min(
                    self.config.timeout_seconds * 0.25,
                    8.0,
                )
                self.logger.write({
                    "event": "linear_fast_path",
                    "program_id": state.program_id,
                    "budget_seconds": linear_budget,
                })
                candidate, linear_checked = self._linear_fast_path(
                    state.analyzer, state.c_path, state.verifier, state.smt_path, state.program_id,
                    state.started, linear_budget,
                )
                state.checked += linear_checked
                if candidate is not None:
                    return self._success_linear(
                        state.program_id, candidate, state.started, state.checked
                    )

            # Layer-exhaustion escalation: the iterative layer order means
            # escalated (higher) layers only execute after every configured
            # layer has failed, so escalation is driven purely by the
            # engine's own layer-exhaustion signal, not by task knowledge.
            state.degree_cap = max(
                self.config.max_degree,
                self.config.degree_escalation_cap,
            )
            state.clause_cap = max(
                self.config.max_clauses,
                self.config.clause_escalation_cap,
            )
            if state.scheduler is not None:
                # The scheduler replaces the degree-outer/clause-inner
                # layer order with per-pool best-first complexity
                # ordering; an empty layer range keeps the legacy loop
                # code path intact but inactive.
                state.degrees = ()
            else:
                state.degrees = (
                    range(1, state.degree_cap + 1)
                    if self.config.degree_iterative
                    else (self.config.max_degree,)
                )
            state.clause_levels = (
                range(1, state.clause_cap + 1)
                if self.config.clause_iterative
                else (self.config.max_clauses,)
            )
            if state.degree_cap > self.config.max_degree or (
                state.clause_cap > self.config.max_clauses
            ):
                self.logger.write(
                    {
                        "event": "layer_escalation_enabled",
                        "program_id": state.program_id,
                        "configured_max_degree": self.config.max_degree,
                        "degree_escalation_cap": state.degree_cap,
                        "configured_max_clauses": self.config.max_clauses,
                        "clause_escalation_cap": state.clause_cap,
                    }
                )

            state.typed_phase_budget = self.config.timeout_seconds * (
                1.0
                if (state.stagnation_mode or not self.config.fallback_enabled)
                else 0.3
            )
            phase_result = self._run_vc_frontend_phase(state)
            if phase_result is not None:
                return phase_result
            phase_result = self._run_postcondition_seed_phase(state)
            if phase_result is not None:
                return phase_result
            self._build_branch_pools(state)
            coverage_result = self._run_coverage_seed_phase(state)
            if coverage_result is not None:
                return coverage_result
            if state.scheduler is not None:
                self._scheduler_fallback_timeout = None
                scheduled_result = self._run_scheduled_phase(state)
                if scheduled_result is not None:
                    return scheduled_result
            phase_result = self._run_typed_layer_phase(state)
            if phase_result is not None:
                return phase_result
            phase_result = self._run_clause_composer_phase(state)
            if phase_result is not None:
                return phase_result
        finally:
            baseline_config.SMT_CHECK_TIME = previous_timeout
        return self._run_fallback_tail(state)

    def _run_fallback_tail(self, state):
        """Fallback hand-over or the final failure result."""
        elapsed = time.perf_counter() - state.started
        if (
            self.config.fallback_enabled
            and elapsed < self.config.timeout_seconds
            and not self._checker_budget_exhausted(state.checked)
        ):
            if self._ranker_requested():
                self.logger.write({
                    "event": "neural_ranker_summary",
                    **self._neural_ranker_metrics(),
                })
            fallback_config = SparseConfig(
                max_degree=self.config.max_degree,
                max_monomials=self.config.max_monomials,
                max_clauses=self.config.max_clauses,
                coefficient_bounds=self.config.coefficient_bounds,
                timeout_seconds=self.config.timeout_seconds - elapsed,
                # Clamp the template-solver budget to the remaining task
                # time so the fallback cannot overshoot the deadline.
                template_timeout_seconds=min(
                    self.config.template_timeout_seconds,
                    max(0.05, self.config.timeout_seconds - elapsed),
                ),
                checker_timeout_seconds=(
                    self._scheduler_fallback_timeout
                    if getattr(self, "_scheduler_fallback_timeout", None)
                    else self.config.checker_timeout_seconds
                ),
                max_candidates_per_structure=self.config.max_candidates_per_structure,
                max_checker_calls=(
                    max(
                        0,
                        int(self.config.max_checker_calls) - state.checked,
                    )
                    if self.config.max_checker_calls
                    else 0
                ),
                seed=self.config.seed,
                relations=("=", ">=", "<="),
                monomial_feedback=self.config.monomial_feedback,
            )
            fallback = SparseHeuristicEngine(
                fallback_config,
                str(self.logger.path) if self.logger.path else None,
            ).run(state.program_id + "-fallback", state.c_path, state.smt_path)
            # The fallback's own wall deadline (its start plus the
            # remaining budget) coincides with the task deadline up to
            # engine-construction overhead, so its checker calls are
            # clamped to the original program budget as well.
            fallback.total_time += elapsed
            fallback.checker_calls += state.checked
            return fallback

        total = time.perf_counter() - state.started
        checker_budget_exhausted = self._checker_budget_exhausted(state.checked)
        final_status = "failed" if checker_budget_exhausted else "timeout"
        final_reason = (
            "checker-budget-exhausted"
            if checker_budget_exhausted
            else "budget-exhausted"
        )
        self._save_neural_scorer()
        self.logger.write(
            {
                "event": "final",
                "program_id": state.program_id,
                "template_mode": "adasparce",
                "status": final_status,
                "reason": final_reason,
                "total_time_seconds": total,
                "iterations": state.checked,
                "checker_calls": state.checked,
                **self._neural_ranker_metrics(),
            }
        )
        return SparseRunResult(
            final_status,
            None,
            None,
            total,
            state.checked,
            reason=final_reason,
            checker_calls=state.checked,
        )

    def _success(self, program_id, branch, started, checked):
        total = time.perf_counter() - started
        self._save_neural_scorer()
        self.logger.write(
            {
                "event": "final",
                "program_id": program_id,
                "template_mode": "adasparce",
                "status": "solved",
                "total_time_seconds": total,
                "iterations": checked,
                "checker_calls": checked,
                "candidate": str(branch.formula),
                "mechanism": branch.mechanism,
                **self._neural_ranker_metrics(),
            }
        )
        return SparseRunResult(
            "solved",
            branch.formula,
            None,
            total,
            checked,
            reason=branch.mechanism,
            checker_calls=checked,
        )

    def _success_linear(self, program_id, candidate, started, checked):
        total = time.perf_counter() - started
        invariant = candidate.to_z3()
        self.logger.write(
            {
                "event": "final",
                "program_id": program_id,
                "template_mode": "adasparce",
                "status": "solved",
                "total_time_seconds": total,
                "iterations": checked,
                "checker_calls": checked,
                "candidate": candidate.pretty_print(),
                "mechanism": "linear-fast-path",
                **self._neural_ranker_metrics(),
            }
        )
        return SparseRunResult(
            "solved", invariant, candidate, total, checked,
            reason="linear-fast-path",
            checker_calls=checked,
        )
