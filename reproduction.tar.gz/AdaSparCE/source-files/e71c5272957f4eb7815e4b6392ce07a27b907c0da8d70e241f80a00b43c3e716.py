"""Integer quotient/remainder candidate construction."""

import z3
from SparCE.symbolic.candidate import CandidateBranch


class DivisionGeneration:
    """Integer quotient/remainder candidate construction."""

    def _divmod_branches(self, analyzer):
        """Generate quotient-remainder invariants for div/mod programs.

        For a postcondition that relates a variable to an integer division
        (``q == x div y``) or a remainder (``r == x mod y``), synthesize
        the standard inductive decomposition::

            x == y*q + r  and  0 <= r <= y - 1

        Variants with ``>=`` (weaker at entry), with a paired remainder
        (``r1 + r2``), and with no explicit remainder variable
        (``y*q <= x <= y*(q+1) - 1``) cover the common Euclidean-division
        loops without relying on the monomial template search.
        """
        if not self.config.divmod_frontend or analyzer is None:
            return []
        post = analyzer.postcondition
        if post is None:
            return []
        symbols = analyzer.translator.symbols
        mutated = sorted(analyzer.mutated)
        branches = []
        for target, operation, dividend, divisor in self._collect_divmod(post):
            target_symbol = symbols.get(target) if target in symbols else None
            dividend_symbols = self._symbols_in(dividend)
            divisor_symbols = self._symbols_in(divisor)
            excluded = {target}
            excluded.update(dividend_symbols)
            excluded.update(divisor_symbols)
            if operation == "mod":
                remainder_symbol = (
                    target_symbol if target_symbol is not None else target
                )
                quotient_candidates = [
                    name for name in mutated if name not in excluded
                ]
                for q_name in quotient_candidates:
                    q_symbol = symbols.get(q_name, z3.Int(q_name))
                    branches.extend(
                        self._quotient_remainder_candidates(
                            dividend,
                            divisor,
                            q_symbol,
                            remainder_symbol,
                            "{}-qr".format(q_name),
                        )
                    )
            else:
                quotient_symbol = (
                    target_symbol if target_symbol is not None else target
                )
                remainder_candidates = [
                    name for name in mutated if name not in excluded
                ]
                for r_name in remainder_candidates:
                    r_symbol = symbols.get(r_name, z3.Int(r_name))
                    branches.extend(
                        self._quotient_remainder_candidates(
                            dividend,
                            divisor,
                            quotient_symbol,
                            r_symbol,
                            "{}-qr".format(r_name),
                        )
                    )
                # Paired remainder (e.g. q = (a+b) div y style counters).
                for first_name in remainder_candidates:
                    first_symbol = symbols.get(
                        first_name, z3.Int(first_name)
                    )
                    for second_name in remainder_candidates:
                        if second_name <= first_name:
                            continue
                        second_symbol = symbols.get(
                            second_name, z3.Int(second_name)
                        )
                        branches.append(
                            self._qr_branch(
                                dividend,
                                divisor,
                                quotient_symbol,
                                z3.And(
                                    first_symbol >= 0,
                                    first_symbol <= divisor - 1,
                                ),
                                dividend
                                == divisor * quotient_symbol
                                + first_symbol
                                + second_symbol,
                                "typed-divmod-pair-remainder",
                                2,
                                (
                                    "{}+{}".format(
                                        first_name, second_name
                                    ),
                                ),
                            )
                        )
                # No remainder variable: two-sided bound on the quotient.
                branches.append(
                    self._qr_branch(
                        dividend,
                        divisor,
                        quotient_symbol,
                        z3.BoolVal(True),
                        z3.And(
                            divisor * quotient_symbol <= dividend,
                            dividend
                            <= divisor * (quotient_symbol + 1) - 1,
                        ),
                        "typed-divmod-two-sided-bound",
                        2,
                        (),
                    )
                )
        return branches

    @staticmethod
    def _collect_divmod(post):
        """Yield (target, op, dividend, divisor) for div/mod equalities in post.

        ``target`` is the variable name equated to a ``div``/``mod`` term;
        ``dividend`` and ``divisor`` are the raw z3 sub-expressions.
        """
        from SparCE.ada_engine import AdaSparCEEngine

        results = []

        def visit(expression):
            if z3.is_and(expression):
                for child in expression.children():
                    visit(child)
                return
            if not z3.is_eq(expression):
                return
            left, right = expression.children()
            op = AdaSparCEEngine._z3_divmod_op(right)
            sub = right
            other = left
            if op is None:
                op = AdaSparCEEngine._z3_divmod_op(left)
                sub = left
                other = right
            if op is None:
                return
            sub_children = sub.children()
            if len(sub_children) != 2:
                return
            dividend, divisor = sub_children
            target = None
            if (
                z3.is_const(other)
                and other.num_args() == 0
                and not z3.is_int_value(other)
            ):
                target = str(other)
            if target is not None:
                results.append((target, op, dividend, divisor))

        visit(post)
        return results

    @staticmethod
    def _z3_divmod_op(expression):
        kind = expression.decl().kind()
        if kind == z3.Z3_OP_MOD:
            return "mod"
        if kind in (z3.Z3_OP_DIV, z3.Z3_OP_IDIV):
            return "div"
        return None

    def _qr_branch(
        self, dividend, divisor, quotient, bounds, relation, mechanism, clauses, monomials
    ):
        formula = z3.simplify(z3.And(bounds, relation))
        return CandidateBranch(
            formula,
            152.0,
            mechanism,
            self._total_degree(formula),
            clauses,
            tuple(monomials),
        )

    def _quotient_remainder_candidates(self, dividend, divisor, quotient, remainder, tag):
        candidates = []
        exact = (
            dividend == divisor * quotient + remainder
        )
        bounds = z3.And(
            remainder >= 0,
            remainder <= divisor - 1,
        )
        candidates.append(
            self._qr_branch(
                dividend, divisor, quotient, bounds, exact,
                "typed-divmod-euclidean", 3, (tag,),
            )
        )
        weak = dividend >= divisor * quotient + remainder
        candidates.append(
            self._qr_branch(
                dividend, divisor, quotient, bounds, weak,
                "typed-divmod-weak", 3, (tag,),
            )
        )
        return candidates
