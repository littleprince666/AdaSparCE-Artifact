"""Controlled Q0 generation and offline combinator replay; no production edits.

The Clause2Inv arm executes unmodified author function/class ASTs. Only its
LLM material source and checker transport are replaced by shared adapters.
This experiment isolates composition; it is not a replacement Full runner.
"""
from __future__ import annotations

import ast
from collections import deque
from contextlib import contextmanager, redirect_stdout
from dataclasses import asdict
from collections import Counter
import hashlib
import io
import json
from pathlib import Path
import random
import re
import signal
import sys
import time
from types import SimpleNamespace
from unittest import mock

import z3

from SMT_Solver.SMT_verifier import CheckFailureType, CheckResult, SMT_verifier, expr_degree
from SparCE.feedback.clause_bank import UnifiedClauseBank
from SparCE.feedback.clause_composer import ProofGuidedClauseComposer
from SparCE.symbolic.candidate import CandidateBranch
from SparCE.verification.proof_obligations import original_queries

ROOT = Path(__file__).resolve().parents[2]
AUTHOR = ROOT/'baseline/Clause2Inv-main/combinator/checker.py'
VARIANTS = ('ada_c', 'clause2inv', 'enumeration', 'no_composition')
AUTHOR_NAMES = (
    'CounterExample', 'ReplayMem', 'CEHolder', 'get_z3_ice',
    'check_and_add_ce', 'expr_split', 'exprList_update', 'exprList_delete',
    'combine_check', 'boogie_result',
)
AUTHOR_CE_POLICY = dict(
    missing_state_values='Int=1; Real=1; Bool=True (typed numeric-one completion)',
    evaluation='Exact original AST substitution and simplification only; no SAT/existential completion',
    nonconcrete_or_invalid='False for author ICE filtering; counted separately, never a proof',
    arithmetic_boundary='SMT Int/Real/div/mod/Boolean semantics, not native Python eval or floating-point division',
    author_reference='baseline/Clause2Inv-main/combinator/c_inv_checker.py:inv_checker',
)


def digest(data):
    return hashlib.sha256(data if isinstance(data, bytes) else data.encode()).hexdigest()


def sha(path):
    return digest(Path(path).read_bytes())


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


class ReplayStop(Exception):
    """Finite pool, checker-call allowance, or shared wall budget exhausted."""


@contextmanager
def wall_budget(seconds):
    previous = signal.getsignal(signal.SIGALRM)
    def stop(signum, frame):
        raise ReplayStop('wall-budget-exhausted')
    signal.signal(signal.SIGALRM, stop)
    signal.setitimer(signal.ITIMER_REAL, max(0.001, seconds))
    try:
        yield
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, previous)


def symbols_from_vc(path):
    text = Path(path).read_text()
    interface = re.search(r'\(\s*define-fun\s+inv-f\s*\((.*?)\)\s*Bool', text, re.S)
    if interface is None:
        raise ValueError('missing-inv-f-interface')
    constructors = {'Int': z3.Int, 'Real': z3.Real, 'Bool': z3.Bool}
    pairs = re.findall(r'\(\s*([^\s()]+)\s+(Int|Real|Bool)\s*\)', interface.group(1))
    if not pairs or len({n for n, _ in pairs}) != len(pairs):
        raise ValueError('unsupported-or-duplicate-state-interface')
    return {name: constructors[sort](name) for name, sort in pairs}


def parse_formula(sexpr, symbols):
    parsed = z3.parse_smt2_string('(assert ' + sexpr + ')', decls=symbols)
    if len(parsed) != 1 or not z3.is_bool(parsed[0]):
        raise ValueError('expected-one-Boolean-formula')
    return parsed[0]


def ast_size(expression):
    return 1 + sum(ast_size(c) for c in expression.children())


class CPresentationUnsupported(ValueError):
    """Keep the complete SMT leaf when an AST has no supported C spelling."""


def c_style_presentation(formula):
    """Fully parenthesized C-style text; the registry retains the exact AST.

    This is a presentation transport, never a conversion to machine-C numeric
    semantics. In particular, '/' and '%' retain the original SMT operation
    and sorts in metadata. Unsupported ASTs fall back as complete SMT leaves.
    """
    numeric_tags=[]
    rewrites=set()
    binary={z3.Z3_OP_ADD:'+', z3.Z3_OP_SUB:'-', z3.Z3_OP_MUL:'*',
            z3.Z3_OP_DIV:'/', z3.Z3_OP_IDIV:'/', z3.Z3_OP_MOD:'%',
            z3.Z3_OP_EQ:'==', z3.Z3_OP_LE:'<=', z3.Z3_OP_GE:'>=',
            z3.Z3_OP_LT:'<', z3.Z3_OP_GT:'>',
            z3.Z3_OP_AND:'&&', z3.Z3_OP_OR:'||'}

    def visit(node):
        if z3.is_true(node):
            return 'true'
        if z3.is_false(node):
            return 'false'
        if z3.is_int_value(node):
            return str(node.as_long())
        if z3.is_rational_value(node):
            numerator,denominator=node.numerator_as_long(),node.denominator_as_long()
            if denominator==1:
                return str(numerator)+'.0'
            rewrites.add('exact-Real-rational-literal-as-Real-division')
            return f'( {numerator}.0 / {denominator}.0 )'
        if z3.is_const(node) and node.decl().kind()==z3.Z3_OP_UNINTERPRETED:
            name=str(node.decl().name())
            if node.sort().kind() not in (z3.Z3_INT_SORT,z3.Z3_REAL_SORT,z3.Z3_BOOL_SORT):
                raise CPresentationUnsupported('unsupported-state-sort:'+str(node.sort()))
            if not re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*',name):
                raise CPresentationUnsupported('non-C-identifier:'+name)
            return name
        if not z3.is_app(node):
            raise CPresentationUnsupported('non-application-AST')
        kind=node.decl().kind()
        if kind in binary:
            children=[visit(c) for c in node.children()]
            if len(children)<2:
                raise CPresentationUnsupported('unsupported-operator-arity:'+str(node.decl()))
            return '( '+(' '+binary[kind]+' ').join(children)+' )'
        if kind==z3.Z3_OP_UMINUS and node.num_args()==1:
            return '( - '+visit(node.arg(0))+' )'
        if kind==z3.Z3_OP_NOT and node.num_args()==1:
            return '( ! '+visit(node.arg(0))+' )'
        if kind==z3.Z3_OP_ITE and node.num_args()==3:
            return '( '+visit(node.arg(0))+' ? '+visit(node.arg(1))+' : '+visit(node.arg(2))+' )'
        if kind==z3.Z3_OP_IMPLIES and node.num_args()==2:
            rewrites.add('implication-as-not-or')
            return '( ( ! '+visit(node.arg(0))+' ) || '+visit(node.arg(1))+' )'
        if kind in (z3.Z3_OP_DISTINCT,z3.Z3_OP_XOR) and node.num_args()==2:
            if kind==z3.Z3_OP_XOR:
                rewrites.add('Boolean-xor-as-inequality')
            return '( '+visit(node.arg(0))+' != '+visit(node.arg(1))+' )'
        if kind==z3.Z3_OP_POWER and node.num_args()==2:
            exponent=node.arg(1)
            if z3.is_rational_value(exponent) and exponent.denominator_as_long()==1:
                count=exponent.numerator_as_long()
                if 0<=count<=16:
                    rewrites.add('nonnegative-integer-power-as-products')
                    if count==0:
                        return '1.0' if node.sort().kind()==z3.Z3_REAL_SORT else '1'
                    factor=visit(node.arg(0))
                    return '( '+' * '.join([factor]*count)+' )'
        raise CPresentationUnsupported('unsupported-AST:'+str(node.decl()))

    # Collect tags independently of presentation success, including operations
    # after an unsupported subtree in a complete SMT fallback leaf.
    pending=[formula]
    while pending:
        node=pending.pop()
        if z3.is_app(node) and node.decl().kind() in (z3.Z3_OP_DIV,z3.Z3_OP_IDIV,z3.Z3_OP_MOD):
            kind=node.decl().kind()
            numeric_tags.append(dict(operation={z3.Z3_OP_DIV:'Real-div',
                z3.Z3_OP_IDIV:'Int-div',z3.Z3_OP_MOD:'SMT-Int-mod'}[kind],
                result_sort=str(node.sort()),argument_sorts=[str(c.sort()) for c in node.children()],
                ast_sha256=digest(node.sexpr())))
        pending.extend(node.children())
    try:
        text=visit(formula)
        mode,reason='c-infix',None
    except CPresentationUnsupported as exc:
        text,mode,reason=formula.sexpr(),'smt-prefix-fallback',str(exc)
    return dict(text=text,mode=mode,fallback_reason=reason,formula_sort=str(formula.sort()),
                numeric_semantics=numeric_tags,presentation_rewrites=sorted(rewrites),
                formula_sha256=digest(formula.sexpr()),
                interpretation='Exact original AST; C-style text does not select machine-C arithmetic')


def frozen_engine(config, task, dataset):
    """Use the production CLI/config adapter, stopping before engine.run()."""
    import run_sparse
    from SparCE.ada_engine import AdaSparCEEngine
    from tools.run_experiment import command_for
    class Captured(BaseException):
        def __init__(self, engine):
            self.engine = engine
    def capture(engine, *args):
        raise Captured(engine)
    command = command_for(task, Path(dataset), config, Path('/dev/null'), 'adasparce', seed=0)
    with mock.patch.object(sys, 'argv', command[1:]), mock.patch.object(AdaSparCEEngine, 'run', capture):
        try:
            run_sparse.main()
        except Captured as captured:
            return captured.engine
    raise AssertionError('engine-constructor-was-not-captured')


def generate_pool(task, dataset, config, generation_budget=30):
    """Generate once without final checks, CE feedback, C, S, or fallback.

    Preserve complete G formulas AND expose their immediate Boolean children
    identically to every replay arm. No successful replay formula enters Q0.
    """
    from pycparser import parse_file
    from SparCE.generation.program_analyzer import ProgramAnalyzer
    from SparCE.search.state import _RunState
    from SparCE.symbolic.variables import base_variables
    started = time.perf_counter()
    c_path = Path(dataset)/task['relative_path']/'normalized.c'
    vc_path = Path(dataset)/task['relative_path']/'task.c_smt'
    result = dict(schema='adasparce.shared-q0.v1', id=task['id'],
                  c_path=str(c_path.resolve()), vc_path=str(vc_path.resolve()),
                  c_sha256=sha(c_path), vc_sha256=sha(vc_path), generation_seed=0,
                  generation_budget_seconds=generation_budget, candidates=[])
    try:
        with wall_budget(generation_budget):
            engine = frozen_engine(config, task, dataset)
            engine._task_started = started
            engine._task_wall_deadline = started + generation_budget
            engine._reset_prefilter_task()
            variables = base_variables(engine._variables(str(c_path), str(vc_path)))
            analyzer = ProgramAnalyzer(variables, collect_branch_transitions=True)
            analyzer.visit(parse_file(str(c_path), use_cpp=True))
            if analyzer.postcondition is None:
                raise ValueError('program-has-no-assert')
            if analyzer.needs_smt_fallback():
                analyzer.fill_from_smt(str(vc_path))
            base = CandidateBranch(analyzer.postcondition, 130, 'postcondition-seed',
                                   engine._total_degree(analyzer.postcondition), 1)
            state = _RunState(task['id'], str(c_path), str(vc_path), started,
                              analyzer, None, None, variables, base)
            state.degree_cap = max(engine.config.max_degree, engine.config.degree_escalation_cap)
            vc = engine._vc_branches(str(vc_path), analyzer, apply_limit=True)
            engine._build_branch_pools(state)
            branches = (vc + state.all_branches + state.reserve_branches
                        + engine._coverage_branches(analyzer))
            unique = {}
            for branch in branches:
                formula = z3.simplify(branch.formula)
                forms = [(formula, False)]
                if z3.is_and(formula) or z3.is_or(formula):
                    forms += [(child, True) for child in formula.children()]
                for item, component in forms:
                    item = z3.simplify(item)
                    if z3.is_true(item) or z3.is_false(item):
                        continue
                    key = item.sexpr()
                    provenance = branch.mechanism + (':shared-component' if component else '')
                    if key in unique:
                        unique[key]['sources'].append(provenance)
                        continue
                    unique[key] = dict(sexpr=key, sources=[provenance],
                        mechanism=provenance, score=float(branch.score) - int(component),
                        degree=int(expr_degree(item)), clauses=1 if component else branch.clauses,
                        monomials=[str(m) for m in branch.monomials], ast_size=ast_size(item))
            candidates = sorted(unique.values(), key=lambda r: (
                2*r['degree']+r['clauses'], -r['score'], r['mechanism'], r['sexpr']))
            # Round-trip against the authoritative state interface before freezing.
            symbols = symbols_from_vc(vc_path)
            presentation_branches=[]
            for index, row in enumerate(candidates):
                parsed=parse_formula(row['sexpr'], symbols)
                row['index'] = index
                row['formula_sha256'] = digest(row['sexpr'])
                presentation_branches.append(CandidateBranch(parsed,row['score'],row['mechanism'],
                    row['degree'],row['clauses'],tuple(row['monomials'])))
            registry=FormulaRegistry(presentation_branches)
            for row,presentation in zip(candidates,registry.records):
                row['author_transport']=presentation
            result.update(status='prepared', candidates=candidates,
                          author_transport_summary=registry.summary(),
                          resolved_engine_config=asdict(engine.config))
    except (ReplayStop, ValueError, z3.Z3Exception, OSError) as exc:
        result.update(status='generation-failed', reason=type(exc).__name__+':'+str(exc))
    result['generation_seconds'] = time.perf_counter() - started
    result['candidate_count'] = len(result['candidates'])
    result['candidate_content_sha256'] = digest(json.dumps(
        result['candidates'], ensure_ascii=False, sort_keys=True, separators=(',', ':')))
    return result


class FormulaRegistry:
    """Lossless bridge for author C-style expressions and original Q0 ASTs.

    Leaves are full shared formulas, not opaque IDs: the author's string-length
    tie-break and substring tests still operate on actual formula text. Parsing
    adds no new formulas, rewrites, or ranking policy.
    """
    def __init__(self, branches, representation='c-infix'):
        if representation not in ('c-infix','smt-prefix'):
            raise ValueError('unsupported-author-representation')
        self.representation=representation
        self.records=[c_style_presentation(b.formula) for b in branches]
        if representation=='smt-prefix':
            for branch,record in zip(branches,self.records):
                record.update(text=branch.formula.sexpr(),mode='smt-prefix-sensitivity',
                              fallback_reason=None,presentation_rewrites=[])
        # No text can silently alias a different AST. Both colliding leaves
        # receive complete original SMT spellings, never opaque identifiers.
        by_text={}
        for branch,record in zip(branches,self.records):
            by_text.setdefault(record['text'],set()).add(branch.formula.sexpr())
        for branch,record in zip(branches,self.records):
            if len(by_text[record['text']])>1:
                record.update(text=branch.formula.sexpr(),mode='smt-prefix-fallback',
                              fallback_reason='C-style-text-collision-between-distinct-ASTs')
        self.leaves={}
        self.text_by_ast={}
        for branch,record in zip(branches,self.records):
            text=record['text']
            if text in self.leaves and self.leaves[text].sexpr()!=branch.formula.sexpr():
                raise ValueError('unresolved-formula-transport-collision')
            self.leaves[text]=branch.formula
            self.text_by_ast[branch.formula.sexpr()]=text
        self.cache = dict(self.leaves)

    def text_for_formula(self,formula):
        return self.text_by_ast[formula.sexpr()]

    def summary(self):
        return dict(representation=self.representation,formulas=len(self.records),
            modes=dict(Counter(r['mode'] for r in self.records)),
            fallback_count=sum(r['mode']=='smt-prefix-fallback' for r in self.records),
            fallback_reasons=dict(Counter(r['fallback_reason'] for r in self.records if r['fallback_reason'])),
            division_operations=dict(Counter(tag['operation'] for r in self.records for tag in r['numeric_semantics'])),
            presentation_rewrites=dict(Counter(tag for r in self.records for tag in r['presentation_rewrites'])))

    def parse(self, text):
        text = str(text).strip()
        if text in self.cache:
            return self.cache[text]
        original = text
        if text.startswith('( ') and text.endswith(' )'):
            text = text[2:-2].strip()
        depth = 0
        for index, char in enumerate(text):
            if char == '(':
                depth += 1
            elif char == ')':
                depth -= 1
            elif depth == 0 and text[index:index+2] in ('&&', '||'):
                left, right = self.parse(text[:index]), self.parse(text[index+2:])
                formula = z3.And(left, right) if text[index:index+2] == '&&' else z3.Or(left, right)
                self.cache[original] = formula
                return formula
        raise ValueError('unrecognized-author-composition:' + original[:120])


class SharedChecker:
    """Plain original VCs, one candidate deadline, identical for all arms."""
    def __init__(self, vc_path, trace, query_dir, deadline, seed=0,
                 candidate_seconds=4, max_checks=256):
        self.vc_path, self.trace, self.query_dir = Path(vc_path), Path(trace), Path(query_dir)
        self.deadline, self.seed = deadline, seed
        self.candidate_seconds, self.max_checks = candidate_seconds, max_checks
        self.started = time.perf_counter()
        self.cache, self.checks, self.completed, self.solver_seconds = {}, 0, 0, 0.0
        self.last = None
        self.success = None
        self.query_dir.mkdir(parents=True, exist_ok=True)
        verifier = SMT_verifier()
        verifier.initTpl(str(vc_path))
        self.state_variables = verifier.state_variables

    def emit(self, event, **fields):
        with self.trace.open('a') as out:
            out.write(json.dumps(dict(event=event, **fields), ensure_ascii=False, default=str)+'\n')

    def ensure_budget(self):
        if time.perf_counter() >= self.deadline:
            raise ReplayStop('wall-budget-exhausted')
        if self.checks >= self.max_checks:
            raise ReplayStop('checker-call-allowance-exhausted')

    def check(self, formula, source='candidate'):
        self.ensure_budget()
        key = z3.simplify(formula).sexpr()
        if key in self.cache:
            self.emit('duplicate-candidate', formula_sha256=digest(key), source=source)
            return self.cache[key]
        self.checks += 1
        self.emit('candidate-start', attempt=self.checks, source=source,
                  formula_smtlib=formula.sexpr(), formula_sha256=digest(formula.sexpr()))
        started = time.perf_counter()
        stop = min(self.deadline, started+self.candidate_seconds)
        statuses, examples, vcs = [], [], []
        queries = original_queries(self.vc_path, formula)
        for index, (name, query) in enumerate(zip(('INIT','STEP','EXIT'), queries)):
            # A watchdog interrupt persists in its Z3 context until a later
            # check. Never let it cancel parsing/composition in the main
            # context. Each obligation owns exactly one solver/context.
            context = z3.Context()
            solver = z3.Solver(ctx=context)
            solver.add(query.translate(context))
            query_text = solver.to_smt2()
            query_hash = digest(query_text)
            query_path = self.query_dir/(query_hash+'.smt2')
            if not query_path.exists():
                query_path.write_text(query_text)
            remaining = stop-time.perf_counter()
            solver_started = time.perf_counter()
            if remaining <= 0:
                status, example, reason = z3.unknown, None, 'candidate-budget-exhausted'
            else:
                solver.set(timeout=max(1, int(remaining*1000)), random_seed=self.seed)
                status, interrupted = SMT_verifier._check_with_watchdog(solver, remaining)
                reason = solver.reason_unknown() if status == z3.unknown else None
                example = (SMT_verifier._extract_counterexample(solver.model(), index, self.state_variables)
                           if status == z3.sat else None)
                if example is not None:
                    def rehome(value):
                        if isinstance(value, dict):
                            return {key: rehome(item) for key, item in value.items()}
                        if isinstance(value, tuple):
                            return tuple(rehome(item) for item in value)
                        if isinstance(value, list):
                            return [rehome(item) for item in value]
                        return value.translate(z3.main_ctx()) if isinstance(value, z3.AstRef) else value
                    example = rehome(example)
            elapsed = time.perf_counter()-solver_started
            self.solver_seconds += elapsed
            statuses.append(status)
            examples.append(example)
            vcs.append(dict(vc=name, status=str(status), solver_time_seconds=elapsed,
                            query_sha256=query_hash, reason_unknown=reason))
        if all(status == z3.unsat for status in statuses):
            failure, example = CheckFailureType.SUCCESS, None
            self.success = formula
        else:
            first = next(i for i, status in enumerate(statuses) if status != z3.unsat)
            failure = (list(CheckFailureType)[first] if statuses[first] == z3.sat
                       else CheckFailureType.UNKNOWN)
            example = examples[first]
        result = CheckResult('success' if failure == CheckFailureType.SUCCESS else 'counterexample',
            failure, example, time.perf_counter()-started, 'shared-plain-original-z3',
            sum(len(str(q)) for q in queries), digest(key), ','.join(map(str,statuses)), tuple(vcs))
        full = dict(result=result, statuses=statuses, examples=examples, formula=formula)
        self.cache[key] = full
        self.completed += 1
        self.last = full
        self.emit('candidate-check', source=source, candidate_index=self.checks,
                  formula_smtlib=formula.sexpr(), formula_sha256=digest(formula.sexpr()),
                  failure_type=failure.value, counterexample=example,
                  checker_seconds=result.solver_time, vc_results=vcs)
        return full


def author_namespace(path, generator, adapter, seed):
    """Compile the author's exact ASTs, bypassing only import-time LLM setup."""
    source = Path(path).read_text()
    tree = ast.parse(source, filename=str(path))
    selected = [node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.ClassDef))
                and node.name in AUTHOR_NAMES]
    if {node.name for node in selected} != set(AUTHOR_NAMES):
        raise ValueError('author-API-changed')
    namespace = dict(random=random.Random(seed), z3=z3, generator=generator,
                     checker_module=adapter, ICE_KEYS=('T:','I:','F:'),
                     cmd_args=SimpleNamespace(input_vcs=str(adapter.checker.vc_path),
                                              replay_memsize=100, ce_batchsize=100),
                     exprList=[], exprStore=set(), expr_ans=None, expr_failed=set(),
                     tqdm=SimpleNamespace(write=lambda *args, **kwargs: None),
                     __name__='shared_pool_clause2inv_author')
    exec(compile(ast.Module(body=selected, type_ignores=[]), str(path), 'exec'), namespace)
    return namespace


def evaluate_author_state(formula, assignments):
    """Complete a concrete CE with the author's missing-variable default.

    The author uses Python eval with each formula variable initially set to 1.
    Our shared formula transport instead retains exact mathematical ASTs.  In
    particular Int division/modulo and exact Real values follow SMT semantics,
    not Python division or floating point.  A non-concrete/invalid evaluation
    is False for this heuristic filter; no solver or existential query runs.
    """
    defaulted=[]
    details=dict(defaulted_variables=defaulted,outcome=None)
    try:
        assignment=dict(assignments)
        substitutions=[]
        seen=set()
        pending=[formula]
        while pending:
            node=pending.pop()
            if node.get_id() in seen:
                continue
            seen.add(node.get_id())
            if z3.is_const(node) and node.decl().kind()==z3.Z3_OP_UNINTERPRETED:
                name=str(node)
                missing=name not in assignment
                value=1 if missing else assignment[name]
                kind=node.sort().kind()
                if kind==z3.Z3_BOOL_SORT:
                    if isinstance(value,z3.ExprRef):
                        if not (z3.is_true(value) or z3.is_false(value)):
                            raise ValueError('nonconcrete-Boolean-assignment')
                        concrete=z3.BoolVal(z3.is_true(value),ctx=formula.ctx)
                    elif value in (True,1,'true','True','1'):
                        concrete=z3.BoolVal(True,ctx=formula.ctx)
                    elif value in (False,0,'false','False','0'):
                        concrete=z3.BoolVal(False,ctx=formula.ctx)
                    else:
                        raise ValueError('invalid-Boolean-assignment')
                elif kind==z3.Z3_INT_SORT:
                    if isinstance(value,z3.ExprRef):
                        if not z3.is_int_value(value):
                            raise ValueError('nonconcrete-Int-assignment')
                        value=value.as_long()
                    if isinstance(value,float) and (not value.is_integer()):
                        raise ValueError('nonintegral-Int-assignment')
                    concrete=z3.IntVal(int(value),ctx=formula.ctx)
                elif kind==z3.Z3_REAL_SORT:
                    if isinstance(value,z3.ExprRef):
                        if z3.is_int_value(value):
                            concrete=z3.RealVal(value.as_long(),ctx=formula.ctx)
                        elif z3.is_rational_value(value) or z3.is_algebraic_value(value):
                            concrete=value if value.ctx==formula.ctx else value.translate(formula.ctx)
                        else:
                            raise ValueError('nonconcrete-Real-assignment')
                    else:
                        concrete=z3.RealVal(str(value),ctx=formula.ctx)
                else:
                    raise ValueError('unsupported-state-sort:'+str(node.sort()))
                substitutions.append((node,concrete))
                if missing:
                    defaulted.append(dict(name=name,sort=str(node.sort()),value=str(concrete)))
            pending.extend(node.children())
        reduced=z3.simplify(z3.substitute(formula,*substitutions))
        if z3.is_true(reduced):
            details['outcome']='true'
            return True,details
        if z3.is_false(reduced):
            details['outcome']='false'
            return False,details
        details['outcome']='nonconcrete'
    except (TypeError,ValueError,OverflowError,z3.Z3Exception) as exc:
        details.update(outcome='invalid',reason=type(exc).__name__+':'+str(exc))
    return False,details


class SharedAuthorAdapter:
    def __init__(self, checker, registry):
        self.checker, self.registry = checker, registry
        self.ce_evaluation_counts=Counter()
        self.ce_defaulted_variables=Counter()
        self.ce_evaluation_reasons=Counter()
        self.ce_evaluation_seconds=0.0

    def inv_solver(self, unused_path, expression):
        full = self.checker.check(self.registry.parse(expression), 'clause2inv-author')
        return [None if status == z3.unsat else example if status == z3.sat else 'EXCEPT'
                for status, example in zip(full['statuses'], full['examples'])]

    def inv_checker(self, unused_path, expression, assignments):
        self.checker.ensure_budget()
        started=time.perf_counter()
        formula = self.registry.parse(expression)
        value,details=evaluate_author_state(formula,assignments)
        self.ce_evaluation_seconds+=time.perf_counter()-started
        self.ce_evaluation_counts['calls']+=1
        self.ce_evaluation_counts[details['outcome']]+=1
        if details['defaulted_variables']:
            self.ce_evaluation_counts['with_defaulted_variables']+=1
        self.ce_defaulted_variables.update(item['name'] for item in details['defaulted_variables'])
        if details.get('reason'):
            self.ce_evaluation_reasons[details['reason']]+=1
        return value

    def ce_audit(self):
        return dict(policy=AUTHOR_CE_POLICY,
            counts=dict(self.ce_evaluation_counts),seconds=self.ce_evaluation_seconds,
            defaulted_variables=dict(self.ce_defaulted_variables),
            invalid_reasons=dict(self.ce_evaluation_reasons),solver_calls=0)


class FrozenGenerator:
    def __init__(self, formulas):
        self.formulas, self.offered = formulas, False
        self.existing_clauses, self.attention = set(), None

    def generate(self):
        if self.offered:
            raise ReplayStop('fixed-material-stream-exhausted')
        self.offered = True
        return list(self.formulas)


def replay_author(branches, checker, author_path=AUTHOR, representation='c-infix'):
    registry = FormulaRegistry(branches,representation)
    generator = FrozenGenerator(list(registry.leaves))
    adapter = SharedAuthorAdapter(checker, registry)
    namespace = author_namespace(author_path, generator, adapter, checker.seed)
    checker.emit('author-source', path=str(author_path), sha256=sha(author_path),
                 exact_ast_names=list(AUTHOR_NAMES), replay_memsize=100, ce_batchsize=100,
                 transport=f'Complete {representation} leaves plus author AND/OR; exact original AST registry',
                 transport_summary=registry.summary(),transport_mappings=registry.records,
                 ce_filter_policy=AUTHOR_CE_POLICY,
                 original_length_and_substring_rules_retained=True)
    # Suppress only the author's potentially huge diagnostic print(set(Q0)).
    try:
        with redirect_stdout(io.StringIO()):
            namespace['boogie_result']()
    finally:
        # Aggregate into the existing replay-end/result record.  Per-CE file
        # I/O would add work absent from the author's heuristic filter.
        checker.author_ce_evaluation=adapter.ce_audit()


def replay_ada(branches, checker):
    bank = UnifiedClauseBank(max_trials=64)
    composer = ProofGuidedClauseComposer(max_bank_size=64, max_ast_size=180,
                                        max_clauses=3, max_total_proposals=32)
    for branch in branches:
        composer.ingest(branch.formula, score=branch.score, mechanism=branch.mechanism,
                        degree=branch.degree, clauses=branch.clauses,
                        monomials=branch.monomials, split_top_level=False)
    direct, conjunctions, local = deque(branches), deque(), deque()
    queues = (direct, conjunctions, local)
    while any(queues):
        for queue in queues:  # fixed round-robin, no S or learned ranking
            for _ in range(4):
                if not queue:
                    break
                branch = queue.popleft()
                full = checker.check(branch.formula, branch.mechanism)
                result = full['result']
                if checker.success is not None:
                    return
                if result.failure_type in (CheckFailureType.STEP, CheckFailureType.EXIT):
                    for formula in bank.note_result(branch, result):
                        conjunctions.append(CandidateBranch(formula, branch.score,
                            'partial-lemma-conjunction', branch.degree, branch.clauses))
                composer.ingest(branch.formula, score=branch.score, mechanism=branch.mechanism,
                    degree=branch.degree, clauses=branch.clauses, monomials=branch.monomials,
                    split_top_level=False)
                composer.observe(branch.formula, result.failure_type)
                for proposal in composer.propose(branch.formula, score=branch.score,
                    mechanism=branch.mechanism, degree=branch.degree, clauses=branch.clauses,
                    monomials=branch.monomials, failure_type=result.failure_type,
                    counterexample=result.counterexample, max_results=4):
                    local.append(CandidateBranch(proposal.formula, proposal.score,
                        proposal.mechanism, proposal.degree, proposal.clauses, proposal.monomials))
    raise ReplayStop('fixed-material-search-exhausted')


def replay_enumeration(branches, checker):
    # Breadth-first closure over Q0 with explicit syntactic limits, no CE ranking.
    atoms = [b.formula for b in branches]
    pending = deque((b.formula, 1, b.mechanism) for b in branches)
    emitted = {z3.simplify(f).sexpr() for f in atoms}
    while pending:
        formula, leaves, source = pending.popleft()
        checker.check(formula, source)
        if checker.success is not None:
            return
        if leaves >= 3:
            continue
        for partner in atoms:
            for operator in (z3.And, z3.Or):
                checker.ensure_budget()
                combined = z3.simplify(operator(formula, partner))
                key = combined.sexpr()
                if key in emitted or ast_size(combined)>180:
                    continue
                emitted.add(key)
                pending.append((combined, leaves+1, 'bounded-uniform-and-or'))
    raise ReplayStop('bounded-enumeration-exhausted')


def replay_pool(pool, variant, seed, trace, query_dir, budget=30,
                candidate_seconds=4, max_checks=256, author_path=AUTHOR,
                author_representation='c-infix'):
    if variant not in VARIANTS:
        raise ValueError('unknown-variant')
    started = time.perf_counter()
    generation = float(pool['generation_seconds'])
    trace = Path(trace)
    trace.parent.mkdir(parents=True, exist_ok=True)
    trace.write_text('')
    result = dict(status='failed', invariant=None, invariant_smtlib=None,
        generation_seconds=generation, replay_seconds=0, total_time=generation,
        checker_calls=0, attempted_checker_calls=0, solver_seconds=0, pool_sha256=pool['candidate_content_sha256'],
        candidate_count=pool['candidate_count'], author_representation=author_representation,reason=None)
    if pool['status']!='prepared' or generation>=budget:
        result['reason']='shared-generation-failed-or-exhausted-budget'
        trace.write_text(json.dumps(dict(event='shared-generation-failed',**result))+'\n')
        return result
    checker = None
    try:
        with wall_budget(budget-generation):
            symbols = symbols_from_vc(pool['vc_path'])
            branches = [CandidateBranch(parse_formula(r['sexpr'], symbols), r['score'],
                r['mechanism'], r['degree'], r['clauses'], tuple(r['monomials']))
                for r in pool['candidates']]
            checker = SharedChecker(pool['vc_path'], trace, query_dir,
                started+budget-generation, seed, candidate_seconds, max_checks)
            checker.emit('replay-start', variant=variant, seed=seed,
                pool_sha256=pool['candidate_content_sha256'], generation_seconds=generation,
                budget_seconds=budget, candidate_seconds=candidate_seconds, max_checks=max_checks,
                scheduler=False, fallback=False, dynamic_ce_generation=False)
            if variant=='clause2inv':
                replay_author(branches, checker, author_path,author_representation)
            elif variant=='ada_c':
                replay_ada(branches, checker)
            elif variant=='enumeration':
                replay_enumeration(branches, checker)
            else:
                for branch in branches:
                    checker.check(branch.formula, branch.mechanism)
                    if checker.success is not None:
                        break
    except ReplayStop as exc:
        result['reason']=str(exc)
    except Exception as exc:
        result.update(status='error', reason=type(exc).__name__+':'+str(exc))
    result['replay_seconds']=time.perf_counter()-started
    result['total_time']=generation+result['replay_seconds']
    if checker is not None:
        result.update(checker_calls=checker.completed, attempted_checker_calls=checker.checks,
                      solver_seconds=checker.solver_seconds)
        if hasattr(checker,'author_ce_evaluation'):
            result['author_ce_evaluation']=checker.author_ce_evaluation
        if checker.success is not None:
            result.update(status='solved', invariant=str(checker.success),
                          invariant_smtlib=checker.success.sexpr(), reason='all-original-vcs-unsat')
        elif result['reason'] is None:
            result['reason']='fixed-material-search-exhausted'
        checker.emit('replay-end', **result)
    return result
